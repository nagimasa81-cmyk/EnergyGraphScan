const $=id=>document.getElementById(id); const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
let sourceImage=null,roi=null,roiManual=false,currentResult=null,cameraStream=null,cameraBusy=false;
const els={stage:$('stage'),roi:$('roi'),status:$('status'),mode:$('modeSelect'),result:$('resultCard'),camera:$('cameraInput'),photo:$('photoInput'),cameraBtn:$('cameraBtn'),cameraModal:$('cameraModal'),cameraVideo:$('cameraVideo'),cameraState:$('cameraState'),cameraShutter:$('cameraShutter'),cameraGuide:document.querySelector('.camera-guide-frame')};
$('resetBtn').onclick=reset;
$('autoDetectBtn').onclick=()=>{if(sourceImage){redrawSource();const found=detectGraph();if(found){roi=found;roiManual=false;els.roi.classList.remove('manual');renderROI();setStatus('Auto ROI updated.');}else{setStatus('Auto ROI failed. Use ROI adjustment to select Energy per Band only.');}}};
$('manualBtn').onclick=()=>{if(!roi)return;roiManual=true;els.roi.classList.remove('hidden');els.roi.classList.add('manual');setStatus('ROI adjustment enabled. Drag inside to move; drag a corner to resize.');};
$('analyzeBtn').onclick=analyze;
els.photo.addEventListener('change',e=>{const f=e.target.files?.[0];if(f){loadFile(f);e.target.value='';}});
// Standard-camera input is fallback only. It must never appear as a normal file button.
els.camera.addEventListener('change',e=>{const f=e.target.files?.[0];if(f){loadFile(f);e.target.value='';}});
els.cameraBtn.addEventListener('click',()=>openCamera());
$('cameraCancel').addEventListener('click',closeCamera);
$('cameraRetry').addEventListener('click',()=>startCameraStream());
els.cameraShutter.addEventListener('click',captureCameraFrame);

function cameraMessage(text,error=false){if(els.cameraState){els.cameraState.textContent=text;els.cameraState.classList.toggle('error',!!error)}}
async function openCamera(){
  if(cameraBusy)return;
  // Show the overlay first so every tap has immediate visible feedback.
  els.cameraModal.classList.remove('hidden');els.cameraModal.setAttribute('aria-hidden','false');
  document.body.classList.add('camera-open');
  cameraMessage('カメラ準備中…');
  els.cameraShutter.disabled=true;
  await startCameraStream();
}
async function startCameraStream(){
  if(cameraBusy)return; cameraBusy=true;
  try{
    stopCameraStream();
    if(!window.isSecureContext)throw new Error('Camera requires HTTPS');
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera API unavailable');
    let stream;
    try{
      stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
    }catch(firstErr){
      // Some iOS/PWA builds reject detailed constraints. Retry with the
      // simplest video request before declaring failure.
      stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});
    }
    cameraStream=stream; els.cameraVideo.srcObject=stream;
    await new Promise((resolve,reject)=>{
      const done=()=>{cleanup();resolve()}; const fail=()=>{cleanup();reject(new Error('Video could not start'))};
      const cleanup=()=>{els.cameraVideo.removeEventListener('loadedmetadata',done);els.cameraVideo.removeEventListener('error',fail)};
      if(els.cameraVideo.readyState>=1)return resolve();
      els.cameraVideo.addEventListener('loadedmetadata',done,{once:true});els.cameraVideo.addEventListener('error',fail,{once:true});
      setTimeout(()=>{cleanup();resolve()},2500);
    });
    await els.cameraVideo.play();
    cameraMessage('ガイド枠内に Energy per Band と Channel欄が入るように撮影してください');
    els.cameraShutter.disabled=false;
  }catch(e){
    console.error('camera start failed',e);
    cameraMessage('アプリ内カメラを開始できません。Safari/ホーム画面アプリのカメラ許可を確認して「再試行」してください。',true);
    els.cameraShutter.disabled=true;
  }finally{cameraBusy=false}
}
function stopCameraStream(){if(cameraStream){for(const t of cameraStream.getTracks())try{t.stop()}catch(_){}cameraStream=null}els.cameraVideo.srcObject=null}
function closeCamera(){stopCameraStream();els.cameraModal.classList.add('hidden');els.cameraModal.setAttribute('aria-hidden','true');document.body.classList.remove('camera-open');cameraBusy=false}
function cameraGuideSourceRect(){
  const v=els.cameraVideo,g=els.cameraGuide;
  if(!v||!g||!v.videoWidth||!v.videoHeight)return null;
  const vr=v.getBoundingClientRect(),gr=g.getBoundingClientRect();
  if(vr.width<=0||vr.height<=0||gr.width<=0||gr.height<=0)return null;

  // <video> uses object-fit:cover. Convert the visible guide-frame rectangle
  // back to intrinsic camera pixels, including the portions cropped by cover.
  const scale=Math.max(vr.width/v.videoWidth,vr.height/v.videoHeight);
  const renderedW=v.videoWidth*scale,renderedH=v.videoHeight*scale;
  const cropX=(renderedW-vr.width)/2,cropY=(renderedH-vr.height)/2;

  let sx=(gr.left-vr.left+cropX)/scale;
  let sy=(gr.top-vr.top+cropY)/scale;
  let sw=gr.width/scale,sh=gr.height/scale;

  // Small inward margin prevents the yellow guide border itself from entering
  // the analysis image.
  const mx=sw*.012,my=sh*.025;
  sx+=mx;sy+=my;sw-=2*mx;sh-=2*my;

  sx=Math.max(0,Math.min(v.videoWidth-2,sx));
  sy=Math.max(0,Math.min(v.videoHeight-2,sy));
  sw=Math.max(2,Math.min(v.videoWidth-sx,sw));
  sh=Math.max(2,Math.min(v.videoHeight-sy,sh));
  return{sx,sy,sw,sh};
}
function captureCameraFrame(){
  const v=els.cameraVideo;
  if(!v.videoWidth||!v.videoHeight){cameraMessage('カメラ画像を取得できません。再試行してください。',true);return}
  const r=cameraGuideSourceRect();
  if(!r){cameraMessage('撮影枠の位置を取得できません。再試行してください。',true);return}

  els.cameraShutter.disabled=true;
  cameraMessage('撮影枠内だけを切り出しています…');

  // Analyze only the guide-frame crop.  This avoids decoding and scanning the
  // entire iPhone camera frame, which was the main post-capture freeze source.
  const maxOutW=1400;
  const scale=Math.min(1,maxOutW/r.sw);
  const outW=Math.max(2,Math.round(r.sw*scale));
  const outH=Math.max(2,Math.round(r.sh*scale));
  const c=document.createElement('canvas');
  c.width=outW;c.height=outH;
  const cctx=c.getContext('2d',{alpha:false});
  cctx.imageSmoothingEnabled=true;
  cctx.imageSmoothingQuality='high';
  cctx.drawImage(v,r.sx,r.sy,r.sw,r.sh,0,0,outW,outH);

  // Let iOS paint the status text before JPEG encoding starts.
  requestAnimationFrame(()=>setTimeout(()=>{
    c.toBlob(blob=>{
      if(!blob){
        els.cameraShutter.disabled=false;
        cameraMessage('撮影画像の切り出しに失敗しました。',true);
        return;
      }
      closeCamera();
      loadCapturedBlob(blob,true);
    },'image/jpeg',.90);
  },0));
}
function loadCapturedBlob(blob,guideCropped=false){
  // Do not route a captured frame back through <input type=file>. On iOS that
  // can lose the selected file when control returns from the camera/PWA.
  const url=URL.createObjectURL(blob),img=new Image();
  img.onload=()=>{
    URL.revokeObjectURL(url);
    useImage(img);
    if(guideCropped)setStatus('撮影枠内を切り出して読み込みました。');
  };
  img.onerror=()=>{URL.revokeObjectURL(url);setStatus('Could not read captured image.')};img.src=url;
}

function setStatus(s){els.status.textContent=s}
function redrawSource(){if(sourceImage)ctx.drawImage(sourceImage,0,0,canvas.width,canvas.height)}
function reset(){closeCamera();sourceImage=null;roi=null;currentResult=null;ctx.clearRect(0,0,canvas.width,canvas.height);els.stage.classList.add('empty');els.roi.classList.add('hidden');els.roi.classList.remove('manual');els.result.classList.add('hidden');$('placeholder').classList.remove('hidden');['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=true);els.camera.value='';els.photo.value='';setStatus('Ready')}
async function loadFile(file){setStatus('Loading image…');const url=URL.createObjectURL(file),img=new Image();img.onload=()=>{URL.revokeObjectURL(url);useImage(img)};img.onerror=()=>setStatus('Could not read image.');img.src=url}
function useImage(img){sourceImage=img;const maxW=1800,scale=Math.min(1,maxW/img.naturalWidth);canvas.width=Math.round(img.naturalWidth*scale);canvas.height=Math.round(img.naturalHeight*scale);redrawSource();els.stage.classList.remove('empty');$('placeholder').classList.add('hidden');const found=detectGraph();if(found){roi=found;roiManual=false;renderROI();['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=false);setStatus('Image loaded. Auto ROI detected.');analyze();}else{const w=Math.floor(canvas.width*.42),h=Math.floor(w/2.05);roi={x:Math.floor((canvas.width-w)/2),y:Math.floor(canvas.height*.15),w,h,manualSeed:true};roiManual=true;els.roi.classList.add('manual');renderROI();['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=false);setStatus('Auto ROI failed. Adjust ROI to Energy per Band, then Analyze.');}}
const lum=(d,i)=>(d[i]+d[i+1]+d[i+2])/3;
function isGreen(r,g,b){return g>42&&g>r*1.24&&g>b*1.12&&(g-Math.min(r,b))>18}
function rectStats(src,W,H,x0,y0,x1,y1,step=2){
  let n=0,dark=0,green=0,warm=0,color=0;
  for(let y=y0;y<y1;y+=step)for(let x=x0;x<x1;x+=step){const i=(y*W+x)*4,r=src[i],g=src[i+1],b=src[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b);n++;if((r+g+b)/3<92)dark++;if(isGreen(r,g,b))green++;const hsv=rgbToHsv(r,g,b);if(hsv.s>.32&&hsv.v>.38)color++;if(hsv.s>.38&&hsv.v>.42&&(hsv.h<58||hsv.h>345))warm++}
  return{dark:dark/Math.max(1,n),green:green/Math.max(1,n),color:color/Math.max(1,n),warm:warm/Math.max(1,n)}
}
function detectGraph(){
  const W=canvas.width,H=canvas.height,src=ctx.getImageData(0,0,W,H).data;
  const ds=Math.max(2,Math.ceil(Math.max(W,H)/820)),cands=[];
  const minW=Math.max(120,Math.floor(W*.14)),maxW=Math.floor(W*.62);
  const minH=Math.max(58,Math.floor(H*.045)),maxH=Math.floor(H*.30);
  function structureScore(x,y,w,h){
    const st=rectStats(src,W,H,x,y,x+w,y+h,ds);
    if(st.dark<.38||st.green<.004||st.color<.003)return null;
    const im=ctx.getImageData(x,y,w,h).data,row=new Uint32Array(h),col=new Uint32Array(w),traceSpans=[];
    const traceRows=new Uint32Array(h);
    for(let xx=0;xx<w;xx++){
      let ymin=h,ymax=-1,seen=0;
      for(let yy=0;yy<h;yy++){
        const i=(yy*w+xx)*4,r=im[i],g=im[i+1],b=im[i+2];
        if(isGreen(r,g,b)){row[yy]++;col[xx]++;continue}
        const q=rgbToHsv(r,g,b);
        // Energy-per-Band has a thin, horizontally continuous colored trace.
        if(q.v>.38&&q.s>.24){ymin=Math.min(ymin,yy);ymax=Math.max(ymax,yy);seen++;traceRows[yy]++}
      }
      if(seen>=1&&ymax>=ymin)traceSpans.push((ymax-ymin+1)/Math.max(1,h));
    }
    const rg=lineGroups(row,Math.max(6,w*.22)),cg=lineGroups(col,Math.max(5,h*.23));
    if(rg.length<2||cg.length<3)return null;
    const aspect=w/Math.max(1,h);
    if(aspect<1.35||aspect>3.35)return null;
    const aspectScore=Math.exp(-Math.pow((aspect-2.05)/.85,2)),area=(w*h)/(W*H),compact=Math.exp(-Math.pow((area-.040)/.052,2)),gridScore=Math.min(1,(rg.length+cg.length)/10);
    let thin=.15,concentration=.15;
    if(traceSpans.length>=Math.max(8,w*.06)){
      const med=EGSCore.median(traceSpans);
      thin=EGSCore.clamp((.50-med)/.42,0,1);
      const peak=Math.max(...traceRows),sum=traceRows.reduce((a,b)=>a+b,0);
      concentration=EGSCore.clamp((peak/Math.max(1,sum/h)-1)/8,0,1);
    }
    const gridSpanX=cg.length>=2?(cg.at(-1)-cg[0])/w:0,gridSpanY=rg.length>=2?(rg.at(-1)-rg[0])/h:0;
    const spanScore=EGSCore.clamp((Math.min(gridSpanX,.95)-.42)/.42,0,1)*.55+EGSCore.clamp((Math.min(gridSpanY,.95)-.28)/.50,0,1)*.45;
    // Thin-trace score strongly rejects Raw Data/Spectrum panels and their subregions.
    const score=1.35*st.dark+6.7*st.green+1.15*st.color+.18*st.warm+1.0*aspectScore+1.0*compact+1.25*gridScore+3.1*thin+1.1*concentration+1.25*spanScore;
    return{score,st,aspect,area,thin,concentration,spanScore,rg,cg}
  }
  for(let h=minH;h<=maxH;h=Math.round(h*1.16)+1)for(const asp of [1.45,1.65,1.85,2.05,2.25,2.5,2.8,3.1]){
    const w=Math.round(h*asp);if(w<minW||w>maxW)continue;
    const sx=Math.max(ds*3,Math.round(w*.075)),sy=Math.max(ds*3,Math.round(h*.09));
    for(let y=0;y+h<=H;y+=sy)for(let x=0;x+w<=W;x+=sx){const q=structureScore(x,y,w,h);if(q)cands.push({x,y,w,h,...q})}
  }
  if(cands.length){
    cands.sort((a,b)=>b.score-a.score);let best=null;
    for(const c of cands.slice(0,28)){
      const box={x:c.x,y:c.y,w:c.w,h:c.h},ins=plotInsets(box),g=EGSCore.geometry(box,ins),gw=g.x1-g.x0,gh=g.y1-g.y0;
      if(gw<c.w*.50||gh<c.h*.30)continue;
      const tightness=(gw*gh)/(c.w*c.h),refine=c.score+(ins.source==='major-grid'?2.2:0)+(tightness>.30&&tightness<.82?.7:0)+1.4*c.thin+.5*c.spanScore;
      if(!best||refine>best.refine)best={...c,refine}
    }
    if(best){
      const padX=Math.round(best.w*.045),padY=Math.round(best.h*.065),bx=Math.max(0,best.x-padX),by=Math.max(0,best.y-padY);
      return{x:bx,y:by,w:Math.min(W-bx,best.w+padX*2),h:Math.min(H-by,best.h+padY*2),confidence:EGSCore.clamp((best.thin*.45+best.spanScore*.25+.30),0,1)}
    }
  }
  // Unified contract v2: never invent a broad fallback ROI.
  return null;
}
function renderROI(){if(!roi)return;const r=canvas.getBoundingClientRect(),sx=r.width/canvas.width,sy=r.height/canvas.height;Object.assign(els.roi.style,{left:`${roi.x*sx}px`,top:`${roi.y*sy}px`,width:`${roi.w*sx}px`,height:`${roi.h*sy}px`});els.roi.classList.remove('hidden')}
window.addEventListener('resize',renderROI);
let drag=null;
els.roi.addEventListener('pointerdown',e=>{if(!roiManual)return;e.preventDefault();els.roi.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,orig:{...roi},handle:e.target?.dataset?.handle||'move'}});
els.roi.addEventListener('pointermove',e=>{if(!drag||!roiManual)return;const r=canvas.getBoundingClientRect(),dx=(e.clientX-drag.x)*canvas.width/r.width,dy=(e.clientY-drag.y)*canvas.height/r.height,o=drag.orig,minW=Math.max(70,canvas.width*.10),minH=Math.max(45,canvas.height*.05);if(drag.handle==='move'){roi.x=EGSCore.clamp(o.x+dx,0,canvas.width-o.w);roi.y=EGSCore.clamp(o.y+dy,0,canvas.height-o.h);roi.w=o.w;roi.h=o.h}else{let left=o.x,top=o.y,right=o.x+o.w,bottom=o.y+o.h;if(drag.handle.includes('l'))left=EGSCore.clamp(o.x+dx,0,right-minW);if(drag.handle.includes('r'))right=EGSCore.clamp(o.x+o.w+dx,left+minW,canvas.width);if(drag.handle.includes('t'))top=EGSCore.clamp(o.y+dy,0,bottom-minH);if(drag.handle.includes('b'))bottom=EGSCore.clamp(o.y+o.h+dy,top+minH,canvas.height);roi={x:left,y:top,w:right-left,h:bottom-top}}renderROI()});
els.roi.addEventListener('pointerup',()=>drag=null);els.roi.addEventListener('pointercancel',()=>drag=null);
function lineGroups(values,threshold){const idx=[];for(let i=0;i<values.length;i++)if(values[i]>=threshold)idx.push(i);const groups=[];for(const v of idx){if(!groups.length||v-groups.at(-1).at(-1)>2)groups.push([v]);else groups.at(-1).push(v)}return groups.map(g=>g.reduce((a,b)=>a+b,0)/g.length)}
function bestEvenRun(groups,minGap,maxGap){
  if(groups.length<2)return null;let best=null;
  for(let i=0;i<groups.length-1;i++)for(let j=i+1;j<groups.length;j++){
    const gap=groups[j]-groups[i];if(gap<minGap||gap>maxGap)continue;const seq=[groups[i],groups[j]];let last=groups[j];
    for(let k=j+1;k<groups.length;k++){const d=groups[k]-last;if(Math.abs(d-gap)<=Math.max(2,gap*.28)){seq.push(groups[k]);last=groups[k]}}
    if(seq.length<2)continue;const span=seq.at(-1)-seq[0],score=seq.length*3+span/Math.max(1,gap);
    if(!best||score>best.score)best={seq,gap,score}
  }return best
}
function plotInsets(box){
  const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h),col=new Uint32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2])){row[y]++;col[x]++}}
  // Long-line thresholds suppress green title/axis-label text.
  const rows=lineGroups(row,Math.max(7,w*.30)),cols=lineGroups(col,Math.max(7,h*.30));
  const rr=bestEvenRun(rows,Math.max(5,h*.055),h*.38),cc=bestEvenRun(cols,Math.max(6,w*.055),w*.30);
  let ty,by,lx,rx;
  if(rr&&rr.seq.length>=3){ty=rr.seq[0];by=rr.seq.at(-1)}else if(rows.length>=2){ty=rows[0];by=rows.at(-1)}
  if(cc&&cc.seq.length>=3){lx=cc.seq[0];rx=cc.seq.at(-1)}else if(cols.length>=2){lx=cols[0];rx=cols.at(-1)}
  if([ty,by,lx,rx].every(Number.isFinite)&&rx-lx>w*.38&&by-ty>h*.25){
    return{left:EGSCore.clamp(lx/w,.01,.38),right:EGSCore.clamp(1-rx/w,.002,.26),top:EGSCore.clamp(ty/h,.002,.35),bottom:EGSCore.clamp(1-by/h,.01,.48),source:'major-grid',rows,cols};
  }
  // Dark-plot fallback: locate the densest contiguous dark rectangle inside the ROI.
  const rscore=new Float32Array(h),cscore=new Float32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,d=(im[i]+im[i+1]+im[i+2])/3;if(d<105){rscore[y]++;cscore[x]++}}
  const rids=[];for(let y=0;y<h;y++)if(rscore[y]>w*.48)rids.push(y);const cids=[];for(let x=0;x<w;x++)if(cscore[x]>h*.40)cids.push(x);
  if(rids.length&&cids.length){ty=Math.min(...rids);by=Math.max(...rids);lx=Math.min(...cids);rx=Math.max(...cids);if(rx-lx>w*.38&&by-ty>h*.24)return{left:lx/w,right:1-rx/w,top:ty/h,bottom:1-by/h,source:'dark-plot'}}
  return{left:.14,top:.12,right:.035,bottom:.20,source:'fallback'}
}
function checkedChannels(box){
  // Search the checkbox row relative to the graph rather than a fixed 320px offset.
  const d=ctx.getImageData(0,0,canvas.width,canvas.height).data,left=Math.max(0,box.x-box.w*1.22),right=Math.max(left+8,box.x-box.w*.06),top=Math.max(0,box.y+box.h*.52),bottom=Math.min(canvas.height,box.y+box.h*1.35),rw=right-left,rh=bottom-top;if(rw<40||rh<15)return[];
  const out=[],slot=rw/8;for(let ch=0;ch<8;ch++){const sx=Math.floor(left+slot*ch+slot*.16),ex=Math.floor(left+slot*(ch+1)-slot*.16);let best=0;for(let yy=Math.floor(top);yy<bottom;yy+=Math.max(1,Math.floor(rh/18))){let dark=0,total=0;for(let y=yy;y<Math.min(bottom,yy+Math.max(4,rh*.16));y++)for(let x=sx;x<ex;x++){const i=(y*canvas.width+x)*4;if(d[i]<82&&d[i+1]<82&&d[i+2]<82)dark++;total++}best=Math.max(best,dark/Math.max(1,total))}if(best>.16)out.push(ch)}return out
}
function greenRowGroups(box){const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2]))row[y]++}const centers=lineGroups(row,Math.max(8,w*.20));return{groups:centers.map(v=>[v]),centers,w,h}}
const axisTemplateCache=new Map();
function axisCandidates(mode){
  const out=[];
  if(mode==='Gain'){
    for(let v=-2;v<=7;v++)out.push({value:v,forms:[String(v),v.toFixed(1)]});
  }else{
    for(let i=-2;i<=10;i++){
      const v=i/100,forms=[v.toFixed(2),v.toFixed(3),v.toFixed(4),v.toFixed(5),v.toFixed(6)];
      if(Math.abs(v)<1)forms.push(v.toFixed(2).replace(/^0/,''));
      out.push({value:v,forms:[...new Set(forms)]});
    }
  }
  return out;
}
function normPoints(points,tw=112,th=28){
  if(!points||points.length<5)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const p of points){minx=Math.min(minx,p[0]);miny=Math.min(miny,p[1]);maxx=Math.max(maxx,p[0]);maxy=Math.max(maxy,p[1])}
  const w=Math.max(1,maxx-minx+1),h=Math.max(1,maxy-miny+1),sc=Math.min((tw-4)/w,(th-4)/h),nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));
  const ox=tw-nw-2,oy=Math.floor((th-nh)/2),arr=new Uint8Array(tw*th);
  for(const p of points){const xx=ox+Math.min(nw-1,Math.max(0,Math.round((p[0]-minx)*sc))),yy=oy+Math.min(nh-1,Math.max(0,Math.round((p[1]-miny)*sc)));arr[yy*tw+xx]=1}
  return arr;
}
function observedAxisLabelNorm(x0,y0,w,h){
  x0=Math.max(0,Math.floor(x0));y0=Math.max(0,Math.floor(y0));w=Math.max(1,Math.min(canvas.width-x0,Math.floor(w)));h=Math.max(1,Math.min(canvas.height-y0,Math.floor(h)));
  if(w<3||h<3)return null;const im=ctx.getImageData(x0,y0,w,h).data,pts=[];
  // Labels are nearest the plot. Discard the leftmost strip that may contain the vertical Energy title.
  const keep=Math.floor(w*.24);
  for(let y=0;y<h;y++)for(let x=keep;x<w;x++){const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2];if(g>38&&g>r*1.10&&g>b*1.04)pts.push([x-keep,y])}
  return normPoints(pts);
}
function axisTextTemplate(text,font){
  const key=text+'|'+font;if(axisTemplateCache.has(key))return axisTemplateCache.get(key);
  const c=document.createElement('canvas');c.width=180;c.height=48;const q=c.getContext('2d');q.fillStyle='#000';q.fillRect(0,0,c.width,c.height);q.font='24px '+font;q.textBaseline='top';q.fillStyle='#fff';q.fillText(text,2,2);
  const im=q.getImageData(0,0,c.width,c.height).data,pts=[];for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){const i=(y*c.width+x)*4;if(im[i]>90)pts.push([x,y])}
  const n=normPoints(pts);axisTemplateCache.set(key,n);return n;
}
function maskSimilarity(a,b,tw=112,th=28){if(!a||!b)return 0;let best=0;for(let dy=-2;dy<=2;dy++)for(let dx=-3;dx<=3;dx++){let inter=0,union=0;for(let y=0;y<th;y++)for(let x=0;x<tw;x++){const aa=a[y*tw+x],xx=x-dx,yy=y-dy,bb=(xx>=0&&xx<tw&&yy>=0&&yy<th)?b[yy*tw+xx]:0;if(aa&&bb)inter++;if(aa||bb)union++}if(union)best=Math.max(best,inter/union)}return best}
function recognizeAxisLabel(norm,mode){if(!norm)return null;let best=null;for(const c of axisCandidates(mode))for(const text of c.forms)for(const font of ['Arial','monospace','sans-serif']){const score=maskSimilarity(norm,axisTextTemplate(text,font));if(!best||score>best.conf)best={value:c.value,conf:score,text}}return best&&best.conf>=.18?best:null}
function yAxisCalibration(box,insets,mode){
  if(mode!=='Gain'&&mode!=='Noise')return null;
  const g=EGSCore.geometry(box,insets),gx0=Math.max(0,Math.floor(g.x0)),gx1=Math.min(canvas.width,Math.ceil(g.x1)),gy0=Math.max(0,Math.floor(g.y0)),gy1=Math.min(canvas.height,Math.ceil(g.y1));
  const w=Math.max(1,gx1-gx0),h=Math.max(1,gy1-gy0),im=ctx.getImageData(gx0,gy0,w,h).data,row=new Uint32Array(h);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2]))row[y]++}
  let centers=lineGroups(row,Math.max(9,w*.30)).filter(v=>v>=1&&v<=h-2);if(centers.length<2)return null;
  const merged=[];for(const y of centers){if(!merged.length||y-merged.at(-1)>Math.max(3,h*.025))merged.push(y);else merged[merged.length-1]=(merged.at(-1)+y)/2}centers=merged;if(centers.length<2)return null;
  const diffs=[];for(let i=1;i<centers.length;i++){const d=centers[i]-centers[i-1];if(d>=Math.max(5,h*.07)&&d<=h*.50)diffs.push(d)}if(!diffs.length)return null;
  const bases=[];for(const d of diffs)for(const k of [1,2,3]){const b=d/k;if(b>=h*.07&&b<=h*.45)bases.push(b)}if(!bases.length)return null;
  let bestBase=null,bestErr=Infinity;for(const b of bases){const err=EGSCore.median(diffs.map(d=>{const m=Math.max(1,Math.round(d/b));return Math.abs(d-m*b)/b}));if(err<bestErr){bestErr=err;bestBase=b}}
  if(!Number.isFinite(bestBase)||bestBase<4||bestErr>.36)return null;

  // Read numeric anchors from the left Y-axis. Never assume the lowest gridline is zero.
  const stripLeft=Math.max(box.x,g.x0-(g.x1-g.x0)*.34),stripRight=g.x0-2,anchors=[];
  for(const cy of centers){const ay=gy0+cy,hh=Math.max(7,bestBase*.38),norm=observedAxisLabelNorm(stripLeft,ay-hh,stripRight-stripLeft,hh*2+1),rec=recognizeAxisLabel(norm,mode);if(rec)anchors.push({y:ay,value:rec.value,conf:rec.conf,text:rec.text})}
  anchors.sort((a,b)=>a.y-b.y);
  const ded=[];for(const a of anchors){if(ded.length&&Math.abs(a.y-ded.at(-1).y)<3){if(a.conf>ded.at(-1).conf)ded[ded.length-1]=a}else ded.push(a)}
  const stepValue=mode==='Gain'?1.0:.01;
  if(ded.length>=2){let best=null;for(let i=0;i<ded.length;i++)for(let j=i+1;j<ded.length;j++){const A=ded[i],B=ded[j];if(B.value>=A.value||Math.abs(B.y-A.y)<3)continue;const slope=(B.value-A.value)/(B.y-A.y),expected=-stepValue/bestBase,rel=Math.abs(slope-expected)/Math.max(1e-9,Math.abs(expected)),score=(A.conf+B.conf)/2-.35*Math.min(2,rel);if(!best||score>best.score)best={score,slope,intercept:A.value-slope*A.y}}
    if(best&&best.score>.01){const zeroY=-best.intercept/best.slope,stepPx=Math.abs(stepValue/best.slope);return{zeroY,stepPx,stepValue,source:'left-axis-labels',anchors:ded,fitScore:best.score}}
  }
  if(ded.length===1&&ded[0].conf>=.20){const A=ded[0],slope=-stepValue/bestBase,intercept=A.value-slope*A.y;return{zeroY:-intercept/slope,stepPx:bestBase,stepValue,source:'one-axis-label+grid-spacing',anchors:ded,fitScore:A.conf}}
  return null;
}

function pixelLevelSummary(track,box,insets,cal){
  const g=EGSCore.geometry(box,insets),h=Math.max(1,g.y1-g.y0),sp=EGSCore.splitPixel(track.width),margin=Math.max(2,track.width*.016),L=[],R=[];
  for(let i=0;i<track.xs.length;i++){if(!Number.isFinite(track.ys?.[i]))continue;const py=g.y0+(track.ys[i]/Math.max(1,h-1))*h;if(track.xs[i]<=sp-margin)L.push(py);else if(track.xs[i]>=sp+margin)R.push(py)}
  const robustY=a=>{if(a.length<5)return NaN;let v=EGSCore.robust(a,3.2,1.2);if(v.length>=5){const lo=EGSCore.percentile(v,.10),hi=EGSCore.percentile(v,.90);v=v.filter(y=>y>=lo&&y<=hi)}return EGSCore.mean(v)};
  const lowY=robustY(L),highY=robustY(R);if(!Number.isFinite(lowY)||!Number.isFinite(highY))throw Error('Low/High trace position could not be stabilized');
  const toValue=py=>cal?Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue):NaN;
  return{lowY,highY,low:toValue(lowY),high:toValue(highY),leftN:L.length,rightN:R.length}
}
function calibrateTrack(track,box,insets,mode){
  const cal=yAxisCalibration(box,insets,mode);if(!cal)return{track,cal:null,pixels:null};
  const g=EGSCore.geometry(box,insets),h=Math.max(1,g.y1-g.y0),ys=track.ys||[],vals=track.vals.map((_,i)=>{let py;if(Number.isFinite(ys[i]))py=g.y0+(ys[i]/Math.max(1,h-1))*h;else py=g.y1-track.vals[i]*h;return Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue)});
  const out={...track,vals};let pixels=null;try{pixels=pixelLevelSummary(out,box,insets,cal)}catch(_){}
  return{track:out,cal,pixels}
}
function calibratedValueY(box,value,top,insets,cal){if(cal)return cal.zeroY-(value/cal.stepValue)*cal.stepPx;return EGSCore.valueY(box,value,top,insets)}

function gainAutoRegions(track){
  const n=track.xs.length;if(n<30)throw Error('Not enough Gain trace samples for automatic Low/High range detection');
  const pts=track.xs.map((x,i)=>({x,v:track.vals[i],y:track.ys?.[i]})).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.v)).sort((a,b)=>a.x-b.x);
  if(pts.length<30)throw Error('Not enough Gain trace samples for automatic Low/High range detection');
  // Bin the tracked foreground trace over X so irregularly missing pixels do not bias the change-point search.
  const bins=72,bv=Array.from({length:bins},()=>[]),bx=Array.from({length:bins},()=>[]);const xmin=pts[0].x,xmax=pts.at(-1).x,span=Math.max(1,xmax-xmin);
  for(const p of pts){const k=Math.min(bins-1,Math.max(0,Math.floor((p.x-xmin)/span*bins)));bv[k].push(p.v);bx[k].push(p.x)}
  const series=[];for(let k=0;k<bins;k++)if(bv[k].length)series.push({k,x:EGSCore.median(bx[k]),v:EGSCore.median(bv[k])});
  if(series.length<18)throw Error('Gain trace is too sparse for automatic Low/High range detection');
  // Mild median smoothing keeps the search insensitive to isolated spikes.
  const sm=series.map((p,i)=>{const a=[];for(let j=Math.max(0,i-2);j<=Math.min(series.length-1,i+2);j++)a.push(series[j].v);return{...p,sv:EGSCore.median(a)}});
  let best=null;
  for(let c=4;c<=sm.length-5;c++){
    const left=sm.slice(0,c).map(p=>p.sv),right=sm.slice(c).map(p=>p.sv),L=EGSCore.stableLevel(left,1),R=EGSCore.stableLevel(right,1);
    if(!Number.isFinite(L.median)||!Number.isFinite(R.median))continue;
    const diff=R.median-L.median,spread=Math.max(.004,(L.spread+R.spread)/2),balance=Math.min(c,sm.length-c)/Math.max(c,sm.length-c),score=Math.abs(diff)/(spread+.006)*(.55+.45*balance);
    // Gain normally has a low plateau followed by a higher plateau. Penalize the reverse, but do not make it impossible.
    const dir=diff>=0?1:.35,final=score*dir;if(!best||final>best.score)best={c,score:final,L,R,diff};
  }
  if(!best||best.score<1.15)throw Error('Gain Low/High transition could not be identified reliably');
  const cx=(sm[best.c-1].x+sm[best.c].x)/2;
  // Determine a transition band from local deviation around the change point; do not include it in either level calculation.
  const localStep=Math.abs(best.diff),tol=Math.max(.018,localStep*.18),lowMed=best.L.median,highMed=best.R.median;
  let li=best.c-1;while(li>1&&Math.abs(sm[li].sv-lowMed)>tol)li--;
  let ri=best.c;while(ri<sm.length-2&&Math.abs(sm[ri].sv-highMed)>tol)ri++;
  let lowEnd=sm[Math.max(1,li)].x,highStart=sm[Math.min(sm.length-2,ri)].x;
  if(!(lowEnd<highStart)){const gap=Math.max(3,track.width*.025);lowEnd=cx-gap;highStart=cx+gap}
  // Trim the outer edges and transition vicinity, then choose the most stable plateau samples.
  const xlo=pts[0].x,xhi=pts.at(-1).x,edge=Math.max(2,(xhi-xlo)*.025);
  let lowPts=pts.filter(p=>p.x>=xlo+edge&&p.x<=lowEnd),highPts=pts.filter(p=>p.x>=highStart&&p.x<=xhi-edge);
  const selectStable=(arr,target)=>{if(arr.length<6)return arr;const dev=arr.map(p=>Math.abs(p.v-target)),cut=EGSCore.percentile(dev,.80);return arr.filter((p,i)=>dev[i]<=cut)};
  lowPts=selectStable(lowPts,lowMed);highPts=selectStable(highPts,highMed);
  if(lowPts.length<5||highPts.length<5)throw Error('Gain Low/High stable regions are too short');
  const low=EGSCore.stableLevel(lowPts.map(p=>p.v),1),high=EGSCore.stableLevel(highPts.map(p=>p.v),1);
  return{low:low.mean,high:high.mean,confidence:EGSCore.clamp(.45+.16*Math.min(3,best.score)+.20*Math.min(lowPts.length,highPts.length)/Math.max(12,pts.length*.18),0,1),
    lowRange:{x0:Math.min(...lowPts.map(p=>p.x)),x1:Math.max(...lowPts.map(p=>p.x))},highRange:{x0:Math.min(...highPts.map(p=>p.x)),x1:Math.max(...highPts.map(p=>p.x))},transition:{x0:lowEnd,x1:highStart,cx},diagnostics:{change_score:best.score,step:best.diff,low_n:lowPts.length,high_n:highPts.length}}
}
function gainPixelLevelSummary(track,box,insets,cal,regions){
  const g=EGSCore.geometry(box,insets),h=Math.max(1,g.y1-g.y0),L=[],R=[];
  for(let i=0;i<track.xs.length;i++){if(!Number.isFinite(track.ys?.[i]))continue;const x=track.xs[i],py=g.y0+(track.ys[i]/Math.max(1,h-1))*h;if(x>=regions.lowRange.x0&&x<=regions.lowRange.x1)L.push(py);else if(x>=regions.highRange.x0&&x<=regions.highRange.x1)R.push(py)}
  const robustY=a=>{if(a.length<5)return NaN;let v=EGSCore.robust(a,3.2,1.2);if(v.length>=5){const lo=EGSCore.percentile(v,.10),hi=EGSCore.percentile(v,.90);v=v.filter(y=>y>=lo&&y<=hi)}return EGSCore.mean(v)};
  const lowY=robustY(L),highY=robustY(R),toValue=py=>cal?Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue):NaN;
  return{lowY,highY,low:toValue(lowY),high:toValue(highY),leftN:L.length,rightN:R.length}
}

function normalizedModeFeatures(track){
  let gainScore=.15,gain=null;
  try{gain=gainAutoRegions(track);const step=gain.high-gain.low,sep=Math.abs(step),lowPos=EGSCore.clamp((.32-gain.low)/.32,0,1),stepScore=EGSCore.clamp((step-.06)/.28,0,1),stable=EGSCore.clamp(gain.confidence,0,1);gainScore=.35*lowPos+.42*stepScore+.23*stable}catch(_){}
  // Noise remains evaluated as a broad, low-amplitude trace. Its Low/High reporting still uses the Noise split rule.
  const lv=EGSCore.horizontalLevels(track.xs,track.vals,1,track.width),low=lv.low,high=lv.high,delta=high-low,absDelta=Math.abs(delta),mean=(low+high)/2;
  const noiseLowBand=EGSCore.clamp((.42-mean)/.42,0,1),noiseFlat=EGSCore.clamp((.18-absDelta)/.18,0,1),noiseNoStep=EGSCore.clamp((.12-delta)/.22,0,1),noiseScore=.42*noiseLowBand+.38*noiseFlat+.20*noiseNoStep;
  return{low,high,delta,gainScore,noiseScore,levelConfidence:lv.confidence,gainRegions:gain}
}
function inferModeFromTrace(track,requested){
  if(requested!=='Auto')return{mode:requested,note:'',confidence:1,features:null};
  const f=normalizedModeFeatures(track),margin=Math.abs(f.gainScore-f.noiseScore),best=Math.max(f.gainScore,f.noiseScore);
  if(best<.50||margin<.08)return{mode:'Unknown',note:`Auto mode uncertain (Gain ${Math.round(f.gainScore*100)}% / Noise ${Math.round(f.noiseScore*100)}%). Select Gain or Noise manually.`,confidence:Math.max(.18,margin),features:f};
  const mode=f.gainScore>f.noiseScore?'Gain':'Noise';return{mode,note:`Auto mode: ${mode} from foreground signal shape (${Math.round(best*100)}%)`,confidence:EGSCore.clamp(.58+.42*margin,0,1),features:f}
}
function modeTop(mode){return mode==='Noise'?.04:mode==='Gain'?3.0:1}
function scaleTrack(track,top){return{...track,vals:track.vals.map(v=>v*top)}}
function rgbToHsv(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=((h*60)%360+360)%360}return{h,s:mx?d/mx:0,v:mx}}
function hueDistance(a,b){const d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function colorSamples(box,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,s=[];for(let y=0;y<h;y+=2)for(let x=0;x<w;x+=2){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],hsv=rgbToHsv(r,gg,b);if(isGreen(r,gg,b))continue;if(hsv.v>.34&&hsv.s>.22)s.push({h:hsv.h,s:hsv.s,v:hsv.v,r,g:gg,b})}return s}
function clusterTraceColors(box,insets){const pts=colorSamples(box,insets);if(!pts.length)return[];const bins=Array.from({length:24},()=>({n:0,s:0,v:0,rs:0,gs:0,bs:0}));for(const p of pts){const k=Math.floor(((p.h+7.5)%360)/15)%24,b=bins[k];b.n++;b.s+=p.s;b.v+=p.v;b.rs+=p.r;b.gs+=p.g;b.bs+=p.b}let peaks=bins.map((b,k)=>({k,...b})).filter(b=>b.n>=Math.max(8,pts.length*.008)&&b.s/b.n>.27&&b.v/b.n>.38).sort((a,b)=>b.n-a.n);const out=[];for(const p of peaks){const h=(p.k*15+7.5)%360;if(out.some(o=>hueDistance(o.h,h)<24))continue;out.push({h,n:p.n,s:p.s/p.n,v:p.v/p.n,r:p.rs/p.n,g:p.gs/p.n,b:p.bs/p.n});if(out.length>=8)break}return out}
function foregroundTraceForHue(box,top,mode,hue,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[],ysOut=[];let prev=null,miss=0,totalVisible=0,jumps=0;for(let x=0;x<w;x++){const ys=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2];if(isGreen(r,gg,b))continue;const q=rgbToHsv(r,gg,b);if(q.v>.34&&q.s>.23&&hueDistance(q.h,hue)<=22)ys.push({y,score:q.s*q.v*(1-hueDistance(q.h,hue)/30)});else if(prev!=null&&q.v>.72&&q.s<.22&&Math.abs(y-prev)<Math.max(3,h*.035))ys.push({y,score:.18})}if(!ys.length){miss++;continue}let chosen;if(prev==null||miss>9){ys.sort((a,b)=>b.score-a.score);const bestScore=ys[0].score;const cand=ys.filter(z=>z.score>=bestScore*.75).map(z=>z.y).sort((a,b)=>a-b);chosen=EGSCore.median(cand)}else{let best=null,bestCost=1e9;for(const z of ys){const dist=Math.abs(z.y-prev),cost=dist-Math.min(7,z.score*8);if(cost<bestCost){bestCost=cost;best=z}}chosen=best.y;if(Math.abs(chosen-prev)>h*.12)jumps++}prev=chosen;miss=0;totalVisible++;xs.push(x);ysOut.push(chosen);vals.push((1-chosen/Math.max(1,h-1))*top)}const coverage=totalVisible/Math.max(1,w),continuity=1-EGSCore.clamp(jumps/Math.max(1,totalVisible),0,1),sp=EGSCore.splitPixel(w),ln=xs.filter(x=>x<sp).length,rn=xs.filter(x=>x>=sp).length,leftCoverage=ln/Math.max(1,sp),rightCoverage=rn/Math.max(1,w-sp),balance=Math.sqrt(EGSCore.clamp(leftCoverage,0,1)*EGSCore.clamp(rightCoverage,0,1)),leftVals=vals.filter((_,i)=>xs[i]<sp),rightVals=vals.filter((_,i)=>xs[i]>=sp),lm=EGSCore.median(leftVals),rm=EGSCore.median(rightVals),shape=mode==='Gain'?(EGSCore.clamp((.45-(lm/top))/.45,0,1)*.55+EGSCore.clamp((rm/top)/.18,0,1)*.45):.65;return{hue,xs,vals,ys:ysOut,width:w,coverage,leftCoverage,rightCoverage,continuity,shape,score:.42*coverage+.22*continuity+.22*balance+.14*shape}}
function chooseForegroundTrace(box,top,mode,insets){const colors=clusterTraceColors(box,insets),tracks=[];for(const c of colors){const t=foregroundTraceForHue(box,1,'Auto',c.h,insets);if(t.vals.length<Math.max(22,t.width*.07))continue;let mf;try{mf=normalizedModeFeatures(t)}catch(_){mf={gainScore:.2,noiseScore:.2}}const plausible=mode==='Gain'?mf.gainScore:mode==='Noise'?mf.noiseScore:Math.max(mf.gainScore,mf.noiseScore);const dominance=EGSCore.clamp(c.n/Math.max(12,t.width*.35),0,1);t.score=.34*t.coverage+.23*t.continuity+.18*Math.sqrt(EGSCore.clamp(t.leftCoverage,0,1)*EGSCore.clamp(t.rightCoverage,0,1))+.15*dominance+.10*plausible;tracks.push({...t,color:c,modeFeatures:mf,dominance})}if(!tracks.length)throw Error('Foreground signal trace could not be isolated');tracks.sort((a,b)=>b.score-a.score);const best=tracks[0];best.alternates=tracks.slice(1,4).map(t=>({hue:Math.round(t.hue),coverage:t.coverage,score:t.score}));return best}
function genericTrace(box,top,mode,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[];let prev=null,miss=0;for(let x=0;x<w;x++){const yy=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b),sat=mx-mn,white=(r+gg+b)>385&&mx>138&&sat<72,colored=mx>108&&sat>42;if(!isGreen(r,gg,b)&&(white||colored))yy.push(y)}if(!yy.length){miss++;continue}let py;if(prev==null||miss>6)py=EGSCore.median(yy);else{let best=yy[0],bd=Math.abs(best-prev);for(const y of yy){const d=Math.abs(y-prev);if(d<bd){best=y;bd=d}}py=bd<h*.18?best:EGSCore.median(yy)}prev=py;miss=0;xs.push(x);vals.push((1-py/Math.max(1,h-1))*top)}if(vals.length<Math.max(25,w*.08))throw Error('Not enough signal pixels were found');return{xs,vals,width:w,coverage:vals.length/Math.max(1,w),continuity:.5,score:.5,hue:null}}
function channelDecision(channels,track){if(channels.length===1)return{channel:channels[0],source:'single checkbox',confidence:1};if(channels.length>1){return{channel:null,source:'foreground trace among checked channels',confidence:track.score,candidates:[...channels]}}return{channel:null,source:'foreground trace color',confidence:track.score,candidates:[]}}
function overlay(result){
  redrawSource();const b=result.box,g=EGSCore.geometry(b,result.insets),split=EGSCore.splitX(b,result.insets),tw=Math.max(1,g.x1-g.x0);ctx.lineWidth=Math.max(2,canvas.width/500);ctx.strokeStyle='#ff3c4b';ctx.strokeRect(b.x,b.y,b.w,b.h);
  if(result.mode==='Gain'&&result.gainRegions){const xr=x=>g.x0+(x/Math.max(1,result.trace.width-1))*tw,a=xr(result.gainRegions.lowRange.x0),c=xr(result.gainRegions.lowRange.x1),d=xr(result.gainRegions.highRange.x0),e=xr(result.gainRegions.highRange.x1);ctx.strokeStyle='#ffd23f';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(c,g.y0);ctx.lineTo(c,g.y1);ctx.moveTo(d,g.y0);ctx.lineTo(d,g.y1);ctx.stroke();ctx.setLineDash([]);result._gainDraw={a,c,d,e}}else{ctx.strokeStyle='#ffd23f';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(split,g.y0);ctx.lineTo(split,g.y1);ctx.stroke();ctx.setLineDash([]);}
  // Show the actually tracked foreground trace, so the user can verify which line was measured.
  if(result.trace&&result.trace.ys&&result.trace.ys.length){const tw=Math.max(1,g.x1-g.x0),th=Math.max(1,g.y1-g.y0);ctx.fillStyle='rgba(255,255,255,.78)';const step=Math.max(1,Math.floor(result.trace.xs.length/90));for(let i=0;i<result.trace.xs.length;i+=step){const x=g.x0+(result.trace.xs[i]/Math.max(1,result.trace.width-1))*tw,y=g.y0+(result.trace.ys[i]/Math.max(1,th-1))*th;ctx.fillRect(x-1,y-1,2,2)}}
  const ly=result.pixelLevels&&Number.isFinite(result.pixelLevels.lowY)?result.pixelLevels.lowY:calibratedValueY(b,result.low,result.top,result.insets,result.axisCal),hy=result.pixelLevels&&Number.isFinite(result.pixelLevels.highY)?result.pixelLevels.highY:calibratedValueY(b,result.high,result.top,result.insets,result.axisCal);
  ctx.strokeStyle='#00bff3';ctx.beginPath();if(result.mode==='Gain'&&result._gainDraw){ctx.moveTo(result._gainDraw.a,ly);ctx.lineTo(result._gainDraw.c,ly)}else{ctx.moveTo(g.x0,ly);ctx.lineTo(split,ly)}ctx.stroke();ctx.strokeStyle='#ff7f27';ctx.beginPath();if(result.mode==='Gain'&&result._gainDraw){ctx.moveTo(result._gainDraw.d,hy);ctx.lineTo(result._gainDraw.e,hy)}else{ctx.moveTo(split,hy);ctx.lineTo(g.x1,hy)}ctx.stroke();
}
function analyze(){if(!sourceImage||!roi)return;try{
  redrawSource();const insets=plotInsets(roi),channels=checkedChannels(roi);
  let normTrack,fgUsed=false;try{normTrack=chooseForegroundTrace(roi,1,els.mode.value==='Auto'?'Auto':els.mode.value,insets);fgUsed=true}catch(e){if(channels.length>1)throw Error('Foreground trace could not be isolated from multiple checked channels.');normTrack=genericTrace(roi,1,'Auto',insets)}
  let mi=inferModeFromTrace(normTrack,els.mode.value);
  if(mi.mode==='Unknown')throw Error('Auto mode is uncertain. Select Gain or Noise manually.');
  // Once mode is known, re-rank color traces with that mode's expected shape. This prevents a broad background color from beating the actual foreground trace.
  if(fgUsed){try{normTrack=chooseForegroundTrace(roi,1,mi.mode,insets)}catch(_){}}
  if(insets.source!=='major-grid')throw Error('Energy per Band plot grid could not be confirmed. Adjust ROI.');
  const top=modeTop(mi.mode),scaled=scaleTrack(normTrack,top),calibrated=calibrateTrack(scaled,roi,insets,mi.mode),tr=calibrated.track,axisCal=calibrated.cal,decision=channelDecision(channels,tr),digits=mi.mode==='Noise'?4:2,msg=[];
  if(!axisCal)throw Error('Y-axis calibration failed. No numeric result was produced.');
  let gainRegions=null,lv,pixelLevels=calibrated.pixels;
  if(mi.mode==='Gain'){gainRegions=gainAutoRegions(tr);lv={low:gainRegions.low,high:gainRegions.high,confidence:gainRegions.confidence,diagnostics:gainRegions.diagnostics};if(axisCal)pixelLevels=gainPixelLevelSummary(tr,roi,insets,axisCal,gainRegions)}else lv=EGSCore.horizontalLevels(tr.xs,tr.vals,top,tr.width);
  if(mi.note)msg.push(mi.note);msg.push(`Plot geometry: ${insets.source}`);msg.push(axisCal?`Y calibration: ${axisCal.source}; anchors ${axisCal.anchors?.map(a=>a.value+'@'+Math.round(a.y)).join(', ')||'none'}`:'Y calibration: unavailable');if(channels.length===1)msg.push(`Single checked channel CH${channels[0]} prioritized`);else if(channels.length>1){msg.push(`Checked candidates: ${channels.map(c=>'CH'+c).join(', ')}`);msg.push(fgUsed?'Foreground trace only used for calculation':'Foreground isolation fallback used')}else msg.push(fgUsed?'No checkbox resolved; foreground trace used':'Channel unknown; signal analysis continued');if(fgUsed&&Number.isFinite(tr.hue))msg.push(`Foreground hue ${Math.round(tr.hue)}°, visibility ${Math.round(tr.coverage*100)}%`);
  const modeConfidence=els.mode.value==='Auto'?mi.confidence:1,confidence=EGSCore.clamp(lv.confidence*(fgUsed?(.72+.28*tr.score):.72)*(.72+.28*modeConfidence),0,1);
  if(!pixelLevels||!Number.isFinite(pixelLevels.low)||!Number.isFinite(pixelLevels.high))throw Error('Trace pixel levels could not be calibrated. No numeric result was produced.');
  const lowValue=pixelLevels.low,highValue=pixelLevels.high;
  if(mi.mode==='Gain'&&gainRegions)msg.push(`Gain ranges auto-detected: Low ${Math.round(gainRegions.lowRange.x0)}-${Math.round(gainRegions.lowRange.x1)}, High ${Math.round(gainRegions.highRange.x0)}-${Math.round(gainRegions.highRange.x1)}`);
  currentResult={mode:mi.mode,channels,channel:decision.channel,channelSource:decision.source,low:+lowValue.toFixed(digits),high:+highValue.toFixed(digits),confidence,box:{...roi},top,insets,axisCal,pixelLevels,gainRegions,trace:{xs:[...tr.xs],ys:[...tr.ys||[]],width:tr.width},diagnostics:{...lv.diagnostics,mode_features:mi.features,foreground_hue:tr.hue,foreground_coverage:tr.coverage,foreground_continuity:tr.continuity},message:msg.join('; ')};
  overlay(currentResult);showResult(currentResult);setStatus('Analysis complete.');
}catch(e){redrawSource();renderROI();setStatus(e.message||String(e));}}
function showResult(r){els.result.classList.remove('hidden');$('modeOut').textContent=r.mode;$('channelOut').textContent=r.channel!=null?`CH${r.channel}`:(r.channels.length?r.channels.map(c=>'CH'+c).join(' / '):'Unknown');$('confidenceOut').textContent=`${Math.round(r.confidence*100)}%`;if(r.mode==='Unknown'||!Number.isFinite(r.low)||!Number.isFinite(r.high)){$('lowOut').textContent='—';$('highOut').textContent='—';const sp=$('specOut');sp.textContent='—';sp.className='';$('messageOut').textContent=r.message||'Select Gain or Noise manually.';return}$('lowOut').textContent=r.mode==='Noise'?r.low.toFixed(4):r.low.toFixed(2);$('highOut').textContent=r.mode==='Noise'?r.high.toFixed(4):r.high.toFixed(2);const ok=EGSCore.spec(r.mode,r.low,r.high),sp=$('specOut');sp.textContent=ok?'IN':'OUT';sp.className=ok?'spec-in':'spec-out';$('messageOut').textContent=r.message||'—'}
if('serviceWorker' in navigator){
  window.addEventListener('load',async()=>{
    try{
      const reg=await navigator.serviceWorker.register('./sw.js',{scope:'./'});
      await navigator.serviceWorker.ready;
      // Ask the browser to check for an updated offline bundle whenever the app opens online.
      if(navigator.onLine)reg.update().catch(()=>{});
    }catch(e){console.warn('Offline service worker unavailable',e)}
  });
}
window.addEventListener('online',()=>setStatus(sourceImage?'Online — analysis ready':'Online — app ready'));
window.addEventListener('offline',()=>setStatus(sourceImage?'Offline — local analysis ready':'Offline — app ready'));
