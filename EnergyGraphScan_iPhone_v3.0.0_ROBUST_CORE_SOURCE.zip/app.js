const $=id=>document.getElementById(id); const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
let sourceImage=null,roi=null,roiManual=false,currentResult=null,cameraStream=null,cameraBusy=false,sourceGuideCropped=false,autoPipelineToken=0;
const els={stage:$('stage'),roi:$('roi'),status:$('status'),mode:$('modeSelect'),result:$('resultCard'),camera:$('cameraInput'),photo:$('photoInput'),cameraBtn:$('cameraBtn'),cameraModal:$('cameraModal'),cameraVideo:$('cameraVideo'),cameraState:$('cameraState'),cameraShutter:$('cameraShutter'),cameraGuide:document.querySelector('.camera-guide-frame')};
$('resetBtn').onclick=reset;
$('autoDetectBtn').onclick=()=>{autoPipelineToken++;if(!sourceImage)return;
  setStatus('Auto ROI searching…');
  $('autoDetectBtn').disabled=true;
  // Let iOS paint the status before the CPU-heavy search starts.
  requestAnimationFrame(()=>setTimeout(()=>{
    try{
      redrawSource();
      const found=detectGraph();
      if(found){
        roi=found;roiManual=false;els.roi.classList.remove('manual');renderROI();
        setStatus('Auto ROI候補を更新しました。位置を確認してください。');
      }else{
        setStatus('Auto ROI候補を確定できませんでした。現在のROIを手動調整してください。');
      }
    }finally{$('autoDetectBtn').disabled=false}
  },20));
};
$('manualBtn').onclick=()=>{autoPipelineToken++;if(!roi)return;roiManual=true;els.roi.classList.remove('hidden');els.roi.classList.add('manual');setStatus('ROI adjustment enabled. Drag inside to move; drag a corner to resize.');};
$('analyzeBtn').onclick=analyze;
els.photo.addEventListener('change',e=>{const f=e.target.files?.[0];if(f){loadFile(f);e.target.value='';}});
// Standard-camera input is fallback only. It must never appear as a normal file button.
els.camera.addEventListener('change',e=>{const f=e.target.files?.[0];if(f){loadFile(f);e.target.value='';}});
els.cameraBtn.addEventListener('click',()=>openCamera());
$('cameraCancel').addEventListener('click',closeCamera);
$('cameraRetry').addEventListener('click',()=>startCameraStream());
els.cameraShutter.addEventListener('click',captureCameraFrame);

function cameraMessage(text,error=false){if(els.cameraState){els.cameraState.textContent=text;els.cameraState.classList.toggle('error',!!error)}}
async function openCamera(){
  if(cameraBusy)return;
  // Show the overlay first so every tap has immediate visible feedback.
  els.cameraModal.classList.remove('hidden');els.cameraModal.setAttribute('aria-hidden','false');
  document.body.classList.add('camera-open');
  cameraMessage('カメラ準備中…');
  els.cameraShutter.disabled=true;
  await startCameraStream();
}
async function startCameraStream(){
  if(cameraBusy)return; cameraBusy=true;
  try{
    stopCameraStream();
    if(!window.isSecureContext)throw new Error('Camera requires HTTPS');
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera API unavailable');
    let stream;
    try{
      stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
    }catch(firstErr){
      // Some iOS/PWA builds reject detailed constraints. Retry with the
      // simplest video request before declaring failure.
      stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});
    }
    cameraStream=stream; els.cameraVideo.srcObject=stream;
    await new Promise((resolve,reject)=>{
      const done=()=>{cleanup();resolve()}; const fail=()=>{cleanup();reject(new Error('Video could not start'))};
      const cleanup=()=>{els.cameraVideo.removeEventListener('loadedmetadata',done);els.cameraVideo.removeEventListener('error',fail)};
      if(els.cameraVideo.readyState>=1)return resolve();
      els.cameraVideo.addEventListener('loadedmetadata',done,{once:true});els.cameraVideo.addEventListener('error',fail,{once:true});
      setTimeout(()=>{cleanup();resolve()},2500);
    });
    await els.cameraVideo.play();
    cameraMessage('ガイド枠内に Energy per Band と Channel欄が入るように撮影してください');
    els.cameraShutter.disabled=false;
  }catch(e){
    console.error('camera start failed',e);
    cameraMessage('アプリ内カメラを開始できません。Safari/ホーム画面アプリのカメラ許可を確認して「再試行」してください。',true);
    els.cameraShutter.disabled=true;
  }finally{cameraBusy=false}
}
function stopCameraStream(){if(cameraStream){for(const t of cameraStream.getTracks())try{t.stop()}catch(_){}cameraStream=null}els.cameraVideo.srcObject=null}
function closeCamera(){stopCameraStream();els.cameraModal.classList.add('hidden');els.cameraModal.setAttribute('aria-hidden','true');document.body.classList.remove('camera-open');cameraBusy=false}
function cameraGuideSourceRect(){
  const v=els.cameraVideo,g=els.cameraGuide;
  if(!v||!g||!v.videoWidth||!v.videoHeight)return null;
  const vr=v.getBoundingClientRect(),gr=g.getBoundingClientRect();
  if(vr.width<=0||vr.height<=0||gr.width<=0||gr.height<=0)return null;

  // <video> uses object-fit:cover. Convert the visible guide-frame rectangle
  // back to intrinsic camera pixels, including the portions cropped by cover.
  const scale=Math.max(vr.width/v.videoWidth,vr.height/v.videoHeight);
  const renderedW=v.videoWidth*scale,renderedH=v.videoHeight*scale;
  const cropX=(renderedW-vr.width)/2,cropY=(renderedH-vr.height)/2;

  let sx=(gr.left-vr.left+cropX)/scale;
  let sy=(gr.top-vr.top+cropY)/scale;
  let sw=gr.width/scale,sh=gr.height/scale;

  // Small inward margin prevents the yellow guide border itself from entering
  // the analysis image.
  const mx=sw*.012,my=sh*.025;
  sx+=mx;sy+=my;sw-=2*mx;sh-=2*my;

  sx=Math.max(0,Math.min(v.videoWidth-2,sx));
  sy=Math.max(0,Math.min(v.videoHeight-2,sy));
  sw=Math.max(2,Math.min(v.videoWidth-sx,sw));
  sh=Math.max(2,Math.min(v.videoHeight-sy,sh));
  return{sx,sy,sw,sh};
}
function captureCameraFrame(){
  const v=els.cameraVideo;
  if(!v.videoWidth||!v.videoHeight){cameraMessage('カメラ画像を取得できません。再試行してください。',true);return}
  const r=cameraGuideSourceRect();
  if(!r){cameraMessage('撮影枠の位置を取得できません。再試行してください。',true);return}

  els.cameraShutter.disabled=true;
  cameraMessage('撮影枠内だけを切り出しています…');

  // Analyze only the guide-frame crop.  This avoids decoding and scanning the
  // entire iPhone camera frame, which was the main post-capture freeze source.
  const maxOutW=1400;
  const scale=Math.min(1,maxOutW/r.sw);
  const outW=Math.max(2,Math.round(r.sw*scale));
  const outH=Math.max(2,Math.round(r.sh*scale));
  const c=document.createElement('canvas');
  c.width=outW;c.height=outH;
  const cctx=c.getContext('2d',{alpha:false});
  cctx.imageSmoothingEnabled=true;
  cctx.imageSmoothingQuality='high';
  cctx.drawImage(v,r.sx,r.sy,r.sw,r.sh,0,0,outW,outH);

  // Let iOS paint the status text before JPEG encoding starts.
  requestAnimationFrame(()=>setTimeout(()=>{
    c.toBlob(blob=>{
      if(!blob){
        els.cameraShutter.disabled=false;
        cameraMessage('撮影画像の切り出しに失敗しました。',true);
        return;
      }
      closeCamera();
      loadCapturedBlob(blob,true);
    },'image/jpeg',.90);
  },0));
}
function loadCapturedBlob(blob,guideCropped=false){
  // Do not route a captured frame back through <input type=file>. On iOS that
  // can lose the selected file when control returns from the camera/PWA.
  const url=URL.createObjectURL(blob),img=new Image();
  img.onload=()=>{
    URL.revokeObjectURL(url);
    useImage(img,{guideCropped});
  };
  img.onerror=()=>{URL.revokeObjectURL(url);setStatus('Could not read captured image.')};img.src=url;
}

function setStatus(s){els.status.textContent=s}
function redrawSource(){if(sourceImage)ctx.drawImage(sourceImage,0,0,canvas.width,canvas.height)}
function reset(){closeCamera();sourceImage=null;roi=null;currentResult=null;ctx.clearRect(0,0,canvas.width,canvas.height);els.stage.classList.add('empty');els.roi.classList.add('hidden');els.roi.classList.remove('manual');els.result.classList.add('hidden');$('placeholder').classList.remove('hidden');['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=true);els.camera.value='';els.photo.value='';setStatus('Ready')}
async function loadFile(file){setStatus('Loading image…');const url=URL.createObjectURL(file),img=new Image();img.onload=()=>{URL.revokeObjectURL(url);useImage(img)};img.onerror=()=>setStatus('Could not read image.');img.src=url}
// Core color classifier used by ROI/grid/foreground analysis.
function isGreen(r,g,b){
  return g>42 && g>r*1.24 && g>b*1.12 && (g-Math.min(r,b))>18;
}

function guideCropSeed(){
  const W=canvas.width,H=canvas.height;
  // Camera guide crop already contains the target application region.
  // Start with a lightweight editable seed around the upper-right Energy per Band
  // plot including the left Y-axis labels and the Channel/Bands row.
  const x=Math.round(W*.47), y=Math.round(H*.06);
  const w=Math.round(W*.52), h=Math.round(H*.60);
  return{
    x:EGSCore.clamp(x,0,Math.max(0,W-80)),
    y:EGSCore.clamp(y,0,Math.max(0,H-60)),
    w:Math.min(W-x,Math.max(80,w)),
    h:Math.min(H-y,Math.max(60,h)),
    manualSeed:true
  };
}

function runPostCapturePipeline(){
  const token=++autoPipelineToken;
  setStatus('撮影画像を読み込みました。Auto ROIを確認中…');

  // Phase 1: return control to iOS so the captured image is painted first.
  requestAnimationFrame(()=>setTimeout(()=>{
    if(token!==autoPipelineToken||!sourceImage)return;

    let found=null;
    try{ found=detectGraph(); }catch(e){ found=null; }

    if(found){
      roi=found; roiManual=false; els.roi.classList.remove('manual'); renderROI();
      setStatus('Auto ROI候補を検出しました。解析中…');
    }else{
      // Keep the editable seed. Analysis may still succeed if the seed already
      // covers the Energy per Band plot.
      roiManual=true; els.roi.classList.add('manual'); renderROI();
      setStatus('Auto ROI候補は不確実です。初期ROIで解析を試行中…');
    }

    // Phase 2: yield once more before analysis.
    requestAnimationFrame(()=>setTimeout(()=>{
      if(token!==autoPipelineToken||!sourceImage||!roi)return;
      try{
        analyze();
      }catch(e){
        console.error('post-capture analyze failed',e);
        setStatus(`自動解析エラー: ${e?.message||e}. ROIを調整してAnalyzeしてください。`);
      }
    },30));
  },40));
}
function useImage(img,opts={}){
  sourceImage=img;sourceGuideCropped=!!opts.guideCropped;
  const maxW=1400,scale=Math.min(1,maxW/img.naturalWidth);
  canvas.width=Math.max(2,Math.round(img.naturalWidth*scale));
  canvas.height=Math.max(2,Math.round(img.naturalHeight*scale));
  redrawSource();
  els.stage.classList.remove('empty');
  $('placeholder').classList.add('hidden');

  if(sourceGuideCropped){
    roi=guideCropSeed();
  }else{
    roi={
      x:Math.round(canvas.width*.48),
      y:Math.round(canvas.height*.06),
      w:Math.round(canvas.width*.50),
      h:Math.round(canvas.height*.50),
      manualSeed:true
    };
    roi.w=Math.min(canvas.width-roi.x,Math.max(80,roi.w));
    roi.h=Math.min(canvas.height-roi.y,Math.max(60,roi.h));
  }

  roiManual=true;
  els.roi.classList.add('manual');
  renderROI();
  ['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=false);

  if(sourceGuideCropped){
    // Default camera workflow: capture -> crop -> auto ROI -> analyze.
    runPostCapturePipeline();
  }else{
    setStatus('画像を読み込みました。ROIを確認してAnalyzeしてください。');
  }
}
function detectGraph(){
  const W=canvas.width,H=canvas.height,src=ctx.getImageData(0,0,W,H).data;
  const ds=Math.max(sourceGuideCropped?4:2,Math.ceil(Math.max(W,H)/(sourceGuideCropped?520:820))),cands=[];
  const minW=Math.max(120,Math.floor(W*.14)),maxW=Math.floor(W*.62);
  const minH=Math.max(58,Math.floor(H*.045)),maxH=Math.floor(H*.30);
  function structureScore(x,y,w,h){
    const st=rectStats(src,W,H,x,y,x+w,y+h,ds);
    if(st.dark<.50||st.green<.0045||st.color<.0025)return null;
    const im=ctx.getImageData(x,y,w,h).data,row=new Uint32Array(h),col=new Uint32Array(w),traceSpans=[];
    const traceRows=new Uint32Array(h);
    for(let xx=0;xx<w;xx++){
      let ymin=h,ymax=-1,seen=0;
      for(let yy=0;yy<h;yy++){
        const i=(yy*w+xx)*4,r=im[i],g=im[i+1],b=im[i+2];
        if(isGreen(r,g,b)){row[yy]++;col[xx]++;continue}
        const q=rgbToHsv(r,g,b);
        // Energy-per-Band has a thin, horizontally continuous colored trace.
        if(q.v>.38&&q.s>.24){ymin=Math.min(ymin,yy);ymax=Math.max(ymax,yy);seen++;traceRows[yy]++}
      }
      if(seen>=1&&ymax>=ymin)traceSpans.push((ymax-ymin+1)/Math.max(1,h));
    }
    const rg=lineGroups(row,Math.max(6,w*.22)),cg=lineGroups(col,Math.max(5,h*.23));
    if(rg.length<2||cg.length<3)return null;
    const aspect=w/Math.max(1,h);
    if(aspect<1.35||aspect>3.35)return null;
    const aspectScore=Math.exp(-Math.pow((aspect-2.05)/.85,2)),area=(w*h)/(W*H),compact=Math.exp(-Math.pow((area-.040)/.052,2)),gridScore=Math.min(1,(rg.length+cg.length)/10);
    let thin=.15,concentration=.15;
    if(traceSpans.length>=Math.max(8,w*.06)){
      const med=EGSCore.median(traceSpans);
      thin=EGSCore.clamp((.50-med)/.42,0,1);
      const peak=Math.max(...traceRows),sum=traceRows.reduce((a,b)=>a+b,0);
      concentration=EGSCore.clamp((peak/Math.max(1,sum/h)-1)/8,0,1);
    }
    const gridSpanX=cg.length>=2?(cg.at(-1)-cg[0])/w:0,gridSpanY=rg.length>=2?(rg.at(-1)-rg[0])/h:0;
    const spanScore=EGSCore.clamp((Math.min(gridSpanX,.95)-.42)/.42,0,1)*.55+EGSCore.clamp((Math.min(gridSpanY,.95)-.28)/.50,0,1)*.45;
    // Thin-trace score strongly rejects Raw Data/Spectrum panels and their subregions.
    const centerY=(y+h*.5)/H,centerX=(x+w*.5)/W;
    // After camera guide-cropping, Energy per Band is structurally the upper chart.
    // Raw Data/Spectrum candidates in the lower half are strongly suppressed.
    const guideBonus=sourceGuideCropped?(centerY<.58?1.25:-2.2)+(centerX>.38?.35:0):0;
    const score=1.55*st.dark+6.7*st.green+1.15*st.color+.18*st.warm+1.0*aspectScore+1.0*compact+1.25*gridScore+3.1*thin+1.1*concentration+1.25*spanScore+guideBonus;
    return{score,st,aspect,area,thin,concentration,spanScore,rg,cg}
  }
  for(let h=minH;h<=maxH;h=Math.round(h*1.16)+1)for(const asp of [1.45,1.65,1.85,2.05,2.25,2.5,2.8,3.1]){
    const w=Math.round(h*asp);if(w<minW||w>maxW)continue;
    const sx=Math.max(ds*3,Math.round(w*.075)),sy=Math.max(ds*3,Math.round(h*.09));
    const yStart=0, yStop=sourceGuideCropped?Math.floor(H*.72):H;
    const xStart=sourceGuideCropped?Math.floor(W*.28):0;
    for(let y=yStart;y+h<=yStop;y+=sy)for(let x=xStart;x+w<=W;x+=sx){
      const q=structureScore(x,y,w,h);
      if(q)cands.push({x,y,w,h,...q})
    }
  }
  if(cands.length){
    cands.sort((a,b)=>b.score-a.score);let best=null;
    for(const c of cands.slice(0,28)){
      const box={x:c.x,y:c.y,w:c.w,h:c.h},ins=plotInsets(box),g=EGSCore.geometry(box,ins),gw=g.x1-g.x0,gh=g.y1-g.y0;
      if(gw<c.w*.50||gh<c.h*.30)continue;
      const tightness=(gw*gh)/(c.w*c.h),refine=c.score+(ins.source==='major-grid'?2.2:0)+(tightness>.30&&tightness<.82?.7:0)+1.4*c.thin+.5*c.spanScore;
      if(!best||refine>best.refine)best={...c,refine}
    }
    if(best){
      const padX=Math.round(best.w*.045),padY=Math.round(best.h*.065),bx=Math.max(0,best.x-padX),by=Math.max(0,best.y-padY);
      return{x:bx,y:by,w:Math.min(W-bx,best.w+padX*2),h:Math.min(H-by,best.h+padY*2),confidence:EGSCore.clamp((best.thin*.45+best.spanScore*.25+.30),0,1)}
    }
  }
  // Unified contract v2: never invent a broad fallback ROI.
  return null;
}

function canvasDisplayTransform(){
  const cr=canvas.getBoundingClientRect(),
        sr=els.stage.getBoundingClientRect();
  return{
    scaleX:cr.width/Math.max(1,canvas.width),
    scaleY:cr.height/Math.max(1,canvas.height),
    offsetX:cr.left-sr.left,
    offsetY:cr.top-sr.top,
    canvasRect:cr,
    stageRect:sr
  };
}
function renderROI(){
  if(!roi)return;
  const m=canvasDisplayTransform(),sx=m.scaleX,sy=m.scaleY,ox=m.offsetX,oy=m.offsetY;
  Object.assign(els.roi.style,{left:`${ox+roi.x*sx}px`,top:`${oy+roi.y*sy}px`,width:`${roi.w*sx}px`,height:`${roi.h*sy}px`});
  els.roi.classList.remove('hidden');
}
window.addEventListener('resize',renderROI);
let drag=null;
els.roi.addEventListener('pointerdown',e=>{if(!roiManual)return;e.preventDefault();els.roi.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,orig:{...roi},handle:e.target?.dataset?.handle||'move'}});
els.roi.addEventListener('pointermove',e=>{if(!drag||!roiManual)return;const m=canvasDisplayTransform(),dx=(e.clientX-drag.x)/Math.max(1e-9,m.scaleX),dy=(e.clientY-drag.y)/Math.max(1e-9,m.scaleY),o=drag.orig,minW=Math.max(70,canvas.width*.10),minH=Math.max(45,canvas.height*.05);if(drag.handle==='move'){roi.x=EGSCore.clamp(o.x+dx,0,canvas.width-o.w);roi.y=EGSCore.clamp(o.y+dy,0,canvas.height-o.h);roi.w=o.w;roi.h=o.h}else{let left=o.x,top=o.y,right=o.x+o.w,bottom=o.y+o.h;if(drag.handle.includes('l'))left=EGSCore.clamp(o.x+dx,0,right-minW);if(drag.handle.includes('r'))right=EGSCore.clamp(o.x+o.w+dx,left+minW,canvas.width);if(drag.handle.includes('t'))top=EGSCore.clamp(o.y+dy,0,bottom-minH);if(drag.handle.includes('b'))bottom=EGSCore.clamp(o.y+o.h+dy,top+minH,canvas.height);roi={x:left,y:top,w:right-left,h:bottom-top}}renderROI()});
els.roi.addEventListener('pointerup',()=>drag=null);els.roi.addEventListener('pointercancel',()=>drag=null);
function lineGroups(values,threshold){const idx=[];for(let i=0;i<values.length;i++)if(values[i]>=threshold)idx.push(i);const groups=[];for(const v of idx){if(!groups.length||v-groups.at(-1).at(-1)>2)groups.push([v]);else groups.at(-1).push(v)}return groups.map(g=>g.reduce((a,b)=>a+b,0)/g.length)}
function bestEvenRun(groups,minGap,maxGap){
  if(groups.length<2)return null;let best=null;
  for(let i=0;i<groups.length-1;i++)for(let j=i+1;j<groups.length;j++){
    const gap=groups[j]-groups[i];if(gap<minGap||gap>maxGap)continue;const seq=[groups[i],groups[j]];let last=groups[j];
    for(let k=j+1;k<groups.length;k++){const d=groups[k]-last;if(Math.abs(d-gap)<=Math.max(2,gap*.28)){seq.push(groups[k]);last=groups[k]}}
    if(seq.length<2)continue;const span=seq.at(-1)-seq[0],score=seq.length*3+span/Math.max(1,gap);
    if(!best||score>best.score)best={seq,gap,score}
  }return best
}
function plotInsets(box){
  const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h),col=new Uint32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2])){row[y]++;col[x]++}}
  // Long-line thresholds suppress green title/axis-label text.
  const rows=lineGroups(row,Math.max(7,w*.30)),cols=lineGroups(col,Math.max(7,h*.30));
  const rr=bestEvenRun(rows,Math.max(5,h*.055),h*.38),cc=bestEvenRun(cols,Math.max(6,w*.055),w*.30);
  let ty,by,lx,rx;
  if(rr&&rr.seq.length>=3){ty=rr.seq[0];by=rr.seq.at(-1)}else if(rows.length>=2){ty=rows[0];by=rows.at(-1)}
  if(cc&&cc.seq.length>=3){lx=cc.seq[0];rx=cc.seq.at(-1)}else if(cols.length>=2){lx=cols[0];rx=cols.at(-1)}
  if([ty,by,lx,rx].every(Number.isFinite)&&rx-lx>w*.38&&by-ty>h*.25){
    return{left:EGSCore.clamp(lx/w,.01,.38),right:EGSCore.clamp(1-rx/w,.002,.26),top:EGSCore.clamp(ty/h,.002,.35),bottom:EGSCore.clamp(1-by/h,.01,.48),source:'major-grid',rows,cols};
  }
  // v1.7.3 rescue: perspective/moire can weaken long green grid lines on iPhone.
  // Use a lower threshold only to recover plot geometry; this does not determine Gain/Noise.
  const rrows=lineGroups(row,Math.max(5,w*.14)),rcols=lineGroups(col,Math.max(5,h*.14));
  if(rrows.length>=2&&rcols.length>=2){
    const rty=rrows[0],rby=rrows.at(-1),rlx=rcols[0],rrx=rcols.at(-1);
    if(rrx-rlx>w*.36&&rby-rty>h*.22){
      return{left:EGSCore.clamp(rlx/w,.01,.40),right:EGSCore.clamp(1-rrx/w,.002,.30),top:EGSCore.clamp(rty/h,.002,.38),bottom:EGSCore.clamp(1-rby/h,.005,.50),source:'relaxed-grid',rows:rrows,cols:rcols};
    }
  }
  // Dark-plot fallback: locate the densest contiguous dark rectangle inside the ROI.
  const rscore=new Float32Array(h),cscore=new Float32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,d=(im[i]+im[i+1]+im[i+2])/3;if(d<105){rscore[y]++;cscore[x]++}}
  const rids=[];for(let y=0;y<h;y++)if(rscore[y]>w*.48)rids.push(y);const cids=[];for(let x=0;x<w;x++)if(cscore[x]>h*.40)cids.push(x);
  if(rids.length&&cids.length){ty=Math.min(...rids);by=Math.max(...rids);lx=Math.min(...cids);rx=Math.max(...cids);if(rx-lx>w*.38&&by-ty>h*.24)return{left:lx/w,right:1-rx/w,top:ty/h,bottom:1-by/h,source:'dark-plot'}}
  // Last-resort ROI geometry: do not stop analysis solely because green grid
  // confirmation failed. Preserve room on the left for Y-axis labels and on the
  // bottom for Sample# labels while using the ROI as the plot envelope.
  return{left:.16,top:.10,right:.025,bottom:.18,source:'roi-estimate',confidence:.28}
}
function checkedChannels(box){
  // Search the checkbox row relative to the graph rather than a fixed 320px offset.
  const d=ctx.getImageData(0,0,canvas.width,canvas.height).data,left=Math.max(0,box.x-box.w*1.22),right=Math.max(left+8,box.x-box.w*.06),top=Math.max(0,box.y+box.h*.52),bottom=Math.min(canvas.height,box.y+box.h*1.35),rw=right-left,rh=bottom-top;if(rw<40||rh<15)return[];
  const out=[],slot=rw/8;for(let ch=0;ch<8;ch++){const sx=Math.floor(left+slot*ch+slot*.16),ex=Math.floor(left+slot*(ch+1)-slot*.16);let best=0;for(let yy=Math.floor(top);yy<bottom;yy+=Math.max(1,Math.floor(rh/18))){let dark=0,total=0;for(let y=yy;y<Math.min(bottom,yy+Math.max(4,rh*.16));y++)for(let x=sx;x<ex;x++){const i=(y*canvas.width+x)*4;if(d[i]<82&&d[i+1]<82&&d[i+2]<82)dark++;total++}best=Math.max(best,dark/Math.max(1,total))}if(best>.16)out.push(ch)}return out
}
function greenRowGroups(box){const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2]))row[y]++}const centers=lineGroups(row,Math.max(8,w*.20));return{groups:centers.map(v=>[v]),centers,w,h}}
const axisTemplateCache=new Map();
function axisCandidates(mode='Any'){
  const out=[];
  const add=(value,forms,family)=>out.push({value,forms:[...new Set(forms)],family});
  if(mode==='Gain'||mode==='Any'){
    for(let v=0;v<=4;v++)add(v,[v.toFixed(1)],'Gain');
  }
  if(mode==='Noise'||mode==='Any'){
    for(let i=0;i<=5;i++){
      const v=i/100;
      add(v,[v.toFixed(3),v.toFixed(4),v.toFixed(5)],'Noise');
    }
  }
  return out;
}
function normPoints(points,tw=112,th=28){
  if(!points||points.length<4)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const p of points){minx=Math.min(minx,p[0]);miny=Math.min(miny,p[1]);maxx=Math.max(maxx,p[0]);maxy=Math.max(maxy,p[1])}
  const w=Math.max(1,maxx-minx+1),h=Math.max(1,maxy-miny+1),sc=Math.min((tw-4)/w,(th-4)/h),nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));
  const ox=tw-nw-2,oy=Math.floor((th-nh)/2),arr=new Uint8Array(tw*th);
  for(const p of points){
    const xx=ox+Math.min(nw-1,Math.max(0,Math.round((p[0]-minx)*sc))),
          yy=oy+Math.min(nh-1,Math.max(0,Math.round((p[1]-miny)*sc)));
    arr[yy*tw+xx]=1;
  }
  arr._aspect=w/Math.max(1,h);
  arr._density=points.length/Math.max(1,w*h);
  arr._origW=w;arr._origH=h;
  const xp=new Float32Array(16),yp=new Float32Array(8);
  for(const p of points){
    xp[Math.min(15,Math.floor((p[0]-minx)/Math.max(1,w)*16))]++;
    yp[Math.min(7,Math.floor((p[1]-miny)/Math.max(1,h)*8))]++;
  }
  const n=Math.max(1,points.length);
  for(let i=0;i<xp.length;i++)xp[i]/=n;
  for(let i=0;i<yp.length;i++)yp[i]/=n;
  arr._xp=xp;arr._yp=yp;
  return arr;
}
function observedAxisLabelNorm(x0,y0,w,h){
  x0=Math.max(0,Math.floor(x0));y0=Math.max(0,Math.floor(y0));
  w=Math.max(1,Math.min(canvas.width-x0,Math.floor(w)));h=Math.max(1,Math.min(canvas.height-y0,Math.floor(h)));
  if(w<3||h<3)return null;
  const im=ctx.getImageData(x0,y0,w,h).data,pts=[];
  // Keep the part nearest the plot. Use a deliberately permissive green/chroma
  // threshold because iPhone photos soften the tiny 1.0/2.0/3.0 glyph edges.
  const keep=Math.floor(w*.14);
  for(let y=0;y<h;y++)for(let x=keep;x<w;x++){
    const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2],
          mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,
          chroma=g-Math.max(r,b),lum=(r+g+b)/3;
    // Axis glyphs are nominally green, but iPhone photos often make their
    // anti-aliased edges yellow/grey/near-white. This crop is already limited
    // to the Y-label strip, so a softened bright-glyph fallback is safe.
    const greenish=g>28 && ((g>r*1.025&&g>b*.99&&chroma>2) || (chroma>7&&lum>24));
    const softBright=lum>72 && sat<58;
    if(greenish||softBright)pts.push([x-keep,y]);
  }
  return normPoints(pts);
}
function axisTextTemplate(text,font,size=24,weight=''){
  const key=text+'|'+font+'|'+size+'|'+weight;
  if(axisTemplateCache.has(key))return axisTemplateCache.get(key);
  const c=document.createElement('canvas');c.width=190;c.height=54;
  const q=c.getContext('2d');q.fillStyle='#000';q.fillRect(0,0,c.width,c.height);
  q.font=`${weight?weight+' ':''}${size}px ${font}`;q.textBaseline='top';q.fillStyle='#fff';q.fillText(text,2,2);
  const im=q.getImageData(0,0,c.width,c.height).data,pts=[];
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
    const i=(y*c.width+x)*4;if(im[i]>75)pts.push([x,y]);
  }
  const n=normPoints(pts);axisTemplateCache.set(key,n);return n;
}
function projectionSimilarity(a,b,key){
  const A=a?.[key],B=b?.[key];if(!A||!B||A.length!==B.length)return .5;
  let dot=0,aa=0,bb=0;
  for(let i=0;i<A.length;i++){dot+=A[i]*B[i];aa+=A[i]*A[i];bb+=B[i]*B[i]}
  return aa>0&&bb>0?dot/Math.sqrt(aa*bb):0;
}
function maskSimilarity(a,b,tw=112,th=28){
  if(!a||!b)return 0;let iou=0;
  for(let dy=-3;dy<=3;dy++)for(let dx=-4;dx<=4;dx++){
    let inter=0,union=0;
    for(let y=0;y<th;y++)for(let x=0;x<tw;x++){
      const aa=a[y*tw+x],xx=x-dx,yy=y-dy,bb=(xx>=0&&xx<tw&&yy>=0&&yy<th)?b[yy*tw+xx]:0;
      if(aa&&bb)inter++;if(aa||bb)union++;
    }
    if(union)iou=Math.max(iou,inter/union);
  }
  const arA=Math.max(.05,a._aspect||1),arB=Math.max(.05,b._aspect||1),
        aspect=Math.exp(-Math.abs(Math.log(arA/arB))*1.25),
        dA=a._density||.2,dB=b._density||.2,
        density=Math.max(0,1-Math.abs(dA-dB)/Math.max(.08,(dA+dB)*.8)),
        xp=projectionSimilarity(a,b,'_xp'),yp=projectionSimilarity(a,b,'_yp');
  return .52*iou+.18*aspect+.10*density+.12*xp+.08*yp;
}
function axisLabelHypotheses(norm,mode='Any',limit=6){
  if(!norm)return[];
  const fonts=['Arial','Arial Narrow','Helvetica','Tahoma','Verdana','Courier New','monospace','sans-serif'],
        sizes=[18,20,22,24,26,28],byValue=new Map();
  for(const c of axisCandidates(mode))for(const text of c.forms)for(const font of fonts)for(const size of sizes){
    const score=maskSimilarity(norm,axisTextTemplate(text,font,size));
    const k=c.family+'|'+c.value,prev=byValue.get(k);
    if(!prev||score>prev.conf)byValue.set(k,{value:c.value,conf:score,text,family:c.family});
  }
  const ranked=[...byValue.values()].sort((a,b)=>b.conf-a.conf);
  if(!ranked.length)return[];
  const best=ranked[0].conf;
  return ranked.filter(x=>x.conf>=.14 && x.conf>=best-.075).slice(0,Math.min(limit,4));
}
function recognizeAxisLabel(norm,mode='Any'){
  const h=axisLabelHypotheses(norm,mode,1);return h.length&&h[0].conf>=.12?h[0]:null;
}
function fitAxisLabelSequence(rows,bestBase){
  let best=null;
  const sameFamily=(a,b)=>a.family===b.family;
  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const Arow=rows[i],Brow=rows[j];
    for(const A of Arow.hyps)for(const B of Brow.hyps){
      if(!sameFamily(A,B)||B.value>=A.value||Brow.y-Arow.y<3)continue;
      const slope=(B.value-A.value)/(Brow.y-Arow.y);
      if(!(slope<0))continue;
      const unit=A.family==='Gain'?1:.01,
            pxPerUnit=Math.abs(unit/slope);
      // A true major-axis numeric series should advance about one displayed
      // unit per major-grid spacing. Broad acceptance allowed 3.0/2.0/1.0
      // glyphs to masquerade as 0.10/0.04/0.02. Keep perspective tolerance,
      // but require the numeric step to agree with the measured grid lattice.
      if(pxPerUnit<bestBase*.62||pxPerUnit>bestBase*1.62)continue;
      const intercept=A.value-slope*Arow.y;
      let support=0,conf=A.conf+B.conf,anchors=[
        {y:Arow.y,value:A.value,conf:A.conf,text:A.text,family:A.family},
        {y:Brow.y,value:B.value,conf:B.conf,text:B.text,family:B.family}
      ];
      for(let k=0;k<rows.length;k++){
        if(k===i||k===j)continue;
        const row=rows[k],expected=slope*row.y+intercept,
              tol=A.family==='Gain'?.34:.0038;
        let hit=null;
        for(const h of row.hyps){
          if(h.family!==A.family)continue;
          const err=Math.abs(h.value-expected);
          if(err<=tol&&(!hit||err<hit.err))hit={...h,err};
        }
        if(hit){support++;conf+=hit.conf;anchors.push({y:row.y,value:hit.value,conf:hit.conf,text:hit.text,family:hit.family})}
      }
      const sortedAnchors=[...anchors].sort((a,b)=>a.y-b.y);
      let gapBad=false;
      for(let z=1;z<sortedAnchors.length;z++){
        const gridGap=Math.abs((sortedAnchors[z].y-sortedAnchors[z-1].y)/bestBase),
              valueGap=Math.abs(sortedAnchors[z].value-sortedAnchors[z-1].value)/unit;
        if(gridGap>2.45||valueGap>2.45){gapBad=true;break}
      }
      if(gapBad)continue;
      const maxVal=Math.max(...sortedAnchors.map(a=>a.value)),
            minVal=Math.min(...sortedAnchors.map(a=>a.value));
      if(A.family==='Gain'&&(minVal<-.01||maxVal>4.01))continue;
      if(A.family==='Noise'&&(minVal<-.0001||maxVal>.0501))continue;
      const meanConf=conf/(2+support),
            directStrong=sortedAnchors.filter(a=>a.conf>=.16).length,
            spacingPenalty=Math.min(1.5,Math.abs(pxPerUnit-bestBase)/Math.max(1,bestBase)),
            score=meanConf+support*.10+Math.min(.14,directStrong*.045)-spacingPenalty*.10;
      if(directStrong<2)continue;
      if(!best||score>best.score)best={score,slope,intercept,family:A.family,anchors:sortedAnchors,pxPerUnit};
    }
  }
  return best;
}

function supportedSingleAxisAnchor(rows,bestBase,modeHint){
  let best=null;
  const families=modeHint==='Any'?['Gain','Noise']:[modeHint];
  for(const family of families){
    const unit=family==='Gain'?1:.01,
          tol=family==='Gain'?.38:.0042;
    for(const row of rows)for(const h of row.hyps){
      if(h.family!==family||h.conf<.13)continue;
      let support=0,score=h.conf,anchors=[{y:row.y,value:h.value,conf:h.conf,text:h.text,family}],
          totalChecked=0;
      for(const other of rows){
        if(other===row)continue;
        const gridSteps=Math.round((other.y-row.y)/bestBase);
        if(gridSteps===0||Math.abs(gridSteps)>5)continue;
        totalChecked++;
        const expected=h.value-gridSteps*unit;
        let hit=null;
        for(const q of other.hyps){
          if(q.family!==family)continue;
          const err=Math.abs(q.value-expected);
          if(err<=tol&&q.conf>=.045&&(!hit||q.conf>hit.conf))hit={...q,err};
        }
        if(hit){
          support++;
          score+=hit.conf*.8;
          anchors.push({y:other.y,value:hit.value,conf:hit.conf,text:hit.text,family});
        }
      }
      // A single OCR glyph is never enough anymore. Require at least one
      // neighboring grid row to weakly corroborate the expected numeric series.
      if(support<1)continue;
      score+=support*.10;
      if(!best||score>best.score)best={score,family,base:h,support,anchors};
    }
  }
  return best;
}
function axisCalibrationBounds(cal,centersAbs){
  if(!cal||!Array.isArray(centersAbs)||!centersAbs.length)return null;
  const values=centersAbs.map(y=>(cal.zeroY-y)/Math.max(1e-9,cal.stepPx)*cal.stepValue);
  return{
    min:Math.min(...values),
    max:Math.max(...values),
    values
  };
}
function yAxisCalibration(box,insets,modeHint='Any'){
  const g=EGSCore.geometry(box,insets),
        gx0=Math.max(0,Math.floor(g.x0)),gx1=Math.min(canvas.width,Math.ceil(g.x1)),
        gy0=Math.max(0,Math.floor(g.y0)),gy1=Math.min(canvas.height,Math.ceil(g.y1)),
        w=Math.max(1,gx1-gx0),h=Math.max(1,gy1-gy0),
        im=ctx.getImageData(gx0,gy0,w,h).data,row=new Uint32Array(h);

  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2]))row[y]++;
  }
  let centers=lineGroups(row,Math.max(6,w*(insets.source==='major-grid'?.20:.11))).filter(v=>v>=1&&v<=h-2);
  if(centers.length<2)return null;

  const merged=[];
  for(const y of centers){
    if(!merged.length||y-merged.at(-1)>Math.max(3,h*.022))merged.push(y);
    else merged[merged.length-1]=(merged.at(-1)+y)/2;
  }
  centers=merged;
  if(centers.length<2)return null;

  const diffs=[];
  for(let i=1;i<centers.length;i++){
    const d=centers[i]-centers[i-1];
    if(d>=Math.max(4,h*.055)&&d<=h*.55)diffs.push(d);
  }
  if(!diffs.length)return null;
  const bases=[];
  for(const d of diffs)for(const k of [1,2,3]){
    const b=d/k;if(b>=h*.055&&b<=h*.48)bases.push(b);
  }
  if(!bases.length)return null;
  let bestBase=null,bestErr=Infinity;
  for(const b of bases){
    const err=EGSCore.median(diffs.map(d=>{const m=Math.max(1,Math.round(d/b));return Math.abs(d-m*b)/b}));
    if(err<bestErr){bestErr=err;bestBase=b}
  }
  if(!Number.isFinite(bestBase)||bestBase<4||bestErr>.48)return null;

  // Read every visible Y label independently of the currently inferred mode.
  // This allows 3.0/2.0/1.0 to correct an erroneous Auto=Noise decision.
  const stripLeft=Math.max(box.x,g.x0-(g.x1-g.x0)*.42),
        stripRight=Math.min(g.x0-1,box.x+box.w*.42),
        rows=[];
  for(const cy of centers){
    const ay=gy0+cy,hh=Math.max(9,bestBase*.48),
          norm=observedAxisLabelNorm(stripLeft,ay-hh,stripRight-stripLeft,hh*2+1),
          hyps=axisLabelHypotheses(norm,modeHint==='Any'?'Any':modeHint,9);
    if(hyps.length)rows.push({
      y:ay,hyps,
      labelAspect:Number.isFinite(norm?._aspect)?norm._aspect:0,
      labelWidth:Number.isFinite(norm?._origW)?norm._origW:0,
      labelHeight:Number.isFinite(norm?._origH)?norm._origH:0
    });
  }

  const seq=fitAxisLabelSequence(rows,bestBase);

  // v1.8.5: grid gives spacing, but the zero row is solved from label/grid
  // ordinal consensus. Never assume the lowest detected major line is zero.
  const unit=modeHint==='Noise'?.01:1,
        centersAbs=centers.map(cy=>gy0+cy).sort((a,b)=>a-b);

  if((modeHint==='Gain'||modeHint==='Noise')&&centersAbs.length>=3){
    const idxs=centersAbs.map((_,i)=>i),
          mi=EGSCore.median(idxs),my=EGSCore.median(centersAbs),
          num=idxs.reduce((a,i,k)=>a+(i-mi)*(centersAbs[k]-my),0),
          den=idxs.reduce((a,i)=>a+(i-mi)*(i-mi),0),
          rowStep=den>0?num/den:bestBase,
          rowY0=my-rowStep*mi,
          gridResiduals=centersAbs.map((y,i)=>Math.abs(y-(rowY0+i*rowStep))/Math.max(1,bestBase)),
          regular=gridResiduals.filter(r=>r<=.24).length;

    if(regular>=Math.max(3,centersAbs.length-1)){
      const votes=[];
      for(const row of rows){
        let nearest=0,bd=Infinity;
        for(let i=0;i<centersAbs.length;i++){
          const d=Math.abs(centersAbs[i]-row.y);
          if(d<bd){bd=d;nearest=i}
        }
        if(bd>Math.abs(rowStep)*.46)continue;
        for(const h of row.hyps){
          if(h.family!==modeHint||h.conf<.14)continue;
          const q=h.value/unit;
          if(!Number.isFinite(q))continue;
          const qRound=Math.round(q);
          if(Math.abs(q-qRound)>.18)continue;
          const offset=nearest+qRound;
          votes.push({offset,rowIndex:nearest,y:row.y,value:h.value,conf:h.conf,text:h.text});
        }
      }

      if(votes.length>=2){
        const buckets=new Map();
        for(const v of votes){
          const b=buckets.get(v.offset)||{score:0,count:0,items:[]};
          b.score+=v.conf*v.conf;
          b.count++;
          b.items.push(v);
          buckets.set(v.offset,b);
        }
        const ranked=[...buckets.entries()].sort((a,b)=>b[1].score-a[1].score);
        const [zeroIndex,bestVote]=ranked[0],
              second=ranked[1]?.[1],
              decisive=bestVote.count>=2 && (!second || bestVote.score>=second.score*1.20);

        if(decisive){
          const zeroY=rowY0+zeroIndex*rowStep,
                anchors=bestVote.items.map(v=>({
                  y:v.y,value:v.value,conf:v.conf,text:v.text,
                  rowIndex:v.rowIndex,zeroIndex
                })),
                cal={
                  zeroY,
                  stepPx:Math.abs(rowStep),
                  stepValue:unit,
                  source:'zero-row-label-grid-consensus',
                  anchors,
                  fitScore:bestVote.score/Math.max(1,bestVote.count),
                  family:modeHint,
                  modeHint,
                  zeroRowIndex:zeroIndex,
                  gridResidual:EGSCore.median(gridResiduals),
                  labelAspect:EGSCore.median(bestVote.items.map(v=>{
                    const rr=rows.find(r=>Math.abs(r.y-v.y)<1.5);
                    return rr?.labelAspect||0;
                  }).filter(v=>v>0)),
                  labelWidths:bestVote.items.map(v=>{
                    const rr=rows.find(r=>Math.abs(r.y-v.y)<1.5);
                    return rr?.labelWidth||0;
                  }).filter(v=>v>0)
                };
          cal.gridBounds=axisCalibrationBounds(cal,centersAbs);
          cal.completedAnchors=completedAxisAnchorSeries(cal);
          return cal;
        }
      }
    }
  }
  return null;
}



function completedAxisAnchorSeries(cal){
  if(!cal?.anchors?.length)return[];
  const unit=cal.stepValue||1,
        a=[...cal.anchors].sort((x,y)=>y.value-x.value),
        out=[...a];
  for(let i=0;i<a.length-1;i++){
    const hi=a[i],lo=a[i+1],
          steps=Math.round((hi.value-lo.value)/unit);
    if(steps>1&&steps<=4){
      for(let k=1;k<steps;k++){
        const value=hi.value-k*unit,
              y=hi.y+(lo.y-hi.y)*(k/steps);
        if(!out.some(q=>Math.abs(q.value-value)<unit*.15))
          out.push({value,y,conf:Math.min(hi.conf||.1,lo.conf||.1)*.75,interpolated:true});
      }
    }
  }
  return out.sort((x,y)=>x.y-y.y);
}

function axisVisualFamilyEvidence(cal){
  if(!cal)return{Gain:0,Noise:0,aspect:0,widthMed:0};
  const aspect=cal.labelAspect||0,
        widths=cal.labelWidths||[],
        widthMed=widths.length?EGSCore.median(widths):0;
  let Gain=0,Noise=0;

  // Noise labels such as 0.04000 are much wider than Gain labels such as 3.0.
  // This direct glyph geometry prevents 0.04000 from being read as 4.0.
  if(aspect>=2.15){Noise+=.62;Gain-=.42}
  else if(aspect>=1.75){Noise+=.34;Gain-=.18}
  else if(aspect>0&&aspect<=1.48){Gain+=.34;Noise-=.16}

  if(widthMed>=24)Noise+=.18;
  else if(widthMed>0&&widthMed<=17)Gain+=.12;
  return{Gain,Noise,aspect,widthMed};
}

function axisHypothesisScore(cal,family,traceFeatures,traceMode){
  if(!cal)return -Infinity;
  const anchors=cal.anchors||[],n=anchors.length,
        meanConf=n?anchors.reduce((a,b)=>a+(b.conf||0),0)/n:0,
        vals=anchors.map(a=>Math.abs(a.value)).filter(Number.isFinite),
        medVal=vals.length?EGSCore.median(vals):0;
  let score=(cal.fitScore||meanConf||0)+Math.min(.30,n*.08)+Math.min(.18,meanConf*.55);

  // Numeric-scale context: Gain labels are typically order-unity (1.0,2.0,3.0);
  // Noise labels are small decimals. This is context, not a hard-coded axis top.
  const visual=axisVisualFamilyEvidence(cal);
  if(family==='Gain'){
    if(medVal>=.65)score+=.28;
    else if(medVal<.22)score-=.34;
    score+=(traceFeatures?.gainScore||0)*.18;
    score+=visual.Gain;
  }else{
    if(vals.length&&Math.max(...vals)<=.20)score+=.18;
    if(medVal>=.65)score-=.42;
    score+=(traceFeatures?.noiseScore||0)*.18;
    score+=visual.Noise;
  }
  if(traceMode===family)score+=.06;
  return score;
}
function visionAxisReasoning(box,insets,requestedMode,trace,modeInference){
  const features=modeInference?.features||normalizedModeFeatures(trace);

  // Manual mode is authoritative. Never allow the opposite OCR family.
  if(requestedMode==='Gain'||requestedMode==='Noise'){
    const cal=yAxisCalibration(box,insets,requestedMode);
    return{
      mode:requestedMode,cal,
      family:requestedMode,
      source:cal?'manual-mode-axis':'manual-mode-axis-unavailable',
      scores:{[requestedMode]:cal?axisHypothesisScore(cal,requestedMode,features,requestedMode):-Infinity},
      decisive:true
    };
  }

  const gainCal=yAxisCalibration(box,insets,'Gain'),
        noiseCal=yAxisCalibration(box,insets,'Noise'),
        traceMode=modeInference?.mode&&modeInference.mode!=='Unknown'?modeInference.mode:null,
        gainScore=axisHypothesisScore(gainCal,'Gain',features,traceMode),
        noiseScore=axisHypothesisScore(noiseCal,'Noise',features,traceMode);

  let family=traceMode||((features.gainScore||0)>=(features.noiseScore||0)?'Gain':'Noise'),
      cal=family==='Gain'?gainCal:noiseCal,
      decisive=false;

  if(Number.isFinite(gainScore)||Number.isFinite(noiseScore)){
    const gv=axisVisualFamilyEvidence(gainCal),
          nv=axisVisualFamilyEvidence(noiseCal),
          noiseVisual=Math.max(gv.Noise,nv.Noise),
          gainVisual=Math.max(gv.Gain,nv.Gain),
          visualDiff=gainVisual-noiseVisual,
          diff=gainScore-noiseScore;

    if(noiseCal&&visualDiff<-.28){family='Noise';cal=noiseCal;decisive=true}
    else if(gainCal&&visualDiff>.28){family='Gain';cal=gainCal;decisive=true}
    else if(diff>.16){family='Gain';cal=gainCal;decisive=true}
    else if(diff<-.16){family='Noise';cal=noiseCal;decisive=true}
    else cal=family==='Gain'?gainCal:noiseCal;
  }
  return{
    mode:family,cal,family,
    source:'vision-axis-reasoning',
    scores:{Gain:gainScore,Noise:noiseScore},
    decisive
  };
}

function calibrateTrack(track,box,insets,mode,calOverride=null){
  const cal=calOverride||yAxisCalibration(box,insets,mode);
  if(!cal)return{track,cal:null,pixels:null};
  const g=EGSCore.geometry(box,insets),h=Math.max(1,g.y1-g.y0),ys=track.ys||[],
        vals=track.vals.map((_,i)=>{
          let py;
          if(Number.isFinite(ys[i]))py=g.y0+(ys[i]/Math.max(1,h-1))*h;
          else py=g.y1-track.vals[i]*h;
          return Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue);
        });
  const out={...track,vals};let pixels=null;
  try{pixels=pixelLevelSummary(out,box,insets,cal)}catch(_){}
  return{track:out,cal,pixels};
}

function validateMeasuredCalibration(mode,cal,pixels,regions=null){
  if(!cal||!pixels||!Number.isFinite(pixels.low)||!Number.isFinite(pixels.high))
    return{ok:false,reason:'missing calibration or measured values'};
  const low=pixels.low,high=pixels.high,b=cal.gridBounds,
        aVals=(cal.anchors||[]).map(a=>a.value);
  if((cal.anchors?.length||0)<2)return{ok:false,reason:`${mode} axis lacks two calibration anchors`};
  if(mode==='Gain'){
    if(aVals.length&&(Math.min(...aVals)<0||Math.max(...aVals)>4))
      return{ok:false,reason:'Gain OCR anchors outside displayed scale'};
    if(high+0.04<low)return{ok:false,reason:`Gain calibration reversed Low/High (${low.toFixed(2)}>${high.toFixed(2)})`};
    if(low<0||high<0||low>3.6||high>3.6)
      return{ok:false,reason:'Gain measured values exceed displayed Energy scale'};
    if(b&&Number.isFinite(b.min)&&Number.isFinite(b.max)){
      const pad=Math.max(.45,cal.stepValue*.55),
            lo=Math.min(b.min,b.max)-pad,hi=Math.max(b.min,b.max)+pad;
      if(low<lo||low>hi||high<lo||high>hi)
        return{ok:false,reason:`Gain values outside visible grid span ${lo.toFixed(2)}..${hi.toFixed(2)}`};
    }
  }else{
    if(aVals.length&&(Math.min(...aVals)<0||Math.max(...aVals)>.0501))
      return{ok:false,reason:'Noise OCR anchors outside displayed small-decimal scale'};
    if(low<0||high<0||low>.055||high>.055)
      return{ok:false,reason:'Noise measured values exceed displayed Energy scale'};
  }
  return{ok:true};
}

function calibratedValueY(box,value,top,insets,cal){
  if(cal)return cal.zeroY-(value/cal.stepValue)*cal.stepPx;
  return EGSCore.valueY(box,value,top,insets);
}

function pixelLevelSummary(track,box,insets,cal){
  const g=EGSCore.geometry(box,insets),srcH=Math.max(1,(track.height||Math.round(g.y1-g.y0))-1),dstH=Math.max(1,g.y1-g.y0),sp=EGSCore.splitPixel(track.width);
  const robustMedianY=a=>{if(a.length<5)return NaN;let v=EGSCore.robust(a,3.0,1.0);if(v.length>=7){const lo=EGSCore.percentile(v,.08),hi=EGSCore.percentile(v,.92);v=v.filter(y=>y>=lo&&y<=hi)}return EGSCore.median(v)};
  const margins=[Math.max(3,track.width*.030),Math.max(2,track.width*.020),Math.max(1,track.width*.010)];
  let chosen=null;
  for(const margin of margins){
    const L=[],R=[];
    for(let i=0;i<track.xs.length;i++){
      if(!Number.isFinite(track.ys?.[i]))continue;
      const py=g.y0+(track.ys[i]/srcH)*dstH;
      if(track.xs[i]<=sp-margin)L.push(py);
      else if(track.xs[i]>=sp+margin)R.push(py);
    }
    if(L.length>=6&&R.length>=6){chosen={margin,L,R};break}
  }
  if(!chosen)throw Error('Noise Low/High trace positions do not contain enough samples around Sample#270');
  const lowY=robustMedianY(chosen.L),highY=robustMedianY(chosen.R);
  if(!Number.isFinite(lowY)||!Number.isFinite(highY))throw Error('Noise Low/High trace positions could not be stabilized');
  const toValue=py=>cal?Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue):NaN;
  return{lowY,highY,low:toValue(lowY),high:toValue(highY),leftN:chosen.L.length,rightN:chosen.R.length,marginPx:chosen.margin,source:'measured-trace-pixel-median'}
}

function gainAutoRegions(track){
  const n=track.xs.length;if(n<30)throw Error('Not enough Gain trace samples for automatic Low/High range detection');
  const pts=track.xs.map((x,i)=>({x,v:track.vals[i],y:track.ys?.[i]})).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.v)).sort((a,b)=>a.x-b.x);
  if(pts.length<30)throw Error('Not enough Gain trace samples for automatic Low/High range detection');
  // Bin the tracked foreground trace over X so irregularly missing pixels do not bias the change-point search.
  const bins=72,bv=Array.from({length:bins},()=>[]),bx=Array.from({length:bins},()=>[]);const xmin=pts[0].x,xmax=pts.at(-1).x,span=Math.max(1,xmax-xmin);
  for(const p of pts){const k=Math.min(bins-1,Math.max(0,Math.floor((p.x-xmin)/span*bins)));bv[k].push(p.v);bx[k].push(p.x)}
  const series=[];for(let k=0;k<bins;k++)if(bv[k].length)series.push({k,x:EGSCore.median(bx[k]),v:EGSCore.median(bv[k])});
  if(series.length<18)throw Error('Gain trace is too sparse for automatic Low/High range detection');
  // Mild median smoothing keeps the search insensitive to isolated spikes.
  const sm=series.map((p,i)=>{const a=[];for(let j=Math.max(0,i-2);j<=Math.min(series.length-1,i+2);j++)a.push(series[j].v);return{...p,sv:EGSCore.median(a)}});
  let best=null;
  for(let c=4;c<=sm.length-5;c++){
    const left=sm.slice(0,c).map(p=>p.sv),right=sm.slice(c).map(p=>p.sv),L=EGSCore.stableLevel(left,1),R=EGSCore.stableLevel(right,1);
    if(!Number.isFinite(L.median)||!Number.isFinite(R.median))continue;
    const diff=R.median-L.median,spread=Math.max(.004,(L.spread+R.spread)/2),balance=Math.min(c,sm.length-c)/Math.max(c,sm.length-c),score=Math.abs(diff)/(spread+.006)*(.55+.45*balance);
    // Gain normally has a low plateau followed by a higher plateau. Penalize the reverse, but do not make it impossible.
    const dir=diff>=0?1:.35,final=score*dir;if(!best||final>best.score)best={c,score:final,L,R,diff};
  }
  if(!best||best.score<1.15){
    // Gain rescue: do not stop on a visually clear trace merely because the
    // change-point score is low. Use stable outer plateaus and keep confidence low.
    const edgeN=Math.max(6,Math.floor(pts.length*.24)),
          lowPts0=pts.slice(0,edgeN),highPts0=pts.slice(-edgeN),
          low0=EGSCore.stableLevel(lowPts0.map(p=>p.v),1),
          high0=EGSCore.stableLevel(highPts0.map(p=>p.v),1);
    if(low0.n>=5&&high0.n>=5&&Number.isFinite(low0.mean)&&Number.isFinite(high0.mean)){
      return{
        low:low0.mean,high:high0.mean,confidence:.36,
        lowRange:{x0:pts[0].x,x1:lowPts0.at(-1).x},
        highRange:{x0:highPts0[0].x,x1:pts.at(-1).x},
        lowMeasureRange:{x0:lowPts0[0].x,x1:lowPts0.at(-1).x},
        highMeasureRange:{x0:highPts0[0].x,x1:highPts0.at(-1).x},
        transition:{x0:lowPts0.at(-1).x,x1:highPts0[0].x,cx:(lowPts0.at(-1).x+highPts0[0].x)/2},
        diagnostics:{change_score:best?.score||0,step:high0.mean-low0.mean,low_n:low0.n,high_n:high0.n,fallback:'outer-stable-plateaus'}
      };
    }
    throw Error('Gain Low/High regions could not be stabilized');
  }
  const cx=(sm[best.c-1].x+sm[best.c].x)/2;
  // Determine a transition band from local deviation around the change point; do not include it in either level calculation.
  const localStep=Math.abs(best.diff),tol=Math.max(.018,localStep*.18),lowMed=best.L.median,highMed=best.R.median;
  let li=best.c-1;while(li>1&&Math.abs(sm[li].sv-lowMed)>tol)li--;
  let ri=best.c;while(ri<sm.length-2&&Math.abs(sm[ri].sv-highMed)>tol)ri++;
  let lowEnd=sm[Math.max(1,li)].x,highStart=sm[Math.min(sm.length-2,ri)].x;
  if(!(lowEnd<highStart)){const gap=Math.max(3,track.width*.025);lowEnd=cx-gap;highStart=cx+gap}
  // Trim the outer edges and transition vicinity, then choose the most stable plateau samples.
  const xlo=pts[0].x,xhi=pts.at(-1).x,edge=Math.max(2,(xhi-xlo)*.025);
  let lowPts=pts.filter(p=>p.x>=xlo+edge&&p.x<=lowEnd),highPts=pts.filter(p=>p.x>=highStart&&p.x<=xhi-edge);
  const selectStable=(arr,target)=>{if(arr.length<6)return arr;const dev=arr.map(p=>Math.abs(p.v-target)),cut=EGSCore.percentile(dev,.80);return arr.filter((p,i)=>dev[i]<=cut)};
  lowPts=selectStable(lowPts,lowMed);highPts=selectStable(highPts,highMed);
  if(lowPts.length<5||highPts.length<5)throw Error('Gain Low/High stable regions are too short');
  const low=EGSCore.stableLevel(lowPts.map(p=>p.v),1),high=EGSCore.stableLevel(highPts.map(p=>p.v),1);
  return{low:low.mean,high:high.mean,confidence:EGSCore.clamp(.45+.16*Math.min(3,best.score)+.20*Math.min(lowPts.length,highPts.length)/Math.max(12,pts.length*.18),0,1),
    // Display the full stable plateau extent, but compute Y only from robust
    // stable samples. This matches human visual reading better than drawing the
    // min/max of the retained subset.
    lowRange:{x0:xlo+edge,x1:lowEnd},highRange:{x0:highStart,x1:xhi-edge},
    lowMeasureRange:{x0:Math.min(...lowPts.map(p=>p.x)),x1:Math.max(...lowPts.map(p=>p.x))},
    highMeasureRange:{x0:Math.min(...highPts.map(p=>p.x)),x1:Math.max(...highPts.map(p=>p.x))},
    transition:{x0:lowEnd,x1:highStart,cx},diagnostics:{change_score:best.score,step:best.diff,low_n:lowPts.length,high_n:highPts.length}}
}
function gainPixelLevelSummary(track,box,insets,cal,regions){
  const g=EGSCore.geometry(box,insets),srcH=Math.max(1,(track.height||Math.round(g.y1-g.y0))-1),dstH=Math.max(1,g.y1-g.y0),L=[],R=[],
        lm=regions.lowMeasureRange||regions.lowRange,hm=regions.highMeasureRange||regions.highRange;
  for(let i=0;i<track.xs.length;i++){
    if(!Number.isFinite(track.ys?.[i]))continue;
    const x=track.xs[i],py=g.y0+(track.ys[i]/srcH)*dstH;
    if(x>=lm.x0&&x<=lm.x1)L.push(py);
    else if(x>=hm.x0&&x<=hm.x1)R.push(py);
  }
  const robustMedianY=a=>{
    if(a.length<5)return NaN;
    let v=EGSCore.robust(a,3.0,1.0);
    if(v.length>=7){
      const lo=EGSCore.percentile(v,.08),hi=EGSCore.percentile(v,.92);
      v=v.filter(y=>y>=lo&&y<=hi);
    }
    return EGSCore.median(v);
  };
  const lowY=robustMedianY(L),highY=robustMedianY(R),
        toValue=py=>cal?Math.max(0,(cal.zeroY-py)/Math.max(1e-9,cal.stepPx)*cal.stepValue):NaN;
  return{lowY,highY,low:toValue(lowY),high:toValue(highY),leftN:L.length,rightN:R.length,
    source:'measured-trace-pixel-median'};
}

function normalizedModeFeatures(track){
  let gainScore=.15,gain=null;
  try{gain=gainAutoRegions(track);const step=gain.high-gain.low,sep=Math.abs(step),lowPos=EGSCore.clamp((.32-gain.low)/.32,0,1),stepScore=EGSCore.clamp((step-.06)/.28,0,1),stable=EGSCore.clamp(gain.confidence,0,1);gainScore=.35*lowPos+.42*stepScore+.23*stable}catch(_){}
  // Noise remains evaluated as a broad, low-amplitude trace. Its Low/High reporting still uses the Noise split rule.
  const lv=EGSCore.noiseLevels(track.xs,track.vals,1,track.width),low=lv.low,high=lv.high,delta=high-low,absDelta=Math.abs(delta),mean=(low+high)/2;
  const noiseLowBand=EGSCore.clamp((.42-mean)/.42,0,1),noiseFlat=EGSCore.clamp((.18-absDelta)/.18,0,1),noiseNoStep=EGSCore.clamp((.12-delta)/.22,0,1),noiseScore=.42*noiseLowBand+.38*noiseFlat+.20*noiseNoStep;
  return{low,high,delta,gainScore,noiseScore,levelConfidence:lv.confidence,gainRegions:gain}
}
function inferModeFromTrace(track,requested){
  if(requested!=='Auto')return{mode:requested,note:'',confidence:1,features:null};
  const f=normalizedModeFeatures(track),margin=Math.abs(f.gainScore-f.noiseScore),best=Math.max(f.gainScore,f.noiseScore);
  if(best<.50||margin<.08)return{mode:'Unknown',note:`Auto mode uncertain (Gain ${Math.round(f.gainScore*100)}% / Noise ${Math.round(f.noiseScore*100)}%). Select Gain or Noise manually.`,confidence:Math.max(.18,margin),features:f};
  const mode=f.gainScore>f.noiseScore?'Gain':'Noise';return{mode,note:`Auto mode: ${mode} from foreground signal shape (${Math.round(best*100)}%)`,confidence:EGSCore.clamp(.58+.42*margin,0,1),features:f}
}
function modeTop(mode){return mode==='Noise'?.04:mode==='Gain'?3.0:1}
function scaleTrack(track,top){return{...track,vals:track.vals.map(v=>v*top)}}
function rgbToHsv(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=((h*60)%360+360)%360}return{h,s:mx?d/mx:0,v:mx}}
function hueDistance(a,b){const d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function colorSamples(box,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,s=[];for(let y=0;y<h;y+=2)for(let x=0;x<w;x+=2){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],hsv=rgbToHsv(r,gg,b);if(isGreen(r,gg,b))continue;if(hsv.v>.34&&hsv.s>.22)s.push({h:hsv.h,s:hsv.s,v:hsv.v,r,g:gg,b})}return s}
function clusterTraceColors(box,insets){const pts=colorSamples(box,insets);if(!pts.length)return[];const bins=Array.from({length:24},()=>({n:0,s:0,v:0,rs:0,gs:0,bs:0}));for(const p of pts){const k=Math.floor(((p.h+7.5)%360)/15)%24,b=bins[k];b.n++;b.s+=p.s;b.v+=p.v;b.rs+=p.r;b.gs+=p.g;b.bs+=p.b}let peaks=bins.map((b,k)=>({k,...b})).filter(b=>b.n>=Math.max(8,pts.length*.008)&&b.s/b.n>.27&&b.v/b.n>.38).sort((a,b)=>b.n-a.n);const out=[];for(const p of peaks){const h=(p.k*15+7.5)%360;if(out.some(o=>hueDistance(o.h,h)<24))continue;out.push({h,n:p.n,s:p.s/p.n,v:p.v/p.n,r:p.rs/p.n,g:p.gs/p.n,b:p.bs/p.n});if(out.length>=8)break}return out}
function foregroundTraceForHue(box,top,mode,hue,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[],ysOut=[];let prev=null,miss=0,totalVisible=0,jumps=0;for(let x=0;x<w;x++){const ys=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2];if(isGreen(r,gg,b))continue;const q=rgbToHsv(r,gg,b);if(q.v>.34&&q.s>.23&&hueDistance(q.h,hue)<=22)ys.push({y,score:q.s*q.v*(1-hueDistance(q.h,hue)/30)});else if(prev!=null&&q.v>.72&&q.s<.22&&Math.abs(y-prev)<Math.max(3,h*.035))ys.push({y,score:.18})}if(!ys.length){miss++;continue}let chosen;if(prev==null||miss>9){ys.sort((a,b)=>b.score-a.score);const bestScore=ys[0].score;const cand=ys.filter(z=>z.score>=bestScore*.75).map(z=>z.y).sort((a,b)=>a-b);chosen=EGSCore.median(cand)}else{let best=null,bestCost=1e9;for(const z of ys){const dist=Math.abs(z.y-prev),cost=dist-Math.min(7,z.score*8);if(cost<bestCost){bestCost=cost;best=z}}chosen=best.y;if(Math.abs(chosen-prev)>h*.12)jumps++}prev=chosen;miss=0;totalVisible++;xs.push(x);ysOut.push(chosen);vals.push((1-chosen/Math.max(1,h-1))*top)}const coverage=totalVisible/Math.max(1,w),continuity=1-EGSCore.clamp(jumps/Math.max(1,totalVisible),0,1),sp=EGSCore.splitPixel(w),ln=xs.filter(x=>x<sp).length,rn=xs.filter(x=>x>=sp).length,leftCoverage=ln/Math.max(1,sp),rightCoverage=rn/Math.max(1,w-sp),balance=Math.sqrt(EGSCore.clamp(leftCoverage,0,1)*EGSCore.clamp(rightCoverage,0,1)),leftVals=vals.filter((_,i)=>xs[i]<sp),rightVals=vals.filter((_,i)=>xs[i]>=sp),lm=EGSCore.median(leftVals),rm=EGSCore.median(rightVals),shape=mode==='Gain'?(EGSCore.clamp((.45-(lm/top))/.45,0,1)*.55+EGSCore.clamp((rm/top)/.18,0,1)*.45):.65;return{hue,xs,vals,ys:ysOut,width:w,height:h,coverage,leftCoverage,rightCoverage,continuity,shape,score:.42*coverage+.22*continuity+.22*balance+.14*shape}}
function chooseForegroundTrace(box,top,mode,insets){const colors=clusterTraceColors(box,insets),tracks=[];for(const c of colors){const t=foregroundTraceForHue(box,1,'Auto',c.h,insets);if(t.vals.length<Math.max(22,t.width*.07))continue;let mf;try{mf=normalizedModeFeatures(t)}catch(_){mf={gainScore:.2,noiseScore:.2}}const plausible=mode==='Gain'?mf.gainScore:mode==='Noise'?mf.noiseScore:Math.max(mf.gainScore,mf.noiseScore);const dominance=EGSCore.clamp(c.n/Math.max(12,t.width*.35),0,1);t.score=.34*t.coverage+.23*t.continuity+.18*Math.sqrt(EGSCore.clamp(t.leftCoverage,0,1)*EGSCore.clamp(t.rightCoverage,0,1))+.15*dominance+.10*plausible;tracks.push({...t,color:c,modeFeatures:mf,dominance})}if(!tracks.length)throw Error('Foreground signal trace could not be isolated');tracks.sort((a,b)=>b.score-a.score);const best=tracks[0];best.alternates=tracks.slice(1,4).map(t=>({hue:Math.round(t.hue),coverage:t.coverage,score:t.score}));return best}
function genericTrace(box,top,mode,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[],ysOut=[];let prev=null,miss=0;for(let x=0;x<w;x++){const yy=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b),sat=mx-mn,white=(r+gg+b)>385&&mx>138&&sat<72,colored=mx>108&&sat>42;if(!isGreen(r,gg,b)&&(white||colored))yy.push(y)}if(!yy.length){miss++;continue}let py;if(prev==null||miss>6)py=EGSCore.median(yy);else{let best=yy[0],bd=Math.abs(best-prev);for(const y of yy){const d=Math.abs(y-prev);if(d<bd){best=y;bd=d}}py=bd<h*.18?best:EGSCore.median(yy)}prev=py;miss=0;xs.push(x);ysOut.push(py);vals.push((1-py/Math.max(1,h-1))*top)}if(vals.length<Math.max(25,w*.08))throw Error('Not enough signal pixels were found');return{xs,vals,ys:ysOut,width:w,height:h,coverage:vals.length/Math.max(1,w),continuity:.5,score:.5,hue:null}}

// Observed per-channel foreground colors from verification images.
// Only use entries that have actually been observed; unknown/unlearned colors
// must never be guessed. Hue distance is circular.
const CHANNEL_COLOR_MODEL = {
  2:{hue:300,tol:24,label:'purple/magenta'},
  3:{hue:4,tol:22,label:'red'},
  4:{hue:220,tol:24,label:'blue'},
  6:{hue:188,tol:22,label:'cyan'}
};
function hueDistance(a,b){
  if(!Number.isFinite(a)||!Number.isFinite(b))return Infinity;
  const d=Math.abs(a-b)%360;return Math.min(d,360-d);
}
function foregroundChannelFromHue(hue,selected){
  if(!Number.isFinite(hue)||!Array.isArray(selected)||selected.length<2)return null;
  let best=null;
  for(const ch of selected){
    const m=CHANNEL_COLOR_MODEL[ch];
    if(!m)continue;
    const d=hueDistance(hue,m.hue);
    if(d<=m.tol && (!best||d<best.distance))best={channel:ch,distance:d,model:m};
  }
  // Conservative uniqueness rule: if two selected known colors are similarly close,
  // do not invent a channel.
  if(!best)return null;
  let second=Infinity;
  for(const ch of selected){
    if(ch===best.channel||!CHANNEL_COLOR_MODEL[ch])continue;
    second=Math.min(second,hueDistance(hue,CHANNEL_COLOR_MODEL[ch].hue));
  }
  if(Number.isFinite(second)&&second-best.distance<8)return null;
  return best;
}
function channelDecision(channels,track){
  if(channels.length===1)return{channel:channels[0],source:'single checkbox',confidence:1,candidates:[...channels]};
  if(channels.length>1){
    const hit=foregroundChannelFromHue(track?.hue,channels);
    if(hit)return{channel:hit.channel,source:'foreground color matched checked channel',confidence:Math.max(.55,1-hit.distance/Math.max(1,hit.model.tol)),candidates:[...channels],colorDistance:hit.distance};
    return{channel:null,source:'foreground color did not match selected channels',confidence:track?.score||0,candidates:[...channels]};
  }
  return{channel:null,source:'no checked channel',confidence:track?.score||0,candidates:[]};
}

function exactAnalysisROI(box){
  // Convert the visible ROI to one authoritative canvas-pixel rectangle.
  // Every downstream stage receives this same rectangle; no stage is allowed
  // to independently floor/ceil the outer ROI boundary.
  const x0=EGSCore.clamp(Math.floor(box.x),0,Math.max(0,canvas.width-1)),
        y0=EGSCore.clamp(Math.floor(box.y),0,Math.max(0,canvas.height-1)),
        x1=EGSCore.clamp(Math.ceil(box.x+box.w),x0+1,canvas.width),
        y1=EGSCore.clamp(Math.ceil(box.y+box.h),y0+1,canvas.height);
  return{x:x0,y:y0,w:x1-x0,h:y1-y0,source:'exact-visible-roi-pixels'};
}

function analysisCropFingerprint(box){
  // Internal proof of what pixels are actually being analyzed.
  // This does not OCR or modify the image. It records a lightweight checksum
  // and exact bounds so a displayed ROI can be compared to the real crop.
  const b=exactAnalysisROI(box),
        im=ctx.getImageData(b.x,b.y,b.w,b.h).data,
        sx=Math.max(1,Math.floor(b.w/19)),
        sy=Math.max(1,Math.floor(b.h/13));
  let hash=2166136261>>>0,count=0;
  for(let y=0;y<b.h;y+=sy){
    for(let x=0;x<b.w;x+=sx){
      const i=(y*b.w+x)*4;
      hash^=im[i];hash=Math.imul(hash,16777619)>>>0;
      hash^=im[i+1];hash=Math.imul(hash,16777619)>>>0;
      hash^=im[i+2];hash=Math.imul(hash,16777619)>>>0;
      count++;
    }
  }
  return{...b,hash:hash.toString(16).padStart(8,'0'),samples:count};
}

function overlay(result){
  redrawSource();const b=result.analysisBox||result.box,g=EGSCore.geometry(b,result.insets),split=EGSCore.splitX(b,result.insets),tw=Math.max(1,g.x1-g.x0);
  // Red = full Energy-per-Band analysis panel. Cyan = inner numeric grid only.
  ctx.lineWidth=Math.max(2,canvas.width/500);ctx.strokeStyle='#ff3c4b';ctx.strokeRect(b.x,b.y,b.w,b.h);
  const dbgPlot=result?.diagnostics?.v2_plot;
  if(dbgPlot){ctx.save();ctx.lineWidth=Math.max(1.5,canvas.width/700);ctx.strokeStyle='#00d4ff';ctx.setLineDash([5,4]);ctx.strokeRect(dbgPlot.x,dbgPlot.y,dbgPlot.w,dbgPlot.h);ctx.restore();}
  if(result.mode==='Gain'&&result.gainRegions){const xr=x=>g.x0+(x/Math.max(1,result.trace.width-1))*tw,a=xr(result.gainRegions.lowRange.x0),c=xr(result.gainRegions.lowRange.x1),d=xr(result.gainRegions.highRange.x0),e=xr(result.gainRegions.highRange.x1);ctx.strokeStyle='#ffd23f';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(c,g.y0);ctx.lineTo(c,g.y1);ctx.moveTo(d,g.y0);ctx.lineTo(d,g.y1);ctx.stroke();ctx.setLineDash([]);result._gainDraw={a,c,d,e}}else{ctx.strokeStyle='#ffd23f';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(split,g.y0);ctx.lineTo(split,g.y1);ctx.stroke();ctx.setLineDash([]);}
  // Show the actually tracked foreground trace, so the user can verify which line was measured.
  if(result.trace&&result.trace.ys&&result.trace.ys.length){const tw=Math.max(1,g.x1-g.x0),th=Math.max(1,g.y1-g.y0),srcH=Math.max(1,(result.trace.height||Math.round(th))-1);ctx.fillStyle='rgba(255,255,255,.78)';const step=Math.max(1,Math.floor(result.trace.xs.length/90));for(let i=0;i<result.trace.xs.length;i+=step){const x=g.x0+(result.trace.xs[i]/Math.max(1,result.trace.width-1))*tw,y=g.y0+(result.trace.ys[i]/srcH)*th;ctx.fillRect(x-1,y-1,2,2)}}

  // Core v2.0.3: visualize the exact Noise grid/value path.
  const nd=result?.diagnostics||{},na=nd.v2_noise_axis,nv=nd.v2_noise_values,np=nd.v2_plot;
  if(na?.ok&&np){
    ctx.save();ctx.font=`${Math.max(10,canvas.width/80)}px sans-serif`;
    for(const a of na.anchors||[]){
      ctx.setLineDash([6,5]);ctx.lineWidth=Math.max(1.5,canvas.width/700);
      ctx.strokeStyle='#00d4ff';ctx.beginPath();ctx.moveTo(np.x,a.y);ctx.lineTo(np.x+np.w,a.y);ctx.stroke();
      ctx.setLineDash([]);ctx.fillStyle='#00d4ff';
      ctx.fillText(a.value.toFixed(2)+(a.inferred?'*':''),np.x+4,Math.max(12,a.y-3));
    }
    if(nv?.ok){
      ctx.lineWidth=Math.max(2,canvas.width/600);ctx.setLineDash([]);
      ctx.strokeStyle='#ffffff';ctx.beginPath();ctx.moveTo(np.x,nv.lowY);ctx.lineTo(nv.splitX,nv.lowY);ctx.stroke();
      ctx.strokeStyle='#ff9f0a';ctx.beginPath();ctx.moveTo(nv.splitX,nv.highY);ctx.lineTo(np.x+np.w,nv.highY);ctx.stroke();
      ctx.setLineDash([5,4]);ctx.strokeStyle='#ffd60a';ctx.beginPath();ctx.moveTo(nv.splitX,np.y);ctx.lineTo(nv.splitX,np.y+np.h);ctx.stroke();
    }
    ctx.restore();
  }

  const ly=result.pixelLevels&&Number.isFinite(result.pixelLevels.lowY)?result.pixelLevels.lowY:null,
        hy=result.pixelLevels&&Number.isFinite(result.pixelLevels.highY)?result.pixelLevels.highY:null;
  if(ly==null||hy==null)return;
  ctx.strokeStyle='#00bff3';ctx.beginPath();if(result.mode==='Gain'&&result._gainDraw){ctx.moveTo(result._gainDraw.a,ly);ctx.lineTo(result._gainDraw.c,ly)}else{ctx.moveTo(g.x0,ly);ctx.lineTo(split,ly)}ctx.stroke();ctx.strokeStyle='#ff7f27';ctx.beginPath();if(result.mode==='Gain'&&result._gainDraw){ctx.moveTo(result._gainDraw.d,hy);ctx.lineTo(result._gainDraw.e,hy)}else{ctx.moveTo(split,hy);ctx.lineTo(g.x1,hy)}ctx.stroke();
}
function analyze(){if(!sourceImage||!roi)return;try{
  // Freeze the red visible ROI into exact canvas pixels before doing anything.
  // From this point on, visible ROI == analyzed crop.
  const analysisROI=exactAnalysisROI(roi),
        cropMeta=analysisCropFingerprint(analysisROI);
  roi={...analysisROI};
  renderROI();
  redrawSource();

  // Stage 1 — Channel checkbox interpretation is independent from plot certainty
  // and must always run first.
  const channels=checkedChannels(analysisROI);

  // Stage 2 — Analysis Core v2:
  // the red ROI is a search envelope; numeric analysis uses the independently
  // localized Energy-per-Band plot context.
  const v2=EGSAnalysisV2.prepare(ctx,canvas,analysisROI);
  if(!v2){
    const partial={mode:els.mode.value==='Auto'?'Unknown':els.mode.value,provisional:true,
      channels,channel:channels.length===1?channels[0]:null,
      channelSource:channels.length===1?'single checked channel':'plot not localized',
      low:NaN,high:NaN,confidence:.15,box:{...analysisROI},analysisBox:{...analysisROI},
      top:1,insets:{left:0,top:0,right:0,bottom:0,source:'v2-no-plot'},
      axisCal:null,pixelLevels:null,gainRegions:null,trace:null,
      diagnostics:{analysis_crop:cropMeta,analysis_core:'v2'},
      message:'Analysis Core v2: Energy per Band plot could not be localized. Numeric result withheld.'};
    currentResult=partial;overlay(partial);showResult(partial);
    setStatus('Energy per Band plotを確定できませんでした。数値のみ保留しました。');
    return;
  }
  const analysisBox=v2.context,insets=v2.insets;

  let normTrack,fgUsed=false,trackError=null;
  try{
    normTrack=chooseForegroundTrace(analysisBox,1,els.mode.value==='Auto'?'Auto':els.mode.value,insets);
    fgUsed=true;
  }catch(e){
    trackError=e;
    // Multiple checked channels no longer stop analysis. Try a generic signal
    // trace and keep Channel=Unknown if foreground color cannot be resolved.
    normTrack=genericTrace(analysisBox,1,'Auto',insets);
  }

  // Channel result is available as soon as foreground hue exists.
  let earlyDecision=channelDecision(channels,normTrack);

  let mi=inferModeFromTrace(normTrack,els.mode.value),provisional=false;
  if(els.mode.value==='Auto'&&v2.axisFamily?.family&&v2.axisFamily.confidence>=.58){
    mi={...mi,mode:v2.axisFamily.family,
        confidence:Math.max(mi.confidence||0,v2.axisFamily.confidence),
        note:`Auto mode from Core v2 Y-axis: ${v2.axisFamily.family} (${Math.round(v2.axisFamily.confidence*100)}%)`,
        axisFamilyAuthoritative:true};
  }
  if(mi.mode==='Unknown'){
    if(els.mode.value!=='Auto')throw Error('Mode could not be determined.');
    const f=mi.features||normalizedModeFeatures(normTrack);
    const pick=(f.gainScore||0)>=(f.noiseScore||0)?'Gain':'Noise';
    mi={...mi,mode:pick,confidence:Math.max(f.gainScore||0,f.noiseScore||0),note:`Provisional Auto ${pick}: confirm mode before SPEC`,features:f};
    provisional=true;
  }

  // Vision-style context reasoning: manual mode is authoritative; Auto compares
  // separate Gain/Noise axis hypotheses with trace shape and grid-step consistency.
  if(mi.mode==='Noise' && !v2.noiseAxis?.ok){
    v2.noiseAxis=EGSAnalysisV2.noiseAxisSeries(ctx,canvas,v2);
  }
  if(mi.mode==='Noise'){
    if(!v2.noiseTrace?.ok)v2.noiseTrace=EGSAnalysisV2.directNoiseTrace(ctx,canvas,v2);
    if(v2.noiseAxis?.ok&&v2.noiseTrace?.ok)
      v2.noiseValues=EGSAnalysisV2.directNoiseValues(v2,v2.noiseTrace);
  }

  let axisReason=visionAxisReasoning(analysisBox,insets,(els.mode.value==='Auto'&&mi.axisFamilyAuthoritative)?mi.mode:els.mode.value,normTrack,mi),
      axisProbe=axisReason.cal;
  const robustMode=EGSRobustV3.resolveMode(els.mode.value,v2,mi.mode,axisReason);
  if(els.mode.value==='Auto'&&(robustMode.value==='Gain'||robustMode.value==='Noise')){
    mi={...mi,mode:robustMode.value,confidence:Math.max(mi.confidence||0,robustMode.score||0),
        note:`Robust Core v3 mode consensus: ${robustMode.value} (${Math.round((robustMode.score||0)*100)}%)`};
  }
  if(els.mode.value==='Auto' && !mi.axisFamilyAuthoritative && axisReason.mode && axisReason.mode!==mi.mode){
    mi={...mi,mode:axisReason.mode,
        confidence:Math.max(mi.confidence||0,axisReason.decisive?.80:.58),
        note:`Auto mode ${axisReason.decisive?'corrected':'kept'} as ${axisReason.mode} by vision-style axis reasoning`};
    provisional=!axisReason.decisive;
  }else if(els.mode.value!=='Auto'){
    mi={...mi,mode:els.mode.value,confidence:1,note:`Manual ${els.mode.value} authoritative`};
    provisional=false;
  }

  // Re-rank the foreground trace after the final mode selection. Failure is non-fatal.
  if(fgUsed||channels.length>1){
    try{
      normTrack=chooseForegroundTrace(analysisBox,1,mi.mode,insets);
      fgUsed=true;
      earlyDecision=channelDecision(channels,normTrack);
    }catch(_){}
  }

  const top=modeTop(mi.mode),scaled=scaleTrack(normTrack,top),
        calibrated=calibrateTrack(scaled,analysisBox,insets,mi.mode,axisProbe),
        tr=calibrated.track,
        decision=channelDecision(channels,tr),
        robustChannel=EGSRobustV3.resolveChannel(channels,decision?.channel),
        digits=mi.mode==='Noise'?4:2,msg=[];
  let axisCal=calibrated.cal;
  if(mi.mode==='Noise'&&v2.noiseAxis?.ok){
    axisCal={
      zeroY:v2.noiseAxis.zeroY,
      stepPx:v2.noiseAxis.stepPx,
      stepValue:v2.noiseAxis.stepValue,
      source:v2.noiseAxis.source,
      anchors:v2.noiseAxis.anchors,
      fitScore:v2.noiseAxis.confidence,
      family:'Noise',
      modeHint:'Noise',
      gridBounds:{min:0,max:.05}
    };
  }

  // Y-axis numeric calibration remains required for numeric/SPEC output, but
  // channel/mode/trace analysis has already completed and is never lost.
  if(!axisCal){
    const partial={
      mode:mi.mode,provisional:true,channels,channel:(robustChannel?.value==='Unknown'?null:robustChannel?.value),
      channelSource:robustChannel?.source||decision.source,low:NaN,high:NaN,
      confidence:EGSCore.clamp((tr.score||.3)*.55,0,1),box:{...analysisROI},analysisBox:{...analysisBox},top,insets,
      axisCal:null,pixelLevels:null,gainRegions:null,
      trace:{xs:[...tr.xs],ys:[...tr.ys||[]],width:tr.width,height:tr.height},
      diagnostics:{mode_features:mi.features,foreground_hue:tr.hue,foreground_coverage:tr.coverage,foreground_continuity:tr.continuity,analysis_crop:cropMeta,analysis_core:'v2',v2_plot:v2.plot,v2_axis_family:v2.axisFamily,v2_noise_axis:v2.noiseAxis,v2_noise_trace:v2.noiseTrace,v2_noise_values:v2.noiseValues},
      message:`Plot geometry: ${insets.source}; Channel: ${decision.channel!=null?'CH'+decision.channel:'Unknown'} (${decision.source}); Y-axis labels could not be calibrated. Numeric Low/High withheld.`
    };
    currentResult=partial;overlay(partial);showResult(partial);
    setStatus('Trace/Channel解析は完了。Y軸数値を読み取れないためLow/High数値のみ保留。');
    return;
  }

  const robustNoiseNumeric=mi.mode==='Noise'?EGSRobustV3.resolveNoiseNumeric(v2):null;
  let gainRegions=null,lv,pixelLevels=calibrated.pixels;
  if(mi.mode==='Noise'&&robustNoiseNumeric?.value){
    pixelLevels={...robustNoiseNumeric.value,source:'robust-core-v3-noise-consensus'};
  }
  if(mi.mode==='Noise'&&v2.noiseValues?.ok){
    pixelLevels={low:v2.noiseValues.low,high:v2.noiseValues.high,
                 lowY:v2.noiseValues.lowY,highY:v2.noiseValues.highY,
                 source:'v2.0.4-structural-noise-grid-mapping'};
  }else if(mi.mode==='Noise'&&v2.noiseAxis?.ok&&tr?.points?.length){
    const g=EGSCore.geometry(analysisBox,insets),
          xSplit=g.x0+(g.x1-g.x0)*(EGSCore.SAMPLE_SPLIT/EGSCore.SAMPLE_AXIS_MAX),
          lowVals=[],highVals=[];
    for(const pt of tr.points){
      if(!Number.isFinite(pt.x)||!Number.isFinite(pt.y))continue;
      const v=EGSAnalysisV2.pixelYToValue(pt.y,v2.noiseAxis);
      if(!Number.isFinite(v))continue;
      if(pt.x<xSplit)lowVals.push(v); else highVals.push(v);
    }
    if(lowVals.length>=5&&highVals.length>=5){
      pixelLevels={low:EGSCore.median(lowVals),high:EGSCore.median(highVals),
                   source:'v2-noise-major-grid-series-fallback'};
    }
  }
  if(mi.mode==='Gain'){
    gainRegions=gainAutoRegions(tr);
    lv={low:gainRegions.low,high:gainRegions.high,confidence:gainRegions.confidence,diagnostics:gainRegions.diagnostics};
    pixelLevels=gainPixelLevelSummary(tr,analysisBox,insets,axisCal,gainRegions);
  }else{
    // Noise: Low/High are positional regions around semantic Sample#270.
    // Their amplitudes may be almost identical; no level separation is required.
    lv=EGSCore.noiseLevels(tr.xs,tr.vals,top,tr.width);
    msg.push(`Noise ranges: Sample#0-${EGSCore.SAMPLE_SPLIT} / ${EGSCore.SAMPLE_SPLIT}-${EGSCore.SAMPLE_AXIS_MAX}; amplitude separation not required`);
  }

  if(mi.note)msg.push(mi.note);
  msg.push(`Robust Core v3 + Analysis Providers: ${v2.plot.source}; Y-axis ${v2.axisFamily?.family||'Unknown'} ${Math.round((v2.axisFamily?.confidence||0)*100)}% (${v2.axisFamily?.reason||'n/a'})`); if(v2.noiseAxis?.ok)msg.push(`Noise grid series: ${v2.noiseAxis.anchors.map(a=>a.value.toFixed(2)+'@'+Math.round(a.y)+(a.inferred?'[infer]':'')).join(', ')}`);
  if(v2.noiseValues?.ok)msg.push(`Direct Noise values: Low ${v2.noiseValues.low.toFixed(4)} / High ${v2.noiseValues.high.toFixed(4)} (${v2.noiseValues.lowCount}/${v2.noiseValues.highCount} samples)`); msg.push(`Plot geometry: ${insets.source}`);
  msg.push(`Axis reasoning: Gain ${Number.isFinite(axisReason?.scores?.Gain)?axisReason.scores.Gain.toFixed(2):'—'} / Noise ${Number.isFinite(axisReason?.scores?.Noise)?axisReason.scores.Noise.toFixed(2):'—'}; selected ${mi.mode}${els.mode.value==='Auto'?'':' (manual)'}`);
  msg.push(`Y calibration: ${axisCal.source}; family ${axisCal.family||mi.mode}; anchors ${axisCal.anchors?.map(a=>a.value+'@'+Math.round(a.y)+'('+Math.round((a.conf||0)*100)+'%)').join(', ')||'none'}`);

  if(channels.length===1){
    msg.push(`Single checked channel CH${channels[0]} prioritized`);
  }else if(channels.length>1){
    msg.push(`Checked candidates: ${channels.map(c=>'CH'+c).join(', ')}`);
    if(decision.channel!=null)msg.push(`Foreground color matched CH${decision.channel}`);
    else msg.push('Foreground color did not match a selected known channel; Channel=Unknown');
  }else{
    msg.push('No checked channel resolved; Channel=Unknown');
  }
  if(trackError)msg.push('Foreground-specific tracking failed once; generic trace fallback used');
  if(fgUsed&&Number.isFinite(tr.hue))msg.push(`Foreground hue ${Math.round(tr.hue)}°, visibility ${Math.round(tr.coverage*100)}%`);

  const modeConfidence=els.mode.value==='Auto'?mi.confidence:1,
        axisAnchorFactor=Math.min(1,.55+.17*(axisCal?.anchors?.length||0)+.20*Math.min(1,axisCal?.fitScore||0)),
        confidence=EGSCore.clamp(lv.confidence*(fgUsed?(.72+.28*tr.score):.72)*(.72+.28*modeConfidence)*axisAnchorFactor,0,1);

  if(!pixelLevels||!Number.isFinite(pixelLevels.low)||!Number.isFinite(pixelLevels.high)){
    throw Error('Trace pixel levels could not be calibrated. No numeric result was produced.');
  }

  const calCheck=validateMeasuredCalibration(mi.mode,axisCal,pixelLevels,gainRegions);
  if(!calCheck.ok){
    const partial={
      mode:mi.mode,provisional:true,channels,channel:(robustChannel?.value==='Unknown'?null:robustChannel?.value),
      channelSource:robustChannel?.source||decision.source,low:NaN,high:NaN,
      confidence:EGSCore.clamp(confidence*.55,0,1),box:{...analysisROI},analysisBox:{...analysisBox},top,insets,
      axisCal:null,pixelLevels:null,gainRegions,
      trace:{xs:[...tr.xs],ys:[...tr.ys||[]],width:tr.width,height:tr.height},
      diagnostics:{...lv.diagnostics,mode_features:mi.features,foreground_hue:tr.hue,foreground_coverage:tr.coverage,foreground_continuity:tr.continuity,analysis_crop:cropMeta,analysis_core:'v2',v2_plot:v2.plot,v2_axis_family:v2.axisFamily,v2_noise_axis:v2.noiseAxis,v2_noise_trace:v2.noiseTrace,v2_noise_values:v2.noiseValues},
      message:`Trace/Channel/Mode retained; numeric calibration rejected: ${calCheck.reason}; Axis candidate ${axisCal.source}; anchors ${axisCal.anchors?.map(a=>a.value+'@'+Math.round(a.y)+'('+Math.round((a.conf||0)*100)+'%)').join(', ')||'none'}`
    };
    currentResult=partial;overlay(partial);showResult(partial);
    setStatus('Trace/Channel解析は完了。Y軸校正候補が波形と矛盾したためLow/High数値のみ保留。');
    return;
  }

  msg.push(`Exact analysis ROI: x=${cropMeta.x}, y=${cropMeta.y}, w=${cropMeta.w}, h=${cropMeta.h}, crop#${cropMeta.hash}`);
  const lowValue=pixelLevels.low,highValue=pixelLevels.high;
  if(mi.mode==='Gain'&&gainRegions)msg.push(`Gain ranges auto-detected: Low ${Math.round(gainRegions.lowRange.x0)}-${Math.round(gainRegions.lowRange.x1)}, High ${Math.round(gainRegions.highRange.x0)}-${Math.round(gainRegions.highRange.x1)}`);

  currentResult={
    mode:mi.mode,provisional,channels,channel:decision.channel,channelSource:decision.source,
    low:+lowValue.toFixed(digits),high:+highValue.toFixed(digits),confidence,
    box:{...analysisROI},analysisBox:{...analysisBox},top,insets,axisCal,pixelLevels,gainRegions,
    trace:{xs:[...tr.xs],ys:[...tr.ys||[]],width:tr.width,height:tr.height},
    diagnostics:{...lv.diagnostics,mode_features:mi.features,foreground_hue:tr.hue,foreground_coverage:tr.coverage,foreground_continuity:tr.continuity,analysis_crop:cropMeta,analysis_core:'v2',v2_plot:v2.plot,v2_axis_family:v2.axisFamily,v2_noise_axis:v2.noiseAxis,v2_noise_trace:v2.noiseTrace,v2_noise_values:v2.noiseValues},
    message:msg.join('; ')
  };
  overlay(currentResult);showResult(currentResult);setStatus('Analysis complete.');
}catch(e){redrawSource();renderROI();setStatus(e.message||String(e));}}
function showResult(r){els.result.classList.remove('hidden');$('modeOut').textContent=r.mode;$('channelOut').textContent=r.channel!=null?`CH${r.channel}`:'Unknown';$('confidenceOut').textContent=`${Math.round(r.confidence*100)}%`;if(r.mode==='Unknown'||!Number.isFinite(r.low)||!Number.isFinite(r.high)){$('lowOut').textContent='—';$('highOut').textContent='—';const sp=$('specOut');sp.textContent='—';sp.className='';$('messageOut').textContent=r.message||'Select Gain or Noise manually.';return}$('lowOut').textContent=r.mode==='Noise'?r.low.toFixed(4):r.low.toFixed(2);$('highOut').textContent=r.mode==='Noise'?r.high.toFixed(4):r.high.toFixed(2);const sp=$('specOut');if(r.provisional){sp.textContent='—';sp.className='';$('messageOut').textContent=(r.message?r.message+'; ':'')+'Auto mode is provisional. Select Gain or Noise to enable SPEC.';return}const ok=EGSCore.spec(r.mode,r.low,r.high);sp.textContent=ok?'IN':'OUT';sp.className=ok?'spec-in':'spec-out';$('messageOut').textContent=r.message||'—'}
if('serviceWorker' in navigator){
  window.addEventListener('load',async()=>{
    try{
      const reg=await navigator.serviceWorker.register('./sw.js',{scope:'./'});
      await navigator.serviceWorker.ready;
      // Ask the browser to check for an updated offline bundle whenever the app opens online.
      if(navigator.onLine)reg.update().catch(()=>{});
    }catch(e){console.warn('Offline service worker unavailable',e)}
  });
}
window.addEventListener('online',()=>setStatus(sourceImage?'Online — analysis ready':'Online — app ready'));
window.addEventListener('offline',()=>setStatus(sourceImage?'Offline — local analysis ready':'Offline — app ready'));
