
((root,factory)=>{
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.EGSAnalysisV2=api;
})(typeof window!=='undefined'?window:globalThis,()=>{

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const median=a=>{
    const b=[...a].filter(Number.isFinite).sort((x,y)=>x-y),n=b.length;
    if(!n)return NaN;
    return n%2?b[(n-1)/2]:(b[n/2-1]+b[n/2])/2;
  };

  function greenish(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3;
    return g>34&&(
      (g>r*1.045&&g>b*.96&&g-Math.max(r,b)>3)||
      (lum>42&&sat>20&&g>=mx-3)
    );
  }
  const dark=(r,g,b)=>(r+g+b)/3<112;

  function groups(scores,threshold,maxGap=2){
    const ids=[],out=[];
    for(let i=0;i<scores.length;i++)if(scores[i]>=threshold)ids.push(i);
    for(const v of ids){
      if(!out.length||v-out.at(-1).at(-1)>maxGap)out.push([v]);
      else out.at(-1).push(v);
    }
    return out.map(g=>g.reduce((a,b)=>a+b,0)/g.length);
  }

  function regularRun(values,minGap,maxGap){
    if(values.length<3)return null;
    let best=null;
    for(let i=0;i<values.length-2;i++)for(let j=i+1;j<values.length-1;j++){
      const gap=values[j]-values[i];
      if(gap<minGap||gap>maxGap)continue;
      const seq=[values[i],values[j]];
      let last=values[j],err=0;
      for(let k=j+1;k<values.length;k++){
        const d=values[k]-last;
        if(Math.abs(d-gap)<=Math.max(2,gap*.28)){
          seq.push(values[k]);err+=Math.abs(d-gap)/Math.max(1,gap);last=values[k];
        }
      }
      if(seq.length<3)continue;
      const score=seq.length*4+(seq.at(-1)-seq[0])/Math.max(1,gap)-err;
      if(!best||score>best.score)best={seq,gap,score};
    }
    return best;
  }

  function plotFromGrid(ctx,canvas,roi){
    const x0=Math.max(0,Math.floor(roi.x)),
          y0=Math.max(0,Math.floor(roi.y)),
          w=Math.max(2,Math.min(canvas.width-x0,Math.ceil(roi.w))),
          h=Math.max(2,Math.min(canvas.height-y0,Math.ceil(roi.h))),
          im=ctx.getImageData(x0,y0,w,h).data,
          row=new Uint32Array(h),col=new Uint32Array(w),
          darkRow=new Uint32Array(h),darkCol=new Uint32Array(w);

    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenish(r,g,b)){row[y]++;col[x]++}
      if(dark(r,g,b)){darkRow[y]++;darkCol[x]++}
    }

    const rows=groups(row,Math.max(6,w*.20)),
          cols=groups(col,Math.max(6,h*.19)),
          rr=regularRun(rows,Math.max(5,h*.045),h*.30),
          cc=regularRun(cols,Math.max(6,w*.045),w*.25);

    let top,bottom,left,right,source='';
    if(rr&&cc){
      top=rr.seq[0];bottom=rr.seq.at(-1);
      left=cc.seq[0];right=cc.seq.at(-1);
      source='grid-lattice';
    }else{
      const rids=[],cids=[];
      for(let y=0;y<Math.floor(h*.78);y++)if(darkRow[y]>w*.28)rids.push(y);
      for(let x=Math.floor(w*.34);x<w;x++)if(darkCol[x]>h*.16)cids.push(x);
      if(rids.length&&cids.length){
        top=Math.min(...rids);bottom=Math.max(...rids);
        left=Math.min(...cids);right=Math.max(...cids);
        source='dark-rectangle';
      }
    }
    if(![top,bottom,left,right].every(Number.isFinite))return null;
    if(right-left<w*.26||bottom-top<h*.16)return null;

    const near=(arr,target,rad)=>{
      let best=target,score=-1;
      const a=Math.max(0,Math.floor(target-rad)),b=Math.min(arr.length-1,Math.ceil(target+rad));
      for(let i=a;i<=b;i++)if(arr[i]>score){best=i;score=arr[i]}
      return best;
    };
    top=near(row,top,Math.max(3,h*.035));
    bottom=near(row,bottom,Math.max(3,h*.035));
    left=near(col,left,Math.max(3,w*.035));
    right=near(col,right,Math.max(3,w*.035));

    const plot={x:x0+left,y:y0+top,w:right-left,h:bottom-top,
                x0:x0+left,y0:y0+top,x1:x0+right,y1:y0+bottom,source};
    const aspect=plot.w/Math.max(1,plot.h);
    if(aspect<1.25||aspect>4.5)return null;

    // v2.0.4: the grid lattice is NOT the whole Energy-per-Band panel.
    // Keep plot for numeric geometry, but expand context to include Y labels/title/X labels.
    const lp=Math.max(28,plot.w*.40),rp=Math.max(10,plot.w*.10),
          tp=Math.max(10,plot.h*.18),bp=Math.max(18,plot.h*.36),
          cx0=clamp(plot.x-lp,0,canvas.width-2),
          cy0=clamp(plot.y-tp,0,canvas.height-2),
          cx1=clamp(plot.x+plot.w+rp,cx0+2,canvas.width),
          cy1=clamp(plot.y+plot.h+bp,cy0+2,canvas.height),
          context={x:cx0,y:cy0,w:cx1-cx0,h:cy1-cy0},
          insets={
            left:(plot.x-context.x)/context.w,
            top:(plot.y-context.y)/context.h,
            right:(context.x+context.w-(plot.x+plot.w))/context.w,
            bottom:(context.y+context.h-(plot.y+plot.h))/context.h,
            source:'v2-normalized-plot-context'
          };
    return{plot,context,insets,rows,cols,
      gridRowsAbs:rr?.seq?.map(y=>y0+y)||[],
      gridColsAbs:cc?.seq?.map(x=>x0+x)||[],
      gridStepY:rr?.gap||NaN,gridStepX:cc?.gap||NaN};
  }

  function axisStripFamily(ctx,canvas,q){
    if(!q)return{family:null,confidence:0,reason:'no plot'};
    const p=q.plot,
          step=Number.isFinite(q.gridStepY)?q.gridStepY:Math.max(8,p.h/4),
          sx0=Math.max(0,Math.floor(p.x-p.w*.27)),
          sx1=Math.max(sx0+4,Math.floor(p.x-p.w*.015)),
          sw=sx1-sx0,
          count=Math.max(3,Math.min(7,Math.round(p.h/step)+1)),
          aspects=[],widths=[];

    for(let k=0;k<count;k++){
      const cy=p.y+k*(p.h/Math.max(1,count-1)),
            y0=Math.max(0,Math.floor(cy-step*.34)),
            y1=Math.min(canvas.height,Math.ceil(cy+step*.34)),
            h=Math.max(1,y1-y0),
            im=ctx.getImageData(sx0,y0,sw,h).data;
      let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity,n=0;
      for(let y=0;y<h;y++)for(let x=0;x<sw;x++){
        const i=(y*sw+x)*4,r=im[i],g=im[i+1],b=im[i+2],
              mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3,
              glyph=greenish(r,g,b)||(lum>80&&sat<62);
        if(glyph){minx=Math.min(minx,x);maxx=Math.max(maxx,x);miny=Math.min(miny,y);maxy=Math.max(maxy,y);n++}
      }
      if(n<5||!Number.isFinite(minx))continue;
      const ww=maxx-minx+1,hh=maxy-miny+1;
      if(ww>=3&&hh>=3){aspects.push(ww/hh);widths.push(ww)}
    }
    if(aspects.length<2)return{family:null,confidence:0,reason:'insufficient Y-axis glyph rows',aspects,widths};

    const a=median(aspects),wm=median(widths);
    if(a>=2.0||wm>=24)
      return{family:'Noise',confidence:clamp(.60+(a-2)*.18+(wm-24)*.012,.55,.96),
             reason:'long decimal Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    if(a>0&&a<=1.55&&wm<=20)
      return{family:'Gain',confidence:clamp(.58+(1.55-a)*.22+(20-wm)*.010,.54,.94),
             reason:'short Gain Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    return{family:null,confidence:.35,reason:'axis glyph geometry ambiguous',aspect:a,width:wm,rows:aspects.length};
  }



  function sampleHorizontalGridRows(ctx,canvas,prepared){
    const p=prepared.plot,
          x0=Math.max(0,Math.floor(p.x)),
          y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),
          h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,
          greenScore=new Float32Array(h),
          horizScore=new Float32Array(h),
          edgeScore=new Float32Array(h);

    // Evaluate only the middle 82% of the plot width so Y labels, title text,
    // mouse tooltip and right-edge clutter cannot dominate the row score.
    const xa=Math.floor(w*.08), xb=Math.max(xa+2,Math.floor(w*.90));

    for(let y=0;y<h;y++){
      let green=0,run=0,maxRun=0,lumSum=0,edge=0;
      let prevLum=null;
      for(let x=xa;x<xb;x++){
        const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2],
              lum=(r+g+b)/3,
              gr=greenish(r,g,b),
              lineLike=gr || (g>32 && g>=r*.93 && g>=b*.90 && lum<145);
        if(gr)green++;
        if(lineLike){run++;if(run>maxRun)maxRun=run}else run=0;
        lumSum+=lum;
        if(prevLum!==null)edge+=Math.abs(lum-prevLum);
        prevLum=lum;
      }
      greenScore[y]=green/Math.max(1,xb-xa);
      horizScore[y]=maxRun/Math.max(1,xb-xa);
      edgeScore[y]=edge/Math.max(1,xb-xa-1);
    }

    // A major horizontal grid row is often dim/green and horizontally
    // continuous. Camera moire can weaken the green component, so continuity
    // alone is allowed to nominate a row.
    const raw=[];
    for(let y=1;y<h-1;y++){
      const score=
        greenScore[y]*1.25 +
        horizScore[y]*1.65 +
        Math.min(.30,edgeScore[y]/90*.30);

      const local=score>=(
        greenScore[y-1]*1.25+horizScore[y-1]*1.65+Math.min(.30,edgeScore[y-1]/90*.30)
      ) && score>=(
        greenScore[y+1]*1.25+horizScore[y+1]*1.65+Math.min(.30,edgeScore[y+1]/90*.30)
      );

      if(local && score>=.22) raw.push({y,score});
    }

    // Merge nearby peaks into a single row.
    const merged=[];
    for(const q of raw){
      const last=merged.at(-1);
      if(!last || q.y-last.y>Math.max(2,h*.018)){
        merged.push({...q});
      }else if(q.score>last.score){
        merged[merged.length-1]={...q};
      }
    }

    // Search all candidate subsets for the most regular 4-6 row lattice.
    let best=null;
    for(let i=0;i<merged.length;i++){
      for(let j=i+3;j<Math.min(merged.length,i+8);j++){
        const seq=merged.slice(i,j+1),
              gaps=[];
        for(let k=1;k<seq.length;k++)gaps.push(seq[k].y-seq[k-1].y);
        const med=median(gaps);
        if(!(med>=h*.10 && med<=h*.34))continue;
        const err=median(gaps.map(g=>Math.abs(g-med)/Math.max(1,med)));
        if(err>.28)continue;
        const strength=median(seq.map(q=>q.score));
        const score=seq.length*3 + strength*4 - err*7;
        if(!best||score>best.score)best={seq,step:med,err,score};
      }
    }

    if(best){
      return best.seq.map(q=>y0+q.y);
    }

    // Fallback: use green projection groups with a much lower threshold.
    const fallbackScores=new Uint32Array(h);
    for(let y=0;y<h;y++)
      fallbackScores[y]=Math.round(greenScore[y]*(xb-xa));
    return groups(fallbackScores,Math.max(4,(xb-xa)*.07),3)
      .map(v=>y0+v).sort((a,b)=>a-b);
  }


  function detectNoiseZeroBaseline(ctx,canvas,prepared){
    // Detect the long yellow horizontal zero trace. This is much easier and more
    // stable than reading tiny Y-axis glyphs from an iPhone photo.
    const p=prepared.plot,x0=Math.max(0,Math.floor(p.x)),y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,
          xa=Math.floor(w*.12),xb=Math.floor(w*.94);
    let best=null;
    for(let y=Math.floor(h*.45);y<Math.floor(h*.92);y++){
      let yellow=0,run=0,maxRun=0;
      for(let x=xa;x<xb;x++){
        const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2];
        const hit=r>95&&g>85&&r>1.05*b&&g>1.12*b&&Math.abs(r-g)<115;
        if(hit){yellow++;run++;maxRun=Math.max(maxRun,run)}else run=0;
      }
      const frac=yellow/Math.max(1,xb-xa),runFrac=maxRun/Math.max(1,xb-xa),
            score=frac*.45+runFrac*.55;
      if(!best||score>best.score)best={y:y0+y,score,frac,runFrac};
    }
    return best&&best.score>.10?best:null;
  }

  function permissiveNoiseGridRows(ctx,canvas,prepared){
    // Broad green/dark-green row projection. Unlike the old detector this does not
    // require a single uninterrupted line, because the yellow trace and camera moire
    // break horizontal grid lines into fragments.
    const p=prepared.plot,x0=Math.max(0,Math.floor(p.x)),y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,xa=Math.floor(w*.08),xb=Math.floor(w*.94),
          scores=[];
    for(let y=0;y<h;y++){
      let n=0;
      for(let x=xa;x<xb;x++){
        const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b);
        // green grid: permit desaturated/blurred camera pixels
        if(g>=r*.88&&g>=b*.90&&g>28&&mx-mn>5&&mx<205)n++;
      }
      scores.push(n/Math.max(1,xb-xa));
    }
    const peaks=[];
    for(let y=2;y<h-2;y++){
      if(scores[y]>=.055&&scores[y]>=scores[y-1]&&scores[y]>=scores[y+1])
        peaks.push({y:y0+y,score:scores[y]});
    }
    const out=[];
    for(const q of peaks){
      const last=out.at(-1);
      if(!last||q.y-last.y>Math.max(3,h*.025))out.push(q);
      else if(q.score>last.score)out[out.length-1]=q;
    }
    return out;
  }

  function inferNoiseAxisFromZeroAndRows(ctx,canvas,prepared,knownRows){
    const p=prepared.plot,zero=detectNoiseZeroBaseline(ctx,canvas,prepared),
          extra=permissiveNoiseGridRows(ctx,canvas,prepared),
          ys=[...(knownRows||[]),...extra.map(q=>q.y)]
            .filter(y=>Number.isFinite(y)).sort((a,b)=>a-b);
    if(!zero)return null;

    // Merge rows and retain rows above zero. For each distance from zero, test whether
    // it represents 1..4 grid steps. Consensus of those implied step sizes wins.
    const merged=[];
    for(const y of ys){
      if(y>=zero.y-2)continue;
      const last=merged.at(-1);
      if(last!==undefined&&Math.abs(y-last)<=Math.max(3,p.h*.025))
        merged[merged.length-1]=(last+y)/2;
      else merged.push(y);
    }
    const stepCandidates=[];
    for(const y of merged){
      const d=zero.y-y;
      for(let k=1;k<=4;k++){
        const st=d/k;
        if(st>=p.h*.075&&st<=p.h*.30)stepCandidates.push(st);
      }
    }
    // Even with no visible green rows, use the distance from the plot's upper data
    // neighborhood to zero as a last-resort 4-step estimate. This is intentionally
    // low-confidence but preferable to OCR-only withholding for a known Noise scale.
    if(!stepCandidates.length){
      const approx=(zero.y-(p.y+p.h*.08))/4;
      if(approx>=p.h*.075&&approx<=p.h*.30)stepCandidates.push(approx);
    }
    if(!stepCandidates.length)return null;

    let bestStep=null,bestScore=-1;
    for(const st of stepCandidates){
      let score=0;
      for(const y of merged){
        const k=Math.round((zero.y-y)/st);
        if(k>=1&&k<=4){
          const err=Math.abs((zero.y-y)-k*st)/Math.max(1,st);
          if(err<.24)score+=1-err;
        }
      }
      // prefer plausible full 0.04..0 span within plot
      const top=zero.y-4*st;
      if(top>=p.y-p.h*.08&&top<=p.y+p.h*.28)score+=1.25;
      if(score>bestScore){bestScore=score;bestStep=st}
    }
    if(!bestStep)return null;
    const top=zero.y-4*bestStep;
    if(top<p.y-p.h*.12||top>p.y+p.h*.34)return null;
    return{
      ok:true,family:'Noise',source:'yellow-zero-plus-grid-consensus',
      zeroY:zero.y,stepPx:bestStep,stepValue:.01,
      anchors:[.04,.03,.02,.01,0].map((v,k)=>({y:zero.y-(4-k)*bestStep,value:v,geometry:true})),
      confidence:clamp(.72+Math.min(.20,bestScore*.035)+Math.min(.06,zero.score*.08),.70,.96),
      zeroBaseline:zero,permissiveRows:extra,mergedRows:merged,consensusScore:bestScore
    };
  }

  function noiseAxisSeries(ctx,canvas,prepared){
    // v4.0.2 geometry-first Noise calibration.
    // OCR is not required. The Noise graph family uses 0.04/0.03/0.02/0.01/0.00
    // on five equally spaced horizontal major-grid rows. Recover those rows from
    // plot geometry, then map pixels directly to values.
    const p=prepared.plot,
          yTop=p.y,yBottom=p.y+p.h,
          structural=(prepared.gridRowsAbs||[])
            .filter(y=>Number.isFinite(y)&&y>=yTop-p.h*.06&&y<=yBottom+p.h*.08)
            .sort((a,b)=>a-b),
          sampled=sampleHorizontalGridRows(ctx,canvas,prepared)
            .filter(y=>Number.isFinite(y)&&y>=yTop-p.h*.06&&y<=yBottom+p.h*.08)
            .sort((a,b)=>a-b);

    const raw=[...structural,...sampled].sort((a,b)=>a-b), merged=[];
    for(const y of raw){
      const last=merged[merged.length-1];
      if(last&&Math.abs(y-last.mean)<=Math.max(3,p.h*.025)){
        last.vals.push(y);last.mean=median(last.vals);
      }else merged.push({mean:y,vals:[y]});
    }
    const rows=merged.map(g=>g.mean).sort((a,b)=>a-b);

    if(rows.length<3){
      const z=inferNoiseAxisFromZeroAndRows(ctx,canvas,prepared,rows);
      if(z)return z;
      return{ok:false,reason:'not enough geometry grid rows and zero baseline unavailable',rows,structural,sampled};
    }

    let best=null;
    for(const n of [5,4,3]){
      for(let i=0;i+n<=rows.length;i++){
        const cand=rows.slice(i,i+n),gaps=[];
        for(let k=1;k<cand.length;k++)gaps.push(cand[k]-cand[k-1]);
        const step=median(gaps);
        if(!(step>=p.h*.10&&step<=p.h*.34))continue;
        const err=median(gaps.map(g=>Math.abs(g-step)/Math.max(1,step)));
        if(err>.24)continue;

        const inferredTop=cand[0],
              inferredZero=cand[0]+step*4,
              span=step*4,
              spanRatio=span/Math.max(1,p.h),
              topDist=Math.abs(inferredTop-yTop)/Math.max(1,p.h),
              bottomDist=Math.abs(inferredZero-yBottom)/Math.max(1,p.h);

        const score=
          n*4.5
          -err*15
          -topDist*4.0
          -bottomDist*4.0
          -Math.abs(spanRatio-.78)*2.5;

        if(!best||score>best.score)
          best={cand,step,err,score,inferredZero,topDist,bottomDist,spanRatio,n};
      }
      if(best&&n>=4)break;
    }

    if(!best){
      const gaps=[];
      for(let i=1;i<rows.length;i++){
        const g=rows[i]-rows[i-1];
        if(g>=p.h*.10&&g<=p.h*.34)gaps.push(g);
      }
      if(!gaps.length){
        const z=inferNoiseAxisFromZeroAndRows(ctx,canvas,prepared,rows);
        if(z)return z;
        return{ok:false,reason:'geometry grid spacing and zero-baseline consensus unavailable',rows,structural,sampled};
      }
      const step=median(gaps);
      let topRow=rows.reduce((a,b)=>Math.abs(b-yTop)<Math.abs(a-yTop)?b:a,rows[0]);
      let zeroY=topRow+4*step;
      if(Math.abs(zeroY-yBottom)>p.h*.18){
        zeroY=rows.reduce((a,b)=>Math.abs(b-yBottom)<Math.abs(a-yBottom)?b:a,rows[rows.length-1]);
        topRow=zeroY-4*step;
      }
      best={cand:[topRow,topRow+step,topRow+2*step,topRow+3*step],
            step,err:.22,score:0,inferredZero:zeroY,n:4,
            topDist:Math.abs(topRow-yTop)/p.h,bottomDist:Math.abs(zeroY-yBottom)/p.h,
            spanRatio:(4*step)/p.h,fallback:true};
    }

    const topRow=best.cand[0],step=best.step,zeroY=topRow+4*step,
          anchors=[
            {y:topRow,value:.04,geometry:true},
            {y:topRow+step,value:.03,geometry:true},
            {y:topRow+2*step,value:.02,geometry:true},
            {y:topRow+3*step,value:.01,geometry:true},
            {y:zeroY,value:0,geometry:true,inferred:best.cand.length<5}
          ];

    const tolerance=p.h*.16;
    if(topRow<yTop-tolerance||zeroY>yBottom+tolerance||zeroY<=topRow){
      const z=inferNoiseAxisFromZeroAndRows(ctx,canvas,prepared,rows);
      if(z)return z;
      return{ok:false,reason:'geometry axis falls outside plot bounds',rows,structural,sampled,
             proposed:{topRow,zeroY,step}};
    }

    return{
      ok:true,family:'Noise',
      source:'geometry-first-horizontal-major-grid',
      anchors,stepPx:step,stepValue:.01,zeroY,
      confidence:clamp(.96-best.err-best.topDist*.18-best.bottomDist*.18,.70,.98),
      structuralRows:structural,sampledRows:sampled,mergedRows:rows,
      geometry:{
        topRow,zeroY,stepPx:step,
        topDistance:best.topDist,bottomDistance:best.bottomDist,
        spanRatio:best.spanRatio,rowCount:best.n,fallback:!!best.fallback
      }
    };
  }

  function pixelYToValue(y,cal){
    if(!cal?.ok)return NaN;
    return (cal.zeroY-y)/Math.max(1e-9,cal.stepPx)*cal.stepValue;
  }


  function rgbToHue(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;
    if(d===0)return 0;
    let h;
    if(mx===r)h=((g-b)/d)%6;
    else if(mx===g)h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h*=60;if(h<0)h+=360;
    return h;
  }

  function noiseForegroundMask(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),
          sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3,h=rgbToHue(r,g,b);
    return lum>=72&&sat>=.28&&h>=35&&h<=105&&mx>=95;
  }

  function directNoiseTrace(ctx,canvas,prepared){
    // v4.0.6: follow the lower/high-density Noise band, not upper sparse spikes.
    const p=prepared.plot,x0=Math.max(0,Math.floor(p.x)),y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,raw=[];

    function quantile(a,q){
      if(!a.length)return NaN;
      const b=[...a].sort((x,y)=>x-y),
            k=Math.max(0,Math.min(b.length-1,Math.round((b.length-1)*q)));
      return b[k];
    }

    for(let x=0;x<w;x++){
      const ys=[];
      for(let y=0;y<h;y++){
        const i=(y*w+x)*4;
        if(noiseForegroundMask(im[i],im[i+1],im[i+2]))ys.push(y0+y);
      }
      if(!ys.length)continue;
      raw.push({
        x:x0+x,
        y:quantile(ys,.72),
        count:ys.length,
        minY:ys[0],
        maxY:ys[ys.length-1]
      });
    }

    if(raw.length<Math.max(10,w*.06))
      return{ok:false,reason:'not enough direct Noise foreground columns',columns:raw.length};

    const points=[];
    for(let i=0;i<raw.length;i++){
      const cur=raw[i],near=[];
      for(let j=Math.max(0,i-5);j<=Math.min(raw.length-1,i+5);j++){
        if(Math.abs(raw[j].x-cur.x)<=6)near.push(raw[j].y);
      }
      points.push({...cur,y:median(near.length?near:[cur.y])});
    }

    return{
      ok:true,
      source:'direct-noise-lower-dense-band-v406',
      points,
      coverage:points.length/Math.max(1,w),
      rawPoints:raw,
      yQuantile:.72,
      smoothingHalfWidthPx:6
    };
  }
  function robustMedian(vals){
    const a=vals.filter(Number.isFinite);
    if(!a.length)return NaN;
    const m=median(a),mad=median(a.map(v=>Math.abs(v-m)))||1e-9,
          keep=a.filter(v=>Math.abs(v-m)<=Math.max(mad*3.5,.0015));
    return median(keep.length?keep:a);
  }

  function directNoiseValues(prepared,trace){
    const cal=prepared.noiseAxis;
    if(!cal?.ok||!trace?.ok)return{ok:false,reason:'Noise axis or direct trace unavailable'};
    const p=prepared.plot,splitX=p.x+p.w*(270/500),low=[],high=[];

    for(const pt of trace.points){
      const v=pixelYToValue(pt.y,cal);
      if(!Number.isFinite(v))continue;
      if(v<-.004||v>.055)continue;
      if(pt.x<splitX)low.push(v);else high.push(v);
    }

    if(low.length<5||high.length<5)
      return{ok:false,reason:`insufficient Low/High lower-band samples (${low.length}/${high.length})`,
             lowCount:low.length,highCount:high.length,splitX};

    function denseTrimmedCenter(vals){
      const a=vals.filter(Number.isFinite).sort((x,y)=>x-y);
      if(!a.length)return NaN;
      const med=median(a),
            mad=median(a.map(v=>Math.abs(v-med)))||.00035,
            keep=a.filter(v=>Math.abs(v-med)<=Math.max(mad*2.8,.0012)),
            b=(keep.length>=Math.max(5,a.length*.35)?keep:a).sort((x,y)=>x-y),
            cut=Math.floor(b.length*.10),
            core=b.slice(cut,Math.max(cut+1,b.length-cut));
      return core.reduce((sum,v)=>sum+v,0)/Math.max(1,core.length);
    }

    const lowValue=denseTrimmedCenter(low),highValue=denseTrimmedCenter(high);
    if(!Number.isFinite(lowValue)||!Number.isFinite(highValue))
      return{ok:false,reason:'dense Noise center unavailable',lowCount:low.length,highCount:high.length,splitX};

    return{
      ok:true,
      source:'direct-noise-lower-band-grid-mapping-v406',
      low:lowValue,high:highValue,
      lowCount:low.length,highCount:high.length,splitX,
      lowY:cal.zeroY-(lowValue/cal.stepValue)*cal.stepPx,
      highY:cal.zeroY-(highValue/cal.stepValue)*cal.stepPx,
      estimator:'per-column Y72 + local median + MAD core + 10% trimmed mean'
    };
  }



  function detectRightDarkFrame(ctx,canvas){
    // v3.0.3: detect a DARK RECTANGLE, not a connected black blob.
    // The Energy-per-Band panel may be fragmented by grid lines, labels and trace,
    // so connected-components are intrinsically unstable.
    const W=canvas.width,H=canvas.height,
          im=ctx.getImageData(0,0,W,H).data,
          gray=(x,y)=>{
            x=Math.max(0,Math.min(W-1,x|0)); y=Math.max(0,Math.min(H-1,y|0));
            const i=(y*W+x)*4; return (im[i]+im[i+1]+im[i+2])/3;
          },
          dark=(x,y)=>gray(x,y)<112;

    function interiorStats(x,y,w,h){
      const sx=Math.max(2,Math.round(w/64)), sy=Math.max(2,Math.round(h/38));
      let n=0,d=0,green=0,color=0;
      for(let yy=y+sy;yy<y+h-sy;yy+=sy){
        for(let xx=x+sx;xx<x+w-sx;xx+=sx){
          const i=((yy|0)*W+(xx|0))*4,r=im[i],g=im[i+1],b=im[i+2],
                lum=(r+g+b)/3,mx=Math.max(r,g,b),mn=Math.min(r,g,b),
                sat=(mx-mn)/Math.max(1,mx);
          if(lum<118)d++;
          if(g>45&&g>r*1.08&&g>b*.92)green++;
          if(mx>130&&sat>.25)color++;
          n++;
        }
      }
      return {darkRatio:d/Math.max(1,n),greenRatio:green/Math.max(1,n),
              colorRatio:color/Math.max(1,n),n};
    }

    function edgeDarkRatio(x,y,w,h){
      const step=Math.max(2,Math.round(Math.min(w,h)/42));
      let top=0,bot=0,left=0,right=0,nt=0,nb=0,nl=0,nr=0;
      for(let xx=x;xx<=x+w;xx+=step){
        if(dark(xx,y)){top++} nt++;
        if(dark(xx,y+h)){bot++} nb++;
      }
      for(let yy=y;yy<=y+h;yy+=step){
        if(dark(x,yy)){left++} nl++;
        if(dark(x+w,yy)){right++} nr++;
      }
      return {top:top/nt,bottom:bot/nb,left:left/nl,right:right/nr};
    }

    const cands=[];
    // Search plausible panel rectangles directly. The photo is roughly aligned by the user,
    // but the detector does not require exact upper-right placement.
    for(let wf=.26;wf<=.52;wf+=.035){
      const w=Math.round(W*wf);
      for(let aspect=1.55;aspect<=3.25;aspect+=.22){
        const h=Math.round(w/aspect);
        if(h<H*.10||h>H*.34)continue;
        const sx=Math.max(10,Math.round(w*.055)),
              sy=Math.max(8,Math.round(h*.075));
        for(let y=Math.round(H*.12);y+h<Math.round(H*.70);y+=sy){
          for(let x=Math.round(W*.36);x+w<W;x+=sx){
            const st=interiorStats(x,y,w,h);
            if(st.darkRatio<.50)continue;

            const e=edgeDarkRatio(x,y,w,h);
            // The true panel rectangle must have a dark interior and persistent dark border
            // on most sides; grid/trace may interrupt an edge, so don't require perfection.
            const edgeMean=(e.top+e.bottom+e.left+e.right)/4;
            if(edgeMean<.42)continue;

            const ar=w/h,
                  aspectScore=Math.exp(-Math.pow((ar-2.15)/.85,2)),
                  rightness=(x+w*.5)/W,
                  sizeScore=Math.min(1,(w*h)/(W*H*.085)),
                  score=
                    st.darkRatio*4.1+
                    edgeMean*2.2+
                    Math.min(.8,st.greenRatio*13)+
                    Math.min(.65,st.colorRatio*7)+
                    aspectScore*.9+
                    rightness*.45+
                    sizeScore*.45;

            cands.push({x,y,w,h,score,stats:st,edges:e,aspect:ar});
          }
        }
      }
    }

    if(!cands.length)return null;
    cands.sort((a,b)=>b.score-a.score);

    // Refine each side independently by looking for the strongest transition
    // from pale UI -> dark plot near the coarse rectangle.
    const b={...cands[0]};
    function verticalDarkness(xx,y0,y1){
      let n=0,d=0,step=Math.max(2,Math.round((y1-y0)/55));
      for(let y=y0;y<=y1;y+=step){if(dark(xx,y))d++;n++}
      return d/Math.max(1,n);
    }
    function horizontalDarkness(yy,x0,x1){
      let n=0,d=0,step=Math.max(2,Math.round((x1-x0)/70));
      for(let x=x0;x<=x1;x+=step){if(dark(x,yy))d++;n++}
      return d/Math.max(1,n);
    }

    let bestL={x:b.x,s:-1}, bestR={x:b.x+b.w,s:-1},
        bestT={y:b.y,s:-1}, bestB={y:b.y+b.h,s:-1};

    const dx=Math.max(8,Math.round(b.w*.12)),
          dy=Math.max(6,Math.round(b.h*.16));
    for(let x=Math.max(0,b.x-dx);x<=Math.min(W-1,b.x+dx);x++){
      const inside=verticalDarkness(x+3,b.y,b.y+b.h),
            outside=verticalDarkness(x-4,b.y,b.y+b.h),
            sc=inside-outside;
      if(sc>bestL.s)bestL={x,s:sc};
    }
    for(let x=Math.max(1,b.x+b.w-dx);x<=Math.min(W-2,b.x+b.w+dx);x++){
      const inside=verticalDarkness(x-3,b.y,b.y+b.h),
            outside=verticalDarkness(x+4,b.y,b.y+b.h),
            sc=inside-outside;
      if(sc>bestR.s)bestR={x,s:sc};
    }
    for(let y=Math.max(0,b.y-dy);y<=Math.min(H-1,b.y+dy);y++){
      const inside=horizontalDarkness(y+3,b.x,b.x+b.w),
            outside=horizontalDarkness(y-4,b.x,b.x+b.w),
            sc=inside-outside;
      if(sc>bestT.s)bestT={y,s:sc};
    }
    for(let y=Math.max(1,b.y+b.h-dy);y<=Math.min(H-2,b.y+b.h+dy);y++){
      const inside=horizontalDarkness(y-3,b.x,b.x+b.w),
            outside=horizontalDarkness(y+4,b.x,b.x+b.w),
            sc=inside-outside;
      if(sc>bestB.s)bestB={y,s:sc};
    }

    let x=Math.max(0,bestL.x), y=Math.max(0,bestT.y),
        x2=Math.min(W,bestR.x), y2=Math.min(H,bestB.y);
    if(x2-x<W*.16||y2-y<H*.08){x=b.x;y=b.y;x2=b.x+b.w;y2=b.y+b.h}

    return{
      x,y,w:x2-x,h:y2-y,
      source:'energy-dark-rectangle-boundary',
      confidence:clamp(.58+b.score/10,.58,.98),
      diagnostics:{
        coarse:b,
        refined:{left:bestL,right:bestR,top:bestT,bottom:bestB},
        method:'dark-rectangle-interior+four-edge-transition'
      }
    };
  }


  function localPanelBoundaryFromPlot(ctx,canvas,plot){
    const W=canvas.width,H=canvas.height,
          im=ctx.getImageData(0,0,W,H).data,
          lum=(x,y)=>{
            x=Math.max(0,Math.min(W-1,x|0));y=Math.max(0,Math.min(H-1,y|0));
            const i=(y*W+x)*4;return (im[i]+im[i+1]+im[i+2])/3;
          },
          dark=(x,y)=>lum(x,y)<125;

    function vRatio(x,y0,y1){
      let n=0,d=0,st=Math.max(2,Math.round((y1-y0)/60));
      for(let y=y0;y<=y1;y+=st){if(dark(x,y))d++;n++}
      return d/Math.max(1,n);
    }
    function hRatio(y,x0,x1){
      let n=0,d=0,st=Math.max(2,Math.round((x1-x0)/80));
      for(let x=x0;x<=x1;x+=st){if(dark(x,y))d++;n++}
      return d/Math.max(1,n);
    }

    const px=plot.x,py=plot.y,pw=plot.w,ph=plot.h,
          y0=Math.max(0,py-ph*.06),y1=Math.min(H-1,py+ph*1.08),
          x0=Math.max(0,px-pw*.04),x1=Math.min(W-1,px+pw*1.04);

    // Starting from an already-confirmed grid plot, search only locally for the
    // pale-UI -> dark-panel transition. This is far more stable than finding a
    // black rectangle from the entire photograph.
    function bestLeft(){
      let best={v:px-pw*.30,s:-1};
      const lo=Math.max(1,Math.round(px-pw*.48)),hi=Math.max(lo,Math.round(px-pw*.04));
      for(let x=lo;x<=hi;x++){
        const inside=vRatio(x+4,y0,y1),outside=vRatio(x-5,y0,y1),
              sc=inside-outside;
        if(sc>best.s)best={v:x,s:sc};
      }
      return best;
    }
    function bestRight(){
      let best={v:px+pw*.10,s:-1};
      const lo=Math.min(W-2,Math.round(px+pw*1.01)),
            hi=Math.min(W-2,Math.round(px+pw*1.28));
      for(let x=lo;x<=hi;x++){
        const inside=vRatio(x-4,y0,y1),outside=vRatio(x+5,y0,y1),
              sc=inside-outside;
        if(sc>best.s)best={v:x,s:sc};
      }
      return best;
    }
    function bestTop(){
      let best={v:py-ph*.10,s:-1};
      const lo=Math.max(1,Math.round(py-ph*.30)),hi=Math.max(lo,Math.round(py-ph*.01));
      for(let y=lo;y<=hi;y++){
        const inside=hRatio(y+4,x0,x1),outside=hRatio(y-5,x0,x1),
              sc=inside-outside;
        if(sc>best.s)best={v:y,s:sc};
      }
      return best;
    }
    function bestBottom(){
      let best={v:py+ph*.18,s:-1};
      const lo=Math.min(H-2,Math.round(py+ph*1.01)),
            hi=Math.min(H-2,Math.round(py+ph*1.46));
      for(let y=lo;y<=hi;y++){
        const inside=hRatio(y-4,x0,x1),outside=hRatio(y+5,x0,x1),
              sc=inside-outside;
        if(sc>best.s)best={v:y,s:sc};
      }
      return best;
    }

    const L=bestLeft(),R=bestRight(),T=bestTop(),B=bestBottom(),
          weak=[L,R,T,B].filter(o=>o.s<.16).length;

    // If a side transition is weak, use a conservative geometry expansion from
    // the confirmed grid instead of inventing a remote edge.
    const left =L.s>=.16?L.v:px-pw*.30,
          right=R.s>=.16?R.v:px+pw*1.10,
          top  =T.s>=.16?T.v:py-ph*.12,
          bottom=B.s>=.16?B.v:py+ph*1.28,
          x=Math.max(0,left),y=Math.max(0,top),
          x2=Math.min(W,right),y2=Math.min(H,bottom);

    return{
      x,y,w:Math.max(2,x2-x),h:Math.max(2,y2-y),
      source:'guide-grid-local-panel-boundary',
      confidence:clamp(.94-weak*.08,.62,.94),
      diagnostics:{L,R,T,B,weakSides:weak}
    };
  }

  function guideAlignedPanelDetect(ctx,canvas){
    const W=canvas.width,H=canvas.height,cands=[];

    // The camera image has ALREADY been cropped to the shooting guide.
    // Search only the expected upper-right application area for a regular grid.
    // No global dark-component or global black-rectangle detector is used here.
    const seeds=[
      {x:.42,y:.10,w:.57,h:.43},
      {x:.46,y:.12,w:.53,h:.40},
      {x:.50,y:.14,w:.49,h:.37},
      {x:.40,y:.15,w:.59,h:.36},
      {x:.44,y:.18,w:.55,h:.34},
      {x:.48,y:.20,w:.51,h:.32}
    ];

    for(const ss of seeds){
      const roi={
        x:Math.round(W*ss.x),y:Math.round(H*ss.y),
        w:Math.round(W*ss.w),h:Math.round(H*ss.h)
      };
      if(roi.x+roi.w>W)roi.w=W-roi.x;
      if(roi.y+roi.h>H)roi.h=H-roi.y;
      const q=plotFromGrid(ctx,canvas,roi);
      if(!q)continue;
      const p=q.plot,
            rows=(q.gridRowsAbs||[]).length,
            cols=(q.gridColsAbs||[]).length,
            aspect=p.w/Math.max(1,p.h),
            right=(p.x+p.w*.5)/W,
            upper=1-(p.y+p.h*.5)/H,
            rowScore=Math.min(1,rows/5),
            colScore=Math.min(1,cols/6),
            aspectScore=Math.exp(-Math.pow((aspect-2.15)/.85,2)),
            score=rowScore*4+colScore*4+aspectScore*2+right*.7+upper*.3;
      cands.push({q,score,rows,cols,aspect});
    }

    if(!cands.length)return null;
    cands.sort((a,b)=>b.score-a.score);
    const best=cands[0];
    if(best.rows<3||best.cols<3)return null;

    const panel=localPanelBoundaryFromPlot(ctx,canvas,best.q.plot);
    return{
      ...panel,
      plot:{...best.q.plot},
      gridRowsAbs:[...(best.q.gridRowsAbs||[])],
      gridColsAbs:[...(best.q.gridColsAbs||[])],
      confidence:clamp((panel.confidence*.65)+Math.min(1,best.score/10)*.35,.60,.98),
      source:'guide-first-grid-then-local-panel',
      diagnostics:{
        candidateScore:best.score,rows:best.rows,cols:best.cols,
        plotAspect:best.aspect,panel:panel.diagnostics
      }
    };
  }

  function autoPanelDetect(ctx,canvas){
    const W=canvas.width,H=canvas.height,cands=[],
          darkFrame=detectRightDarkFrame(ctx,canvas),
          search=darkFrame||{x:Math.round(W*.18),y:0,w:Math.round(W*.82),h:Math.round(H*.76)};

    // v3.0.2: first crop to the right dark Energy-per-Band frame when present.
    // Each candidate is validated by the exact same plotFromGrid()/prepare()
    // geometry used after a successful manual ROI.
    const widths=darkFrame?[.72,.82,.92,1.00]:[.30,.36,.42,.48,.54,.60];
    const aspects=[1.7,2.0,2.3,2.6,3.0,3.4];

    for(const wf of widths){
      const w=Math.round((darkFrame?search.w:W)*wf);
      for(const asp of aspects){
        const h=Math.round(w/asp);
        if(h<(darkFrame?search.h*.55:H*.08)||h>(darkFrame?search.h*1.05:H*.34))continue;
        const sx=Math.max(12,Math.round(w*.11)),
              sy=Math.max(10,Math.round(h*.15));
        for(let y=Math.floor(search.y);y+h<=Math.min(H,search.y+search.h);y+=sy){
          for(let x=Math.floor(search.x);x+w<=Math.min(W,search.x+search.w);x+=sx){
            const roi={x,y,w,h},
                  q=plotFromGrid(ctx,canvas,roi);
            if(!q)continue;

            const p=q.plot,
                  coverage=(p.w*p.h)/Math.max(1,w*h),
                  aspect=p.w/Math.max(1,p.h),
                  rows=(q.gridRowsAbs||[]).length,
                  cols=(q.gridColsAbs||[]).length,
                  rightness=(p.x+p.w*.5)/Math.max(1,W),
                  upperness=1-(p.y+p.h*.5)/Math.max(1,H);

            if(rows<3||cols<3)continue;
            if(coverage<.12||coverage>.82)continue;

            // Strongest evidence is: successful exact plot localization,
            // regular grid support, plausible plot aspect, and right-side location.
            const aspectScore=Math.exp(-Math.pow((aspect-2.2)/1.2,2)),
                  latticeScore=Math.min(1,(rows+cols)/10),
                  score=
                    4.5*latticeScore +
                    1.5*aspectScore +
                    1.2*Math.min(1,coverage/.45) +
                    .65*rightness +
                    .25*upperness;

            cands.push({roi,q,score,rows,cols,coverage,aspect});
          }
        }
      }
    }

    if(!cands.length)return null;
    cands.sort((a,b)=>b.score-a.score);

    // De-duplicate overlapping hypotheses; keep strongest.
    const kept=[];
    for(const c of cands){
      const p=c.q.plot,pc={x:p.x,y:p.y,w:p.w,h:p.h};
      let dup=false;
      for(const k of kept){
        const a=pc,b=k.plot,
              ix=Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x)),
              iy=Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y)),
              inter=ix*iy,
              union=a.w*a.h+b.w*b.h-inter;
        if(union>0&&inter/union>.60){dup=true;break}
      }
      if(!dup)kept.push({plot:pc,c});
      if(kept.length>=8)break;
    }

    const best=kept[0]?.c;
    if(!best)return null;

    // Return the same normalized context that manual ROI analysis would use.
    // This prevents Auto ROI from inventing a second geometry.
    const c=best.q.context;
    return{
      x:c.x,y:c.y,w:c.w,h:c.h,
      confidence:clamp(.55+best.score/12,.55,.99),
      source:darkFrame?'dark-rectangle-first+shared-analysis-core':'shared-analysis-core-auto-panel',
      plot:{...best.q.plot},
      darkFrame:darkFrame?{...darkFrame}:null,
      diagnostics:{
        rows:best.rows,cols:best.cols,coverage:best.coverage,
        aspect:best.aspect,score:best.score,
        blackFrameFirst:!!darkFrame,
        blackFrame:darkFrame?.diagnostics||null
      }
    };
  }

  function prepareManualROI(ctx,canvas,roi){
    // v4.0.5 Manual ROI authoritative fallback.
    // The user already selected the Energy-per-Band panel. Do not invoke the
    // shared/global plot localizer again.
    const R={
      x:clamp(roi.x,0,canvas.width-2),
      y:clamp(roi.y,0,canvas.height-2),
      w:clamp(roi.w,2,canvas.width-roi.x),
      h:clamp(roi.h,2,canvas.height-roi.y)
    };

    // Stable panel-relative inner plot. No black-frame/grid localization required.
    const plot={
      x:R.x+R.w*.105,
      y:R.y+R.h*.075,
      w:R.w*.865,
      h:R.h*.705
    };
    const insets={
      left:plot.x-R.x,
      right:(R.x+R.w)-(plot.x+plot.w),
      top:plot.y-R.y,
      bottom:(R.y+R.h)-(plot.y+plot.h),
      source:'manual-roi-relative-geometry'
    };

    const q={
      version:'manual-roi-direct-v4.0.5',
      context:{...R},
      plot,
      insets,
      gridRowsAbs:[],
      gridColsAbs:[],
      axisFamily:null,
      noiseAxis:null,
      noiseTrace:null,
      noiseValues:null,
      source:'manual-roi-direct-no-localizer',
      confidence:.90,
      manual:true
    };

    try{q.noiseAxis=noiseAxisSeries(ctx,canvas,q)}catch(_){}
    try{q.noiseTrace=directNoiseTrace(ctx,canvas,q)}catch(_){}
    if(q.noiseAxis?.ok&&q.noiseTrace?.ok){
      try{q.noiseValues=directNoiseValues(q,q.noiseTrace)}catch(_){}
    }
    return q;
  }

  function prepare(ctx,canvas,roi){
    const q=plotFromGrid(ctx,canvas,roi);
    if(!q)return null;
    q.axisFamily=axisStripFamily(ctx,canvas,q);
    q.noiseAxis=noiseAxisSeries(ctx,canvas,q);
    q.noiseTrace=directNoiseTrace(ctx,canvas,q);
    q.noiseValues=(q.noiseAxis?.ok&&q.noiseTrace?.ok)?directNoiseValues(q,q.noiseTrace):null;
    q.version='analysis-core-v3.0.4';
    return q;
  }
  return{prepare,prepareManualROI,plotFromGrid,localPanelBoundaryFromPlot,guideAlignedPanelDetect,detectRightDarkFrame,autoPanelDetect,axisStripFamily,noiseAxisSeries,pixelYToValue,directNoiseTrace,directNoiseValues};
});
