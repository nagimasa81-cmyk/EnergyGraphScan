
((root,factory)=>{
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.EGSAnalysisV2=api;
})(typeof window!=='undefined'?window:globalThis,()=>{

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const median=a=>{
    const b=[...a].filter(Number.isFinite).sort((x,y)=>x-y),n=b.length;
    if(!n)return NaN;
    return n%2?b[(n-1)/2]:(b[n/2-1]+b[n/2])/2;
  };

  function greenish(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3;
    return g>34&&(
      (g>r*1.045&&g>b*.96&&g-Math.max(r,b)>3)||
      (lum>42&&sat>20&&g>=mx-3)
    );
  }
  const dark=(r,g,b)=>(r+g+b)/3<112;

  function groups(scores,threshold,maxGap=2){
    const ids=[],out=[];
    for(let i=0;i<scores.length;i++)if(scores[i]>=threshold)ids.push(i);
    for(const v of ids){
      if(!out.length||v-out.at(-1).at(-1)>maxGap)out.push([v]);
      else out.at(-1).push(v);
    }
    return out.map(g=>g.reduce((a,b)=>a+b,0)/g.length);
  }

  function regularRun(values,minGap,maxGap){
    if(values.length<3)return null;
    let best=null;
    for(let i=0;i<values.length-2;i++)for(let j=i+1;j<values.length-1;j++){
      const gap=values[j]-values[i];
      if(gap<minGap||gap>maxGap)continue;
      const seq=[values[i],values[j]];
      let last=values[j],err=0;
      for(let k=j+1;k<values.length;k++){
        const d=values[k]-last;
        if(Math.abs(d-gap)<=Math.max(2,gap*.28)){
          seq.push(values[k]);err+=Math.abs(d-gap)/Math.max(1,gap);last=values[k];
        }
      }
      if(seq.length<3)continue;
      const score=seq.length*4+(seq.at(-1)-seq[0])/Math.max(1,gap)-err;
      if(!best||score>best.score)best={seq,gap,score};
    }
    return best;
  }

  function plotFromGrid(ctx,canvas,roi){
    const x0=Math.max(0,Math.floor(roi.x)),
          y0=Math.max(0,Math.floor(roi.y)),
          w=Math.max(2,Math.min(canvas.width-x0,Math.ceil(roi.w))),
          h=Math.max(2,Math.min(canvas.height-y0,Math.ceil(roi.h))),
          im=ctx.getImageData(x0,y0,w,h).data,
          row=new Uint32Array(h),col=new Uint32Array(w),
          darkRow=new Uint32Array(h),darkCol=new Uint32Array(w);

    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenish(r,g,b)){row[y]++;col[x]++}
      if(dark(r,g,b)){darkRow[y]++;darkCol[x]++}
    }

    const rows=groups(row,Math.max(6,w*.20)),
          cols=groups(col,Math.max(6,h*.19)),
          rr=regularRun(rows,Math.max(5,h*.045),h*.30),
          cc=regularRun(cols,Math.max(6,w*.045),w*.25);

    let top,bottom,left,right,source='';
    if(rr&&cc){
      top=rr.seq[0];bottom=rr.seq.at(-1);
      left=cc.seq[0];right=cc.seq.at(-1);
      source='grid-lattice';
    }else{
      const rids=[],cids=[];
      for(let y=0;y<Math.floor(h*.78);y++)if(darkRow[y]>w*.28)rids.push(y);
      for(let x=Math.floor(w*.34);x<w;x++)if(darkCol[x]>h*.16)cids.push(x);
      if(rids.length&&cids.length){
        top=Math.min(...rids);bottom=Math.max(...rids);
        left=Math.min(...cids);right=Math.max(...cids);
        source='dark-rectangle';
      }
    }
    if(![top,bottom,left,right].every(Number.isFinite))return null;
    if(right-left<w*.26||bottom-top<h*.16)return null;

    const near=(arr,target,rad)=>{
      let best=target,score=-1;
      const a=Math.max(0,Math.floor(target-rad)),b=Math.min(arr.length-1,Math.ceil(target+rad));
      for(let i=a;i<=b;i++)if(arr[i]>score){best=i;score=arr[i]}
      return best;
    };
    top=near(row,top,Math.max(3,h*.035));
    bottom=near(row,bottom,Math.max(3,h*.035));
    left=near(col,left,Math.max(3,w*.035));
    right=near(col,right,Math.max(3,w*.035));

    const plot={x:x0+left,y:y0+top,w:right-left,h:bottom-top,
                x0:x0+left,y0:y0+top,x1:x0+right,y1:y0+bottom,source};
    const aspect=plot.w/Math.max(1,plot.h);
    if(aspect<1.25||aspect>4.5)return null;

    // v2.0.4: the grid lattice is NOT the whole Energy-per-Band panel.
    // Keep plot for numeric geometry, but expand context to include Y labels/title/X labels.
    const lp=Math.max(28,plot.w*.40),rp=Math.max(10,plot.w*.10),
          tp=Math.max(10,plot.h*.18),bp=Math.max(18,plot.h*.36),
          cx0=clamp(plot.x-lp,0,canvas.width-2),
          cy0=clamp(plot.y-tp,0,canvas.height-2),
          cx1=clamp(plot.x+plot.w+rp,cx0+2,canvas.width),
          cy1=clamp(plot.y+plot.h+bp,cy0+2,canvas.height),
          context={x:cx0,y:cy0,w:cx1-cx0,h:cy1-cy0},
          insets={
            left:(plot.x-context.x)/context.w,
            top:(plot.y-context.y)/context.h,
            right:(context.x+context.w-(plot.x+plot.w))/context.w,
            bottom:(context.y+context.h-(plot.y+plot.h))/context.h,
            source:'v2-normalized-plot-context'
          };
    return{plot,context,insets,rows,cols,
      gridRowsAbs:rr?.seq?.map(y=>y0+y)||[],
      gridColsAbs:cc?.seq?.map(x=>x0+x)||[],
      gridStepY:rr?.gap||NaN,gridStepX:cc?.gap||NaN};
  }

  function axisStripFamily(ctx,canvas,q){
    if(!q)return{family:null,confidence:0,reason:'no plot'};
    const p=q.plot,
          step=Number.isFinite(q.gridStepY)?q.gridStepY:Math.max(8,p.h/4),
          sx0=Math.max(0,Math.floor(p.x-p.w*.27)),
          sx1=Math.max(sx0+4,Math.floor(p.x-p.w*.015)),
          sw=sx1-sx0,
          count=Math.max(3,Math.min(7,Math.round(p.h/step)+1)),
          aspects=[],widths=[];

    for(let k=0;k<count;k++){
      const cy=p.y+k*(p.h/Math.max(1,count-1)),
            y0=Math.max(0,Math.floor(cy-step*.34)),
            y1=Math.min(canvas.height,Math.ceil(cy+step*.34)),
            h=Math.max(1,y1-y0),
            im=ctx.getImageData(sx0,y0,sw,h).data;
      let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity,n=0;
      for(let y=0;y<h;y++)for(let x=0;x<sw;x++){
        const i=(y*sw+x)*4,r=im[i],g=im[i+1],b=im[i+2],
              mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3,
              glyph=greenish(r,g,b)||(lum>80&&sat<62);
        if(glyph){minx=Math.min(minx,x);maxx=Math.max(maxx,x);miny=Math.min(miny,y);maxy=Math.max(maxy,y);n++}
      }
      if(n<5||!Number.isFinite(minx))continue;
      const ww=maxx-minx+1,hh=maxy-miny+1;
      if(ww>=3&&hh>=3){aspects.push(ww/hh);widths.push(ww)}
    }
    if(aspects.length<2)return{family:null,confidence:0,reason:'insufficient Y-axis glyph rows',aspects,widths};

    const a=median(aspects),wm=median(widths);
    if(a>=2.0||wm>=24)
      return{family:'Noise',confidence:clamp(.60+(a-2)*.18+(wm-24)*.012,.55,.96),
             reason:'long decimal Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    if(a>0&&a<=1.55&&wm<=20)
      return{family:'Gain',confidence:clamp(.58+(1.55-a)*.22+(20-wm)*.010,.54,.94),
             reason:'short Gain Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    return{family:null,confidence:.35,reason:'axis glyph geometry ambiguous',aspect:a,width:wm,rows:aspects.length};
  }



  function sampleHorizontalGridRows(ctx,canvas,prepared){
    const p=prepared.plot,
          x0=Math.max(0,Math.floor(p.x)),
          y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),
          h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,
          greenScore=new Float32Array(h),
          horizScore=new Float32Array(h),
          edgeScore=new Float32Array(h);

    // Evaluate only the middle 82% of the plot width so Y labels, title text,
    // mouse tooltip and right-edge clutter cannot dominate the row score.
    const xa=Math.floor(w*.08), xb=Math.max(xa+2,Math.floor(w*.90));

    for(let y=0;y<h;y++){
      let green=0,run=0,maxRun=0,lumSum=0,edge=0;
      let prevLum=null;
      for(let x=xa;x<xb;x++){
        const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2],
              lum=(r+g+b)/3,
              gr=greenish(r,g,b),
              lineLike=gr || (g>32 && g>=r*.93 && g>=b*.90 && lum<145);
        if(gr)green++;
        if(lineLike){run++;if(run>maxRun)maxRun=run}else run=0;
        lumSum+=lum;
        if(prevLum!==null)edge+=Math.abs(lum-prevLum);
        prevLum=lum;
      }
      greenScore[y]=green/Math.max(1,xb-xa);
      horizScore[y]=maxRun/Math.max(1,xb-xa);
      edgeScore[y]=edge/Math.max(1,xb-xa-1);
    }

    // A major horizontal grid row is often dim/green and horizontally
    // continuous. Camera moire can weaken the green component, so continuity
    // alone is allowed to nominate a row.
    const raw=[];
    for(let y=1;y<h-1;y++){
      const score=
        greenScore[y]*1.25 +
        horizScore[y]*1.65 +
        Math.min(.30,edgeScore[y]/90*.30);

      const local=score>=(
        greenScore[y-1]*1.25+horizScore[y-1]*1.65+Math.min(.30,edgeScore[y-1]/90*.30)
      ) && score>=(
        greenScore[y+1]*1.25+horizScore[y+1]*1.65+Math.min(.30,edgeScore[y+1]/90*.30)
      );

      if(local && score>=.22) raw.push({y,score});
    }

    // Merge nearby peaks into a single row.
    const merged=[];
    for(const q of raw){
      const last=merged.at(-1);
      if(!last || q.y-last.y>Math.max(2,h*.018)){
        merged.push({...q});
      }else if(q.score>last.score){
        merged[merged.length-1]={...q};
      }
    }

    // Search all candidate subsets for the most regular 4-6 row lattice.
    let best=null;
    for(let i=0;i<merged.length;i++){
      for(let j=i+3;j<Math.min(merged.length,i+8);j++){
        const seq=merged.slice(i,j+1),
              gaps=[];
        for(let k=1;k<seq.length;k++)gaps.push(seq[k].y-seq[k-1].y);
        const med=median(gaps);
        if(!(med>=h*.10 && med<=h*.34))continue;
        const err=median(gaps.map(g=>Math.abs(g-med)/Math.max(1,med)));
        if(err>.28)continue;
        const strength=median(seq.map(q=>q.score));
        const score=seq.length*3 + strength*4 - err*7;
        if(!best||score>best.score)best={seq,step:med,err,score};
      }
    }

    if(best){
      return best.seq.map(q=>y0+q.y);
    }

    // Fallback: use green projection groups with a much lower threshold.
    const fallbackScores=new Uint32Array(h);
    for(let y=0;y<h;y++)
      fallbackScores[y]=Math.round(greenScore[y]*(xb-xa));
    return groups(fallbackScores,Math.max(4,(xb-xa)*.07),3)
      .map(v=>y0+v).sort((a,b)=>a-b);
  }

  function noiseAxisSeries(ctx,canvas,prepared){
    // v2.0.4 authoritative path: reuse the exact horizontal lattice that localized
    // the plot. Do not OCR labels and do not independently rediscover the same rows.
    const structural=(prepared.gridRowsAbs||[]).filter(Number.isFinite).sort((a,b)=>a-b);
    let seq=null,step=NaN,err=1,source='';

    if(structural.length>=4){
      // Find the most regular 4/5-row run.
      let best=null;
      for(let i=0;i<structural.length;i++){
        for(const n of [5,4]){
          if(i+n>structural.length)continue;
          const cand=structural.slice(i,i+n),gaps=[];
          for(let k=1;k<cand.length;k++)gaps.push(cand[k]-cand[k-1]);
          const med=median(gaps),
                e=median(gaps.map(g=>Math.abs(g-med)/Math.max(1,med)));
          if(med>=3&&e<.24){
            const score=n*4-e*10;
            if(!best||score>best.score)best={cand,step:med,err:e,score};
          }
        }
      }
      if(best){seq=best.cand;step=best.step;err=best.err;source='plot-localization-lattice';}
    }

    if(!seq){
      const rows=sampleHorizontalGridRows(ctx,canvas,prepared);
      if(rows.length<4)return{ok:false,reason:'not enough horizontal major-grid rows',rows,structural};
      let best=null;
      for(let i=0;i<=rows.length-4;i++){
        const cand=rows.slice(i,Math.min(rows.length,i+5)),gaps=[];
        for(let k=1;k<cand.length;k++)gaps.push(cand[k]-cand[k-1]);
        const med=median(gaps),
              e=median(gaps.map(g=>Math.abs(g-med)/Math.max(1,med)));
        if(cand.length>=4&&e<.30){
          const score=cand.length*3-e*6;
          if(!best||score>best.score)best={cand,step:med,err:e,score};
        }
      }
      if(!best)return{ok:false,reason:'major-grid sequence not regular',rows,structural};
      seq=best.cand;step=best.step;err=best.err;source='sampled-major-grid-fallback';
    }

    // Noise graph scale is fixed by this UI family: 0.04,0.03,0.02,0.01,0.
    // With four visible rows, zero is one structural step below 0.01.
    const anchors=[
      {y:seq[0],value:.04},
      {y:seq[1],value:.03},
      {y:seq[2],value:.02},
      {y:seq[3],value:.01}
    ];
    if(seq.length>=5)anchors.push({y:seq[4],value:0});
    else anchors.push({y:seq[3]+step,value:0,inferred:true});

    return{
      ok:true,family:'Noise',source,
      anchors,stepPx:step,stepValue:.01,
      zeroY:anchors[4].y,
      confidence:clamp(.94-err,.72,.98),
      structuralRows:structural
    };
  }

  function pixelYToValue(y,cal){
    if(!cal?.ok)return NaN;
    return (cal.zeroY-y)/Math.max(1e-9,cal.stepPx)*cal.stepValue;
  }


  function rgbToHue(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;
    if(d===0)return 0;
    let h;
    if(mx===r)h=((g-b)/d)%6;
    else if(mx===g)h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h*=60;if(h<0)h+=360;
    return h;
  }

  function noiseForegroundMask(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),
          sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3,h=rgbToHue(r,g,b);
    return lum>=72&&sat>=.28&&h>=35&&h<=105&&mx>=95;
  }

  function directNoiseTrace(ctx,canvas,prepared){
    const p=prepared.plot,x0=Math.max(0,Math.floor(p.x)),y0=Math.max(0,Math.floor(p.y)),
          w=Math.max(2,Math.floor(p.w)),h=Math.max(2,Math.floor(p.h)),
          im=ctx.getImageData(x0,y0,w,h).data,columns=[];
    for(let x=0;x<w;x++){
      const ys=[];
      for(let y=0;y<h;y++){
        const i=(y*w+x)*4;
        if(noiseForegroundMask(im[i],im[i+1],im[i+2]))ys.push(y0+y);
      }
      if(ys.length)columns.push({x:x0+x,y:median(ys),count:ys.length});
    }
    if(columns.length<Math.max(10,w*.06))
      return{ok:false,reason:'not enough direct Noise foreground columns',columns:columns.length};
    return{ok:true,source:'direct-noise-foreground-mask',points:columns,
           coverage:columns.length/Math.max(1,w)};
  }

  function robustMedian(vals){
    const a=vals.filter(Number.isFinite);
    if(!a.length)return NaN;
    const m=median(a),mad=median(a.map(v=>Math.abs(v-m)))||1e-9,
          keep=a.filter(v=>Math.abs(v-m)<=Math.max(mad*3.5,.0015));
    return median(keep.length?keep:a);
  }

  function directNoiseValues(prepared,trace){
    const cal=prepared.noiseAxis;
    if(!cal?.ok||!trace?.ok)return{ok:false,reason:'Noise axis or direct trace unavailable'};
    const p=prepared.plot,splitX=p.x+p.w*(270/500),low=[],high=[];
    for(const pt of trace.points){
      const v=pixelYToValue(pt.y,cal);
      if(!Number.isFinite(v))continue;
      if(pt.x<splitX)low.push(v);else high.push(v);
    }
    if(low.length<5||high.length<5)
      return{ok:false,reason:`insufficient Low/High direct trace samples (${low.length}/${high.length})`,
             lowCount:low.length,highCount:high.length,splitX};
    const lowValue=robustMedian(low),highValue=robustMedian(high);
    return{ok:Number.isFinite(lowValue)&&Number.isFinite(highValue),
      source:'direct-noise-grid-mapping',low:lowValue,high:highValue,
      lowCount:low.length,highCount:high.length,splitX,
      lowY:cal.zeroY-(lowValue/cal.stepValue)*cal.stepPx,
      highY:cal.zeroY-(highValue/cal.stepValue)*cal.stepPx};
  }

  function prepare(ctx,canvas,roi){
    const q=plotFromGrid(ctx,canvas,roi);
    if(!q)return null;
    q.axisFamily=axisStripFamily(ctx,canvas,q);
    q.noiseAxis=noiseAxisSeries(ctx,canvas,q);
    q.noiseTrace=directNoiseTrace(ctx,canvas,q);
    q.noiseValues=(q.noiseAxis?.ok&&q.noiseTrace?.ok)?directNoiseValues(q,q.noiseTrace):null;
    q.version='analysis-core-v2.0.4';
    return q;
  }
  return{prepare,plotFromGrid,axisStripFamily,noiseAxisSeries,pixelYToValue,directNoiseTrace,directNoiseValues};
});
