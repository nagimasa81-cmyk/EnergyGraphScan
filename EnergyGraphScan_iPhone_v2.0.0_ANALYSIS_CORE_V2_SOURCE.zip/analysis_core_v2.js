
((root,factory)=>{
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.EGSAnalysisV2=api;
})(typeof window!=='undefined'?window:globalThis,()=>{

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const median=a=>{
    const b=[...a].filter(Number.isFinite).sort((x,y)=>x-y),n=b.length;
    if(!n)return NaN;
    return n%2?b[(n-1)/2]:(b[n/2-1]+b[n/2])/2;
  };

  function greenish(r,g,b){
    const mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3;
    return g>34&&(
      (g>r*1.045&&g>b*.96&&g-Math.max(r,b)>3)||
      (lum>42&&sat>20&&g>=mx-3)
    );
  }
  const dark=(r,g,b)=>(r+g+b)/3<112;

  function groups(scores,threshold,maxGap=2){
    const ids=[],out=[];
    for(let i=0;i<scores.length;i++)if(scores[i]>=threshold)ids.push(i);
    for(const v of ids){
      if(!out.length||v-out.at(-1).at(-1)>maxGap)out.push([v]);
      else out.at(-1).push(v);
    }
    return out.map(g=>g.reduce((a,b)=>a+b,0)/g.length);
  }

  function regularRun(values,minGap,maxGap){
    if(values.length<3)return null;
    let best=null;
    for(let i=0;i<values.length-2;i++)for(let j=i+1;j<values.length-1;j++){
      const gap=values[j]-values[i];
      if(gap<minGap||gap>maxGap)continue;
      const seq=[values[i],values[j]];
      let last=values[j],err=0;
      for(let k=j+1;k<values.length;k++){
        const d=values[k]-last;
        if(Math.abs(d-gap)<=Math.max(2,gap*.28)){
          seq.push(values[k]);err+=Math.abs(d-gap)/Math.max(1,gap);last=values[k];
        }
      }
      if(seq.length<3)continue;
      const score=seq.length*4+(seq.at(-1)-seq[0])/Math.max(1,gap)-err;
      if(!best||score>best.score)best={seq,gap,score};
    }
    return best;
  }

  function plotFromGrid(ctx,canvas,roi){
    const x0=Math.max(0,Math.floor(roi.x)),
          y0=Math.max(0,Math.floor(roi.y)),
          w=Math.max(2,Math.min(canvas.width-x0,Math.ceil(roi.w))),
          h=Math.max(2,Math.min(canvas.height-y0,Math.ceil(roi.h))),
          im=ctx.getImageData(x0,y0,w,h).data,
          row=new Uint32Array(h),col=new Uint32Array(w),
          darkRow=new Uint32Array(h),darkCol=new Uint32Array(w);

    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenish(r,g,b)){row[y]++;col[x]++}
      if(dark(r,g,b)){darkRow[y]++;darkCol[x]++}
    }

    const rows=groups(row,Math.max(6,w*.20)),
          cols=groups(col,Math.max(6,h*.19)),
          rr=regularRun(rows,Math.max(5,h*.045),h*.30),
          cc=regularRun(cols,Math.max(6,w*.045),w*.25);

    let top,bottom,left,right,source='';
    if(rr&&cc){
      top=rr.seq[0];bottom=rr.seq.at(-1);
      left=cc.seq[0];right=cc.seq.at(-1);
      source='grid-lattice';
    }else{
      const rids=[],cids=[];
      for(let y=0;y<Math.floor(h*.78);y++)if(darkRow[y]>w*.28)rids.push(y);
      for(let x=Math.floor(w*.34);x<w;x++)if(darkCol[x]>h*.16)cids.push(x);
      if(rids.length&&cids.length){
        top=Math.min(...rids);bottom=Math.max(...rids);
        left=Math.min(...cids);right=Math.max(...cids);
        source='dark-rectangle';
      }
    }
    if(![top,bottom,left,right].every(Number.isFinite))return null;
    if(right-left<w*.26||bottom-top<h*.16)return null;

    const near=(arr,target,rad)=>{
      let best=target,score=-1;
      const a=Math.max(0,Math.floor(target-rad)),b=Math.min(arr.length-1,Math.ceil(target+rad));
      for(let i=a;i<=b;i++)if(arr[i]>score){best=i;score=arr[i]}
      return best;
    };
    top=near(row,top,Math.max(3,h*.035));
    bottom=near(row,bottom,Math.max(3,h*.035));
    left=near(col,left,Math.max(3,w*.035));
    right=near(col,right,Math.max(3,w*.035));

    const plot={x:x0+left,y:y0+top,w:right-left,h:bottom-top,
                x0:x0+left,y0:y0+top,x1:x0+right,y1:y0+bottom,source};
    const aspect=plot.w/Math.max(1,plot.h);
    if(aspect<1.25||aspect>4.5)return null;

    const lp=Math.max(18,plot.w*.23),rp=Math.max(5,plot.w*.025),
          tp=Math.max(7,plot.h*.11),bp=Math.max(14,plot.h*.28),
          cx0=clamp(plot.x-lp,0,canvas.width-2),
          cy0=clamp(plot.y-tp,0,canvas.height-2),
          cx1=clamp(plot.x+plot.w+rp,cx0+2,canvas.width),
          cy1=clamp(plot.y+plot.h+bp,cy0+2,canvas.height),
          context={x:cx0,y:cy0,w:cx1-cx0,h:cy1-cy0},
          insets={
            left:(plot.x-context.x)/context.w,
            top:(plot.y-context.y)/context.h,
            right:(context.x+context.w-(plot.x+plot.w))/context.w,
            bottom:(context.y+context.h-(plot.y+plot.h))/context.h,
            source:'v2-normalized-plot-context'
          };
    return{plot,context,insets,rows,cols,gridStepY:rr?.gap||NaN,gridStepX:cc?.gap||NaN};
  }

  function axisStripFamily(ctx,canvas,q){
    if(!q)return{family:null,confidence:0,reason:'no plot'};
    const p=q.plot,
          step=Number.isFinite(q.gridStepY)?q.gridStepY:Math.max(8,p.h/4),
          sx0=Math.max(0,Math.floor(p.x-p.w*.27)),
          sx1=Math.max(sx0+4,Math.floor(p.x-p.w*.015)),
          sw=sx1-sx0,
          count=Math.max(3,Math.min(7,Math.round(p.h/step)+1)),
          aspects=[],widths=[];

    for(let k=0;k<count;k++){
      const cy=p.y+k*(p.h/Math.max(1,count-1)),
            y0=Math.max(0,Math.floor(cy-step*.34)),
            y1=Math.min(canvas.height,Math.ceil(cy+step*.34)),
            h=Math.max(1,y1-y0),
            im=ctx.getImageData(sx0,y0,sw,h).data;
      let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity,n=0;
      for(let y=0;y<h;y++)for(let x=0;x<sw;x++){
        const i=(y*sw+x)*4,r=im[i],g=im[i+1],b=im[i+2],
              mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx-mn,lum=(r+g+b)/3,
              glyph=greenish(r,g,b)||(lum>80&&sat<62);
        if(glyph){minx=Math.min(minx,x);maxx=Math.max(maxx,x);miny=Math.min(miny,y);maxy=Math.max(maxy,y);n++}
      }
      if(n<5||!Number.isFinite(minx))continue;
      const ww=maxx-minx+1,hh=maxy-miny+1;
      if(ww>=3&&hh>=3){aspects.push(ww/hh);widths.push(ww)}
    }
    if(aspects.length<2)return{family:null,confidence:0,reason:'insufficient Y-axis glyph rows',aspects,widths};

    const a=median(aspects),wm=median(widths);
    if(a>=2.0||wm>=24)
      return{family:'Noise',confidence:clamp(.60+(a-2)*.18+(wm-24)*.012,.55,.96),
             reason:'long decimal Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    if(a>0&&a<=1.55&&wm<=20)
      return{family:'Gain',confidence:clamp(.58+(1.55-a)*.22+(20-wm)*.010,.54,.94),
             reason:'short Gain Y-axis glyphs',aspect:a,width:wm,rows:aspects.length};
    return{family:null,confidence:.35,reason:'axis glyph geometry ambiguous',aspect:a,width:wm,rows:aspects.length};
  }

  function prepare(ctx,canvas,roi){
    const q=plotFromGrid(ctx,canvas,roi);
    if(!q)return null;
    q.axisFamily=axisStripFamily(ctx,canvas,q);
    q.version='analysis-core-v2';
    return q;
  }
  return{prepare,plotFromGrid,axisStripFamily};
});
