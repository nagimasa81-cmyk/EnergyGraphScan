
const fs=require('fs');
const s=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(s.includes("function exactAnalysisROI"),"exactAnalysisROI missing");
ok(s.includes("const analysisROI=exactAnalysisROI(roi)"),"analyze does not freeze visible ROI");
ok(s.includes("roi={...analysisROI};"),"visible ROI is not synchronized to exact pixels");
ok(s.includes("checkedChannels(analysisROI)"),"channel stage not using exact ROI");
ok(s.includes("plotInsets(analysisROI)"),"geometry stage not using exact ROI");
ok(s.includes("calibrateTrack(scaled,analysisROI,insets"),"calibration stage not using exact ROI");
ok(s.includes("gainPixelLevelSummary(tr,analysisROI,insets"),"pixel level stage not using exact ROI");
ok(s.includes("function canvasDisplayTransform"),"shared display transform missing");
ok(s.includes("analysisCropFingerprint"),"analysis crop proof missing");
console.log("Exact visible ROI pixel regression PASS");
