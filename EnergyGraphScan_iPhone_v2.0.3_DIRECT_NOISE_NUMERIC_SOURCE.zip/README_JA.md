# Energy Graph Scan iPhone v1.7.0

## v1.7.0 Foreground trace isolation
- 複数Channelが重なって表示される場合、色クラスタごとにトレースを分離し、横方向の可視率と連続性から前面トレースを選択します。
- Low/High計算は前面トレース1本だけを使用し、背面トレースを平均・混合しません。
- Channel checkboxが1個だけ検出された場合はそのChannelを最優先します。
- 複数checkboxの場合は候補集合を保持し、foreground traceを解析対象とします。色→CH番号マッピングが十分に確定できない場合は無理にCH番号を断定しません。
- 完全重複区間では前後の同色トレース連続性を優先し、別色トレースへの乗り換えを抑制します。

# Energy Graph Scan iPhone v1.5.0

Mac/XcodeなしでiPhoneから使用できるSafari/PWA版です。

## 機能
- iPhoneカメラから直接撮影
- 写真ライブラリから画像選択
- 撮影時のEnergy per Bandガイド枠
- Energy per BandのAuto ROI
- ROIの手動位置調整
- Auto / Gain / Noise切替
- Low = Sample#0–270、High = Sample#270以降
- Channel未検出でもUnknownとして解析継続
- 複数Channel候補でも解析継続
- Gainは小数2桁、Noiseは小数4桁
- Gain High 1.00–1.50、Noise Low 0–0.015 / High 0.001–0.02のSpec判定
- 数値と同じ座標モデルでSample#270線・Low/High検出ラインを描画
- PWAキャッシュ対応。ホーム画面追加後はアプリ風に起動可能

## iPhoneでの使い方
1. GitHub Pages等のHTTPSサイトへこのフォルダを公開します。
2. iPhone SafariでURLを開きます。
3. 「共有」→「ホーム画面に追加」でアプリとして登録できます。
4. 「写真を撮る」でカメラを起動し、Channel欄とEnergy per Bandが入るよう撮影します。
5. 撮影後、自動ROIと解析が実行されます。
6. ROIがずれている場合は「ROI調整」を押し、赤枠をドラッグします。
7. 「Analyze」で再解析します。

## GitHub Pages
`.github/workflows/deploy-pages.yml`を同梱しています。GitHubのSettings → PagesでSourceをGitHub Actionsに設定後、workflowを実行してください。

## Windows v1.4.0との共通仕様 / iPhone v1.5.0 algorithm update
解析ロジックはWindows v1.4.0と同じ考え方で整理しています。ただしブラウザCanvas実装のためpixel extractionは別実装です。今後、実画像でWindows/iPhone双方の期待値を比較しながら閾値を揃える前提です。


## v1.5.0 解析アルゴリズム改善
- UI/撮影フローはv1.4.0から変更せず、解析エンジンを重点的に更新。
- Auto ROIを固定位置・固定サイズ中心の探索から、ダウンサンプル画像の黒背景連結領域検出へ変更。
- Energy per Band内の緑グリッドを検出できる場合、plotのleft/right/top/bottomを画像ごとに推定。
- Sample#270の分割線、Low/High表示線、数値換算が同じplot geometryを使用。
- 信号pixel抽出は各列独立のquantileだけでなく、前列の信号位置との連続性を使ってtraceを追跡。
- Low/High値はMAD外れ値除去に加え、10–90 percentileで極端値を抑制。
- ConfidenceはLow/Highのsample coverageと信号分離度の両方から算出。
- Channel検出はgraphからの固定320px位置依存を廃止し、graph相対領域から8候補を探索。
- Channel不明/複数候補の場合でも解析継続。
- Auto Gain/Noise判定はファイル名ではなくhorizontal green grid group数を利用。

### 重要
本版は解析アルゴリズムの構造改善版です。実際の失敗写真群を使ってROI、Channel、Low/High期待値を回帰検証すると、さらに精度を詰められます。


## iPhoneでオフラインアプリとして使う（v1.7.0）

1. GitHub PagesなどHTTPSの公開URLをSafariで一度オンラインで開きます。
2. 画面が完全に表示されたら、Safariの共有ボタンから「ホーム画面に追加」を選びます。
3. ホーム画面の **Energy Scan** アイコンから一度起動します。これでアプリ本体がiPhone内へキャッシュされます。
4. 以後は機内モードなど通信が無い状態でも、ホーム画面から起動して「写真を撮る」「写真を選ぶ」「解析」を利用できます。解析は端末内JavaScriptのみで実行され、画像をサーバーへ送信しません。

### 更新方法
新しいSOURCE ZIPをGitHubへアップロードしてPagesが更新された後、iPhoneをオンラインにしてEnergy Scanを一度起動してください。Service Workerが新しいアプリファイルを取得します。その後は再びオフライン利用できます。

### 注意
初回インストール/初回キャッシュだけはオンライン接続が必要です。Safariの通常タブより、ホーム画面に追加したアイコンからの起動を推奨します。iOSがWebサイトデータを削除した場合は、再度オンラインで開いてキャッシュし直す必要があります。


## v1.7.0 analysis fixes
- Auto mode does not use grid count. It uses the isolated foreground trace baseline/step/value-shape features.
- Auto ROI: prioritizes the compact green Energy per Band grid instead of generic black chart regions.
- Manual ROI: four corner handles resize the ROI; dragging inside moves it.
- Plot geometry: derives top/bottom/left/right from long green grid lines rather than green text pixels.
- Foreground trace scoring now requires coverage on both sides of Sample#270 and follows overexposed white centers near the same trace.
- Existing offline PWA behavior is preserved.


## v1.7.0 Auto mode
- Gain/Noise の判定にグリッド本数を使用しません。
- 前面トレースを0–1正規化してから Low/High の相対位置、段差、ベースライン形状で判定します。
- 判定が曖昧な場合は誤判定を避けるため Unknown とし、Gain/Noise の手動選択を求めます。
- Noise の縦軸換算はグリッド本数に依存せず 0.04 を基準にします。


## v1.7.0 fixes
- Auto ROI now uses multi-cue compact-chart scoring (dark plot + green grid + warm foreground signal) to avoid Raw Data/Spectrum.
- Plot geometry selects long, near-even major grid lines and ignores green text labels.
- Foreground color tracks are re-ranked after Gain/Noise is known; only the selected foreground trace is used.
- Auto mode uses the foreground step/baseline pattern; grid count is not used.
- Overlay now marks the actually tracked foreground trace and draws Low/High lines from the same geometry/value model.


## v1.7.0 変更点
- 撮影ボタンはアプリ内カメラを優先し、撮影中だけ3x3グリッドを表示。通常の解析画面には撮影グリッドを表示しません。
- Auto ROIの右上位置ボーナスを削除。Energy per Bandの見た目（黒背景、緑グリッド、色トレース、コンパクト形状）だけで全画面を探索します。
- Gain/Noise判定にグリッド本数は使用しません。
- Mode確定後、主要横グリッド間隔からY軸を校正し、同じ校正を数値計算とLow/High表示ラインに使用します。
- foreground trace / Channel優先ルール / オフラインPWAは維持。


## v1.7.0 camera fix
- 撮影経路をアプリ内カメラへ一本化。撮影中のみ3x3グリッド表示。
- 撮影画像はfile inputへ戻さず直接Imageとして読み込み、撮影後に選択が消えるiOS問題を回避。
- PWAのCSS/JSをnetwork-first + version queryにし、旧版キャッシュ混在を防止。
- カメラ許可/起動失敗時はモーダル内で状態を表示し再試行可能。


## v1.7.0
- 撮影時の3x3グリッドを廃止し、Energy per Band + Channel用の外枠だけを表示。
- Auto ROIを画面位置非依存の構造スコア方式へ再実装。
- Y軸校正はplot内部の長い横グリッドだけを使用。
- Low/Highラインは解析トレースの実pixel位置を直接表示し、その同じpixel位置を数値へ変換。
- グリッド本数はGain/Noise判定には使用しない。


## v1.7.0
- 横向き撮影時にガイド枠も横向き・実グラフ比率に追従。
- Auto ROIは細い横方向トレースを強く評価し、Raw Data/Spectrumの誤選択を抑制。
- Autoモードが不確実でもProvisional Autoとして解析を継続。


## v1.7.0 統合解析コア
Windows v1.9.0 と `analysis_contract_v2.json` を共有します。Auto ROI / plot / foreground / mode / Y軸校正のいずれかが成立しない場合、推測値やSPEC結果を出しません。Gainは横方向固定分割を使用せず、Low安定区間・遷移区間・High安定区間を自動認識します。NoiseのみSample#270境界を維持します。


## v1.7.1 撮影後フリーズ対策
- iPhoneカメラ撮影後、フル解像度の画面全体を解析しない。
- 黄色の撮影ガイド枠をカメラのintrinsic pixel座標へ変換し、枠内だけを直接切り出す。
- `object-fit: cover` による画面表示時のcrop量も補正する。
- 黄色枠自体が画像へ入らないように小さな内側marginを設ける。
- 切り出し画像は最大幅1400pxへ縮小してからJPEG化し、Auto ROI / Channel / foreground解析へ渡す。
- これにより撮影後のメモリ使用量と全画面走査量を大幅に削減する。


## 1.7.2 Y軸数値ラベル校正
- 最下段major gridline=0 の仮定を廃止。
- Energy per Band左Y軸で実際に見えている数値ラベルだけをアンカーとして使用。
- 2個以上のラベル: pixel Y ↔ 実値を回帰して傾き/切片を決定。
- 1個だけのラベル: 読み取った実値をアンカーにし、major grid spacingから傾きだけ補完。
- 0個: 数値とSPECを出さない。
- ラベルが一部隠れていても、見えているアンカーだけで処理。
- グリッド本数をGain/Noise判定には使用しない。
- Gain Low/High横範囲は自動認識、NoiseのみSample#270。
- デバッグ情報にY-axis anchorsを表示。

## v1.7.3 ROI Rescue
- Auto ROIは確定値ではなく候補表示に変更。画像ロード直後に自動解析しない。
- 撮影枠切り出し画像ではEnergy per Bandの上側小グラフを優先し、Raw Data/Spectrum候補を抑制。
- ROI表示座標をcanvasの実表示offset込みで計算し、下方向へ動かせない問題を修正。
- ROI操作中のiOSテキスト選択/長押しメニューを無効化。
- perspective/moire向けrelaxed-grid geometryを追加。
- Auto modeが曖昧でもLow/HighはProvisionalとして計算。モード確定までSPECは表示しない。


## v1.7.4 Camera Return Freeze Fix
- 撮影後/写真読込直後の `detectGraph()` 自動実行を完全停止。
- 撮影後は画像を即表示し、編集可能な初期ROIを置いてUIを返す。
- Auto ROIはボタンを押した時だけ実行。
- Auto ROI実行前にstatusを描画し、終了までボタンを一時disable。
- 撮影枠切り出し画像ではAuto ROI探索範囲を上側72%・右側72%へ限定し、downsampleを強化。
- カメラ切り出し画像は最大1400pxへ縮小してメモリ負荷を抑制。


## v1.7.5 Default Auto Analyze Flow
- iPhone撮影後の基本フローを `撮影 → 撮影枠crop → Auto ROI → Analyze` に統一。
- 撮影直後に同期処理せず、画像を先に描画してから requestAnimationFrame + setTimeout で段階実行。
- Auto ROI失敗時は初期editable ROIでAnalyzeを試行し、失敗した場合のみ手動ROI調整へ移行。
- ユーザーがROI調整/Auto ROI/Analyzeを手動操作した場合は実行中の自動パイプラインをキャンセル。


## v1.7.6 Post-Capture Runtime Fix
- 撮影後の `Can't find variable: isGreen` を修正。
- ROI/grid/foreground解析で共通使用する `isGreen()` を復元。
- 撮影後 `useImage()` の直後にstatusを上書きしていた処理を削除。
- 自動Analyzeの例外内容を画面へ表示し、無反応/フリーズに見えないよう改善。
- `check_runtime_helpers.py` を追加し、必須JS helperの欠落を配布前に検出。

## v1.7.7 Channel-first / No Plot Hard-Stop
- Channel checkbox判定をplot確定より先に実行。
- Channelルール:
  - 1個チェック: そのCHを確定。
  - 複数チェック: foreground hueが選択済みの既知Channel色と一致した時だけ確定。
  - 一致しない/未知色: Channel=Unknown。
  - Unknownでも解析継続。
- `Energy per Band plot could not be confirmed` をhard stopから削除。
- geometry fallback: major-grid -> relaxed-grid -> dark-plot -> ROI-estimate。
- Y軸数値ラベル校正が失敗した場合も、Channel/Mode/Trace結果は保持し、Low/High数値とSPECだけ保留。
- 確定していない複数Channel候補を結果欄に `CH3/CH4/...` と表示せず、明確に `Unknown` と表示。

## v1.7.8 Y-axis Label Sequence OCR
- Y軸OCRをMode依存から分離。AutoがNoiseと誤判定していてもGainの3.0/2.0/1.0を探索する。
- 各ラベルを単独閾値で捨てず、複数ラベルを上下位置・単調減少・grid spacingと合わせて系列認識。
- Arial/Helvetica/Tahoma/Verdana/Courier/monospace/sans-serif、複数font sizeのテンプレートを比較。
- iPhone写真のぼけ/モアレに合わせ、Y軸緑文字抽出を緩和。
- 2個以上の可視ラベルからpixel-value一次式を直接fit。最下段grid=0の仮定は使用しない。
- 読み取った値のfamilyがGain/NoiseのAuto判定と矛盾した場合、Y軸ラベルを優先してAuto modeを補正。
- デバッグ表示にanchor値・pixel Y・個別confidenceを表示。

## v1.7.9 Noise Low/High Robust Split
- NoiseはLow/Highの振幅差で境界判定しない。
- Noise Low/HighはSample#270を意味上の境界として左右を独立集計。
- 270近傍は遷移/重なり帯として除外し、サンプル不足時のみmarginを段階的に縮小。
- Low/Highの値がほぼ同じ、または完全に同じでも正常に計算する。
- Noise confidenceからLow/High separation依存を削除。左右coverage + 各区間のstabilityだけで評価。
- 外れ値/MAD/10–90 percentile処理を左右別々に適用。
- Gainのtransition検出が弱い場合も、左右外側のstable plateauを低confidenceで採用して解析停止を回避。

## v1.8.0 Vision-style Axis Reasoning
- Manual Gain/Noiseを絶対優先。Manual GainでNoise familyを使う経路を禁止。
- AutoはGain/NoiseのY軸仮説を別々に作成し、trace shape + label series + grid step + numeric scaleを統合評価。
- `3.0/2.0/1.0` を `0.10/0.04/0.02` と誤採用しにくいよう、1 major gridあたりの数値step整合を厳格化。
- OCR単独winnerではなく、複数ラベル系列の整合性を優先。
- OCRが曖昧なら、弱い反対familyで明瞭なtrace-modeを上書きしない。
- Axis reasoningのGain/Noise scoreを結果messageに表示。

## iPhone v1.8.1 Pixel-primary Measurement
- foreground traceの実pixelを一次測定値として保存。
- Low/High代表高さはrobust median。平均値による下振れを抑制。
- Gainの表示X範囲はstable subsetのmin/maxではなく、transition前後のplateau全体。
- 数値は同じ代表pixelをY軸校正へ入力して算出。
- overlayも同じ代表pixelとplateau範囲を直接使用。
- 値からpixelへ逆変換してoverlayを作らない。

## v1.8.2 Axis Contradiction Guard
- yAxisCalibrationのOCR候補を確定Mode familyへロック。Gain指定時にNoise候補を混ぜない。
- 単一ラベルだけで数値確定しない。隣接major-grid rowに予測値の弱いOCR裏取りが必要。
- 3.0/2.0/1.0等のカメラ撮影文字に合わせ、緑＋anti-aliased明色をY-label strip内だけ許容。
- GainでHigh<Lowになる校正を棄却。
- 可視major-gridの数値spanから大きく外れるLow/Highを棄却。
- 校正矛盾時はTrace/Channel/Mode/overlayを保持し、Low/High/SPECのみ保留。
- Y軸anchor数/fit qualityをConfidenceへ反映し、弱い1-anchorで90%超にならないよう修正。

## v1.8.3 Direct Glyph Evidence
- Gain OCR候補を0.0〜4.0、Noiseを0.000〜0.050へ制約。
- 正規化前の文字aspect ratio / ink density / X-Y projectionを保持。
- IoUだけでなく文字列形状・横長さ・密度をtemplate照合へ反映。
- weak OCR候補を数学的系列補完へ使わない。
- direct strong glyph anchor 2個以上を必須化。
- one-anchor numeric calibrationを廃止。

## v1.8.4 Major-grid Zero Baseline
- Y軸OCRを数値定規から外し、major horizontal gridを数値定規として使用。
- 最下段major grid=0。
- Gainは上へ1 grid=1.0、Noiseは上へ1 grid=0.01。
- OCRはfamily/confidence補助のみ。`4,3,3,2` のような誤系列でscale全体をずらさない。

## v1.8.5 Zero-row Label/Grid Consensus
- 最下段major grid=0という仮定を撤廃。
- major gridは間隔の測定に使用。
- Y軸ラベルは「どのgrid rowが何の値か」のordinal投票に使用。
- 2つ以上の独立ラベルが同じzero-row offsetを支持した場合のみ数値校正。
- Gain 3.0/2.0/1.0なら1.0の1段下を0として復元。
- Noise 0.04/0.03/0.02/0.01も同じ方式で0位置を復元。

## v1.8.7 Exact Visible ROI Pixels
- Auto ROIのサイズ/位置アルゴリズムは変更しない。
- Analyze開始時、赤枠をcanvas整数pixelへ1回だけ確定。
- Channel / plot geometry / foreground trace / Y-axis / Low-High / overlayが同じanalysisROIを共有。
- DOM表示ROIとcanvas pixel ROIの変換をcanvasDisplayTransformへ一本化。
- 各処理が独立にROI外周をfloor/ceilする経路を廃止。
- 実際に解析したcropのx/y/w/hと軽量hashをdiagnosticsへ保存。

## v1.8.8 Y-axis Family Geometry
- ROI / Exact Analysis ROIは変更なし。
- Y軸ラベルの実画像aspect/widthを保持。
- 長い `0.04000 / 0.03000 / 0.02000` 型ラベルをNoise familyの直接証拠として使用。
- 短い `3.0 / 2.0 / 1.0` 型ラベルをGain familyの証拠として使用。
- AutoではY軸文字形状を波形形状より優先してGain/Noiseを補正。
- `4,3,2,0` のような欠落系列はcompletedAnchorsで `1` を補間するが、補間だけでzero位置は決めない。

# v2.0.0 Analysis Core v2

旧v1.xの補正積み上げから解析順序を再構成。

- 赤ROI = 探索範囲。ROIそのものをEnergy per Band plotとはみなさない。
- ROI内からgreen major-grid / dark chart rectangleで実plotを独立検出。
- 実plotからY-axis labels + plot + Sample/Bandsだけのanalysis contextを生成。
- Channel checkboxは元画面/ROIで判定。
- Gain/Noise Auto判定は、Y軸文字列の見た目を優先:
  - 長い `0.04000 / 0.03000 ...` = Noise
  - 短い `3.0 / 2.0 / 1.0` = Gain
- foreground trace / Y calibration / Low-Highは同じanalysis contextを共有。
- plotやY軸が不確かな場合は誤数値を出さずLow/Highだけ保留。

今回の目的は補正係数追加ではなく、
ROI / plot / axis / trace / numeric calibration の責務分離。

## v2.0.1 Noise Y-axis Major-grid Series
- Noise確定時はY軸数値OCRを主経路から外す。
- plot内の横major-gridを直接検出し、上から0.04 / 0.03 / 0.02 / 0.01 / 0へ系列化。
- 4本しか見えない場合のみzero rowを1 grid下へ補外。
- trace pixel Yをこの系列でEnergy値へ変換。
- Low/High横範囲はSample# 0–270 / 270–500。

## v2.0.2 Structural Noise Grid Detection
- v2.0.1の「緑色pixel数が一定以上」という条件を廃止。
- 横方向の線連続性、green成分、明暗edgeを合成してhorizontal grid候補を検出。
- 4〜6本の候補から等間隔性が最も高いmajor-grid latticeを選択。
- camera moire / 色褪せ / 黄色foregroundがあってもgridを候補化。
- Noise axis candidateはGain/Noise family判定より前に常時作成。
- Mode=Noise確定後、prepare時に失敗していても再度Noise grid seriesを試行。

## v2.0.3 Direct Noise Numeric Path
- Noise数値化を汎用calibrated.trackから分離。
- plot内の明るいyellow/orange/green foreground traceを直接抽出。
- Sample# 270/500でLow/Highを分割。
- 各column代表YをNoise major-gridへ直接変換。
- MAD外れ値除外 + median。
- 新Noise経路失敗時のみ旧trackへfallback。
- 0.04/0.03/0.02/0.01/0.00 gridを水色、Lowを白、Highを橙、270境界を黄点線でoverlay。
