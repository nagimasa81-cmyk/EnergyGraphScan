
const fs=require('fs');
const s=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(s.includes("major-grid-zero-baseline"),"grid baseline calibration missing");
ok(s.includes("value:o.k*unit"),"ordinal value mapping missing");
ok(s.includes("modeHint==='Noise'?.01:1"),"Gain/Noise unit mapping missing");
ok(!s.includes("zeroY=-seq.intercept/seq.slope"),"OCR still controls zero intercept");
console.log("Grid ordinal axis regression PASS");
