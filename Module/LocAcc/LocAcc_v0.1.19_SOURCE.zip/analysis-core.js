(function(global){
  'use strict';

  function rgbToHSV(r,g,b){
    r/=255; g/=255; b/=255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
    let h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return [h, max?d/max:0, max];
  }


  function clamp255(v){ return v<0?0:v>255?255:v; }

  function sampledPercentile(values,p){
    if(!values.length) return 0;
    values.sort((a,b)=>a-b);
    return values[Math.max(0,Math.min(values.length-1,Math.floor((values.length-1)*p)))];
  }

  function bandAdaptiveStats(data,w,h,x0,y0,x1,y1,step){
    const lum=[],cyan=[],red=[],yellow=[];
    step=Math.max(1,step||3);
    for(let y=y0;y<y1;y+=step) for(let x=x0;x<x1;x+=step){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const l=.2126*r+.7152*g+.0722*b;
      lum.push(l);
      cyan.push(Math.max(g-r,b-r,(g+b)*.5-r));
      red.push(r-Math.max(g,b));
      yellow.push(Math.min(r,g)-b*.55);
    }
    return {
      lum10:sampledPercentile(lum,.10), lum50:sampledPercentile(lum,.50), lum90:sampledPercentile(lum,.90),
      cyan70:sampledPercentile(cyan,.70), cyan84:sampledPercentile(cyan,.84), cyan93:sampledPercentile(cyan,.93),
      red70:sampledPercentile(red,.70), red88:sampledPercentile(red,.88),
      yellow75:sampledPercentile(yellow,.75), yellow90:sampledPercentile(yellow,.90)
    };
  }

  function adaptiveContrastValue(lum,lo,hi){
    const den=Math.max(12,hi-lo);
    return clamp255((lum-lo)*255/den);
  }

  function connectedComponents(mask,w,h,minArea){
    const seen=new Uint8Array(mask.length), comps=[];
    const stack=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||seen[idx]) continue;
      let sp=0; stack[sp++]=idx; seen[idx]=1;
      let area=0,sumX=0,sumY=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        const ci=stack[--sp], cx=ci%w, cy=(ci/w)|0; area++; sumX+=cx; sumY+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k], ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h) continue;
          const ni=ny*w+nx; if(mask[ni]&&!seen[ni]){seen[ni]=1;stack[sp++]=ni;}
        }
      }
      if(area>=minArea) comps.push({area,cx:sumX/area,cy:sumY/area,minX,maxX,minY,maxY});
    }
    return comps;
  }

  function redRegion(data,w,h){
    const raw=new Uint8Array(w*h),xLo=w*.08,xHi=w*.86,yLo=h*.08,yHi=h*.90;
    const rs=bandAdaptiveStats(data,w,h,Math.floor(xLo),Math.floor(yLo),Math.floor(xHi),Math.floor(yHi),Math.max(2,Math.round(Math.min(w,h)/650)));
    const minRedExcess=Math.max(10,Math.min(38,rs.red88*.24)),minLum=Math.max(32,Math.min(88,rs.lum50*.55));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      if(x<xLo||x>xHi||y<yLo||y>yHi)continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b;
      if((hh<48||hh>326)&&r-Math.max(g,b)>=minRedExcess&&r>g*1.055&&r>b*1.07&&ss>.13&&vv>.25&&lum>=minLum)raw[y*w+x]=1;
    }
    const comps=connectedComponents(raw,w,h,Math.max(80,Math.floor(w*h*.00035))).filter(c=>{
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      return c.area<w*h*.24&&bw>w*.035&&bh>h*.035&&c.cx>w*.18&&c.cx<w*.78&&c.cy>h*.18&&c.cy<h*.82;
    }).sort((a,b)=>b.area-a.area);
    if(!comps.length)throw new Error('Red thermal region not detected.');
    const seed=comps[0],rows=[],widths=[];
    for(let y=seed.minY;y<=seed.maxY;y++){
      let lo=w,hi=-1,n=0;
      for(let x=seed.minX;x<=seed.maxX;x++)if(raw[y*w+x]){lo=Math.min(lo,x);hi=Math.max(hi,x);n++;}
      if(hi>=lo&&n>=Math.max(2,(hi-lo+1)*.055)){rows.push({y,lo,hi});widths.push(hi-lo+1);}
    }
    widths.sort((a,b)=>a-b);const medW=widths[Math.floor(widths.length*.5)]||1;
    const filled=new Uint8Array(w*h);let area=0,sx=0,sy=0,minX=w,maxX=0,minY=h,maxY=0;
    for(const q of rows.filter(q=>(q.hi-q.lo+1)>=Math.max(4,medW*.16))){
      for(let x=q.lo;x<=q.hi;x++){filled[q.y*w+x]=1;area++;sx+=x;sy+=q.y;}
      minX=Math.min(minX,q.lo);maxX=Math.max(maxX,q.hi);minY=Math.min(minY,q.y);maxY=Math.max(maxY,q.y);
    }
    if(area<100)throw new Error('Red thermal region geometry was not stable enough.');
    return {component:{area,cx:sx/area,cy:sy/area,minX,maxX,minY,maxY,rawCx:seed.cx,rawCy:seed.cy},mask:filled,rawMask:raw};
  }

  function crossCenter(data,w,h,red){
    const c=red.component,bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
    const x0=Math.max(0,Math.floor(c.minX+bw*.20)),x1=Math.min(w-1,Math.ceil(c.maxX-bw*.20));
    const y0=Math.max(0,Math.floor(c.minY+bh*.20)),y1=Math.min(h-1,Math.ceil(c.maxY-bh*.20));
    const mask=new Uint8Array(w*h),cs=bandAdaptiveStats(data,w,h,x0,y0,x1+1,y1+1,1);
    const yellowCut=Math.max(12,cs.yellow90*.46),brightCut=Math.max(52,cs.lum50*.72);
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      if(!red.mask[y*w+x])continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b,ys=Math.min(r,g)-b*.55;
      if(hh>=25&&hh<=125&&ss>.12&&vv>.32&&lum>=brightCut&&ys>=yellowCut)mask[y*w+x]=1;
    }
    const comps=connectedComponents(mask,w,h,3);let best=null;
    for(const q of comps){
      const qw=q.maxX-q.minX+1,qh=q.maxY-q.minY+1;if(qw<5||qh<5||qw>bw*.42||qh>bh*.42)continue;
      const band=Math.max(1,Math.round(Math.min(w,h)*.0025)),cx=Math.round(q.cx),cy=Math.round(q.cy);let hl=0,hr=0,vu=0,vd=0;
      for(let x=q.minX;x<=q.maxX;x++){let hit=0;for(let y=Math.max(q.minY,cy-band);y<=Math.min(q.maxY,cy+band);y++)hit+=mask[y*w+x];if(hit){if(x<cx)hl++;else if(x>cx)hr++;}}
      for(let y=q.minY;y<=q.maxY;y++){let hit=0;for(let x=Math.max(q.minX,cx-band);x<=Math.min(q.maxX,cx+band);x++)hit+=mask[y*w+x];if(hit){if(y<cy)vu++;else if(y>cy)vd++;}}
      const minArm=Math.max(2,Math.round(Math.min(qw,qh)*.15));if(hl<minArm||hr<minArm||vu<minArm||vd<minArm)continue;
      const aspect=Math.min(qw,qh)/Math.max(qw,qh),dist=Math.hypot(q.cx-c.cx,q.cy-c.cy)/Math.max(1,Math.min(bw,bh));
      const balance=Math.min(hl,hr)/Math.max(hl,hr)*.5+Math.min(vu,vd)/Math.max(vu,vd)*.5,score=aspect*.28+balance*.42+Math.max(0,1-dist/.38)*.30;
      if(!best||score>best.score)best={q,score,cx,cy};
    }
    if(!best||best.score<.50)throw new Error('Cross center not shape-confirmed.');
    return {x:best.cx,y:best.cy,rawX:best.q.cx,rawY:best.q.cy,pixelCount:best.q.area,shapeScore:best.score};
  }

  function localContrastGray(data,w,h,x0,y0,x1,y1){
    const pts=[]; let mean=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4; const r=data[i],g=data[i+1],b=data[i+2]; const lum=.2126*r+.7152*g+.0722*b;
      mean+=lum;n++;pts.push([x,y,lum,r,g,b]);
    }
    mean/=Math.max(1,n); let variance=0; for(const p of pts)variance+=(p[2]-mean)*(p[2]-mean); const sd=Math.sqrt(variance/Math.max(1,n));
    return {pts,mean,sd};
  }

  function detectOrientation(data,w,h){
    // Bottom-right marker detector.
    // The marker can be cyan, gray or partially washed out in a photographed LCD,
    // so use local contrast as the primary signal and color only as a bonus.
    const x0=Math.floor(w*.82),x1=Math.floor(w*.985),y0=Math.floor(h*.80),y1=Math.floor(h*.985);
    const rw=x1-x0,rh=y1-y0;
    const lc=localContrastGray(data,w,h,x0,y0,x1,y1);
    const os=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const mask=new Uint8Array(rw*rh);

    const lumBase=Math.max(os.lum50+2,lc.mean+Math.max(2,lc.sd*.12));
    const cyanBase=Math.max(1.5,os.cyan70*.42);

    for(const p of lc.pts){
      const [x,y,lum,r,g,b]=p;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const contrast=lum-lc.mean;
      // Accept either highlighted cyan pixels OR locally bright/contrasty neutral pixels.
      const on=(cyanScore>=cyanBase && lum>=os.lum50) ||
               (lum>=lumBase && contrast>=Math.max(2,lc.sd*.10));
      if(on) mask[(y-y0)*rw+(x-x0)]=1;
    }

    // Bridge one-pixel gaps caused by moire / antialiasing.
    const joined=new Uint8Array(mask);
    for(let yy=1;yy<rh-1;yy++)for(let xx=1;xx<rw-1;xx++){
      if(mask[yy*rw+xx])continue;
      const h=mask[yy*rw+xx-1]&&mask[yy*rw+xx+1];
      const v=mask[(yy-1)*rw+xx]&&mask[(yy+1)*rw+xx];
      const d1=mask[(yy-1)*rw+xx-1]&&mask[(yy+1)*rw+xx+1];
      const d2=mask[(yy-1)*rw+xx+1]&&mask[(yy+1)*rw+xx-1];
      if(h||v||d1||d2)joined[yy*rw+xx]=1;
    }

    const comps=connectedComponents(joined,rw,rh,2)
      .filter(c=>{
        const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
        return c.area<rw*rh*.10 && ww>=3 && hh>=3 &&
               ww<rw*.55 && hh<rh*.55;
      });

    function caretScores(c){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      const pts=[];
      for(let y=c.minY;y<=c.maxY;y++)for(let x=c.minX;x<=c.maxX;x++){
        if(joined[y*rw+x])pts.push([x,y]);
      }
      if(pts.length<3)return {up:0,right:0};

      const midX=(c.minX+c.maxX)/2,midY=(c.minY+c.maxY)/2;
      const sx=Math.max(1,ww/2),sy=Math.max(1,hh/2);

      // For ^ : apex near top-center, with two arms extending down-left/down-right.
      // For > : apex near right-center, with two arms extending up-left/down-left.
      let upShape=0,rightShape=0,upUsed=0,rightUsed=0;
      for(const [x,y] of pts){
        const nx=(x-midX)/sx, ny=(y-midY)/sy;
        // Ideal ^ arms: |nx| approximately ny+1 (ny=-1 at apex, +1 at base)
        const upErr=Math.abs(Math.abs(nx)-Math.max(0,(ny+1)*.55));
        const upPosPenalty=ny<-1.15||ny>1.15?1:0;
        upShape+=Math.max(0,1-upErr*.90-upPosPenalty);upUsed++;

        // Ideal > arms: |ny| approximately 1-nx (nx=+1 at apex)
        const rightErr=Math.abs(Math.abs(ny)-Math.max(0,(1-nx)*.55));
        const rightPosPenalty=nx<-1.15||nx>1.15?1:0;
        rightShape+=Math.max(0,1-rightErr*.90-rightPosPenalty);rightUsed++;
      }
      upShape/=Math.max(1,upUsed);rightShape/=Math.max(1,rightUsed);

      // Apex evidence: top-center for ^, right-center for >.
      let upApex=0,rightApex=0;
      for(const [x,y] of pts){
        const nx=Math.abs((x-midX)/sx),ny=(y-c.minY)/Math.max(1,hh-1);
        if(ny<.35 && nx<.45)upApex++;
        const rx=(c.maxX-x)/Math.max(1,ww-1),ry=Math.abs((y-midY)/sy);
        if(rx<.35 && ry<.45)rightApex++;
      }
      upApex/=pts.length;rightApex/=pts.length;

      // Bilateral arm evidence.
      let ul=0,ur=0,rl=0,rr=0;
      for(const [x,y] of pts){
        if(y>midY){
          if(x<midX)ul++; else ur++;
        }
        if(x<midX){
          if(y<midY)rl++; else rr++;
        }
      }
      const upBalance=Math.min(ul,ur)/Math.max(1,Math.max(ul,ur));
      const rightBalance=Math.min(rl,rr)/Math.max(1,Math.max(rl,rr));

      return {
        up:upShape*.58+upApex*.22+upBalance*.20,
        right:rightShape*.58+rightApex*.22+rightBalance*.20
      };
    }

    let best=null;
    for(const c of comps){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      const sc=caretScores(c);
      // Prefer the actual marker zone: lower-right of the thermal viewport ROI,
      // but do not hardcode a single pixel coordinate.
      const cx=(c.minX+c.maxX)/2,cy=(c.minY+c.maxY)/2;
      const posX=cx/rw,posY=cy/rh;
      const posBonus=(posX>.25?.06:0)+(posY>.20?.04:0);
      const compact=c.area/Math.max(1,ww*hh);
      const quality=Math.max(sc.up,sc.right)+posBonus+Math.min(.08,compact*.08);
      if(!best||quality>best.quality)best={c,sc,quality,ww,hh};
    }

    if(!best){
      return {direction:'up',confidence:.34,reason:'marker not isolated; conservative up fallback'};
    }

    // Right must win clearly. A photographed ^ often becomes vertically fragmented,
    // so ambiguous cases should remain Up rather than being flipped to Right.
    const margin=best.sc.up-best.sc.right;
    let direction='up';
    if(best.sc.right>best.sc.up+.16 && best.sc.right>.48)direction='right';

    const winning=direction==='up'?best.sc.up:best.sc.right;
    const conf=Math.max(.36,Math.min(.97,.46+winning*.42+Math.min(.12,Math.abs(margin)*.35)));

    return {
      direction,confidence:conf,
      bbox:{minX:best.c.minX+x0,maxX:best.c.maxX+x0,minY:best.c.minY+y0,maxY:best.c.maxY+y0},
      width:best.ww,height:best.hh,
      upScore:best.sc.up,rightScore:best.sc.right,
      reason:`caret shape up=${best.sc.up.toFixed(2)} right=${best.sc.right.toFixed(2)}`
    };
  }

  function percentile(arr,p){ const a=Array.from(arr).sort((a,b)=>a-b); return a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))]; }

  function findSixRegularTicks(cands,h){
    let best=null;
    const minGap=h*.018,maxGap=h*.095;
    for(let a=0;a<cands.length;a++) for(let b=a+1;b<cands.length;b++){
      const span=cands[b].y-cands[a].y;
      for(let steps=1;steps<=5;steps++){
        const gap=span/steps;if(gap<minGap||gap>maxGap)continue;
        for(let apos=0;apos<=5-steps;apos++){
          const first=cands[a].y-apos*gap,selected=[];let err=0,strength=0,ok=true,lastIdx=-1;
          const tol=Math.max(4,gap*.14);
          for(let k=0;k<6;k++){
            const target=first+k*gap;let bi=-1,be=1e9;
            for(let j=lastIdx+1;j<cands.length;j++){
              const e=Math.abs(cands[j].y-target);if(e<be){be=e;bi=j;}if(cands[j].y>target+tol)break;
            }
            if(bi<0||be>tol){ok=false;break;}selected.push(cands[bi]);lastIdx=bi;err+=be/gap;strength+=cands[bi].score;
          }
          if(!ok)continue;
          const ys=selected.map(t=>t.y),gaps=[];for(let k=0;k<5;k++)gaps.push(ys[k+1]-ys[k]);
          const mean=gaps.reduce((x,y)=>x+y,0)/5,maxDev=Math.max(...gaps.map(g=>Math.abs(g-mean)/mean));
          const fullSpan=ys[5]-ys[0];if(maxDev>.15||fullSpan<h*.09||fullSpan>h*.48)continue;
          const quality=130-err*20-maxDev*190+Math.min(40,strength*.18);
          if(!best||quality>best.quality)best={quality,selected,gaps,fullSpan,maxDev};
        }
      }
    }
    return best;
  }

  function detectScale(data,w,h){
    // First locate the vertical ruler spine, then search ONLY for six ticks attached to that spine.
    // This avoids using text baselines and other horizontal UI edges as a ruler.
    const sx0=Math.floor(w*.78),sx1=Math.floor(w*.965),y0=Math.floor(h*.18),y1=Math.floor(h*.84);
    const lum=new Float32Array(w*h);
    // Scale profile: grayscale + robust contrast stretch. No color enhancement is
    // used here because the ruler is a geometric edge problem.
    const ss=bandAdaptiveStats(data,w,h,sx0,y0,sx1,y1,Math.max(2,Math.round(Math.min(w,h)/700)));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,rawLum=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];
      lum[y*w+x]=adaptiveContrastValue(rawLum,ss.lum10,ss.lum90);
    }
    const xScores=[];
    for(let x=sx0+2;x<sx1-2;x++){
      let s=0,n=0;
      for(let y=y0;y<y1;y+=2){
        const edge=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
        const verticalSmooth=Math.abs(lum[(Math.min(h-1,y+1))*w+x]-lum[(Math.max(0,y-1))*w+x]);
        s+=Math.max(0,edge-verticalSmooth*.22);n++;
      }
      xScores.push({x,score:s/Math.max(1,n)});
    }
    xScores.sort((a,b)=>b.score-a.score);
    const spineCandidates=xScores.slice(0,10);
    let globalBest=null;
    for(const sp of spineCandidates){
      const left=Math.max(0,Math.floor(sp.x-w*.075)),right=Math.min(w-1,Math.floor(sp.x+w*.012));
      const scores=[];
      for(let y=y0+2;y<y1-2;y++){
        let s=0,n=0;
        for(let x=left+1;x<right-1;x++){
          const dv=Math.abs(lum[(y+1)*w+x]-lum[(y-1)*w+x]);
          const dh=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
          // horizontal tick edge near the detected vertical spine
          s+=Math.max(0,dv-dh*.28);n++;
        }
        scores.push({y,score:s/Math.max(1,n)});
      }
      const vals=scores.map(q=>q.score),th=percentile(vals,.79),raw=[];
      for(let i=3;i<scores.length-3;i++){
        if(scores[i].score<th)continue;let mx=true;for(let k=-3;k<=3;k++)if(scores[i+k].score>scores[i].score){mx=false;break;}
        if(mx)raw.push(scores[i]);
      }
      const clustered=[],mergeDist=Math.max(4,Math.round(h*.007));
      for(const q of raw){const last=clustered[clustered.length-1];if(last&&q.y-last.y<=mergeDist){const wt=last.weight+q.score;last.y=(last.y*last.weight+q.y*q.score)/wt;last.score=Math.max(last.score,q.score);last.weight=wt;}else clustered.push({y:q.y,score:q.score,weight:q.score});}
      const best=findSixRegularTicks(clustered,h);
      if(best){
        // Prefer a regular set and a strong continuous spine.
        best.quality+=Math.min(25,sp.score*.8);best.spineX=sp.x;best.candidates=clustered;
        if(!globalBest||best.quality>globalBest.quality)globalBest=best;
      }
    }
    if(!globalBest)return {pxPerMm:null,confidence:.12,selectedTicks:[],reason:'5 mm ruler spine + six ticks not reliably detected'};
    const ticks=globalBest.selected.map(p=>p.y),pxPerMm=(ticks[5]-ticks[0])/5;
    const regularity=Math.max(0,1-globalBest.maxDev/.15),confidence=Math.min(.98,.64+.32*regularity);
    return {pxPerMm,confidence,selectedTicks:ticks.map(Math.round),fullSpanPx:ticks[5]-ticks[0],rulerMm:5,intervalCount:5,tickCount:6,gaps:globalBest.gaps,spineX:globalBest.spineX};
  }

  // Tiny offline glyph templates for the edge annotations. Recognition is deliberately restricted to
  // the six expected anatomical letters, and opposite-side consistency is used to reject false positives.
  const GLYPHS={
    R:['11110','10001','10001','11110','10100','10010','10001'],
    L:['10000','10000','10000','10000','10000','10000','11111'],
    A:['01110','10001','10001','11111','10001','10001','10001'],
    P:['11110','10001','10001','11110','10000','10000','10000'],
    S:['01111','10000','10000','01110','00001','00001','11110'],
    I:['11111','00100','00100','00100','00100','00100','11111']
  };
  function sampleGlyph(data,w,h,roi){
    const [x0,y0,x1,y1]=roi;const pts=[];
    const gs=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const cyanCut=Math.max(2,gs.cyan70*.62),lumCut=Math.max(32,gs.lum50*.70);
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const cyan=cyanScore>=cyanCut && lum>=lumCut && (g+b)>r*1.48;
      if(cyan)pts.push([x,y]);
    }
    if(pts.length<3)return null;
    let minX=Math.min(...pts.map(p=>p[0])),maxX=Math.max(...pts.map(p=>p[0])),minY=Math.min(...pts.map(p=>p[1])),maxY=Math.max(...pts.map(p=>p[1]));
    // Ignore very large UI fragments; keep the compact component-ish center zone.
    if(maxX-minX> (x1-x0)*.75 || maxY-minY>(y1-y0)*.75)return null;
    const grid=[];
    for(let gy=0;gy<7;gy++){
      let row='';for(let gx=0;gx<5;gx++){
        const ax=minX+(maxX-minX+1)*gx/5,bx=minX+(maxX-minX+1)*(gx+1)/5;
        const ay=minY+(maxY-minY+1)*gy/7,by=minY+(maxY-minY+1)*(gy+1)/7;
        let on=0,tot=0;
        for(let y=Math.floor(ay);y<Math.ceil(by);y++)for(let x=Math.floor(ax);x<Math.ceil(bx);x++){
          if(x<0||y<0||x>=w||y>=h)continue;tot++;const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
          const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
          if(cyanScore>=cyanCut&&lum>=lumCut&&(g+b)>r*1.48)on++;
        }
        row+=on/Math.max(1,tot)>.16?'1':'0';
      }grid.push(row);
    }
    let best=null;
    for(const [label,t] of Object.entries(GLYPHS)){
      let same=0;for(let y=0;y<7;y++)for(let x=0;x<5;x++)if(grid[y][x]===t[y][x])same++;
      const score=same/35;if(!best||score>best.score)best={label,score,grid,bbox:{minX,maxX,minY,maxY}};
    }
    return best;
  }
  function classifyGlyphComponent(data,w,h,bbox){
    // Expand only around one compact connected component.  This is intentionally
    // different from the old whole-ROI sampler which mixed anatomy letters with
    // nearby UI text and often returned SI/AP or no drawable box.
    const padX=Math.max(2,Math.round((bbox.maxX-bbox.minX+1)*.45));
    const padY=Math.max(2,Math.round((bbox.maxY-bbox.minY+1)*.35));
    const roi=[Math.max(0,bbox.minX-padX),Math.max(0,bbox.minY-padY),Math.min(w,bbox.maxX+padX+1),Math.min(h,bbox.maxY+padY+1)];
    const g=sampleGlyph(data,w,h,roi);
    if(!g) return null;
    // Preserve the actual component position for the yellow rectangle.  The
    // classifier may use a padded ROI, but the overlay must surround the letter.
    g.bbox={minX:bbox.minX,maxX:bbox.maxX,minY:bbox.minY,maxY:bbox.maxY};
    return g;
  }

  function glyphBinary(data,w,h,box){
    const bw=Math.max(1,box.maxX-box.minX+1),bh=Math.max(1,box.maxY-box.minY+1);
    const cols=9,rows=13,grid=Array.from({length:rows},()=>Array(cols).fill(0));
    const stats=bandAdaptiveStats(data,w,h,box.minX,box.minY,box.maxX+1,box.maxY+1,1);
    const cyanCut=Math.max(1.5,stats.cyan70*.48);
    const lumCut=Math.max(28,stats.lum50*.62);
    for(let gy=0;gy<rows;gy++)for(let gx=0;gx<cols;gx++){
      const xa=Math.floor(box.minX+gx*bw/cols),xb=Math.max(xa+1,Math.floor(box.minX+(gx+1)*bw/cols));
      const ya=Math.floor(box.minY+gy*bh/rows),yb=Math.max(ya+1,Math.floor(box.minY+(gy+1)*bh/rows));
      let on=0,total=0;
      for(let y=ya;y<=Math.min(box.maxY,yb);y++)for(let x=xa;x<=Math.min(box.maxX,xb);x++){
        const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
        const cyan=Math.max(g-r,b-r,(g+b)*.5-r);
        total++;
        if(lum>=lumCut&&cyan>=cyanCut&&(g+b)>r*1.40)on++;
      }
      grid[gy][gx]=on/Math.max(1,total)>.16?1:0;
    }
    return grid;
  }

  function templateScore(grid,label){
    const R=grid.length,C=grid[0].length;
    const at=(ry,cx)=>grid[Math.max(0,Math.min(R-1,Math.round(ry*(R-1))))][Math.max(0,Math.min(C-1,Math.round(cx*(C-1))))];
    const meanRegion=(r0,r1,c0,c1)=>{
      let n=0,v=0;
      for(let r=Math.floor(r0*R);r<Math.ceil(r1*R);r++)for(let c=Math.floor(c0*C);c<Math.ceil(c1*C);c++){n++;v+=grid[Math.min(R-1,r)][Math.min(C-1,c)];}
      return v/Math.max(1,n);
    };
    const left=meanRegion(.08,.92,.05,.27),right=meanRegion(.08,.92,.73,.95);
    const top=meanRegion(.04,.25,.15,.85),mid=meanRegion(.40,.60,.15,.85),bottom=meanRegion(.75,.96,.15,.85);
    const upperRight=meanRegion(.12,.48,.62,.95),lowerRight=meanRegion(.52,.90,.62,.95);
    const center=meanRegion(.10,.90,.40,.60);
    const diagDown=meanRegion(.45,.92,.52,.92);
    let score=0;
    if(label==='I'){
      score=center*.58+top*.20+bottom*.20-(left+right)*.08;
    }else if(label==='L'){
      score=left*.52+bottom*.38-right*.04-top*.02;
    }else if(label==='A'){
      score=(left+right)*.27+top*.18+mid*.24-bottom*.03;
    }else if(label==='P'){
      score=left*.45+top*.22+mid*.20+upperRight*.18-lowerRight*.08;
    }else if(label==='R'){
      score=left*.36+top*.18+mid*.17+upperRight*.14+diagDown*.20;
    }else if(label==='S'){
      score=top*.25+mid*.23+bottom*.25+
        meanRegion(.10,.48,.05,.42)*.15+
        meanRegion(.52,.90,.58,.95)*.15;
    }
    return score;
  }

  function classifySixGlyph(data,w,h,box,allowed){
    const grid=glyphBinary(data,w,h,box);
    let best=null,second=null;
    for(const label of allowed){
      const score=templateScore(grid,label);
      const item={label,score};
      if(!best||score>best.score){second=best;best=item;}
      else if(!second||score>second.score)second=item;
    }
    if(!best)return null;
    const margin=best.score-(second?second.score:0);
    return {label:best.label,score:best.score,margin};
  }

  function anatomyCandidates(data,w,h,side){
    // Vendor annotation locations:
    // top/bottom = left side of the thermal image; left/right = vertical middle.
    // The only valid glyphs are R/L/S/I/A/P.
    let x0=0,y0=0,x1=w,y1=h,allowed=[];
    if(side==='top'){
      x0=Math.floor(w*.18); x1=Math.floor(w*.39);
      y0=Math.floor(h*.030); y1=Math.floor(h*.145);
      allowed=['A','S'];
    }else if(side==='bottom'){
      x0=Math.floor(w*.18); x1=Math.floor(w*.39);
      y0=Math.floor(h*.815); y1=Math.floor(h*.965);
      allowed=['P','I'];
    }else if(side==='left'){
      x0=Math.floor(w*.025); x1=Math.floor(w*.145);
      y0=Math.floor(h*.38); y1=Math.floor(h*.67);
      allowed=['R','L'];
    }else{
      x0=Math.floor(w*.855); x1=Math.floor(w*.985);
      y0=Math.floor(h*.38); y1=Math.floor(h*.67);
      allowed=['R','L'];
    }

    const rw=x1-x0,rh=y1-y0,mask=new Uint8Array(rw*rh);
    const st=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,Math.max(1,Math.round(Math.min(w,h)/1300)));
    const cyanCut=Math.max(1.2,Math.min(24,st.cyan84*.42));
    const lumCut=Math.max(26,Math.min(112,st.lum50*.60));

    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
      const cyan=Math.max(g-r,b-r,(g+b)*.5-r);
      if(lum>=lumCut&&cyan>=cyanCut&&(g+b)>r*1.34)mask[(y-y0)*rw+(x-x0)]=1;
    }

    // Connect 1-2 px LCD gaps without merging neighboring text.
    let joined=new Uint8Array(mask);
    for(let pass=0;pass<2;pass++){
      const next=new Uint8Array(joined);
      for(let yy=1;yy<rh-1;yy++)for(let xx=1;xx<rw-1;xx++){
        if(joined[yy*rw+xx])continue;
        const hbridge=joined[yy*rw+xx-1]&&joined[yy*rw+xx+1];
        const vbridge=joined[(yy-1)*rw+xx]&&joined[(yy+1)*rw+xx];
        if(hbridge||vbridge)next[yy*rw+xx]=1;
      }
      joined=next;
    }

    const comps=connectedComponents(joined,rw,rh,2),out=[];
    for(const c of comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      if(bw<2||bh<3)continue;
      if(bw>w*.032||bh>h*.045)continue;
      const aspect=bw/Math.max(1,bh);
      if(aspect<.12||aspect>1.35)continue;
      if(c.area<2||c.area>bw*bh*.92)continue;

      const box={minX:c.minX+x0,maxX:c.maxX+x0,minY:c.minY+y0,maxY:c.maxY+y0};
      const g=classifySixGlyph(data,w,h,box,allowed);
      if(!g||g.score<.20)continue;

      const cx=(box.minX+box.maxX)/2,cy=(box.minY+box.maxY)/2;
      let locationScore=0;
      if(side==='left') locationScore=1-Math.min(1,Math.abs(cy/h-.515)/.18);
      else if(side==='right') locationScore=1-Math.min(1,Math.abs(cy/h-.515)/.18);
      else locationScore=1-Math.min(1,Math.abs(cx/w-.285)/.16);

      const edgeScore=side==='left'?1-cx/w:
                      side==='right'?cx/w:
                      side==='top'?1-cy/h:cy/h;

      const score=g.score*.58+Math.max(0,g.margin)*.10+locationScore*.20+edgeScore*.12;
      out.push({label:g.label,score,scoreRaw:g.score,margin:g.margin,side,cx,cy,bbox:box});
    }
    out.sort((a,b)=>b.score-a.score);
    return out;
  }

  function detectAnatomy(data,w,h){
    const all={};
    for(const side of ['top','bottom','left','right'])all[side]=anatomyCandidates(data,w,h,side);

    let hp=null;
    for(const l of all.left.slice(0,10))for(const r of all.right.slice(0,10)){
      if(!((l.label==='R'&&r.label==='L')||(l.label==='L'&&r.label==='R')))continue;
      const align=Math.abs(l.cy-r.cy)/h;if(align>.10)continue;
      const alignScore=1-align/.10;
      const pairScore=l.score+r.score+alignScore*.55;
      if(!hp||pairScore>hp.pairScore)hp={l,r,pairScore,alignScore};
    }

    let vp=null;
    for(const t of all.top.slice(0,10))for(const b of all.bottom.slice(0,10)){
      let axis=null,pos=null,neg=null;
      if((t.label==='A'&&b.label==='P')||(t.label==='P'&&b.label==='A')){axis='AP';pos='A';neg='P';}
      if((t.label==='S'&&b.label==='I')||(t.label==='I'&&b.label==='S')){axis='SI';pos='S';neg='I';}
      if(!axis)continue;
      const align=Math.abs(t.cx-b.cx)/w;if(align>.11)continue;
      const alignScore=1-align/.11;
      const pairScore=t.score+b.score+alignScore*.55;
      if(!vp||pairScore>vp.pairScore)vp={t,b,axis,pos,neg,pairScore,alignScore};
    }

    const edges={top:null,bottom:null,left:null,right:null};
    let horizontal=null,vertical=null;

    if(hp){
      edges.left=hp.l;edges.right=hp.r;
      horizontal={
        axis:'RL',
        positiveSide:hp.l.label==='R'?'left':'right',
        positiveLabel:'R',negativeLabel:'L',
        confidence:Math.min(.99,.58+hp.alignScore*.18+Math.min(hp.l.score,hp.r.score)*.24)
      };
    }

    if(vp){
      edges.top=vp.t;edges.bottom=vp.b;
      vertical={
        axis:vp.axis,
        positiveSide:vp.t.label===vp.pos?'top':'bottom',
        positiveLabel:vp.pos,negativeLabel:vp.neg,
        confidence:Math.min(.99,.58+vp.alignScore*.18+Math.min(vp.t.score,vp.b.score)*.24)
      };
    }

    return {edges,candidates:all,horizontal,vertical,detectedPairCount:(hp?1:0)+(vp?1:0)};
  }

  function analyze(imageData,w,h,overrides){
    overrides=overrides||{};
    const red=redRegion(imageData.data,w,h);

    let cross=null;
    try{cross=crossCenter(imageData.data,w,h,red);}catch(_e){cross=null;}

    const reference=chooseReference(imageData.data,w,h,red,cross);
    const greenCircle=detectColoredCircle(imageData.data,w,h,red,'green');
    const yellowCircle=detectColoredCircle(imageData.data,w,h,red,'yellow');
    const circleHint=greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpot(imageData.data,w,h,red,circleHint);
    const referenceConfirmed=!!reference;

    const ori=detectOrientation(imageData.data,w,h);
    const scale=detectScale(imageData.data,w,h);
    const anatomy=detectAnatomy(imageData.data,w,h);
    const direction=overrides.direction||ori.direction;
    const pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3)throw new Error('5 mm scale could not be calibrated automatically. Tap the top and bottom ruler ticks.');

    const dxPx=referenceConfirmed ? red.component.cx-reference.x : NaN;
    const dyPx=referenceConfirmed ? red.component.cy-reference.y : NaN;

    function componentResult(screenAxis,rawPx,axis){
      let signedPx=rawPx,positiveLabel='?',negativeLabel='?',axisKnown=false,axisName=screenAxis==='horizontal'?'H':'V';
      if(axis){
        axisKnown=true;
        axisName=axis.axis;
        positiveLabel=axis.positiveLabel;
        negativeLabel=axis.negativeLabel;
        const positiveScreenSign=(axis.positiveSide==='right'||axis.positiveSide==='bottom')?1:-1;
        signedPx=rawPx*positiveScreenSign;
      }
      const signedMm=Number.isFinite(signedPx)?signedPx/pxPerMm:NaN;
      return {screenAxis,axis:axisName,axisKnown,rawPx,signedPx,signedMm,positiveLabel,negativeLabel,valid:Number.isFinite(signedMm)};
    }

    const horizontal=componentResult('horizontal',dxPx,anatomy.horizontal);
    const vertical=componentResult('vertical',dyPx,anatomy.vertical);

    const finalComponent=direction==='up'?horizontal:vertical;
    const markerPerpendicular=direction==='up'?'horizontal':'vertical';

    let confidence=referenceConfirmed?Math.max(0,Math.min(1,
      (scale.confidence||.3)*.35+
      (reference.confidence||.5)*.40+
      (ori.confidence||.3)*.15+
      (finalComponent.axisKnown?.90:.35)*.10
    )):0;

    return {
      red,reference,referenceConfirmed,needsAttention:!referenceConfirmed,cross,greenCircle,yellowCircle,greenSpot,
      orientation:ori,direction,scale,anatomy,pxPerMm,
      horizontal,vertical,
      finalComponent,
      markerPerpendicular,
      measurementAxis:finalComponent.axis,
      screenAxis:finalComponent.screenAxis,
      signedMm:finalComponent.signedMm,
      signedPx:finalComponent.signedPx,
      axisKnown:finalComponent.axisKnown,
      positiveLabel:finalComponent.positiveLabel,
      negativeLabel:finalComponent.negativeLabel,
      confidence,
      processing:{
        red:'geometric hotspot centroid',
        referencePriority:'cross > green/yellow circle fit > green spot',
        circle:'hotspot-constrained circle fit + angular evidence validation',
        anatomy:'validated opposite-edge pair (RL/AP/SI)',
        final:'marker-perpendicular component'
      }
    };
  }

  global.LocAccCore={analyze,redRegion,crossCenter,detectColoredCircle,detectGreenSpot,chooseReference,detectOrientation,detectScale,detectAnatomy};
})(window);
