# LocAcc regression policy

Every future detector change must preserve these invariants:

- Reference priority is fixed: Cross > green ring > yellow ring > green spot.
- Hotspot centroid is equal-area geometry, never intensity-weighted.
- A Cross candidate must be a four-arm intersection in hotspot geometry.
- Ring center comes from ring geometry; isolated colored UI pixels cannot become a ring.
- Green spot search is local only.
- All four anatomy edges may contain any of R/L/S/I/A/P.
- Anatomy axes are accepted only from valid opposite pairs RL/AP/SI.
- R/S/A are positive; L/I/P are negative.
- Both H and V are always calculated when reference+scale are valid.
- Marker Up => final H; marker Right => final V.
- No unconfirmed reference may produce a millimeter result.
