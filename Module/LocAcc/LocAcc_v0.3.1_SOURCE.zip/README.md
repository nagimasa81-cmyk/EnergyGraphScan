# LocAcc v0.1.27

Offline iPhone Safari PWA for thermal hotspot location accuracy measurement.

## Measurement rules
- lower-right `^` marker => measure the **R-L (RL)** axis.
- lower-right `>` marker => measure the vertical anatomical pair detected from the edge annotations: **S-I (SI)** or **A-P (AP)**.
- Red thermal overlay center = geometric centroid of a filled red silhouette (moire gaps are filled before centroid calculation).
- Cross center = intersection of the yellow/green cross arms.
- Ruler = **6 ticks / 5 intervals / 5 mm total**; calibration uses the entire 5 mm span.
- Anatomical edge annotations are used for sign. **R, S and A are positive**; L, I and P are negative.
- Result is displayed to 0.1 mm.

## GitHub Pages path
Deploy the contents to `Module/LocAcc/`. Safari URL:
`https://<GitHub-user>.github.io/<repository>/Module/LocAcc/`

The Service Worker uses relative URLs so the PWA remains scoped to `Module/LocAcc/` and works offline after initial caching.


## Result notation (v0.1.4)
Results use anatomical axis names only: **RL / SI / AP**. R, S and A are positive; L, I and P are negative. Example: `RL +0.1 mm (R)`. Horizontal/Vertical are not used as the user-facing measurement-axis names.


## v0.1.27
- Visible software version in the header.
- Measurement stays on one line: H/V + RL/SI/AP + signed mm + direction.
- Anatomy detection searches border bands for the **actual single-letter glyphs** instead of assuming exact edge midpoints.
- Yellow rectangles are drawn directly around the detected R/L/A/P/S/I glyphs on the source image.
- Opposite-edge pairs are validated as RL, AP, or SI. The ambiguous fallback `SI/AP` has been removed; unresolved vertical anatomy is shown as `Unknown`.
- Distance calculation and 5 mm ruler calibration logic are unchanged.

## v0.1.27 adaptive image optimization
- Hotspot: adaptive red-excess / exposure normalization while preserving geometry.
- Cross: adaptive yellow-green local contrast inside the hotspot.
- 5 mm scale: robust grayscale contrast normalization before edge/tick analysis.
- Direction marker: adaptive cyan + local contrast.
- Anatomy A/P/R/L/S/I: independent adaptive cyan/luminance thresholds for each edge band.
- Photo import now preserves up to 2400 x 2400 pixels, matching the camera-analysis path.
- All processing remains offline and uses only local browser code.

## v0.1.27 anatomy capture correction
- Anatomy search zones are narrowed to the actual vendor annotation positions.
- Patient ID, timing text, temperature labels and ruler text are excluded by geometry.
- Left/right annotations must form a same-height R-L pair.
- Top/bottom annotations must form a same-x A-P or S-I pair.
- Yellow rectangles are drawn only for validated anatomy pairs; unrelated text is never boxed.
- Ambiguous SI/AP fallback remains disabled.

## v0.1.27 measurement reference
- Offset reference changed from the yellow cross to the green target geometry.
- Priority 1: if a small green point is visible, use the center of that point.
- Priority 2: otherwise use the geometric center of the large green circular contour.
- Offset is calculated between that green reference center and the red hotspot geometric centroid.
- Yellow cross remains an optional diagnostic overlay only and no longer affects the calculated value.
- RL / SI / AP axis selection and R/S/A positive-sign convention are unchanged.

## v0.1.27 measurement model
Reference priority is fixed to:
1. Cross center
2. Green or yellow circle-line center (robust circle fitting)
3. Green spot center

The red hotspot geometric centroid is always the measured target.
Both horizontal and vertical offsets are calculated and displayed.
When anatomy annotations are validated, H/V are mapped to RL/SI/AP with R/S/A positive.
When the lower-right marker is detected, the component perpendicular to that marker is the final Measurement.

## v0.1.27 circle candidate hardening
- Green/yellow circle radius is constrained by the detected red-hotspot size, not by the full photo.
- Circle center must remain near the hotspot centroid and the hotspot must lie inside the fitted ring.
- Valid rings require circumference evidence across at least three quadrants and sufficient angular coverage.
- UI text, ruler ticks and very large false fits are rejected before they can become a reference.
- Result overlay no longer draws a complete fitted circle; it shows validated circumference evidence points plus the fitted center only.

## v0.1.27
Red center = equal-area filled visible-red silhouette. Cross requires four confirmed arms inside the red region; invalid cross falls through to circle then green spot.

## v0.1.27 Photo picker fix
- Photo uses a native iOS file input directly under the visible Photo control.
- No programmatic `.click()` is required, avoiding Safari/PWA user-gesture blocking.
- Camera failure no longer changes the Photo picker to `capture=environment`.
- Selecting a photo stops the camera stream and loads the selected image.
- Service Worker cache and asset query versions are synchronized to v0.1.27.

## v0.1.27 reference false-positive guard
- Green spot search is restricted to the local measurement ROI around the hotspot/circle center.
- Left toolbar, right ruler and screen chrome are excluded by geometry.
- Cross/circle/green-spot candidates must pass distance, confidence and geometry validation.
- A green spot farther than the allowed hotspot-centered radius is rejected.
- If no reference passes validation, LocAcc shows `Needs attention` and does not output H/V millimeter values.

## v0.1.27 null-reference UI fix
- `Needs attention` is now a valid terminal analysis state.
- UI/manual-correction code no longer dereferences `reference.type/x/y` when no automatic reference was confirmed.
- No millimeter result is fabricated when the reference is null.

## v0.1.27
Valid green/yellow circle acceptance adjusted for photographed anti-aliased and partially broken rings while retaining hotspot-centered geometry guards. UI false green spots remain rejected.

## v0.1.27 lower-right marker hardening
- Marker ROI widened so photographed/perspective-shifted lower-right carets remain in range.
- Uses local contrast plus optional cyan evidence instead of cyan-only detection.
- Shape scoring distinguishes `^` (top apex + two lower arms) from `>` (right apex + two left arms).
- One-pixel diagonal gaps are bridged for LCD moire/anti-aliasing.
- `Right` is accepted only when it beats `Up` by a clear margin; ambiguous photographed carets conservatively remain `Up`.

## v0.1.27 emergency runtime repair
- Rebased analysis-core on the last runtime-good v0.1.18 core.
- Fixes `Can't find variable: LocAccCore`.
- Restores circle, green-spot, reference, scale and anatomy detector functions that were accidentally removed during v0.1.19 anatomy refactoring.
- Keeps v0.1.18 lower-right caret hardening.
- Anatomy remains pair-validated (RL/AP/SI); no result is promoted from an unconfirmed single edge glyph.

## v0.1.27 cross recovery
- Cross detection no longer requires a single connected cross component.
- Horizontal and vertical line projections are detected independently inside the red hotspot.
- Their intersection defines the Cross center.
- Four-arm evidence is still required, but short LCD/moire gaps are tolerated.
- Outer green/yellow circle cannot qualify as Cross because the Cross ROI is restricted to the hotspot interior.

## v0.1.27 plane-independent anatomy
- All four edges evaluate all six letters R/L/S/I/A/P.
- No letter is hard-coded to top, bottom, left, or right.
- Opposite pairs are accepted only as RL, AP, or SI.
- Horizontal and vertical pairs are selected jointly and cannot use the same anatomical axis.
- Reversed orientation is supported automatically.
- R/S/A are positive; L/I/P are negative.
- Cross, red centroid, circle/spot reference, scale, and lower-right marker are unchanged from v0.1.21.

## v0.1.27 multi-profile anatomy ROI
- Anatomy only was changed; cross, hotspot centroid, circle/spot reference, scale, and marker logic are unchanged.
- Each of the four annotation edges is read from a dedicated high-resolution ROI.
- Every edge evaluates all six glyphs R/L/S/I/A/P; there is no plane-to-edge letter mapping.
- Each ROI is processed with soft, balanced, and strong cyan/luminance profiles.
- Bright neutral anti-aliased LCD glyph pixels are also accepted.
- Duplicate detections from the three profiles are merged before opposite-pair selection.
- Final anatomy axes are still accepted only from RL, AP, or SI opposite pairs.

## v0.1.27
- Cross false-positive guard: final Cross center must be inside or immediately adjacent to the red-hotspot geometry and remain near the red centroid.
- Anatomy selection is pair-first: valid RL/AP/SI opposite pairs outrank isolated glyph candidates.
- Plane independence is preserved; every edge still evaluates all six letters R/L/S/I/A/P.
- Cross/centroid/scale/marker algorithms are otherwise unchanged from v0.1.24.

## v0.1.27
- Tightened anatomy annotation ROIs to the actual vendor edge-label locations.
- Added opposite-pair center-symmetry rejection to prevent false AP/RL/SI pairs.
- All four edges still evaluate all R/L/S/I/A/P letters; no plane assumption was added.

## v0.1.27 center extraction repair
- Red-hotspot detection is restricted to the central thermal-image ROI before segmentation.
- Red UI text/buttons and right-side charts are excluded before component selection.
- Hotspot component selection uses area + centrality + compactness.
- Hotspot center is an equal-area centroid of the cleaned filled red silhouette; brightness is never used as a weight.
- Cross projection is retained but its final center must remain closer to the corrected red centroid.
- Anatomy, scale, lower-right marker, circle and green-spot logic are unchanged from v0.1.26.

## v0.2.3 unified analysis pipeline

The incremental v0.1.x correction chain is frozen. Image analysis now follows one fixed pipeline:

1. Hotspot Detector
   - central treatment ROI only
   - hard red core seed
   - connected growth into a softer red mask
   - equal-area geometric centroid (no intensity weighting)

2. Independent Reference Detectors
   - Cross detector: four-arm intersection within hotspot geometry
   - Green ring detector: robust ellipse-center from actual green line pixels
   - Yellow ring detector: same algorithm
   - Green spot detector: compact local component only

3. Decision Engine
   - fixed priority: Cross > Green circle > Yellow circle > Green spot
   - detectors cannot alter one another's thresholds or coordinates
   - rejected candidates never become measurement references

4. Independent Scale / Marker / Anatomy detectors
   - existing 5 mm scale calibration retained
   - lower-right caret detector retained
   - anatomy remains plane-independent and pair-validated as RL/AP/SI

5. Measurement
   - calculate both H and V from selected reference center to red hotspot centroid
   - map to RL/AP/SI only when anatomy is confirmed
   - lower-right marker chooses the perpendicular component as the primary result

Each detector now returns diagnostics and confidence independently. Non-final debug ring points are hidden from the production overlay.

## v0.2.3 anatomy detector
- Geometry pipeline from v0.2.0 is frozen and unchanged.
- Each edge annotation ROI is processed at source resolution with three preprocessing profiles.
- Tiny glyph components are normalized to a 9x13 grid and compared only against R/L/S/I/A/P structural templates.
- Every edge may contain any of the six letters; there is no plane-to-edge mapping.
- Final axes are decided only from opposite RL/AP/SI pairs with alignment and center-symmetry checks.

## v0.2.3 vertical anatomy recovery
- Geometry pipeline remains frozen from v0.2.0.
- Successful horizontal RL detection logic is preserved.
- Only top/bottom anatomy ROIs are widened.
- Vertical AP/SI pair selection is pair-first and gets extra perspective/alignment tolerance.
- Every edge still evaluates all six letters R/L/S/I/A/P.
- No plane-specific letter mapping is introduced.

## v0.2.3 input normalization
- Camera and Library inputs now use different normalization paths before the same detector pipeline.
- Camera capture keeps a 2400 px normalized working image to limit moire/noise.
- Library images may retain up to 3000 px for small annotation glyphs.
- The analysis core receives inputSourceType.
- Only top/bottom anatomy ROI/tolerance is source-aware.
- Successful horizontal RL logic, Geometry, Cross, Hotspot, Scale and lower-right Marker remain unchanged.
- px/mm is expected to differ between camera and library images; final mm is the comparison target.

## v0.3.1 Photo library repair
- Restores the native iOS file-picker pattern used in the known-working v0.1.14 design.
- The visible Photo control is a label containing the actual file input.
- No JavaScript `.click()` is used to open the iPhone photo library.
- `capture=environment` is never forced onto the library picker.
- Selecting a library image sets inputSourceType=library and uses the v0.2.3 library normalization path.
- Analysis detectors are unchanged from v0.2.3.

## v0.3.1 Anatomy deep regression redesign
- Anatomy ROI placement is no longer based on whole-image percentages.
- The green/yellow reference ring is used as the primary layout anchor; hotspot geometry is fallback.
- All four anatomy slots are expressed in ring-relative coordinates, making Camera and Library crops comparable.
- Every slot still evaluates all six R/L/S/I/A/P glyphs.
- Pair decision accepts only RL/AP/SI and scores both glyph-to-slot distance and opposite-pair alignment.
- Geometry/Cross/Hotspot/Scale/Marker/Photo picker are frozen.
- An anatomy regression inventory covering all currently available LocAcc samples is included under tests/.

## v0.3.1 Anatomy direct-pair classifier
- Anatomy slot localization from v0.2.5 is frozen unchanged.
- Each glyph candidate now retains all six R/L/S/I/A/P scores.
- Left/right and top/bottom are classified as a PAIR directly against RL/AP/SI.
- Independent best-letter decisions no longer determine the anatomical axis.
- Both display directions are evaluated for every pair (R-L vs L-R, A-P vs P-A, S-I vs I-S).
- The accepted pair interpretation overwrites the yellow-box label only after the pair wins.
- Ambiguous near-ties are rejected instead of forcing a wrong axis.
- Geometry, Cross, Hotspot, Scale, Marker and Photo picker are unchanged.

## v0.3.1 Anatomy template-correlation classifier
- Anatomy slot localization remains frozen from v0.2.5.
- Pair decision remains frozen from v0.2.6.
- Only the per-glyph six-letter scoring engine changed.
- Each candidate is normalized to 21x15 and correlated against canonical R/L/S/I/A/P 5x7 stroke templates.
- Correlation tolerates small translation and one-pixel stroke dilation.
- All six template scores are retained and passed to the direct RL/AP/SI pair classifier.
- Geometry, Cross, Hotspot, Scale, Marker and Photo picker are unchanged.

## v0.3.1 Anatomy sliding-window classifier
- Ring-relative anatomy slot localization is unchanged.
- Direct RL/AP/SI pair decision is unchanged.
- Glyph extraction no longer depends on connected components.
- Each slot is scanned directly with multiple glyph sizes/aspect ratios.
- Each window is normalized and correlated against all six R/L/S/I/A/P templates.
- Non-maximum suppression retains the best complete-glyph window, tolerating fragmented LCD characters and moire.
- Geometry, Cross, Hotspot, Scale, Marker and Photo picker remain frozen.

## v0.3.1 Vertical Anatomy pair-scan
- v0.2.8 horizontal RL detection is frozen unchanged.
- Ring-relative anatomy slot geometry is unchanged.
- Sliding-window six-glyph classifier is unchanged.
- Only Vertical Anatomy receives an additional pair-level fallback.
- When normal top/bottom classification is missing or weak, weaker top/bottom windows are jointly rescored as AP/PA, SI/IS, and RL/LR.
- Both letters must have evidence and the winning pair must beat competing axes; ambiguous border noise is rejected.
- Geometry, Cross, Hotspot, Scale, Marker, Camera and Photo picker are unchanged.

## v0.3.1 Anatomy Super Consensus
- Geometry/Cross/Hotspot/Scale/Marker/Camera/Photo picker are frozen.
- Proven v0.2.8 sliding-window glyph extraction is retained.
- Anatomy no longer trusts a single best glyph window.
- Each side aggregates R/L/S/I/A/P evidence across multiple top windows.
- Horizontal and vertical hypotheses are scored as RL/AP/SI pairs from consensus evidence.
- A global two-axis solver chooses both screen axes simultaneously and prohibits duplicate anatomical axes.
- Repeated weak evidence can recover tiny top/bottom glyphs while ambiguous forced guesses remain rejected.

## v0.3.1 Hierarchical Vertical Anatomy
- Horizontal v0.3.0 behavior is frozen.
- Standard two-letter vertical pair recognition remains first priority.
- If the vertical pair is absent/weak, one high-confidence top or bottom glyph may infer its anatomical axis.
- The resolved horizontal axis is excluded from vertical candidates.
- Single-glyph mapping is anatomical only: A/P -> AP, S/I -> SI, R/L -> RL.
- A one-sided result must have sufficient score/support and separation from the competing remaining axis.
- Positive side is derived from the detected glyph identity (R/S/A positive; L/I/P negative).
- Geometry, Cross, Hotspot, Scale, Marker, Camera and Photo picker remain unchanged.
