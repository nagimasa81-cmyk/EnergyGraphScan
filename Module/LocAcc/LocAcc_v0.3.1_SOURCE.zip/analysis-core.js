(function(global){
  'use strict';

  function rgbToHSV(r,g,b){
    r/=255; g/=255; b/=255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
    let h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return [h, max?d/max:0, max];
  }


  function clamp255(v){ return v<0?0:v>255?255:v; }

  function sampledPercentile(values,p){
    if(!values.length) return 0;
    values.sort((a,b)=>a-b);
    return values[Math.max(0,Math.min(values.length-1,Math.floor((values.length-1)*p)))];
  }

  function bandAdaptiveStats(data,w,h,x0,y0,x1,y1,step){
    const lum=[],cyan=[],red=[],yellow=[];
    step=Math.max(1,step||3);
    for(let y=y0;y<y1;y+=step) for(let x=x0;x<x1;x+=step){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const l=.2126*r+.7152*g+.0722*b;
      lum.push(l);
      cyan.push(Math.max(g-r,b-r,(g+b)*.5-r));
      red.push(r-Math.max(g,b));
      yellow.push(Math.min(r,g)-b*.55);
    }
    return {
      lum10:sampledPercentile(lum,.10), lum50:sampledPercentile(lum,.50), lum90:sampledPercentile(lum,.90),
      cyan70:sampledPercentile(cyan,.70), cyan84:sampledPercentile(cyan,.84), cyan93:sampledPercentile(cyan,.93),
      red70:sampledPercentile(red,.70), red88:sampledPercentile(red,.88),
      yellow75:sampledPercentile(yellow,.75), yellow90:sampledPercentile(yellow,.90)
    };
  }

  function adaptiveContrastValue(lum,lo,hi){
    const den=Math.max(12,hi-lo);
    return clamp255((lum-lo)*255/den);
  }

  function connectedComponents(mask,w,h,minArea){
    const seen=new Uint8Array(mask.length), comps=[];
    const stack=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||seen[idx]) continue;
      let sp=0; stack[sp++]=idx; seen[idx]=1;
      let area=0,sumX=0,sumY=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        const ci=stack[--sp], cx=ci%w, cy=(ci/w)|0; area++; sumX+=cx; sumY+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k], ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h) continue;
          const ni=ny*w+nx; if(mask[ni]&&!seen[ni]){seen[ni]=1;stack[sp++]=ni;}
        }
      }
      if(area>=minArea) comps.push({area,cx:sumX/area,cy:sumY/area,minX,maxX,minY,maxY});
    }
    return comps;
  }

  function redRegion(data,w,h){
    const minDim=Math.min(w,h);

    // Central thermal-image ROI only. This excludes the left toolbar,
    // right-side plots/rulers and screen chrome before red segmentation.
    const xLo=Math.floor(w*.20), xHi=Math.ceil(w*.79);
    const yLo=Math.floor(h*.16), yHi=Math.ceil(h*.82);

    const rs=bandAdaptiveStats(
      data,w,h,xLo,yLo,xHi,yHi,
      Math.max(2,Math.round(minDim/700))
    );

    const raw=new Uint8Array(w*h);
    const redExcessCut=Math.max(8,Math.min(34,rs.red88*.20));
    const lumCut=Math.max(28,Math.min(82,rs.lum50*.50));

    for(let y=yLo;y<yHi;y++){
      for(let x=xLo;x<xHi;x++){
        const i=(y*w+x)*4;
        const r=data[i],g=data[i+1],b=data[i+2];
        const [hh,ss,vv]=rgbToHSV(r,g,b);
        const lum=.2126*r+.7152*g+.0722*b;
        const redExcess=r-Math.max(g,b);
        const redHue=(hh<52||hh>322);

        if(
          redHue &&
          redExcess>=redExcessCut &&
          r>g*1.035 &&
          r>b*1.055 &&
          ss>.10 &&
          vv>.22 &&
          lum>=lumCut
        ){
          raw[y*w+x]=1;
        }
      }
    }

    // Close only tiny LCD/moiré gaps.
    let closed=new Uint8Array(raw);
    for(let pass=0;pass<2;pass++){
      const next=new Uint8Array(closed);
      for(let y=yLo+1;y<yHi-1;y++){
        for(let x=xLo+1;x<xHi-1;x++){
          if(closed[y*w+x])continue;
          let n=0;
          for(let yy=y-1;yy<=y+1;yy++)
            for(let xx=x-1;xx<=x+1;xx++)
              n+=closed[yy*w+xx];
          if(n>=5)next[y*w+x]=1;
        }
      }
      closed=next;
    }

    const comps=connectedComponents(
      closed,w,h,
      Math.max(70,Math.floor(w*h*.00022))
    );

    if(!comps.length)
      throw new Error('Red thermal region not detected.');

    // Choose a hotspot-like central component instead of blindly taking the
    // largest red component.
    let best=null;
    for(const c of comps){
      const bw=c.maxX-c.minX+1;
      const bh=c.maxY-c.minY+1;

      if(bw<w*.035||bh<h*.035)continue;
      if(bw>w*.44||bh>h*.44)continue;

      const nx=(c.cx-w*.5)/(w*.30);
      const ny=(c.cy-h*.49)/(h*.32);
      const centerDist=Math.hypot(nx,ny);
      if(centerDist>1.35)continue;

      const fill=c.area/Math.max(1,bw*bh);
      const aspect=Math.min(bw,bh)/Math.max(bw,bh);

      const areaScore=Math.min(1,c.area/(w*h*.030));
      const centerScore=Math.max(0,1-centerDist/1.35);
      const fillScore=Math.min(1,fill/.55);
      const shapeScore=Math.min(1,aspect/.72);

      const score=
        areaScore*.42+
        centerScore*.35+
        fillScore*.13+
        shapeScore*.10;

      if(!best||score>best.score)
        best={component:c,score};
    }

    if(!best)
      throw new Error('Central red hotspot geometry not confirmed.');

    const seed=best.component;

    // Equal-area silhouette centroid. Brightness never weights the center.
    const rows=[];
    const widths=[];

    for(let y=seed.minY;y<=seed.maxY;y++){
      let lo=w,hi=-1,count=0;

      for(let x=seed.minX;x<=seed.maxX;x++){
        if(closed[y*w+x]){
          lo=Math.min(lo,x);
          hi=Math.max(hi,x);
          count++;
        }
      }

      if(hi>=lo){
        const width=hi-lo+1;
        if(count>=Math.max(2,width*.07)){
          rows.push({y,lo,hi,count});
          widths.push(width);
        }
      }
    }

    if(!rows.length)
      throw new Error('Red hotspot silhouette not stable.');

    widths.sort((a,b)=>a-b);
    const medW=widths[Math.floor(widths.length*.5)]||1;

    const filled=new Uint8Array(w*h);
    let area=0,sx=0,sy=0;
    let minX=w,maxX=0,minY=h,maxY=0;

    for(const q of rows){
      const width=q.hi-q.lo+1;
      if(width<Math.max(4,medW*.14))continue;

      for(let x=q.lo;x<=q.hi;x++){
        filled[q.y*w+x]=1;
        area++;
        sx+=x;
        sy+=q.y;
      }

      minX=Math.min(minX,q.lo);
      maxX=Math.max(maxX,q.hi);
      minY=Math.min(minY,q.y);
      maxY=Math.max(maxY,q.y);
    }

    if(area<120)
      throw new Error('Red hotspot area too small after geometry cleanup.');

    const cx=sx/area;
    const cy=sy/area;

    if(
      cx<w*.24||cx>w*.76||
      cy<h*.20||cy>h*.78
    ){
      throw new Error('Red hotspot centroid rejected by central geometry guard.');
    }

    return {
      component:{
        area,
        cx,cy,
        minX,maxX,minY,maxY,
        rawCx:seed.cx,
        rawCy:seed.cy,
        selectionScore:best.score
      },
      mask:filled,
      rawMask:raw
    };
  }

  function crossCenter(data,w,h,red){
    const c=red.component,bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
    const minDim=Math.min(w,h);

    // Cross is searched only inside the red hotspot.  This completely separates it
    // from the outer green/yellow reference ring and most UI elements.
    const x0=Math.max(0,Math.floor(c.minX+bw*.10));
    const x1=Math.min(w-1,Math.ceil(c.maxX-bw*.10));
    const y0=Math.max(0,Math.floor(c.minY+bh*.10));
    const y1=Math.min(h-1,Math.ceil(c.maxY-bh*.10));

    const cs=bandAdaptiveStats(data,w,h,x0,y0,x1+1,y1+1,1);
    const yellowCut=Math.max(7,cs.yellow75*.42);
    const brightCut=Math.max(42,cs.lum50*.62);
    const mask=new Uint8Array(w*h);

    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      if(!red.mask[y*w+x])continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b);
      const lum=.2126*r+.7152*g+.0722*b;
      const yellowScore=Math.min(r,g)-b*.55;
      // Include yellow / yellow-green cross pixels. Keep threshold permissive because
      // photographed LCD pixels shift hue and are often partially desaturated.
      if(hh>=22&&hh<=135&&ss>.08&&vv>.26&&lum>=brightCut&&yellowScore>=yellowCut)
        mask[y*w+x]=1;
    }

    // Bridge very small LCD/moire gaps.
    let joined=new Uint8Array(mask);
    for(let pass=0;pass<2;pass++){
      const next=new Uint8Array(joined);
      for(let y=y0+1;y<y1;y++)for(let x=x0+1;x<x1;x++){
        if(joined[y*w+x])continue;
        const hBridge=joined[y*w+x-1]&&joined[y*w+x+1];
        const vBridge=joined[(y-1)*w+x]&&joined[(y+1)*w+x];
        if(hBridge||vBridge)next[y*w+x]=1;
      }
      joined=next;
    }

    // Cross position is the intersection of the strongest horizontal and vertical
    // line projections.  It does not require the four arms to be one component.
    const band=Math.max(1,Math.round(minDim*.0022));
    let bestX=-1,bestY=-1,bestCol=-1,bestRow=-1;

    const cxLo=Math.max(x0,Math.floor(c.cx-bw*.28));
    const cxHi=Math.min(x1,Math.ceil(c.cx+bw*.28));
    const cyLo=Math.max(y0,Math.floor(c.cy-bh*.28));
    const cyHi=Math.min(y1,Math.ceil(c.cy+bh*.28));

    for(let x=cxLo;x<=cxHi;x++){
      let sum=0;
      for(let y=y0;y<=y1;y++)
        for(let xx=Math.max(x0,x-band);xx<=Math.min(x1,x+band);xx++)
          sum+=joined[y*w+xx];
      // Mild preference toward hotspot center; shape evidence still dominates.
      const d=Math.abs(x-c.cx)/Math.max(1,bw*.28);
      const score=sum*(1-.12*Math.min(1,d));
      if(score>bestCol){bestCol=score;bestX=x;}
    }

    for(let y=cyLo;y<=cyHi;y++){
      let sum=0;
      for(let x=x0;x<=x1;x++)
        for(let yy=Math.max(y0,y-band);yy<=Math.min(y1,y+band);yy++)
          sum+=joined[yy*w+x];
      const d=Math.abs(y-c.cy)/Math.max(1,bh*.28);
      const score=sum*(1-.12*Math.min(1,d));
      if(score>bestRow){bestRow=score;bestY=y;}
    }

    if(bestX<0||bestY<0)throw new Error('Cross line peaks not found.');

    // Confirm arms around the candidate intersection.  Small gaps are permitted.
    const armReachX=Math.max(5,Math.round(bw*.18));
    const armReachY=Math.max(5,Math.round(bh*.18));
    const gapAllowance=Math.max(2,Math.round(minDim*.004));

    function armHitsHorizontal(xa,xb){
      let hits=0,slots=0;
      const step=1;
      for(let x=xa;x<=xb;x+=step){
        slots++;
        let found=false;
        for(let y=Math.max(y0,bestY-band);y<=Math.min(y1,bestY+band);y++){
          if(joined[y*w+x]){found=true;break;}
        }
        if(found)hits++;
      }
      return {hits,slots,ratio:hits/Math.max(1,slots)};
    }
    function armHitsVertical(ya,yb){
      let hits=0,slots=0;
      for(let y=ya;y<=yb;y++){
        slots++;
        let found=false;
        for(let x=Math.max(x0,bestX-band);x<=Math.min(x1,bestX+band);x++){
          if(joined[y*w+x]){found=true;break;}
        }
        if(found)hits++;
      }
      return {hits,slots,ratio:hits/Math.max(1,slots)};
    }

    const L=armHitsHorizontal(Math.max(x0,bestX-armReachX),Math.max(x0,bestX-gapAllowance));
    const R=armHitsHorizontal(Math.min(x1,bestX+gapAllowance),Math.min(x1,bestX+armReachX));
    const U=armHitsVertical(Math.max(y0,bestY-armReachY),Math.max(y0,bestY-gapAllowance));
    const D=armHitsVertical(Math.min(y1,bestY+gapAllowance),Math.min(y1,bestY+armReachY));

    // Require evidence on all four sides, but do not require continuity.
    const minRatio=.12;
    if(L.ratio<minRatio||R.ratio<minRatio||U.ratio<minRatio||D.ratio<minRatio)
      throw new Error('Cross four-arm evidence not confirmed.');

    const balanceH=Math.min(L.ratio,R.ratio)/Math.max(.001,Math.max(L.ratio,R.ratio));
    const balanceV=Math.min(U.ratio,D.ratio)/Math.max(.001,Math.max(U.ratio,D.ratio));
    const centerDist=Math.hypot(bestX-c.cx,bestY-c.cy)/Math.max(1,Math.min(bw,bh));
    const lineStrength=Math.min(1,(L.ratio+R.ratio+U.ratio+D.ratio)/1.20);
    const shapeScore=Math.max(0,Math.min(1,
      lineStrength*.48+balanceH*.18+balanceV*.18+Math.max(0,1-centerDist/.34)*.16
    ));

    if(shapeScore<.38)throw new Error('Cross projection confidence too low.');

    // Subpixel-ish refinement: weighted center of yellow pixels close to each peak.
    let sx=0,swx=0,sy=0,swy=0;
    for(let x=Math.max(x0,bestX-band*2);x<=Math.min(x1,bestX+band*2);x++)
      for(let y=y0;y<=y1;y++)if(joined[y*w+x]){sx+=x;swx++;}
    for(let y=Math.max(y0,bestY-band*2);y<=Math.min(y1,bestY+band*2);y++)
      for(let x=x0;x<=x1;x++)if(joined[y*w+x]){sy+=y;swy++;}

    const finalX=swx?sx/swx:bestX;
    const finalY=swy?sy/swy:bestY;

    // Hard geometry guard: the cross must lie inside or immediately adjacent
    // to the red-hotspot silhouette. This prevents left-toolbar/UI false positives.
    const redW=Math.max(1,c.maxX-c.minX+1),redH=Math.max(1,c.maxY-c.minY+1);
    const distNorm=Math.hypot(finalX-c.cx,finalY-c.cy)/Math.max(1,Math.min(redW,redH));
    const insideExpanded =
      finalX>=c.minX-redW*.06 && finalX<=c.maxX+redW*.06 &&
      finalY>=c.minY-redH*.06 && finalY<=c.maxY+redH*.06;

    if(!insideExpanded || distNorm>.30)
      throw new Error('Cross rejected by hotspot geometry guard.');

    return {
      x:finalX,
      y:swy?sy/swy:bestY,
      rawX:bestX,rawY:bestY,
      shapeScore,
      armRatios:{left:L.ratio,right:R.ratio,up:U.ratio,down:D.ratio},
      method:'projection-cross'
    };
  }

  function localContrastGray(data,w,h,x0,y0,x1,y1){
    const pts=[]; let mean=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4; const r=data[i],g=data[i+1],b=data[i+2]; const lum=.2126*r+.7152*g+.0722*b;
      mean+=lum;n++;pts.push([x,y,lum,r,g,b]);
    }
    mean/=Math.max(1,n); let variance=0; for(const p of pts)variance+=(p[2]-mean)*(p[2]-mean); const sd=Math.sqrt(variance/Math.max(1,n));
    return {pts,mean,sd};
  }

  function detectOrientation(data,w,h){
    // Bottom-right marker detector.
    // The marker can be cyan, gray or partially washed out in a photographed LCD,
    // so use local contrast as the primary signal and color only as a bonus.
    const x0=Math.floor(w*.82),x1=Math.floor(w*.985),y0=Math.floor(h*.80),y1=Math.floor(h*.985);
    const rw=x1-x0,rh=y1-y0;
    const lc=localContrastGray(data,w,h,x0,y0,x1,y1);
    const os=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const mask=new Uint8Array(rw*rh);

    const lumBase=Math.max(os.lum50+2,lc.mean+Math.max(2,lc.sd*.12));
    const cyanBase=Math.max(1.5,os.cyan70*.42);

    for(const p of lc.pts){
      const [x,y,lum,r,g,b]=p;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const contrast=lum-lc.mean;
      // Accept either highlighted cyan pixels OR locally bright/contrasty neutral pixels.
      const on=(cyanScore>=cyanBase && lum>=os.lum50) ||
               (lum>=lumBase && contrast>=Math.max(2,lc.sd*.10));
      if(on) mask[(y-y0)*rw+(x-x0)]=1;
    }

    // Bridge one-pixel gaps caused by moire / antialiasing.
    const joined=new Uint8Array(mask);
    for(let yy=1;yy<rh-1;yy++)for(let xx=1;xx<rw-1;xx++){
      if(mask[yy*rw+xx])continue;
      const h=mask[yy*rw+xx-1]&&mask[yy*rw+xx+1];
      const v=mask[(yy-1)*rw+xx]&&mask[(yy+1)*rw+xx];
      const d1=mask[(yy-1)*rw+xx-1]&&mask[(yy+1)*rw+xx+1];
      const d2=mask[(yy-1)*rw+xx+1]&&mask[(yy+1)*rw+xx-1];
      if(h||v||d1||d2)joined[yy*rw+xx]=1;
    }

    const comps=connectedComponents(joined,rw,rh,2)
      .filter(c=>{
        const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
        return c.area<rw*rh*.10 && ww>=3 && hh>=3 &&
               ww<rw*.55 && hh<rh*.55;
      });

    function caretScores(c){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      const pts=[];
      for(let y=c.minY;y<=c.maxY;y++)for(let x=c.minX;x<=c.maxX;x++){
        if(joined[y*rw+x])pts.push([x,y]);
      }
      if(pts.length<3)return {up:0,right:0};

      const midX=(c.minX+c.maxX)/2,midY=(c.minY+c.maxY)/2;
      const sx=Math.max(1,ww/2),sy=Math.max(1,hh/2);

      // For ^ : apex near top-center, with two arms extending down-left/down-right.
      // For > : apex near right-center, with two arms extending up-left/down-left.
      let upShape=0,rightShape=0,upUsed=0,rightUsed=0;
      for(const [x,y] of pts){
        const nx=(x-midX)/sx, ny=(y-midY)/sy;
        // Ideal ^ arms: |nx| approximately ny+1 (ny=-1 at apex, +1 at base)
        const upErr=Math.abs(Math.abs(nx)-Math.max(0,(ny+1)*.55));
        const upPosPenalty=ny<-1.15||ny>1.15?1:0;
        upShape+=Math.max(0,1-upErr*.90-upPosPenalty);upUsed++;

        // Ideal > arms: |ny| approximately 1-nx (nx=+1 at apex)
        const rightErr=Math.abs(Math.abs(ny)-Math.max(0,(1-nx)*.55));
        const rightPosPenalty=nx<-1.15||nx>1.15?1:0;
        rightShape+=Math.max(0,1-rightErr*.90-rightPosPenalty);rightUsed++;
      }
      upShape/=Math.max(1,upUsed);rightShape/=Math.max(1,rightUsed);

      // Apex evidence: top-center for ^, right-center for >.
      let upApex=0,rightApex=0;
      for(const [x,y] of pts){
        const nx=Math.abs((x-midX)/sx),ny=(y-c.minY)/Math.max(1,hh-1);
        if(ny<.35 && nx<.45)upApex++;
        const rx=(c.maxX-x)/Math.max(1,ww-1),ry=Math.abs((y-midY)/sy);
        if(rx<.35 && ry<.45)rightApex++;
      }
      upApex/=pts.length;rightApex/=pts.length;

      // Bilateral arm evidence.
      let ul=0,ur=0,rl=0,rr=0;
      for(const [x,y] of pts){
        if(y>midY){
          if(x<midX)ul++; else ur++;
        }
        if(x<midX){
          if(y<midY)rl++; else rr++;
        }
      }
      const upBalance=Math.min(ul,ur)/Math.max(1,Math.max(ul,ur));
      const rightBalance=Math.min(rl,rr)/Math.max(1,Math.max(rl,rr));

      return {
        up:upShape*.58+upApex*.22+upBalance*.20,
        right:rightShape*.58+rightApex*.22+rightBalance*.20
      };
    }

    let best=null;
    for(const c of comps){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      const sc=caretScores(c);
      // Prefer the actual marker zone: lower-right of the thermal viewport ROI,
      // but do not hardcode a single pixel coordinate.
      const cx=(c.minX+c.maxX)/2,cy=(c.minY+c.maxY)/2;
      const posX=cx/rw,posY=cy/rh;
      const posBonus=(posX>.25?.06:0)+(posY>.20?.04:0);
      const compact=c.area/Math.max(1,ww*hh);
      const quality=Math.max(sc.up,sc.right)+posBonus+Math.min(.08,compact*.08);
      if(!best||quality>best.quality)best={c,sc,quality,ww,hh};
    }

    if(!best){
      return {direction:'up',confidence:.34,reason:'marker not isolated; conservative up fallback'};
    }

    // Right must win clearly. A photographed ^ often becomes vertically fragmented,
    // so ambiguous cases should remain Up rather than being flipped to Right.
    const margin=best.sc.up-best.sc.right;
    let direction='up';
    if(best.sc.right>best.sc.up+.16 && best.sc.right>.48)direction='right';

    const winning=direction==='up'?best.sc.up:best.sc.right;
    const conf=Math.max(.36,Math.min(.97,.46+winning*.42+Math.min(.12,Math.abs(margin)*.35)));

    return {
      direction,confidence:conf,
      bbox:{minX:best.c.minX+x0,maxX:best.c.maxX+x0,minY:best.c.minY+y0,maxY:best.c.maxY+y0},
      width:best.ww,height:best.hh,
      upScore:best.sc.up,rightScore:best.sc.right,
      reason:`caret shape up=${best.sc.up.toFixed(2)} right=${best.sc.right.toFixed(2)}`
    };
  }

  function percentile(arr,p){ const a=Array.from(arr).sort((a,b)=>a-b); return a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))]; }

  function findSixRegularTicks(cands,h){
    let best=null;
    const minGap=h*.018,maxGap=h*.095;
    for(let a=0;a<cands.length;a++) for(let b=a+1;b<cands.length;b++){
      const span=cands[b].y-cands[a].y;
      for(let steps=1;steps<=5;steps++){
        const gap=span/steps;if(gap<minGap||gap>maxGap)continue;
        for(let apos=0;apos<=5-steps;apos++){
          const first=cands[a].y-apos*gap,selected=[];let err=0,strength=0,ok=true,lastIdx=-1;
          const tol=Math.max(4,gap*.14);
          for(let k=0;k<6;k++){
            const target=first+k*gap;let bi=-1,be=1e9;
            for(let j=lastIdx+1;j<cands.length;j++){
              const e=Math.abs(cands[j].y-target);if(e<be){be=e;bi=j;}if(cands[j].y>target+tol)break;
            }
            if(bi<0||be>tol){ok=false;break;}selected.push(cands[bi]);lastIdx=bi;err+=be/gap;strength+=cands[bi].score;
          }
          if(!ok)continue;
          const ys=selected.map(t=>t.y),gaps=[];for(let k=0;k<5;k++)gaps.push(ys[k+1]-ys[k]);
          const mean=gaps.reduce((x,y)=>x+y,0)/5,maxDev=Math.max(...gaps.map(g=>Math.abs(g-mean)/mean));
          const fullSpan=ys[5]-ys[0];if(maxDev>.15||fullSpan<h*.09||fullSpan>h*.48)continue;
          const quality=130-err*20-maxDev*190+Math.min(40,strength*.18);
          if(!best||quality>best.quality)best={quality,selected,gaps,fullSpan,maxDev};
        }
      }
    }
    return best;
  }

  function detectScale(data,w,h){
    // First locate the vertical ruler spine, then search ONLY for six ticks attached to that spine.
    // This avoids using text baselines and other horizontal UI edges as a ruler.
    const sx0=Math.floor(w*.78),sx1=Math.floor(w*.965),y0=Math.floor(h*.18),y1=Math.floor(h*.84);
    const lum=new Float32Array(w*h);
    // Scale profile: grayscale + robust contrast stretch. No color enhancement is
    // used here because the ruler is a geometric edge problem.
    const ss=bandAdaptiveStats(data,w,h,sx0,y0,sx1,y1,Math.max(2,Math.round(Math.min(w,h)/700)));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,rawLum=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];
      lum[y*w+x]=adaptiveContrastValue(rawLum,ss.lum10,ss.lum90);
    }
    const xScores=[];
    for(let x=sx0+2;x<sx1-2;x++){
      let s=0,n=0;
      for(let y=y0;y<y1;y+=2){
        const edge=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
        const verticalSmooth=Math.abs(lum[(Math.min(h-1,y+1))*w+x]-lum[(Math.max(0,y-1))*w+x]);
        s+=Math.max(0,edge-verticalSmooth*.22);n++;
      }
      xScores.push({x,score:s/Math.max(1,n)});
    }
    xScores.sort((a,b)=>b.score-a.score);
    const spineCandidates=xScores.slice(0,10);
    let globalBest=null;
    for(const sp of spineCandidates){
      const left=Math.max(0,Math.floor(sp.x-w*.075)),right=Math.min(w-1,Math.floor(sp.x+w*.012));
      const scores=[];
      for(let y=y0+2;y<y1-2;y++){
        let s=0,n=0;
        for(let x=left+1;x<right-1;x++){
          const dv=Math.abs(lum[(y+1)*w+x]-lum[(y-1)*w+x]);
          const dh=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
          // horizontal tick edge near the detected vertical spine
          s+=Math.max(0,dv-dh*.28);n++;
        }
        scores.push({y,score:s/Math.max(1,n)});
      }
      const vals=scores.map(q=>q.score),th=percentile(vals,.79),raw=[];
      for(let i=3;i<scores.length-3;i++){
        if(scores[i].score<th)continue;let mx=true;for(let k=-3;k<=3;k++)if(scores[i+k].score>scores[i].score){mx=false;break;}
        if(mx)raw.push(scores[i]);
      }
      const clustered=[],mergeDist=Math.max(4,Math.round(h*.007));
      for(const q of raw){const last=clustered[clustered.length-1];if(last&&q.y-last.y<=mergeDist){const wt=last.weight+q.score;last.y=(last.y*last.weight+q.y*q.score)/wt;last.score=Math.max(last.score,q.score);last.weight=wt;}else clustered.push({y:q.y,score:q.score,weight:q.score});}
      const best=findSixRegularTicks(clustered,h);
      if(best){
        // Prefer a regular set and a strong continuous spine.
        best.quality+=Math.min(25,sp.score*.8);best.spineX=sp.x;best.candidates=clustered;
        if(!globalBest||best.quality>globalBest.quality)globalBest=best;
      }
    }
    if(!globalBest)return {pxPerMm:null,confidence:.12,selectedTicks:[],reason:'5 mm ruler spine + six ticks not reliably detected'};
    const ticks=globalBest.selected.map(p=>p.y),pxPerMm=(ticks[5]-ticks[0])/5;
    const regularity=Math.max(0,1-globalBest.maxDev/.15),confidence=Math.min(.98,.64+.32*regularity);
    return {pxPerMm,confidence,selectedTicks:ticks.map(Math.round),fullSpanPx:ticks[5]-ticks[0],rulerMm:5,intervalCount:5,tickCount:6,gaps:globalBest.gaps,spineX:globalBest.spineX};
  }

  // Tiny offline glyph templates for the edge annotations. Recognition is deliberately restricted to
  // the six expected anatomical letters, and opposite-side consistency is used to reject false positives.
  const GLYPHS={
    R:['11110','10001','10001','11110','10100','10010','10001'],
    L:['10000','10000','10000','10000','10000','10000','11111'],
    A:['01110','10001','10001','11111','10001','10001','10001'],
    P:['11110','10001','10001','11110','10000','10000','10000'],
    S:['01111','10000','10000','01110','00001','00001','11110'],
    I:['11111','00100','00100','00100','00100','00100','11111']
  };
  function sampleGlyph(data,w,h,roi){
    const [x0,y0,x1,y1]=roi;const pts=[];
    const gs=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const cyanCut=Math.max(2,gs.cyan70*.62),lumCut=Math.max(32,gs.lum50*.70);
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const cyan=cyanScore>=cyanCut && lum>=lumCut && (g+b)>r*1.48;
      if(cyan)pts.push([x,y]);
    }
    if(pts.length<3)return null;
    let minX=Math.min(...pts.map(p=>p[0])),maxX=Math.max(...pts.map(p=>p[0])),minY=Math.min(...pts.map(p=>p[1])),maxY=Math.max(...pts.map(p=>p[1]));
    // Ignore very large UI fragments; keep the compact component-ish center zone.
    if(maxX-minX> (x1-x0)*.75 || maxY-minY>(y1-y0)*.75)return null;
    const grid=[];
    for(let gy=0;gy<7;gy++){
      let row='';for(let gx=0;gx<5;gx++){
        const ax=minX+(maxX-minX+1)*gx/5,bx=minX+(maxX-minX+1)*(gx+1)/5;
        const ay=minY+(maxY-minY+1)*gy/7,by=minY+(maxY-minY+1)*(gy+1)/7;
        let on=0,tot=0;
        for(let y=Math.floor(ay);y<Math.ceil(by);y++)for(let x=Math.floor(ax);x<Math.ceil(bx);x++){
          if(x<0||y<0||x>=w||y>=h)continue;tot++;const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
          const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
          if(cyanScore>=cyanCut&&lum>=lumCut&&(g+b)>r*1.48)on++;
        }
        row+=on/Math.max(1,tot)>.16?'1':'0';
      }grid.push(row);
    }
    let best=null;
    for(const [label,t] of Object.entries(GLYPHS)){
      let same=0;for(let y=0;y<7;y++)for(let x=0;x<5;x++)if(grid[y][x]===t[y][x])same++;
      const score=same/35;if(!best||score>best.score)best={label,score,grid,bbox:{minX,maxX,minY,maxY}};
    }
    return best;
  }
  function classifyGlyphComponent(data,w,h,bbox){
    // Expand only around one compact connected component.  This is intentionally
    // different from the old whole-ROI sampler which mixed anatomy letters with
    // nearby UI text and often returned SI/AP or no drawable box.
    const padX=Math.max(2,Math.round((bbox.maxX-bbox.minX+1)*.45));
    const padY=Math.max(2,Math.round((bbox.maxY-bbox.minY+1)*.35));
    const roi=[Math.max(0,bbox.minX-padX),Math.max(0,bbox.minY-padY),Math.min(w,bbox.maxX+padX+1),Math.min(h,bbox.maxY+padY+1)];
    const g=sampleGlyph(data,w,h,roi);
    if(!g) return null;
    // Preserve the actual component position for the yellow rectangle.  The
    // classifier may use a padded ROI, but the overlay must surround the letter.
    g.bbox={minX:bbox.minX,maxX:bbox.maxX,minY:bbox.minY,maxY:bbox.maxY};
    return g;
  }

  function anatomyCandidates(data,w,h,side,inputSourceType,red,ring){
    // v0.2.8 direct sliding-window glyph scanner.
    // The v0.2.5 ring-relative slot geometry is frozen.
    // Unlike v0.2.7, a glyph no longer has to be one connected component.
    const labels=['R','L','S','I','A','P'];
    const minDim=Math.min(w,h);

    const cx=ring&&Number.isFinite(ring.x)?ring.x:red.component.cx;
    const cy=ring&&Number.isFinite(ring.y)?ring.y:red.component.cy;

    let rr=ring&&Number.isFinite(ring.radius)?ring.radius:
      Math.max(red.component.maxX-red.component.minX+1,red.component.maxY-red.component.minY+1)*1.55;
    rr=Math.max(minDim*.07,Math.min(minDim*.28,rr));

    let slotX=cx,slotY=cy,halfW=rr*.55,halfH=rr*.34;
    if(side==='left'){
      slotX=cx-2.12*rr; slotY=cy+.22*rr;
      halfW=.34*rr; halfH=.58*rr;
    }else if(side==='right'){
      slotX=cx+2.12*rr; slotY=cy+.22*rr;
      halfW=.34*rr; halfH=.58*rr;
    }else if(side==='top'){
      slotX=cx-1.34*rr; slotY=cy-1.92*rr;
      halfW=.62*rr; halfH=.38*rr;
    }else{
      slotX=cx-1.30*rr; slotY=cy+2.34*rr;
      halfW=.66*rr; halfH=.42*rr;
    }

    const tol=inputSourceType==='camera'?1.22:1.12;
    halfW*=tol;halfH*=tol;

    const x0=Math.max(0,Math.floor(slotX-halfW));
    const x1=Math.min(w,Math.ceil(slotX+halfW));
    const y0=Math.max(0,Math.floor(slotY-halfH));
    const y1=Math.min(h,Math.ceil(slotY+halfH));
    if(x1-x0<6||y1-y0<8)return [];

    const rw=x1-x0,rh=y1-y0;
    const st=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);

    const glyph5x7={
      R:["11110","10001","10001","11110","10100","10010","10001"],
      L:["10000","10000","10000","10000","10000","10000","11111"],
      A:["01110","10001","10001","11111","10001","10001","10001"],
      P:["11110","10001","10001","11110","10000","10000","10000"],
      S:["01111","10000","10000","01110","00001","00001","11110"],
      I:["11111","00100","00100","00100","00100","00100","11111"]
    };

    function buildMask(profile){
      const mask=new Uint8Array(rw*rh);
      const cyanBase=profile==='soft'?Math.max(.55,st.cyan70*.22):
                     profile==='strong'?Math.max(1.6,st.cyan90*.38):
                     Math.max(.9,st.cyan84*.30);
      const lumBase=profile==='soft'?Math.max(18,st.lum50*.42):
                    profile==='strong'?Math.max(31,st.lum50*.62):
                    Math.max(24,st.lum50*.51);

      for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
        const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
        const lum=.2126*r+.7152*g+.0722*b;
        const cyan=Math.max(g-r,b-r,(g+b)*.5-r);
        const chroma=Math.max(r,g,b)-Math.min(r,g,b);
        const cyanOn=cyan>=cyanBase&&(g+b)>r*1.14;
        const paleOn=lum>=Math.max(lumBase+7,st.lum90*.44)&&
          r<=Math.max(g,b)*1.11&&Math.abs(g-b)<62&&chroma<105;
        if(lum>=lumBase&&(cyanOn||paleOn))mask[(y-y0)*rw+(x-x0)]=1;
      }

      // Gentle close; glyph may still remain split, which is fine for sliding windows.
      for(let pass=0;pass<1;pass++){
        const next=new Uint8Array(mask);
        for(let yy=1;yy<rh-1;yy++)for(let xx=1;xx<rw-1;xx++){
          if(mask[yy*rw+xx])continue;
          const hv=(mask[yy*rw+xx-1]&&mask[yy*rw+xx+1])||
                   (mask[(yy-1)*rw+xx]&&mask[(yy+1)*rw+xx]);
          if(hv)next[yy*rw+xx]=1;
        }
        mask.set(next);
      }
      return mask;
    }

    function renderTemplate(pattern,rows=21,cols=15,dilate=0){
      const base=Array.from({length:rows},()=>Array(cols).fill(0));
      const ph=pattern.length,pw=pattern[0].length;
      for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
        const py=Math.min(ph-1,Math.floor(y*ph/rows));
        const px=Math.min(pw-1,Math.floor(x*pw/cols));
        base[y][x]=pattern[py][px]==='1'?1:0;
      }
      if(!dilate)return base;
      const out=Array.from({length:rows},()=>Array(cols).fill(0));
      for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(base[y][x]){
        for(let dy=-dilate;dy<=dilate;dy++)for(let dx=-dilate;dx<=dilate;dx++){
          const yy=y+dy,xx=x+dx;
          if(yy>=0&&xx>=0&&yy<rows&&xx<cols)out[yy][xx]=1;
        }
      }
      return out;
    }

    const templates={};
    for(const label of labels){
      templates[label]=[
        renderTemplate(glyph5x7[label],21,15,0),
        renderTemplate(glyph5x7[label],21,15,1)
      ];
    }

    function windowGrid(mask,wx,wy,ww,wh){
      const rows=21,cols=15;
      const g=Array.from({length:rows},()=>Array(cols).fill(0));
      for(let gy=0;gy<rows;gy++)for(let gx=0;gx<cols;gx++){
        const xa=Math.floor(wx+gx*ww/cols);
        const xb=Math.max(xa+1,Math.floor(wx+(gx+1)*ww/cols));
        const ya=Math.floor(wy+gy*wh/rows);
        const yb=Math.max(ya+1,Math.floor(wy+(gy+1)*wh/rows));
        let n=0,on=0;
        for(let yy=ya;yy<Math.min(rh,yb);yy++)for(let xx=xa;xx<Math.min(rw,xb);xx++){
          n++;on+=mask[yy*rw+xx]?1:0;
        }
        g[gy][gx]=on/Math.max(1,n);
      }
      return g;
    }

    function corr(obs,tpl){
      const R=obs.length,C=obs[0].length;
      let dot=0,o2=0,t2=0,intersection=0,union=0,fgO=0,fgT=0;
      for(let y=0;y<R;y++)for(let x=0;x<C;x++){
        const o=obs[y][x],t=tpl[y][x];
        dot+=o*t;o2+=o*o;t2+=t*t;
        const ob=o>.18,tb=t>.5;
        if(ob)fgO++;if(tb)fgT++;
        if(ob&&tb)intersection++;
        if(ob||tb)union++;
      }
      const cosine=dot/Math.sqrt(Math.max(1e-9,o2*t2));
      const iou=intersection/Math.max(1,union);
      const densityPenalty=Math.min(1,Math.abs(fgO-fgT)/Math.max(1,fgT));
      return cosine*.72+iou*.24-densityPenalty*.04;
    }

    function allScores(obs){
      const scores={};
      for(const label of labels){
        let best=-Infinity;
        for(const tpl of templates[label]){
          const sc=corr(obs,tpl);
          if(sc>best)best=sc;
        }
        scores[label]=best;
      }
      return scores;
    }

    const candidates=[];

    // Relative glyph size, derived from ring radius rather than image size.
    const heights=[
      Math.max(7,Math.round(rr*.105)),
      Math.max(8,Math.round(rr*.135)),
      Math.max(9,Math.round(rr*.165)),
      Math.max(10,Math.round(rr*.195))
    ];
    const aspectList=[.42,.55,.68,.82,1.00];

    for(const profile of ['soft','balanced','strong']){
      const mask=buildMask(profile);

      for(const gh of heights){
        for(const aspect of aspectList){
          const gw=Math.max(4,Math.round(gh*aspect));
          if(gw>=rw||gh>=rh)continue;

          const stepX=Math.max(1,Math.round(gw*.18));
          const stepY=Math.max(1,Math.round(gh*.16));

          for(let wy=0;wy<=rh-gh;wy+=stepY){
            for(let wx=0;wx<=rw-gw;wx+=stepX){
              // Quick foreground test.
              let fg=0;
              for(let yy=wy;yy<wy+gh;yy+=2)
                for(let xx=wx;xx<wx+gw;xx+=2)
                  fg+=mask[yy*rw+xx];
              const approxN=Math.ceil(gh/2)*Math.ceil(gw/2);
              const density=fg/Math.max(1,approxN);
              if(density<.025||density>.70)continue;

              const gcx=x0+wx+gw/2,gcy=y0+wy+gh/2;
              const dx=(gcx-slotX)/Math.max(1,halfW),dy=(gcy-slotY)/Math.max(1,halfH);
              const slotDist=Math.hypot(dx,dy);
              if(slotDist>1.08)continue;

              const obs=windowGrid(mask,wx,wy,gw,gh);
              const labelScores=allScores(obs);
              const sorted=labels.map(label=>({label,score:labelScores[label]}))
                .sort((a,b)=>b.score-a.score);
              const best=sorted[0],second=sorted[1];
              if(!best||best.score<.24)continue;
              const margin=best.score-(second?second.score:0);
              const loc=Math.max(0,1-slotDist/1.08);
              const profileBonus=profile==='balanced'?.035:.02;
              const final=best.score*.72+Math.max(0,margin)*.10+loc*.16+profileBonus;

              candidates.push({
                label:best.label,
                score:final,
                scoreRaw:best.score,
                margin,
                labelScores,
                side,cx:gcx,cy:gcy,
                bbox:{
                  minX:x0+wx,maxX:x0+wx+gw-1,
                  minY:y0+wy,maxY:y0+wy+gh-1
                },
                profile,
                slot:{x:slotX,y:slotY,radius:rr},
                classifier:'sliding-template-correlation-v2.8',
                window:{width:gw,height:gh,density}
              });
            }
          }
        }
      }
    }

    candidates.sort((a,b)=>b.score-a.score);

    // Non-maximum suppression: keep best window around each actual glyph location.
    const kept=[];
    for(const c of candidates){
      const dup=kept.find(k=>
        Math.abs(k.cx-c.cx)<Math.max(4,c.window.width*.45)&&
        Math.abs(k.cy-c.cy)<Math.max(4,c.window.height*.45)
      );
      if(!dup)kept.push(c);
      if(kept.length>=18)break;
    }
    return kept;
  }

  function detectAnatomy(data,w,h,inputSourceType,red,ring){
    // Anatomy Super Detector v0.3.0
    // Candidate extraction remains the proven v0.2.8 sliding-window method.
    // Decision is completely redesigned as multi-window evidence consensus +
    // global two-axis optimization.
    const all={};
    for(const side of ['top','bottom','left','right'])
      all[side]=anatomyCandidates(data,w,h,side,inputSourceType,red,ring);

    const labels=['R','L','S','I','A','P'];
    const axisDefs=[
      {axis:'RL',positive:'R',negative:'L',pairs:[['R','L'],['L','R']]},
      {axis:'AP',positive:'A',negative:'P',pairs:[['A','P'],['P','A']]},
      {axis:'SI',positive:'S',negative:'I',pairs:[['S','I'],['I','S']]}
    ];

    function sideEvidence(side,label){
      const arr=(all[side]||[]).map(c=>{
        const raw=(c.labelScores&&Number.isFinite(c.labelScores[label]))?c.labelScores[label]:-1;
        const rr=Math.max(1,c.slot&&c.slot.radius||Math.min(w,h)*.15);
        const d=Math.hypot(c.cx-c.slot.x,c.cy-c.slot.y)/rr;
        const loc=Math.max(0,1-d/.95);
        // Raw glyph correlation dominates. Location only stabilizes fragmented candidates.
        const score=raw*.86+loc*.14;
        return {candidate:c,raw,score,loc};
      }).filter(x=>x.raw>-.5).sort((a,b)=>b.score-a.score);

      if(!arr.length)return {score:-1,best:null,consensus:0,support:0};

      // Consensus across the top windows rather than trusting one winner.
      const weights=[.58,.25,.12,.05];
      let sum=0,ws=0,support=0;
      for(let i=0;i<Math.min(weights.length,arr.length);i++){
        const v=arr[i];
        sum+=v.score*weights[i];ws+=weights[i];
        if(v.raw>.18)support++;
      }
      const consensus=sum/Math.max(.001,ws);

      // Reward repeated independent windows supporting the same glyph.
      const supportBonus=Math.min(.08,support*.018);
      return {
        score:consensus+supportBonus,
        best:arr[0].candidate,
        consensus,
        support,
        top:arr.slice(0,4)
      };
    }

    const evidence={};
    for(const side of ['top','bottom','left','right']){
      evidence[side]={};
      for(const label of labels)evidence[side][label]=sideEvidence(side,label);
    }

    function axisHypotheses(sideA,sideB,orientation){
      const out=[];
      for(const def of axisDefs){
        for(const [la,lb] of def.pairs){
          const ea=evidence[sideA][la],eb=evidence[sideB][lb];
          if(!ea.best||!eb.best)continue;

          const rr=Math.max(
            1,
            ea.best.slot&&ea.best.slot.radius||
            eb.best.slot&&eb.best.slot.radius||
            Math.min(w,h)*.15
          );

          const align=(orientation==='horizontal'
            ? Math.abs(ea.best.cy-eb.best.cy)
            : Math.abs(ea.best.cx-eb.best.cx))/rr;
          const maxAlign=orientation==='horizontal'?1.35:1.70;
          if(align>maxAlign)continue;
          const alignScore=Math.max(0,1-align/maxAlign);

          const pairGlyph=(ea.score+eb.score)/2;
          const floor=Math.min(ea.score,eb.score);
          const support=Math.min(ea.support,eb.support);

          // Compare this axis against the other anatomical axes using the same sides.
          let competitor=-Infinity;
          for(const od of axisDefs){
            if(od.axis===def.axis)continue;
            for(const [oa,ob] of od.pairs){
              const ca=evidence[sideA][oa].score;
              const cb=evidence[sideB][ob].score;
              competitor=Math.max(competitor,(ca+cb)/2);
            }
          }
          const axisMargin=pairGlyph-competitor;

          // Super score: repeated-window evidence > axis separation > geometry.
          const score=
            pairGlyph*.58+
            Math.max(-.18,floor)*.12+
            Math.max(-.18,axisMargin)*.18+
            alignScore*.07+
            Math.min(.05,support*.012);

          out.push({
            axis:def.axis,positive:def.positive,negative:def.negative,
            labelA:la,labelB:lb,
            a:{...ea.best,label:la},
            b:{...eb.best,label:lb},
            score,pairGlyph,floor,axisMargin,alignScore,support,
            evidenceA:ea,evidenceB:eb
          });
        }
      }
      out.sort((a,b)=>b.score-a.score);
      return out;
    }

    const H=axisHypotheses('left','right','horizontal');
    const V=axisHypotheses('top','bottom','vertical');

    // Global solver:
    // choose H/V simultaneously, prohibit duplicate anatomical axes, and reward
    // complete two-axis explanations. No screen position is tied to a specific axis.
    let solved=null;
    for(const hp of [null,...H.slice(0,18)]){
      for(const vp of [null,...V.slice(0,18)]){
        if(!hp&&!vp)continue;
        if(hp&&vp&&hp.axis===vp.axis)continue;

        // Require at least weak actual glyph evidence.
        if(hp&&(hp.pairGlyph<.08||hp.floor<-.08))continue;
        if(vp&&(vp.pairGlyph<.06||vp.floor<-.12))continue;

        let score=(hp?hp.score:0)+(vp?vp.score:0);
        if(hp&&vp)score+=.12;
        else score-=.055;

        // Once one axis is strong, the remaining axis gets context from the fact
        // that only the other two anatomical axes are legal.
        if(hp&&vp){
          if(hp.axisMargin>.04)score+=.025;
          if(vp.axisMargin>.025)score+=.020;
        }

        if(!solved||score>solved.score)solved={hp,vp,score};
      }
    }
    if(!solved)solved={hp:null,vp:null,score:-Infinity};

    // v0.3.1 single-side vertical inference.
    // If the normal vertical pair is missing/weak, allow one high-confidence
    // top OR bottom glyph to determine the vertical anatomical axis.
    // The already-resolved horizontal axis acts as an exclusion constraint.
    function bestSingleSideVertical(horizontalAxis){
      const remainingAxes=['RL','AP','SI'].filter(a=>a!==horizontalAxis);
      const labelAxis={R:'RL',L:'RL',A:'AP',P:'AP',S:'SI',I:'SI'};
      const positive={RL:'R',AP:'A',SI:'S'};
      const negative={RL:'L',AP:'P',SI:'I'};

      const options=[];

      for(const side of ['top','bottom']){
        for(const label of labels){
          const axis=labelAxis[label];
          if(!remainingAxes.includes(axis))continue;

          const ev=evidence[side][label];
          if(!ev||!ev.best)continue;

          const rr=Math.max(1,ev.best.slot&&ev.best.slot.radius||Math.min(w,h)*.15);
          const d=Math.hypot(ev.best.cx-ev.best.slot.x,ev.best.cy-ev.best.slot.y)/rr;
          const loc=Math.max(0,1-d/.90);

          // Compare this label against the best alternative label belonging
          // to another still-legal vertical axis.
          let competitor=-Infinity;
          for(const other of labels){
            if(other===label)continue;
            const otherAxis=labelAxis[other];
            if(!remainingAxes.includes(otherAxis))continue;
            if(otherAxis===axis)continue;
            competitor=Math.max(competitor,evidence[side][other].score);
          }
          const margin=ev.score-competitor;

          // Require real, repeated support. A single random pixel window is not enough.
          if(ev.score<.18)continue;
          if(ev.support<1)continue;
          if(margin<.035 && ev.support<2)continue;

          const score=
            ev.score*.68+
            Math.max(0,margin)*.20+
            loc*.08+
            Math.min(.04,ev.support*.012);

          options.push({
            axis,
            positive:positive[axis],
            negative:negative[axis],
            inferred:true,
            singleSide:side,
            singleLabel:label,
            score,
            pairGlyph:ev.score,
            floor:ev.score,
            axisMargin:margin,
            alignScore:1,
            support:ev.support,
            a:side==='top'?{...ev.best,label}:null,
            b:side==='bottom'?{...ev.best,label}:null,
            evidenceSingle:ev
          });
        }
      }

      options.sort((a,b)=>b.score-a.score);
      if(!options.length)return null;

      const best=options[0],second=options[1];

      // Do not force if AP/SI (or RL if horizontal is not RL) are effectively tied.
      if(second && best.axis!==second.axis && best.score-second.score<.025 && best.support<2)
        return null;

      return best;
    }

    // Only invoke fallback when normal pair evidence is absent or weak.
    const horizontalAxisHint=solved.hp&&solved.hp.axis||null;
    const normalVerticalWeak=!solved.vp ||
      solved.vp.pairGlyph<.12 ||
      solved.vp.floor<-.03 ||
      solved.vp.axisMargin<-.04;

    if(normalVerticalWeak){
      const single=bestSingleSideVertical(horizontalAxisHint);
      if(single){
        // Respect same-axis exclusion.
        if(!solved.hp || single.axis!==solved.hp.axis){
          solved={...solved,vp:single,score:solved.score+single.score+.035};
        }
      }
    }

    // Confidence gating: don't publish a weak forced axis.
    function accept(p,orientation){
      if(!p)return false;

      if(orientation==='vertical'&&p.inferred){
        if(p.pairGlyph<.18)return false;
        if(p.axisMargin<.025&&p.support<2)return false;
        return true;
      }

      const minGlyph=orientation==='horizontal'?.14:.105;
      const minFloor=orientation==='horizontal'?.04:-.015;
      if(p.pairGlyph<minGlyph||p.floor<minFloor)return false;

      // Strong repeated support can compensate for a small template margin.
      if(p.axisMargin<-.055&&p.support<2)return false;
      return true;
    }

    let hp=accept(solved.hp,'horizontal')?solved.hp:null;
    let vp=accept(solved.vp,'vertical')?solved.vp:null;

    // If both survived but accidentally share axis after gating/context, keep stronger.
    if(hp&&vp&&hp.axis===vp.axis){
      if(hp.score>=vp.score)vp=null; else hp=null;
    }

    const edges={top:null,bottom:null,left:null,right:null};
    let horizontal=null,vertical=null;

    function conf(p){
      if(!p)return 0;
      return Math.min(.99,Math.max(.30,
        .46+
        Math.max(0,p.pairGlyph)*.25+
        Math.max(0,p.axisMargin)*.18+
        p.alignScore*.06+
        Math.min(.05,p.support*.012)
      ));
    }

    if(hp){
      edges.left=hp.a;edges.right=hp.b;
      horizontal={
        axis:hp.axis,
        positiveSide:hp.a.label===hp.positive?'left':'right',
        positiveLabel:hp.positive,
        negativeLabel:hp.negative,
        confidence:conf(hp)
      };
    }
    if(vp){
      edges.top=vp.a||null;
      edges.bottom=vp.b||null;

      let positiveSide='unknown';
      if(vp.inferred){
        // If the recognized single glyph itself is the positive label,
        // its side is the positive side; otherwise the opposite side is positive.
        const recognizedPositive=vp.singleLabel===vp.positive;
        if(vp.singleSide==='top')positiveSide=recognizedPositive?'top':'bottom';
        else if(vp.singleSide==='bottom')positiveSide=recognizedPositive?'bottom':'top';
      }else{
        positiveSide=vp.a.label===vp.positive?'top':'bottom';
      }

      vertical={
        axis:vp.axis,
        positiveSide,
        positiveLabel:vp.positive,
        negativeLabel:vp.negative,
        confidence:conf(vp),
        inferredFromSingleSide:!!vp.inferred,
        inferredSide:vp.singleSide||null,
        inferredLabel:vp.singleLabel||null
      };
    }

    return {
      edges,candidates:all,horizontal,vertical,
      detectedPairCount:(horizontal?1:0)+(vertical?1:0),
      planeIndependent:true,
      detector:'anatomy-super-hierarchical-v0.3.1',
      inputSourceType:inputSourceType||'unknown',
      globalScore:solved.score,
      evidence,
      pairDiagnostics:{
        horizontal:hp?{
          axis:hp.axis,pairGlyph:hp.pairGlyph,axisMargin:hp.axisMargin,
          support:hp.support,alignScore:hp.alignScore
        }:null,
        vertical:vp?{
          axis:vp.axis,pairGlyph:vp.pairGlyph,axisMargin:vp.axisMargin,
          support:vp.support,alignScore:vp.alignScore,
          inferredFromSingleSide:!!vp.inferred,
          inferredSide:vp.singleSide||null,
          inferredLabel:vp.singleLabel||null
        }:null
      }
    };
  }

  function solve3x3(A,b){
    const m=[
      [A[0][0],A[0][1],A[0][2],b[0]],
      [A[1][0],A[1][1],A[1][2],b[1]],
      [A[2][0],A[2][1],A[2][2],b[2]]
    ];
    for(let c=0;c<3;c++){
      let p=c;
      for(let r=c+1;r<3;r++) if(Math.abs(m[r][c])>Math.abs(m[p][c])) p=r;
      if(Math.abs(m[p][c])<1e-9) return null;
      if(p!==c){const t=m[p];m[p]=m[c];m[c]=t;}
      const d=m[c][c];
      for(let j=c;j<4;j++)m[c][j]/=d;
      for(let r=0;r<3;r++){
        if(r===c)continue;
        const f=m[r][c];
        for(let j=c;j<4;j++)m[r][j]-=f*m[c][j];
      }
    }
    return [m[0][3],m[1][3],m[2][3]];
  }

  function fitCircle(points,seedX,seedY){
    if(points.length<24)return null;
    let pts=points.slice();
    let result=null;
    for(let pass=0;pass<3;pass++){
      let Sxx=0,Sxy=0,Sx=0,Syy=0,Sy=0,N=0,Bx=0,By=0,B1=0;
      for(const p of pts){
        const x=p[0]-seedX,y=p[1]-seedY,z=-(x*x+y*y);
        Sxx+=x*x;Sxy+=x*y;Sx+=x;Syy+=y*y;Sy+=y;N++;
        Bx+=x*z;By+=y*z;B1+=z;
      }
      const sol=solve3x3([[Sxx,Sxy,Sx],[Sxy,Syy,Sy],[Sx,Sy,N]],[Bx,By,B1]);
      if(!sol)return null;
      const D=sol[0],E=sol[1],F=sol[2];
      const cx=seedX-D/2,cy=seedY-E/2;
      const rr=(D*D+E*E)/4-F;
      if(!(rr>0))return null;
      const radius=Math.sqrt(rr);
      const residuals=pts.map(p=>Math.abs(Math.hypot(p[0]-cx,p[1]-cy)-radius)).sort((a,b)=>a-b);
      const med=residuals[Math.floor(residuals.length*.5)]||0;
      const cut=Math.max(2.5,med*2.8);
      result={x:cx,y:cy,radius,residual:med,pointCount:pts.length};
      if(pass<2){
        pts=pts.filter(p=>Math.abs(Math.hypot(p[0]-cx,p[1]-cy)-radius)<=cut);
        if(pts.length<24)break;
      }
    }
    if(!result)return null;
    const bins=new Set();
    for(const p of pts){
      let a=Math.atan2(p[1]-result.y,p[0]-result.x);
      if(a<0)a+=Math.PI*2;
      bins.add(Math.floor(a/(Math.PI*2)*24));
    }
    result.coverage=bins.size/24;
    result.confidence=Math.max(0,Math.min(1,
      result.coverage*.58+
      Math.max(0,1-result.residual/Math.max(3,result.radius*.035))*.30+
      Math.min(1,result.pointCount/350)*.12
    ));
    return result;
  }

  function detectColoredCircle(data,w,h,red,kind){
    const rc=red.component,cx0=rc.cx,cy0=rc.cy,minDim=Math.min(w,h);
    const redW=Math.max(1,rc.maxX-rc.minX+1),redH=Math.max(1,rc.maxY-rc.minY+1);
    const redSize=Math.max(redW,redH);

    // The reference ring surrounds the hotspot.  Constrain radius from the actual
    // hotspot size instead of the whole photograph; this rejects UI text, ruler
    // ticks and the very large false circles seen in v0.1.11.
    const minR=Math.max(minDim*.055,redSize*.58);
    const maxR=Math.min(minDim*.34,redSize*1.85);
    if(maxR<=minR)return null;

    const pts=[];
    const roiR=maxR*1.18;
    const x0=Math.max(0,Math.floor(cx0-roiR)),x1=Math.min(w,Math.ceil(cx0+roiR));
    const y0=Math.max(0,Math.floor(cy0-roiR)),y1=Math.min(h,Math.ceil(cy0+roiR));
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const d=Math.hypot(x-cx0,y-cy0);
      if(d<minR*.78||d>maxR*1.12)continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b);
      let ok=false;
      if(kind==='green'){
        const ex=g-Math.max(r,b);
        ok=hh>=65&&hh<=165&&ss>.16&&vv>.26&&ex>4&&g>r*1.02;
      }else{
        const ex=Math.min(r,g)-b;
        ok=hh>=28&&hh<=72&&ss>.20&&vv>.35&&ex>18&&r>100&&g>85;
      }
      if(ok)pts.push([x,y]);
    }
    if(pts.length<28)return null;
    const fit=fitCircle(pts,cx0,cy0);
    if(!fit)return null;
    if(fit.radius<minR||fit.radius>maxR)return null;

    // A valid target ring must remain close to the hotspot centre.
    const centerShift=Math.hypot(fit.x-cx0,fit.y-cy0);
    const maxShift=Math.max(minDim*.025,redSize*.52);
    if(centerShift>maxShift)return null;

    // Re-evaluate only pixels close to the fitted circumference.  Require evidence
    // around multiple sides of the circle rather than a curved UI fragment.
    const band=Math.max(3,Math.min(fit.radius*.075,12));
    const bins=new Uint16Array(36);
    let nearCount=0;
    for(const p of pts){
      const rr=Math.hypot(p[0]-fit.x,p[1]-fit.y);
      if(Math.abs(rr-fit.radius)>band)continue;
      let a=Math.atan2(p[1]-fit.y,p[0]-fit.x);if(a<0)a+=Math.PI*2;
      bins[Math.min(35,Math.floor(a/(Math.PI*2)*36))]++;nearCount++;
    }
    const occupied=[];for(let i=0;i<36;i++)if(bins[i]>0)occupied.push(i);
    const evidenceCoverage=occupied.length/36;
    let quadrants=0;
    for(let q=0;q<4;q++){let has=false;for(let i=q*9;i<(q+1)*9;i++)if(bins[i]){has=true;break;}if(has)quadrants++;}
    if(evidenceCoverage<.34||quadrants<3||nearCount<24)return null;

    // The hotspot centroid should lie well inside the reference circle.
    if(Math.hypot(cx0-fit.x,cy0-fit.y)>fit.radius*.62)return null;

    const radiusRatio=fit.radius/redSize;
    const ratioScore=Math.max(0,1-Math.abs(radiusRatio-1.10)/.95);
    const adjustedConfidence=Math.max(0,Math.min(1,
      fit.confidence*.48+evidenceCoverage*.30+(quadrants/4)*.12+ratioScore*.10
    ));
    if(adjustedConfidence<.52)return null;

    // Keep a small set of actual circumference samples for overlay/debug.
    const samples=[];
    for(let i=0;i<36;i++){
      if(!bins[i])continue;
      const a=(i+.5)/36*Math.PI*2;
      samples.push([fit.x+Math.cos(a)*fit.radius,fit.y+Math.sin(a)*fit.radius]);
    }
    return {
      type:kind+'-circle',
      x:fit.x,y:fit.y,radius:fit.radius,
      confidence:adjustedConfidence,coverage:evidenceCoverage,
      residual:fit.residual,pointCount:nearCount,quadrants,
      centerShift,radiusRatio,samples
    };
  }

  function detectGreenSpot(data,w,h,red,circleHint){
    const mask=new Uint8Array(w*h),minDim=Math.min(w,h);
    const rcx=red.component.cx,rcy=red.component.cy;
    const anchorX=circleHint&&isFinite(circleHint.x)?circleHint.x:rcx;
    const anchorY=circleHint&&isFinite(circleHint.y)?circleHint.y:rcy;

    // Green spot is allowed only in the measurement ROI around the hotspot/reference.
    // UI areas (left toolbar, right ruler, top/bottom chrome) are excluded by geometry.
    const roiHalf=Math.min(minDim*.18,Math.max(red.component.maxX-red.component.minX,red.component.maxY-red.component.minY)*.55);
    const x0=Math.max(Math.floor(w*.16),Math.floor(anchorX-roiHalf));
    const x1=Math.min(Math.floor(w*.82),Math.ceil(anchorX+roiHalf));
    const y0=Math.max(Math.floor(h*.16),Math.floor(anchorY-roiHalf));
    const y1=Math.min(Math.floor(h*.84),Math.ceil(anchorY+roiHalf));

    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b);
      const ex=g-Math.max(r,b);
      if(hh>=65&&hh<=165&&ss>.18&&vv>.28&&ex>7&&g>r*1.035)mask[y*w+x]=1;
    }

    const comps=connectedComponents(mask,w,h,3);
    let best=null;
    for(const c of comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1,maxDim=Math.max(bw,bh),minD=Math.min(bw,bh);
      if(maxDim<2||maxDim>minDim*.038||minD<2)continue;

      const distToAnchor=Math.hypot(c.cx-anchorX,c.cy-anchorY);
      const distToRed=Math.hypot(c.cx-rcx,c.cy-rcy);

      // A true green spot must be close to the hotspot/circle centre.
      if(distToAnchor>minDim*.095)continue;
      if(distToRed>minDim*.14)continue;

      const compact=c.area/Math.max(1,bw*bh),round=minD/maxDim;
      if(compact<.18||round<.42)continue;

      const nearScore=Math.max(0,1-distToAnchor/(minDim*.095));
      const sizeScore=Math.max(0,1-maxDim/(minDim*.038));
      const score=nearScore*.50+round*.22+Math.min(1,compact)*.18+sizeScore*.10;

      if(!best||score>best.score){
        best={
          type:'green-spot',x:c.cx,y:c.cy,
          confidence:Math.min(.92,.44+score*.48),
          score,
          bbox:{minX:c.minX,minY:c.minY,maxX:c.maxX,maxY:c.maxY}
        };
      }
    }

    // Reject weak spots instead of forcing a result.
    if(!best||best.confidence<.64)return null;
    return best;
  }

  function referenceGeometryOK(ref,red,w,h){
    if(!ref)return false;
    const minDim=Math.min(w,h);
    const d=Math.hypot(ref.x-red.component.cx,ref.y-red.component.cy);

    if(ref.type==='cross'){
      // Cross should be inside/near the hotspot.
      return d<=minDim*.16 && (ref.shapeScore||0)>=.50;
    }

    if(ref.type==='green-circle'||ref.type==='yellow-circle'){
      if(!(ref.radius>0))return false;
      // Circle centre must stay near red centroid, and red centroid must lie inside the fitted circle.
      if(d>Math.min(ref.radius*.42,minDim*.16))return false;
      if(d>=ref.radius*.72)return false;
      if((ref.coverage||0)<.18)return false;
      if((ref.confidence||0)<.48)return false;
      return true;
    }

    if(ref.type==='green-spot'){
      return d<=minDim*.14 && (ref.confidence||0)>=.64;
    }

    return false;
  }

  function chooseReference(data,w,h,red,cross){
    // Priority is fixed, but every candidate must pass geometry/confidence validation.
    if(cross){
      const c={type:'cross',x:cross.x,y:cross.y,confidence:Math.min(.98,.68+(cross.shapeScore||0)*.30),shapeScore:cross.shapeScore||0};
      if(referenceGeometryOK(c,red,w,h))return c;
    }

    const greenCircle=detectColoredCircle(data,w,h,red,'green');
    const yellowCircle=detectColoredCircle(data,w,h,red,'yellow');

    const validCircles=[greenCircle,yellowCircle].filter(c=>referenceGeometryOK(c,red,w,h));
    if(validCircles.length){
      validCircles.sort((a,b)=>(b.confidence||0)-(a.confidence||0));
      return validCircles[0];
    }

    const circleHint=validCircles[0]||greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpot(data,w,h,red,circleHint);
    if(referenceGeometryOK(greenSpot,red,w,h))return greenSpot;

    // Safety behaviour: no forced measurement from an unconfirmed reference.
    return null;
  }

  // ============================================================
  // LocAcc v0.2.0 unified detector pipeline
  // Each detector returns its own candidate/confidence/reject
  // information.  Only the Decision Engine chooses the reference.
  // ============================================================

  function labelComponents(mask,w,h,minArea){
    const labels=new Int32Array(mask.length);
    const comps=[];
    const stack=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    let nextLabel=1;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||labels[idx])continue;
      let sp=0;stack[sp++]=idx;labels[idx]=nextLabel;
      let area=0,sx=0,sy=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        const ci=stack[--sp],cx=ci%w,cy=(ci/w)|0;
        area++;sx+=cx;sy+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k],ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h)continue;
          const ni=ny*w+nx;
          if(mask[ni]&&!labels[ni]){labels[ni]=nextLabel;stack[sp++]=ni;}
        }
      }
      if(area>=minArea)comps.push({label:nextLabel,area,cx:sx/area,cy:sy/area,minX,maxX,minY,maxY});
      nextLabel++;
    }
    return {labels,comps};
  }

  function detectHotspotV2(data,w,h){
    const minDim=Math.min(w,h);
    // Central treatment viewport: exclude side toolbars/plots first.
    const x0=Math.floor(w*.18),x1=Math.ceil(w*.80);
    const y0=Math.floor(h*.14),y1=Math.ceil(h*.84);
    const st=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,Math.max(2,Math.round(minDim/700)));

    const hard=new Uint8Array(w*h),soft=new Uint8Array(w*h);
    const hardEx=Math.max(18,Math.min(52,st.red88*.36));
    const softEx=Math.max(7,Math.min(28,st.red70*.24));
    const hardLum=Math.max(34,st.lum50*.58);
    const softLum=Math.max(25,st.lum50*.44);

    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b;
      const ex=r-Math.max(g,b),redHue=hh<58||hh>318;
      if(redHue&&ex>=softEx&&ss>.08&&vv>.18&&lum>=softLum)soft[y*w+x]=1;
      if(redHue&&ex>=hardEx&&ss>.22&&vv>.28&&lum>=hardLum&&r>g*1.08&&r>b*1.10)hard[y*w+x]=1;
    }

    const hardLab=labelComponents(hard,w,h,Math.max(40,Math.floor(w*h*.00010)));
    let seed=null;
    for(const c of hardLab.comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      if(bw<w*.025||bh<h*.025||bw>w*.36||bh>h*.36)continue;
      const dx=(c.cx-w*.5)/(w*.28),dy=(c.cy-h*.49)/(h*.30);
      const center=Math.hypot(dx,dy);
      if(center>1.2)continue;
      const compact=c.area/Math.max(1,bw*bh);
      const size=Math.min(1,c.area/(w*h*.018));
      const score=size*.42+Math.max(0,1-center/1.2)*.40+Math.min(1,compact/.58)*.18;
      if(!seed||score>seed.score)seed={...c,score};
    }
    if(!seed)throw new Error('Hotspot detector: no central red core.');

    // Grow only from the chosen hard component into the soft red mask.
    const grown=new Uint8Array(w*h),queue=new Int32Array(w*h);
    let qh=0,qt=0;
    for(let y=seed.minY;y<=seed.maxY;y++)for(let x=seed.minX;x<=seed.maxX;x++){
      const idx=y*w+x;
      if(hardLab.labels[idx]===seed.label){grown[idx]=1;queue[qt++]=idx;}
    }

    const padX=Math.max(8,(seed.maxX-seed.minX+1)*.55);
    const padY=Math.max(8,(seed.maxY-seed.minY+1)*.55);
    const gx0=Math.max(x0,Math.floor(seed.minX-padX)),gx1=Math.min(x1-1,Math.ceil(seed.maxX+padX));
    const gy0=Math.max(y0,Math.floor(seed.minY-padY)),gy1=Math.min(y1-1,Math.ceil(seed.maxY+padY));
    const dirs=[-1,0,1,0,-1];
    while(qh<qt){
      const idx=queue[qh++],cx=idx%w,cy=(idx/w)|0;
      for(let k=0;k<4;k++){
        const nx=cx+dirs[k],ny=cy+dirs[k+1];
        if(nx<gx0||nx>gx1||ny<gy0||ny>gy1)continue;
        const ni=ny*w+nx;
        if(!grown[ni]&&soft[ni]){grown[ni]=1;queue[qt++]=ni;}
      }
    }

    // Equal-area centroid of the grown silhouette.
    let area=0,sx=0,sy=0,minX=w,maxX=0,minY=h,maxY=0;
    for(let y=gy0;y<=gy1;y++)for(let x=gx0;x<=gx1;x++){
      if(!grown[y*w+x])continue;
      area++;sx+=x;sy+=y;
      if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;
    }
    if(area<100)throw new Error('Hotspot detector: grown silhouette too small.');

    const cx=sx/area,cy=sy/area,bw=maxX-minX+1,bh=maxY-minY+1;
    const confidence=Math.max(.45,Math.min(.99,
      .52+seed.score*.28+Math.min(1,area/(w*h*.025))*.12+
      (Math.min(bw,bh)/Math.max(bw,bh))*.08
    ));

    return {
      component:{area,cx,cy,minX,maxX,minY,maxY,selectionScore:seed.score},
      mask:grown,rawMask:soft,
      detector:{name:'hotspot-v2',confidence,rejectReason:null}
    };
  }

  function detectCrossV2(data,w,h,red){
    const c=red.component,bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1,minDim=Math.min(w,h);
    const x0=Math.max(0,Math.floor(c.minX-bw*.04)),x1=Math.min(w-1,Math.ceil(c.maxX+bw*.04));
    const y0=Math.max(0,Math.floor(c.minY-bh*.04)),y1=Math.min(h-1,Math.ceil(c.maxY+bh*.04));
    const st=bandAdaptiveStats(data,w,h,x0,y0,x1+1,y1+1,1);
    const mask=new Uint8Array(w*h);
    const yCut=Math.max(5,st.yellow75*.34),lumCut=Math.max(38,st.lum50*.55);

    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      // Cross may sit on the boundary of the red fill; allow a very small halo.
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b;
      const yellow=Math.min(r,g)-b*.55;
      const greenYellow=(hh>=22&&hh<=145);
      if(greenYellow&&ss>.07&&vv>.24&&lum>=lumCut&&yellow>=yCut)mask[y*w+x]=1;
    }

    // Score candidate intersections directly.  A true cross must have support
    // horizontally and vertically around the SAME point.
    const band=Math.max(1,Math.round(minDim*.0025));
    const rx=Math.max(5,Math.round(bw*.20)),ry=Math.max(5,Math.round(bh*.20));
    let best=null;
    const sx0=Math.max(x0,Math.floor(c.cx-bw*.34)),sx1=Math.min(x1,Math.ceil(c.cx+bw*.34));
    const sy0=Math.max(y0,Math.floor(c.cy-bh*.34)),sy1=Math.min(y1,Math.ceil(c.cy+bh*.34));

    function horizontalSupport(cx,cy){
      let left=0,right=0;
      for(let x=Math.max(x0,cx-rx);x<cx-2;x++){
        let hit=false;
        for(let y=Math.max(y0,cy-band);y<=Math.min(y1,cy+band);y++)if(mask[y*w+x]){hit=true;break;}
        if(hit)left++;
      }
      for(let x=cx+2;x<=Math.min(x1,cx+rx);x++){
        let hit=false;
        for(let y=Math.max(y0,cy-band);y<=Math.min(y1,cy+band);y++)if(mask[y*w+x]){hit=true;break;}
        if(hit)right++;
      }
      return {left,right};
    }
    function verticalSupport(cx,cy){
      let up=0,down=0;
      for(let y=Math.max(y0,cy-ry);y<cy-2;y++){
        let hit=false;
        for(let x=Math.max(x0,cx-band);x<=Math.min(x1,cx+band);x++)if(mask[y*w+x]){hit=true;break;}
        if(hit)up++;
      }
      for(let y=cy+2;y<=Math.min(y1,cy+ry);y++){
        let hit=false;
        for(let x=Math.max(x0,cx-band);x<=Math.min(x1,cx+band);x++)if(mask[y*w+x]){hit=true;break;}
        if(hit)down++;
      }
      return {up,down};
    }

    const step=Math.max(1,Math.round(minDim*.002));
    for(let y=sy0;y<=sy1;y+=step)for(let x=sx0;x<=sx1;x+=step){
      // Candidate itself should contain at least one cross-colored pixel nearby.
      let local=0;
      for(let yy=Math.max(y0,y-band);yy<=Math.min(y1,y+band);yy++)
        for(let xx=Math.max(x0,x-band);xx<=Math.min(x1,x+band);xx++)local+=mask[yy*w+xx];
      if(local<2)continue;

      const H=horizontalSupport(x,y),V=verticalSupport(x,y);
      const minH=Math.min(H.left,H.right),minV=Math.min(V.up,V.down);
      if(minH<2||minV<2)continue;

      const hBal=minH/Math.max(H.left,H.right),vBal=minV/Math.max(V.up,V.down);
      const armScore=Math.min(1,(minH/Math.max(3,rx*.18)))*.5+Math.min(1,(minV/Math.max(3,ry*.18)))*.5;
      const d=Math.hypot(x-c.cx,y-c.cy)/Math.max(1,Math.min(bw,bh));
      if(d>.38)continue;
      const score=armScore*.48+hBal*.17+vBal*.17+Math.max(0,1-d/.38)*.18;
      if(!best||score>best.score)best={x,y,score,H,V,d};
    }

    if(!best||best.score<.46)throw new Error('Cross detector: four-arm intersection not confirmed.');
    return {
      type:'cross',x:best.x,y:best.y,
      shapeScore:best.score,
      confidence:Math.min(.99,.58+best.score*.40),
      detector:{name:'cross-v2',confidence:Math.min(.99,.58+best.score*.40),rejectReason:null}
    };
  }

  function detectRingV2(data,w,h,red,kind){
    const c=red.component,minDim=Math.min(w,h);
    const pts=[];
    const x0=Math.max(0,Math.floor(c.cx-minDim*.30)),x1=Math.min(w-1,Math.ceil(c.cx+minDim*.30));
    const y0=Math.max(0,Math.floor(c.cy-minDim*.30)),y1=Math.min(h-1,Math.ceil(c.cy+minDim*.30));
    const exclude=Math.max(c.maxX-c.minX+1,c.maxY-c.minY+1)*.55;

    for(let y=y0;y<=y1;y+=1)for(let x=x0;x<=x1;x+=1){
      const d=Math.hypot(x-c.cx,y-c.cy);
      if(d<exclude||d>minDim*.29)continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b);
      let ok=false;
      if(kind==='green'){
        ok=hh>=58&&hh<=170&&ss>.12&&vv>.22&&(g-Math.max(r,b))>4;
      }else{
        ok=hh>=25&&hh<=82&&ss>.14&&vv>.28&&(Math.min(r,g)-b*.55)>8;
      }
      if(ok)pts.push([x,y]);
    }
    if(pts.length<25)return null;

    // Robust ellipse center from opposite quantile extents. This intentionally
    // measures the center only; perspective may turn the displayed circle into an ellipse.
    const xs=pts.map(p=>p[0]).sort((a,b)=>a-b),ys=pts.map(p=>p[1]).sort((a,b)=>a-b);
    const q=(a,p)=>a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))];
    const left=q(xs,.03),right=q(xs,.97),top=q(ys,.03),bottom=q(ys,.97);
    const cx=(left+right)/2,cy=(top+bottom)/2,rx=(right-left)/2,ry=(bottom-top)/2;
    if(rx<minDim*.07||ry<minDim*.07||rx>minDim*.30||ry>minDim*.30)return null;

    let quad=[0,0,0,0],near=0;
    for(const [x,y] of pts){
      const nx=(x-cx)/Math.max(1,rx),ny=(y-cy)/Math.max(1,ry);
      const rr=Math.sqrt(nx*nx+ny*ny);
      if(rr>.72&&rr<1.28){
        near++;
        quad[(x>=cx?1:0)+(y>=cy?2:0)]++;
      }
    }
    const qCount=quad.filter(v=>v>=3).length;
    const coverage=near/Math.max(1,pts.length);
    const redDist=Math.hypot(cx-c.cx,cy-c.cy);
    if(qCount<3||coverage<.30||redDist>Math.min(rx,ry)*.45)return null;

    const confidence=Math.min(.95,.48+qCount*.07+Math.min(.25,coverage*.25)+Math.max(0,.12-redDist/minDim));
    return {
      type:kind==='green'?'green-circle':'yellow-circle',
      x:cx,y:cy,radius:(rx+ry)/2,rx,ry,
      coverage,confidence,
      detector:{name:`${kind}-ring-v2`,confidence,rejectReason:null}
    };
  }

  function detectGreenSpotV2(data,w,h,red,circleHint){
    const c=red.component,minDim=Math.min(w,h),mask=new Uint8Array(w*h);
    const ax=circleHint?circleHint.x:c.cx,ay=circleHint?circleHint.y:c.cy;
    const radius=minDim*.12;
    const x0=Math.max(0,Math.floor(ax-radius)),x1=Math.min(w-1,Math.ceil(ax+radius));
    const y0=Math.max(0,Math.floor(ay-radius)),y1=Math.min(h-1,Math.ceil(ay+radius));
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b);
      if(hh>=60&&hh<=170&&ss>.15&&vv>.25&&(g-Math.max(r,b))>5)mask[y*w+x]=1;
    }
    const comps=connectedComponents(mask,w,h,2);
    let best=null;
    for(const q of comps){
      const bw=q.maxX-q.minX+1,bh=q.maxY-q.minY+1,maxD=Math.max(bw,bh),minD=Math.min(bw,bh);
      if(maxD<2||maxD>minDim*.035||minD<2)continue;
      const d=Math.hypot(q.cx-ax,q.cy-ay);
      if(d>radius*.72)continue;
      const compact=q.area/Math.max(1,bw*bh),round=minD/maxD;
      if(compact<.15||round<.35)continue;
      const score=Math.max(0,1-d/(radius*.72))*.48+round*.24+Math.min(1,compact)*.18+(1-maxD/(minDim*.035))*.10;
      if(!best||score>best.score)best={q,score};
    }
    if(!best||best.score<.45)return null;
    const confidence=Math.min(.90,.50+best.score*.42);
    return {type:'green-spot',x:best.q.cx,y:best.q.cy,confidence,
      bbox:{minX:best.q.minX,minY:best.q.minY,maxX:best.q.maxX,maxY:best.q.maxY},
      detector:{name:'green-spot-v2',confidence,rejectReason:null}};
  }

  function decideReferenceV2(candidates){
    // Priority is fixed and never changed by other detectors.
    const order=['cross','green-circle','yellow-circle','green-spot'];
    const minimum={'cross':.56,'green-circle':.54,'yellow-circle':.54,'green-spot':.62};
    for(const type of order){
      const c=candidates.find(x=>x&&x.type===type);
      if(c&&(c.confidence||0)>=minimum[type])return c;
    }
    return null;
  }

  function analyzeV2(imageData,w,h,overrides){
    overrides=overrides||{};
    const data=imageData.data;

    const diagnostics={
      pipeline:'LocAcc-0.2.0',
      hotspot:null,cross:null,greenCircle:null,yellowCircle:null,greenSpot:null,
      decision:null
    };

    const red=detectHotspotV2(data,w,h);
    diagnostics.hotspot={ok:true,confidence:red.detector.confidence};

    let cross=null;
    try{
      cross=detectCrossV2(data,w,h,red);
      diagnostics.cross={ok:true,confidence:cross.confidence};
    }catch(e){
      diagnostics.cross={ok:false,reason:e.message};
    }

    const greenCircle=detectRingV2(data,w,h,red,'green');
    diagnostics.greenCircle=greenCircle?{ok:true,confidence:greenCircle.confidence}:{ok:false,reason:'not confirmed'};

    const yellowCircle=detectRingV2(data,w,h,red,'yellow');
    diagnostics.yellowCircle=yellowCircle?{ok:true,confidence:yellowCircle.confidence}:{ok:false,reason:'not confirmed'};

    const circleHint=greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpotV2(data,w,h,red,circleHint);
    diagnostics.greenSpot=greenSpot?{ok:true,confidence:greenSpot.confidence}:{ok:false,reason:'not confirmed'};

    const reference=decideReferenceV2([cross,greenCircle,yellowCircle,greenSpot]);
    const referenceConfirmed=!!reference;
    diagnostics.decision=reference?
      {ok:true,type:reference.type,confidence:reference.confidence}:
      {ok:false,reason:'no candidate passed fixed reference thresholds'};

    // Keep proven independent detectors unchanged.
    const orientation=detectOrientation(data,w,h);
    const scale=detectScale(data,w,h);
    const anatomy=detectAnatomy(data,w,h,overrides.inputSourceType||'unknown',red,greenCircle||yellowCircle||null);
    const direction=overrides.direction||orientation.direction;
    const pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3)
      throw new Error('5 mm scale could not be calibrated automatically. Tap the top and bottom ruler ticks.');

    const dxPx=referenceConfirmed?red.component.cx-reference.x:NaN;
    const dyPx=referenceConfirmed?red.component.cy-reference.y:NaN;

    function component(screenAxis,rawPx,axis){
      let signedPx=rawPx,positiveLabel='?',negativeLabel='?',axisKnown=false;
      let axisName=screenAxis==='horizontal'?'H':'V';
      if(axis){
        axisKnown=true;axisName=axis.axis;
        positiveLabel=axis.positiveLabel;negativeLabel=axis.negativeLabel;
        const positiveScreenSign=(axis.positiveSide==='right'||axis.positiveSide==='bottom')?1:-1;
        signedPx=rawPx*positiveScreenSign;
      }
      const signedMm=Number.isFinite(signedPx)?signedPx/pxPerMm:NaN;
      return {screenAxis,axis:axisName,axisKnown,rawPx,signedPx,signedMm,positiveLabel,negativeLabel,valid:Number.isFinite(signedMm)};
    }

    const horizontal=component('horizontal',dxPx,anatomy.horizontal);
    const vertical=component('vertical',dyPx,anatomy.vertical);
    const finalComponent=direction==='up'?horizontal:vertical;

    const geometryConfidence=referenceConfirmed?
      Math.max(0,Math.min(1,(red.detector.confidence||.5)*.42+(reference.confidence||.5)*.58)):0;
    const anatomyConfidence=Math.max(
      anatomy.horizontal&&anatomy.horizontal.confidence||0,
      anatomy.vertical&&anatomy.vertical.confidence||0
    );
    const confidence=referenceConfirmed?
      Math.max(0,Math.min(1,geometryConfidence*.68+(scale.confidence||.3)*.22+(orientation.confidence||.3)*.10)):0;

    return {
      red,reference,referenceConfirmed,needsAttention:!referenceConfirmed,
      cross,greenCircle,yellowCircle,greenSpot,
      orientation,direction,scale,anatomy,pxPerMm,
      horizontal,vertical,finalComponent,
      markerPerpendicular:direction==='up'?'horizontal':'vertical',
      measurementAxis:finalComponent.axis,
      screenAxis:finalComponent.screenAxis,
      signedMm:finalComponent.signedMm,
      signedPx:finalComponent.signedPx,
      axisKnown:finalComponent.axisKnown,
      positiveLabel:finalComponent.positiveLabel,
      negativeLabel:finalComponent.negativeLabel,
      confidence,geometryConfidence,anatomyConfidence,
      diagnostics,
      processing:{
        pipeline:'detector -> candidate -> decision engine',
        hotspot:'hard red seed -> soft connected growth -> equal-area centroid',
        referencePriority:'cross > green circle > yellow circle > green spot',
        ring:'robust ellipse-center from actual line pixels',
        anatomy:'independent edge glyph detector; RL/AP/SI pair validation',
        final:'marker-perpendicular component'
      }
    };
  }

  function analyze(imageData,w,h,overrides){
    overrides=overrides||{};
    const red=redRegion(imageData.data,w,h);

    let cross=null;
    try{cross=crossCenter(imageData.data,w,h,red);}catch(_e){cross=null;}

    const reference=chooseReference(imageData.data,w,h,red,cross);
    const greenCircle=detectColoredCircle(imageData.data,w,h,red,'green');
    const yellowCircle=detectColoredCircle(imageData.data,w,h,red,'yellow');
    const circleHint=greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpot(imageData.data,w,h,red,circleHint);
    const referenceConfirmed=!!reference;

    const ori=detectOrientation(imageData.data,w,h);
    const scale=detectScale(imageData.data,w,h);
    const anatomy=detectAnatomy(imageData.data,w,h);
    const direction=overrides.direction||ori.direction;
    const pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3)throw new Error('5 mm scale could not be calibrated automatically. Tap the top and bottom ruler ticks.');

    const dxPx=referenceConfirmed ? red.component.cx-reference.x : NaN;
    const dyPx=referenceConfirmed ? red.component.cy-reference.y : NaN;

    function componentResult(screenAxis,rawPx,axis){
      let signedPx=rawPx,positiveLabel='?',negativeLabel='?',axisKnown=false,axisName=screenAxis==='horizontal'?'H':'V';
      if(axis){
        axisKnown=true;
        axisName=axis.axis;
        positiveLabel=axis.positiveLabel;
        negativeLabel=axis.negativeLabel;
        const positiveScreenSign=(axis.positiveSide==='right'||axis.positiveSide==='bottom')?1:-1;
        signedPx=rawPx*positiveScreenSign;
      }
      const signedMm=Number.isFinite(signedPx)?signedPx/pxPerMm:NaN;
      return {screenAxis,axis:axisName,axisKnown,rawPx,signedPx,signedMm,positiveLabel,negativeLabel,valid:Number.isFinite(signedMm)};
    }

    const horizontal=componentResult('horizontal',dxPx,anatomy.horizontal);
    const vertical=componentResult('vertical',dyPx,anatomy.vertical);

    const finalComponent=direction==='up'?horizontal:vertical;
    const markerPerpendicular=direction==='up'?'horizontal':'vertical';

    let confidence=referenceConfirmed?Math.max(0,Math.min(1,
      (scale.confidence||.3)*.35+
      (reference.confidence||.5)*.40+
      (ori.confidence||.3)*.15+
      (finalComponent.axisKnown?.90:.35)*.10
    )):0;

    return {
      red,reference,referenceConfirmed,needsAttention:!referenceConfirmed,cross,greenCircle,yellowCircle,greenSpot,
      orientation:ori,direction,scale,anatomy,pxPerMm,
      horizontal,vertical,
      finalComponent,
      markerPerpendicular,
      measurementAxis:finalComponent.axis,
      screenAxis:finalComponent.screenAxis,
      signedMm:finalComponent.signedMm,
      signedPx:finalComponent.signedPx,
      axisKnown:finalComponent.axisKnown,
      positiveLabel:finalComponent.positiveLabel,
      negativeLabel:finalComponent.negativeLabel,
      confidence,
      processing:{
        red:'geometric hotspot centroid',
        referencePriority:'cross > green/yellow circle fit > green spot',
        circle:'hotspot-constrained circle fit + angular evidence validation',
        anatomy:'validated opposite-edge pair (RL/AP/SI)',
        final:'marker-perpendicular component'
      }
    };
  }

  global.LocAccCore={
    analyze:analyzeV2,
    redRegion:detectHotspotV2,
    crossCenter:detectCrossV2,
    detectColoredCircle:detectRingV2,
    detectGreenSpot:detectGreenSpotV2,
    chooseReference:decideReferenceV2,
    detectOrientation,
    detectScale,
    detectAnatomy,
    legacy:{analyze,redRegion,crossCenter,detectColoredCircle,detectGreenSpot,chooseReference}
  };
})(window);
