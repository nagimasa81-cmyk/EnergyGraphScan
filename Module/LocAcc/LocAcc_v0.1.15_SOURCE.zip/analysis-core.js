(function(global){
  'use strict';

  function rgbToHSV(r,g,b){
    r/=255; g/=255; b/=255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
    let h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return [h, max?d/max:0, max];
  }


  function clamp255(v){ return v<0?0:v>255?255:v; }

  function sampledPercentile(values,p){
    if(!values.length) return 0;
    values.sort((a,b)=>a-b);
    return values[Math.max(0,Math.min(values.length-1,Math.floor((values.length-1)*p)))];
  }

  function bandAdaptiveStats(data,w,h,x0,y0,x1,y1,step){
    const lum=[],cyan=[],red=[],yellow=[];
    step=Math.max(1,step||3);
    for(let y=y0;y<y1;y+=step) for(let x=x0;x<x1;x+=step){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const l=.2126*r+.7152*g+.0722*b;
      lum.push(l);
      cyan.push(Math.max(g-r,b-r,(g+b)*.5-r));
      red.push(r-Math.max(g,b));
      yellow.push(Math.min(r,g)-b*.55);
    }
    return {
      lum10:sampledPercentile(lum,.10), lum50:sampledPercentile(lum,.50), lum90:sampledPercentile(lum,.90),
      cyan70:sampledPercentile(cyan,.70), cyan84:sampledPercentile(cyan,.84), cyan93:sampledPercentile(cyan,.93),
      red70:sampledPercentile(red,.70), red88:sampledPercentile(red,.88),
      yellow75:sampledPercentile(yellow,.75), yellow90:sampledPercentile(yellow,.90)
    };
  }

  function adaptiveContrastValue(lum,lo,hi){
    const den=Math.max(12,hi-lo);
    return clamp255((lum-lo)*255/den);
  }

  function connectedComponents(mask,w,h,minArea){
    const seen=new Uint8Array(mask.length), comps=[];
    const stack=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||seen[idx]) continue;
      let sp=0; stack[sp++]=idx; seen[idx]=1;
      let area=0,sumX=0,sumY=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        const ci=stack[--sp], cx=ci%w, cy=(ci/w)|0; area++; sumX+=cx; sumY+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k], ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h) continue;
          const ni=ny*w+nx; if(mask[ni]&&!seen[ni]){seen[ni]=1;stack[sp++]=ni;}
        }
      }
      if(area>=minArea) comps.push({area,cx:sumX/area,cy:sumY/area,minX,maxX,minY,maxY});
    }
    return comps;
  }

  function redRegion(data,w,h){
    const raw=new Uint8Array(w*h),xLo=w*.08,xHi=w*.86,yLo=h*.08,yHi=h*.90;
    const rs=bandAdaptiveStats(data,w,h,Math.floor(xLo),Math.floor(yLo),Math.floor(xHi),Math.floor(yHi),Math.max(2,Math.round(Math.min(w,h)/650)));
    const minRedExcess=Math.max(10,Math.min(38,rs.red88*.24)),minLum=Math.max(32,Math.min(88,rs.lum50*.55));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      if(x<xLo||x>xHi||y<yLo||y>yHi)continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b;
      if((hh<48||hh>326)&&r-Math.max(g,b)>=minRedExcess&&r>g*1.055&&r>b*1.07&&ss>.13&&vv>.25&&lum>=minLum)raw[y*w+x]=1;
    }
    const comps=connectedComponents(raw,w,h,Math.max(80,Math.floor(w*h*.00035))).filter(c=>{
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      return c.area<w*h*.24&&bw>w*.035&&bh>h*.035&&c.cx>w*.18&&c.cx<w*.78&&c.cy>h*.18&&c.cy<h*.82;
    }).sort((a,b)=>b.area-a.area);
    if(!comps.length)throw new Error('Red thermal region not detected.');
    const seed=comps[0],rows=[],widths=[];
    for(let y=seed.minY;y<=seed.maxY;y++){
      let lo=w,hi=-1,n=0;
      for(let x=seed.minX;x<=seed.maxX;x++)if(raw[y*w+x]){lo=Math.min(lo,x);hi=Math.max(hi,x);n++;}
      if(hi>=lo&&n>=Math.max(2,(hi-lo+1)*.055)){rows.push({y,lo,hi});widths.push(hi-lo+1);}
    }
    widths.sort((a,b)=>a-b);const medW=widths[Math.floor(widths.length*.5)]||1;
    const filled=new Uint8Array(w*h);let area=0,sx=0,sy=0,minX=w,maxX=0,minY=h,maxY=0;
    for(const q of rows.filter(q=>(q.hi-q.lo+1)>=Math.max(4,medW*.16))){
      for(let x=q.lo;x<=q.hi;x++){filled[q.y*w+x]=1;area++;sx+=x;sy+=q.y;}
      minX=Math.min(minX,q.lo);maxX=Math.max(maxX,q.hi);minY=Math.min(minY,q.y);maxY=Math.max(maxY,q.y);
    }
    if(area<100)throw new Error('Red thermal region geometry was not stable enough.');
    return {component:{area,cx:sx/area,cy:sy/area,minX,maxX,minY,maxY,rawCx:seed.cx,rawCy:seed.cy},mask:filled,rawMask:raw};
  }

  function crossCenter(data,w,h,red){
    const c=red.component,bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
    const x0=Math.max(0,Math.floor(c.minX+bw*.20)),x1=Math.min(w-1,Math.ceil(c.maxX-bw*.20));
    const y0=Math.max(0,Math.floor(c.minY+bh*.20)),y1=Math.min(h-1,Math.ceil(c.maxY-bh*.20));
    const mask=new Uint8Array(w*h),cs=bandAdaptiveStats(data,w,h,x0,y0,x1+1,y1+1,1);
    const yellowCut=Math.max(12,cs.yellow90*.46),brightCut=Math.max(52,cs.lum50*.72);
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      if(!red.mask[y*w+x])continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],[hh,ss,vv]=rgbToHSV(r,g,b),lum=.2126*r+.7152*g+.0722*b,ys=Math.min(r,g)-b*.55;
      if(hh>=25&&hh<=125&&ss>.12&&vv>.32&&lum>=brightCut&&ys>=yellowCut)mask[y*w+x]=1;
    }
    const comps=connectedComponents(mask,w,h,3);let best=null;
    for(const q of comps){
      const qw=q.maxX-q.minX+1,qh=q.maxY-q.minY+1;if(qw<5||qh<5||qw>bw*.42||qh>bh*.42)continue;
      const band=Math.max(1,Math.round(Math.min(w,h)*.0025)),cx=Math.round(q.cx),cy=Math.round(q.cy);let hl=0,hr=0,vu=0,vd=0;
      for(let x=q.minX;x<=q.maxX;x++){let hit=0;for(let y=Math.max(q.minY,cy-band);y<=Math.min(q.maxY,cy+band);y++)hit+=mask[y*w+x];if(hit){if(x<cx)hl++;else if(x>cx)hr++;}}
      for(let y=q.minY;y<=q.maxY;y++){let hit=0;for(let x=Math.max(q.minX,cx-band);x<=Math.min(q.maxX,cx+band);x++)hit+=mask[y*w+x];if(hit){if(y<cy)vu++;else if(y>cy)vd++;}}
      const minArm=Math.max(2,Math.round(Math.min(qw,qh)*.15));if(hl<minArm||hr<minArm||vu<minArm||vd<minArm)continue;
      const aspect=Math.min(qw,qh)/Math.max(qw,qh),dist=Math.hypot(q.cx-c.cx,q.cy-c.cy)/Math.max(1,Math.min(bw,bh));
      const balance=Math.min(hl,hr)/Math.max(hl,hr)*.5+Math.min(vu,vd)/Math.max(vu,vd)*.5,score=aspect*.28+balance*.42+Math.max(0,1-dist/.38)*.30;
      if(!best||score>best.score)best={q,score,cx,cy};
    }
    if(!best||best.score<.50)throw new Error('Cross center not shape-confirmed.');
    return {x:best.cx,y:best.cy,rawX:best.q.cx,rawY:best.q.cy,pixelCount:best.q.area,shapeScore:best.score};
  }

  function localContrastGray(data,w,h,x0,y0,x1,y1){
    const pts=[]; let mean=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4; const r=data[i],g=data[i+1],b=data[i+2]; const lum=.2126*r+.7152*g+.0722*b;
      mean+=lum;n++;pts.push([x,y,lum,r,g,b]);
    }
    mean/=Math.max(1,n); let variance=0; for(const p of pts)variance+=(p[2]-mean)*(p[2]-mean); const sd=Math.sqrt(variance/Math.max(1,n));
    return {pts,mean,sd};
  }

  function detectOrientation(data,w,h){
    // Use connected marker components only. The previous bounding-box method could include the panel border,
    // causing a real ^ marker to be misclassified as >.
    const x0=Math.floor(w*.875),x1=Math.floor(w*.992),y0=Math.floor(h*.855),y1=Math.floor(h*.992);
    const rw=x1-x0,rh=y1-y0, m=new Uint8Array(rw*rh);
    const lc=localContrastGray(data,w,h,x0,y0,x1,y1);
    const os=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const cyanCut=Math.max(3,os.cyan84*.58);
    const lumCut=Math.max(os.lum50+3,os.lum90*.58);
    for(const p of lc.pts){
      const [x,y,lum,r,g,b]=p;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const cyan=cyanScore>=cyanCut;
      const bright=lum>Math.max(lumCut,lc.mean+Math.max(3,lc.sd*.22));
      if(cyan&&bright) m[(y-y0)*rw+(x-x0)]=1;
    }
    const comps=connectedComponents(m,rw,rh,2)
      .filter(c=>c.area<rw*rh*.14 && (c.maxX-c.minX)<rw*.72 && (c.maxY-c.minY)<rh*.72)
      .sort((a,b)=>b.area-a.area);
    if(!comps.length) return {direction:'up',confidence:.30,reason:'marker low contrast; defaulted to up'};

    // Prefer a compact glyph in the lower/right half, not long frame/text fragments.
    let best=null,bestScore=-1;
    for(const c of comps.slice(0,12)){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      if(ww<2||hh<2) continue;
      const compact=c.area/(ww*hh);
      const score=c.area*(.65+.35*compact) - Math.max(0,ww-rw*.45)*4 - Math.max(0,hh-rh*.45)*4;
      if(score>bestScore){bestScore=score;best=c;}
    }
    if(!best) return {direction:'up',confidence:.30,reason:'marker ambiguous; defaulted to up'};
    const width=best.maxX-best.minX+1,height=best.maxY-best.minY+1;
    const ratio=width/Math.max(1,height);
    // ^ is characteristically wider; > is characteristically taller. Require strong evidence for Right.
    const direction=ratio>=.82?'up':'right';
    const conf=Math.min(.94,.52+Math.abs(Math.log(Math.max(.15,ratio)))*.30);
    return {direction,confidence:conf,bbox:{minX:best.minX+x0,maxX:best.maxX+x0,minY:best.minY+y0,maxY:best.maxY+y0},width,height,ratio};
  }

  function percentile(arr,p){ const a=Array.from(arr).sort((a,b)=>a-b); return a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))]; }

  function findSixRegularTicks(cands,h){
    let best=null;
    const minGap=h*.018,maxGap=h*.095;
    for(let a=0;a<cands.length;a++) for(let b=a+1;b<cands.length;b++){
      const span=cands[b].y-cands[a].y;
      for(let steps=1;steps<=5;steps++){
        const gap=span/steps;if(gap<minGap||gap>maxGap)continue;
        for(let apos=0;apos<=5-steps;apos++){
          const first=cands[a].y-apos*gap,selected=[];let err=0,strength=0,ok=true,lastIdx=-1;
          const tol=Math.max(4,gap*.14);
          for(let k=0;k<6;k++){
            const target=first+k*gap;let bi=-1,be=1e9;
            for(let j=lastIdx+1;j<cands.length;j++){
              const e=Math.abs(cands[j].y-target);if(e<be){be=e;bi=j;}if(cands[j].y>target+tol)break;
            }
            if(bi<0||be>tol){ok=false;break;}selected.push(cands[bi]);lastIdx=bi;err+=be/gap;strength+=cands[bi].score;
          }
          if(!ok)continue;
          const ys=selected.map(t=>t.y),gaps=[];for(let k=0;k<5;k++)gaps.push(ys[k+1]-ys[k]);
          const mean=gaps.reduce((x,y)=>x+y,0)/5,maxDev=Math.max(...gaps.map(g=>Math.abs(g-mean)/mean));
          const fullSpan=ys[5]-ys[0];if(maxDev>.15||fullSpan<h*.09||fullSpan>h*.48)continue;
          const quality=130-err*20-maxDev*190+Math.min(40,strength*.18);
          if(!best||quality>best.quality)best={quality,selected,gaps,fullSpan,maxDev};
        }
      }
    }
    return best;
  }

  function detectScale(data,w,h){
    // First locate the vertical ruler spine, then search ONLY for six ticks attached to that spine.
    // This avoids using text baselines and other horizontal UI edges as a ruler.
    const sx0=Math.floor(w*.78),sx1=Math.floor(w*.965),y0=Math.floor(h*.18),y1=Math.floor(h*.84);
    const lum=new Float32Array(w*h);
    // Scale profile: grayscale + robust contrast stretch. No color enhancement is
    // used here because the ruler is a geometric edge problem.
    const ss=bandAdaptiveStats(data,w,h,sx0,y0,sx1,y1,Math.max(2,Math.round(Math.min(w,h)/700)));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4,rawLum=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];
      lum[y*w+x]=adaptiveContrastValue(rawLum,ss.lum10,ss.lum90);
    }
    const xScores=[];
    for(let x=sx0+2;x<sx1-2;x++){
      let s=0,n=0;
      for(let y=y0;y<y1;y+=2){
        const edge=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
        const verticalSmooth=Math.abs(lum[(Math.min(h-1,y+1))*w+x]-lum[(Math.max(0,y-1))*w+x]);
        s+=Math.max(0,edge-verticalSmooth*.22);n++;
      }
      xScores.push({x,score:s/Math.max(1,n)});
    }
    xScores.sort((a,b)=>b.score-a.score);
    const spineCandidates=xScores.slice(0,10);
    let globalBest=null;
    for(const sp of spineCandidates){
      const left=Math.max(0,Math.floor(sp.x-w*.075)),right=Math.min(w-1,Math.floor(sp.x+w*.012));
      const scores=[];
      for(let y=y0+2;y<y1-2;y++){
        let s=0,n=0;
        for(let x=left+1;x<right-1;x++){
          const dv=Math.abs(lum[(y+1)*w+x]-lum[(y-1)*w+x]);
          const dh=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
          // horizontal tick edge near the detected vertical spine
          s+=Math.max(0,dv-dh*.28);n++;
        }
        scores.push({y,score:s/Math.max(1,n)});
      }
      const vals=scores.map(q=>q.score),th=percentile(vals,.79),raw=[];
      for(let i=3;i<scores.length-3;i++){
        if(scores[i].score<th)continue;let mx=true;for(let k=-3;k<=3;k++)if(scores[i+k].score>scores[i].score){mx=false;break;}
        if(mx)raw.push(scores[i]);
      }
      const clustered=[],mergeDist=Math.max(4,Math.round(h*.007));
      for(const q of raw){const last=clustered[clustered.length-1];if(last&&q.y-last.y<=mergeDist){const wt=last.weight+q.score;last.y=(last.y*last.weight+q.y*q.score)/wt;last.score=Math.max(last.score,q.score);last.weight=wt;}else clustered.push({y:q.y,score:q.score,weight:q.score});}
      const best=findSixRegularTicks(clustered,h);
      if(best){
        // Prefer a regular set and a strong continuous spine.
        best.quality+=Math.min(25,sp.score*.8);best.spineX=sp.x;best.candidates=clustered;
        if(!globalBest||best.quality>globalBest.quality)globalBest=best;
      }
    }
    if(!globalBest)return {pxPerMm:null,confidence:.12,selectedTicks:[],reason:'5 mm ruler spine + six ticks not reliably detected'};
    const ticks=globalBest.selected.map(p=>p.y),pxPerMm=(ticks[5]-ticks[0])/5;
    const regularity=Math.max(0,1-globalBest.maxDev/.15),confidence=Math.min(.98,.64+.32*regularity);
    return {pxPerMm,confidence,selectedTicks:ticks.map(Math.round),fullSpanPx:ticks[5]-ticks[0],rulerMm:5,intervalCount:5,tickCount:6,gaps:globalBest.gaps,spineX:globalBest.spineX};
  }

  // Tiny offline glyph templates for the edge annotations. Recognition is deliberately restricted to
  // the six expected anatomical letters, and opposite-side consistency is used to reject false positives.
  const GLYPHS={
    R:['11110','10001','10001','11110','10100','10010','10001'],
    L:['10000','10000','10000','10000','10000','10000','11111'],
    A:['01110','10001','10001','11111','10001','10001','10001'],
    P:['11110','10001','10001','11110','10000','10000','10000'],
    S:['01111','10000','10000','01110','00001','00001','11110'],
    I:['11111','00100','00100','00100','00100','00100','11111']
  };
  function sampleGlyph(data,w,h,roi){
    const [x0,y0,x1,y1]=roi;const pts=[];
    const gs=bandAdaptiveStats(data,w,h,x0,y0,x1,y1,1);
    const cyanCut=Math.max(2,gs.cyan70*.62),lumCut=Math.max(32,gs.lum50*.70);
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const cyan=cyanScore>=cyanCut && lum>=lumCut && (g+b)>r*1.48;
      if(cyan)pts.push([x,y]);
    }
    if(pts.length<3)return null;
    let minX=Math.min(...pts.map(p=>p[0])),maxX=Math.max(...pts.map(p=>p[0])),minY=Math.min(...pts.map(p=>p[1])),maxY=Math.max(...pts.map(p=>p[1]));
    // Ignore very large UI fragments; keep the compact component-ish center zone.
    if(maxX-minX> (x1-x0)*.75 || maxY-minY>(y1-y0)*.75)return null;
    const grid=[];
    for(let gy=0;gy<7;gy++){
      let row='';for(let gx=0;gx<5;gx++){
        const ax=minX+(maxX-minX+1)*gx/5,bx=minX+(maxX-minX+1)*(gx+1)/5;
        const ay=minY+(maxY-minY+1)*gy/7,by=minY+(maxY-minY+1)*(gy+1)/7;
        let on=0,tot=0;
        for(let y=Math.floor(ay);y<Math.ceil(by);y++)for(let x=Math.floor(ax);x<Math.ceil(bx);x++){
          if(x<0||y<0||x>=w||y>=h)continue;tot++;const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
          const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
          if(cyanScore>=cyanCut&&lum>=lumCut&&(g+b)>r*1.48)on++;
        }
        row+=on/Math.max(1,tot)>.16?'1':'0';
      }grid.push(row);
    }
    let best=null;
    for(const [label,t] of Object.entries(GLYPHS)){
      let same=0;for(let y=0;y<7;y++)for(let x=0;x<5;x++)if(grid[y][x]===t[y][x])same++;
      const score=same/35;if(!best||score>best.score)best={label,score,grid,bbox:{minX,maxX,minY,maxY}};
    }
    return best;
  }
  function classifyGlyphComponent(data,w,h,bbox){
    // Expand only around one compact connected component.  This is intentionally
    // different from the old whole-ROI sampler which mixed anatomy letters with
    // nearby UI text and often returned SI/AP or no drawable box.
    const padX=Math.max(2,Math.round((bbox.maxX-bbox.minX+1)*.45));
    const padY=Math.max(2,Math.round((bbox.maxY-bbox.minY+1)*.35));
    const roi=[Math.max(0,bbox.minX-padX),Math.max(0,bbox.minY-padY),Math.min(w,bbox.maxX+padX+1),Math.min(h,bbox.maxY+padY+1)];
    const g=sampleGlyph(data,w,h,roi);
    if(!g) return null;
    // Preserve the actual component position for the yellow rectangle.  The
    // classifier may use a padded ROI, but the overlay must surround the letter.
    g.bbox={minX:bbox.minX,maxX:bbox.maxX,minY:bbox.minY,maxY:bbox.maxY};
    return g;
  }

  function anatomyCandidates(data,w,h,side){
    // v0.1.9: anatomy letters live in narrow vendor-defined edge zones of the
    // Thermal viewport.  Do NOT scan the whole edge: that previously captured
    // patient ID, time, temperature text and ruler marks.
    //
    // The zones intentionally allow perspective/cropping, but they are anchored
    // to where the actual single-letter annotations appear in the supplied UI:
    //   top/bottom: left-of-centre band
    //   left/right: mid-height band
    let x0=0,y0=0,x1=w,y1=h;
    if(side==='top'){
      x0=Math.floor(w*.14); x1=Math.floor(w*.42);
      y0=Math.floor(h*.025); y1=Math.floor(h*.155);
    } else if(side==='bottom'){
      x0=Math.floor(w*.14); x1=Math.floor(w*.42);
      y0=Math.floor(h*.80); y1=Math.floor(h*.965);
    } else if(side==='left'){
      x0=Math.floor(w*.025); x1=Math.floor(w*.165);
      y0=Math.floor(h*.34); y1=Math.floor(h*.68);
    } else {
      x0=Math.floor(w*.835); x1=Math.floor(w*.975);
      y0=Math.floor(h*.34); y1=Math.floor(h*.68);
    }

    const rw=x1-x0,rh=y1-y0,mask=new Uint8Array(rw*rh);
    const as=bandAdaptiveStats(
      data,w,h,x0,y0,x1,y1,
      Math.max(1,Math.round(Math.min(w,h)/1200))
    );
    const cyanCut=Math.max(1.5,Math.min(28,as.cyan84*.48));
    const lumCut=Math.max(30,Math.min(118,as.lum50*.66));

    for(let y=y0;y<y1;y++) for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const lum=.2126*r+.7152*g+.0722*b;
      const cyanScore=Math.max(g-r,b-r,(g+b)*.5-r);
      const cyanish=lum>=lumCut && cyanScore>=cyanCut && (g+b)>r*1.42;
      if(cyanish) mask[(y-y0)*rw+(x-x0)]=1;
    }

    // Join only one-pixel LCD/moiré gaps.  Avoid expanding text into large blobs.
    const joined=new Uint8Array(mask);
    for(let yy=1;yy<rh-1;yy++) for(let xx=1;xx<rw-1;xx++){
      if(mask[yy*rw+xx]) continue;
      const hbridge=mask[yy*rw+xx-1]&&mask[yy*rw+xx+1];
      const vbridge=mask[(yy-1)*rw+xx]&&mask[(yy+1)*rw+xx];
      if(hbridge||vbridge) joined[yy*rw+xx]=1;
    }

    const comps=connectedComponents(joined,rw,rh,2);
    const expected=(side==='left'||side==='right')?['R','L']:['A','P','S','I'];
    const candidates=[];

    for(const c of comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      // Single annotation glyph only: compact, small, isolated.
      if(bw<2||bh<3) continue;
      if(bw>w*.035||bh>h*.050) continue;
      const aspect=bw/Math.max(1,bh);
      if(aspect<.16||aspect>1.45) continue;
      if(c.area<2||c.area>bw*bh*.90) continue;

      const box={
        minX:c.minX+x0,maxX:c.maxX+x0,
        minY:c.minY+y0,maxY:c.maxY+y0
      };
      const g=classifyGlyphComponent(data,w,h,box);
      if(!g||!expected.includes(g.label)) continue;

      const cx=(box.minX+box.maxX)/2,cy=(box.minY+box.maxY)/2;
      const edgeDistance = side==='left' ? cx/w :
                           side==='right' ? 1-cx/w :
                           side==='top' ? cy/h : 1-cy/h;

      // Strongly favour a small isolated component near the relevant viewport edge.
      const compact=Math.min(1,c.area/Math.max(1,bw*bh*.28));
      const edgeScore=Math.max(0,1-edgeDistance/.19);
      const score=g.score*.78 + edgeScore*.16 + compact*.06;
      candidates.push({...g,side,scoreRaw:g.score,score,cx,cy});
    }
    candidates.sort((a,b)=>b.score-a.score);
    return candidates;
  }

  function detectAnatomy(data,w,h){
    const all={};
    for(const side of ['top','bottom','left','right']){
      all[side]=anatomyCandidates(data,w,h,side);
    }

    function bestHorizontalPair(){
      let best=null;
      for(const a of all.left.slice(0,12)){
        for(const b of all.right.slice(0,12)){
          if(!((a.label==='R'&&b.label==='L')||(a.label==='L'&&b.label==='R'))) continue;
          // True opposite annotations sit at nearly the same image row.
          const align=Math.abs(a.cy-b.cy)/h;
          if(align>.11) continue;
          const alignScore=Math.max(0,1-align/.11);
          const conf=Math.min(a.scoreRaw,b.scoreRaw);
          const pairScore=a.score+b.score+alignScore*.55+conf*.45;
          if(!best||pairScore>best.pairScore){
            best={a,b,pairScore,conf,alignScore};
          }
        }
      }
      return best;
    }

    function bestVerticalPair(){
      let best=null;
      const valid=[
        ['A','P','AP','A','P'],
        ['S','I','SI','S','I']
      ];
      for(const a of all.top.slice(0,12)){
        for(const b of all.bottom.slice(0,12)){
          for(const [u,v,axis,pos,neg] of valid){
            if(!((a.label===u&&b.label===v)||(a.label===v&&b.label===u))) continue;
            // Top and bottom letters use the same vendor x-position.
            const align=Math.abs(a.cx-b.cx)/w;
            if(align>.12) continue;
            const alignScore=Math.max(0,1-align/.12);
            const conf=Math.min(a.scoreRaw,b.scoreRaw);
            const pairScore=a.score+b.score+alignScore*.55+conf*.45;
            if(!best||pairScore>best.pairScore){
              best={a,b,axis,pos,neg,pairScore,conf,alignScore};
            }
          }
        }
      }
      return best;
    }

    const hp=bestHorizontalPair();
    const vp=bestVerticalPair();

    // Only validated opposite-edge pairs are exposed for yellow annotation boxes.
    // This prevents false rectangles around patient ID/time/scale text.
    const edges={top:null,bottom:null,left:null,right:null};
    let horizontal=null,vertical=null;

    if(hp){
      edges.left=hp.a; edges.right=hp.b;
      horizontal={
        axis:'RL',
        positiveSide:hp.a.label==='R'?'left':'right',
        positiveLabel:'R',negativeLabel:'L',
        confidence:Math.min(.99,.46+hp.conf*.42+hp.alignScore*.12)
      };
    }

    if(vp){
      edges.top=vp.a; edges.bottom=vp.b;
      vertical={
        axis:vp.axis,
        positiveSide:vp.a.label===vp.pos?'top':'bottom',
        positiveLabel:vp.pos,negativeLabel:vp.neg,
        confidence:Math.min(.99,.46+vp.conf*.42+vp.alignScore*.12)
      };
    }

    return {
      edges,
      candidates:all,
      horizontal,
      vertical,
      detectedPairCount:(hp?1:0)+(vp?1:0)
    };
  }

  function solve3x3(A,b){
    const m=[
      [A[0][0],A[0][1],A[0][2],b[0]],
      [A[1][0],A[1][1],A[1][2],b[1]],
      [A[2][0],A[2][1],A[2][2],b[2]]
    ];
    for(let c=0;c<3;c++){
      let p=c;
      for(let r=c+1;r<3;r++) if(Math.abs(m[r][c])>Math.abs(m[p][c])) p=r;
      if(Math.abs(m[p][c])<1e-9) return null;
      if(p!==c){const t=m[p];m[p]=m[c];m[c]=t;}
      const d=m[c][c];
      for(let j=c;j<4;j++)m[c][j]/=d;
      for(let r=0;r<3;r++){
        if(r===c)continue;
        const f=m[r][c];
        for(let j=c;j<4;j++)m[r][j]-=f*m[c][j];
      }
    }
    return [m[0][3],m[1][3],m[2][3]];
  }

  function fitCircle(points,seedX,seedY){
    if(points.length<24)return null;
    let pts=points.slice();
    let result=null;
    for(let pass=0;pass<3;pass++){
      let Sxx=0,Sxy=0,Sx=0,Syy=0,Sy=0,N=0,Bx=0,By=0,B1=0;
      for(const p of pts){
        const x=p[0]-seedX,y=p[1]-seedY,z=-(x*x+y*y);
        Sxx+=x*x;Sxy+=x*y;Sx+=x;Syy+=y*y;Sy+=y;N++;
        Bx+=x*z;By+=y*z;B1+=z;
      }
      const sol=solve3x3([[Sxx,Sxy,Sx],[Sxy,Syy,Sy],[Sx,Sy,N]],[Bx,By,B1]);
      if(!sol)return null;
      const D=sol[0],E=sol[1],F=sol[2];
      const cx=seedX-D/2,cy=seedY-E/2;
      const rr=(D*D+E*E)/4-F;
      if(!(rr>0))return null;
      const radius=Math.sqrt(rr);
      const residuals=pts.map(p=>Math.abs(Math.hypot(p[0]-cx,p[1]-cy)-radius)).sort((a,b)=>a-b);
      const med=residuals[Math.floor(residuals.length*.5)]||0;
      const cut=Math.max(2.5,med*2.8);
      result={x:cx,y:cy,radius,residual:med,pointCount:pts.length};
      if(pass<2){
        pts=pts.filter(p=>Math.abs(Math.hypot(p[0]-cx,p[1]-cy)-radius)<=cut);
        if(pts.length<24)break;
      }
    }
    if(!result)return null;
    const bins=new Set();
    for(const p of pts){
      let a=Math.atan2(p[1]-result.y,p[0]-result.x);
      if(a<0)a+=Math.PI*2;
      bins.add(Math.floor(a/(Math.PI*2)*24));
    }
    result.coverage=bins.size/24;
    result.confidence=Math.max(0,Math.min(1,
      result.coverage*.58+
      Math.max(0,1-result.residual/Math.max(3,result.radius*.035))*.30+
      Math.min(1,result.pointCount/350)*.12
    ));
    return result;
  }

  function detectColoredCircle(data,w,h,red,kind){
    const rc=red.component,cx0=rc.cx,cy0=rc.cy,minDim=Math.min(w,h);
    const redW=Math.max(1,rc.maxX-rc.minX+1),redH=Math.max(1,rc.maxY-rc.minY+1);
    const redSize=Math.max(redW,redH);

    // The reference ring surrounds the hotspot.  Constrain radius from the actual
    // hotspot size instead of the whole photograph; this rejects UI text, ruler
    // ticks and the very large false circles seen in v0.1.11.
    const minR=Math.max(minDim*.055,redSize*.58);
    const maxR=Math.min(minDim*.34,redSize*1.85);
    if(maxR<=minR)return null;

    const pts=[];
    const roiR=maxR*1.18;
    const x0=Math.max(0,Math.floor(cx0-roiR)),x1=Math.min(w,Math.ceil(cx0+roiR));
    const y0=Math.max(0,Math.floor(cy0-roiR)),y1=Math.min(h,Math.ceil(cy0+roiR));
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const d=Math.hypot(x-cx0,y-cy0);
      if(d<minR*.78||d>maxR*1.12)continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b);
      let ok=false;
      if(kind==='green'){
        const ex=g-Math.max(r,b);
        ok=hh>=65&&hh<=165&&ss>.16&&vv>.26&&ex>4&&g>r*1.02;
      }else{
        const ex=Math.min(r,g)-b;
        ok=hh>=28&&hh<=72&&ss>.20&&vv>.35&&ex>18&&r>100&&g>85;
      }
      if(ok)pts.push([x,y]);
    }
    if(pts.length<28)return null;
    const fit=fitCircle(pts,cx0,cy0);
    if(!fit)return null;
    if(fit.radius<minR||fit.radius>maxR)return null;

    // A valid target ring must remain close to the hotspot centre.
    const centerShift=Math.hypot(fit.x-cx0,fit.y-cy0);
    const maxShift=Math.max(minDim*.025,redSize*.52);
    if(centerShift>maxShift)return null;

    // Re-evaluate only pixels close to the fitted circumference.  Require evidence
    // around multiple sides of the circle rather than a curved UI fragment.
    const band=Math.max(3,Math.min(fit.radius*.075,12));
    const bins=new Uint16Array(36);
    let nearCount=0;
    for(const p of pts){
      const rr=Math.hypot(p[0]-fit.x,p[1]-fit.y);
      if(Math.abs(rr-fit.radius)>band)continue;
      let a=Math.atan2(p[1]-fit.y,p[0]-fit.x);if(a<0)a+=Math.PI*2;
      bins[Math.min(35,Math.floor(a/(Math.PI*2)*36))]++;nearCount++;
    }
    const occupied=[];for(let i=0;i<36;i++)if(bins[i]>0)occupied.push(i);
    const evidenceCoverage=occupied.length/36;
    let quadrants=0;
    for(let q=0;q<4;q++){let has=false;for(let i=q*9;i<(q+1)*9;i++)if(bins[i]){has=true;break;}if(has)quadrants++;}
    if(evidenceCoverage<.34||quadrants<3||nearCount<24)return null;

    // The hotspot centroid should lie well inside the reference circle.
    if(Math.hypot(cx0-fit.x,cy0-fit.y)>fit.radius*.62)return null;

    const radiusRatio=fit.radius/redSize;
    const ratioScore=Math.max(0,1-Math.abs(radiusRatio-1.10)/.95);
    const adjustedConfidence=Math.max(0,Math.min(1,
      fit.confidence*.48+evidenceCoverage*.30+(quadrants/4)*.12+ratioScore*.10
    ));
    if(adjustedConfidence<.52)return null;

    // Keep a small set of actual circumference samples for overlay/debug.
    const samples=[];
    for(let i=0;i<36;i++){
      if(!bins[i])continue;
      const a=(i+.5)/36*Math.PI*2;
      samples.push([fit.x+Math.cos(a)*fit.radius,fit.y+Math.sin(a)*fit.radius]);
    }
    return {
      type:kind+'-circle',
      x:fit.x,y:fit.y,radius:fit.radius,
      confidence:adjustedConfidence,coverage:evidenceCoverage,
      residual:fit.residual,pointCount:nearCount,quadrants,
      centerShift,radiusRatio,samples
    };
  }

  function detectGreenSpot(data,w,h,red,circleHint){
    const mask=new Uint8Array(w*h),minDim=Math.min(w,h);
    const rcx=red.component.cx,rcy=red.component.cy;
    const anchorX=circleHint&&isFinite(circleHint.x)?circleHint.x:rcx;
    const anchorY=circleHint&&isFinite(circleHint.y)?circleHint.y:rcy;

    // Green spot is allowed only in the measurement ROI around the hotspot/reference.
    // UI areas (left toolbar, right ruler, top/bottom chrome) are excluded by geometry.
    const roiHalf=Math.min(minDim*.18,Math.max(red.component.maxX-red.component.minX,red.component.maxY-red.component.minY)*.55);
    const x0=Math.max(Math.floor(w*.16),Math.floor(anchorX-roiHalf));
    const x1=Math.min(Math.floor(w*.82),Math.ceil(anchorX+roiHalf));
    const y0=Math.max(Math.floor(h*.16),Math.floor(anchorY-roiHalf));
    const y1=Math.min(Math.floor(h*.84),Math.ceil(anchorY+roiHalf));

    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,ss,vv]=rgbToHSV(r,g,b);
      const ex=g-Math.max(r,b);
      if(hh>=65&&hh<=165&&ss>.18&&vv>.28&&ex>7&&g>r*1.035)mask[y*w+x]=1;
    }

    const comps=connectedComponents(mask,w,h,3);
    let best=null;
    for(const c of comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1,maxDim=Math.max(bw,bh),minD=Math.min(bw,bh);
      if(maxDim<2||maxDim>minDim*.038||minD<2)continue;

      const distToAnchor=Math.hypot(c.cx-anchorX,c.cy-anchorY);
      const distToRed=Math.hypot(c.cx-rcx,c.cy-rcy);

      // A true green spot must be close to the hotspot/circle centre.
      if(distToAnchor>minDim*.095)continue;
      if(distToRed>minDim*.14)continue;

      const compact=c.area/Math.max(1,bw*bh),round=minD/maxDim;
      if(compact<.18||round<.42)continue;

      const nearScore=Math.max(0,1-distToAnchor/(minDim*.095));
      const sizeScore=Math.max(0,1-maxDim/(minDim*.038));
      const score=nearScore*.50+round*.22+Math.min(1,compact)*.18+sizeScore*.10;

      if(!best||score>best.score){
        best={
          type:'green-spot',x:c.cx,y:c.cy,
          confidence:Math.min(.92,.44+score*.48),
          score,
          bbox:{minX:c.minX,minY:c.minY,maxX:c.maxX,maxY:c.maxY}
        };
      }
    }

    // Reject weak spots instead of forcing a result.
    if(!best||best.confidence<.64)return null;
    return best;
  }

  function referenceGeometryOK(ref,red,w,h){
    if(!ref)return false;
    const minDim=Math.min(w,h);
    const d=Math.hypot(ref.x-red.component.cx,ref.y-red.component.cy);

    if(ref.type==='cross'){
      // Cross should be inside/near the hotspot.
      return d<=minDim*.16 && (ref.shapeScore||0)>=.50;
    }

    if(ref.type==='green-circle'||ref.type==='yellow-circle'){
      if(!(ref.radius>0))return false;
      // Circle centre must stay near red centroid, and red centroid must lie inside the fitted circle.
      if(d>Math.min(ref.radius*.34,minDim*.14))return false;
      if(d>=ref.radius*.72)return false;
      if((ref.coverage||0)<.34)return false;
      if((ref.confidence||0)<.52)return false;
      return true;
    }

    if(ref.type==='green-spot'){
      return d<=minDim*.14 && (ref.confidence||0)>=.64;
    }

    return false;
  }

  function chooseReference(data,w,h,red,cross){
    // Priority is fixed, but every candidate must pass geometry/confidence validation.
    if(cross){
      const c={type:'cross',x:cross.x,y:cross.y,confidence:Math.min(.98,.68+(cross.shapeScore||0)*.30),shapeScore:cross.shapeScore||0};
      if(referenceGeometryOK(c,red,w,h))return c;
    }

    const greenCircle=detectColoredCircle(data,w,h,red,'green');
    const yellowCircle=detectColoredCircle(data,w,h,red,'yellow');

    const validCircles=[greenCircle,yellowCircle].filter(c=>referenceGeometryOK(c,red,w,h));
    if(validCircles.length){
      validCircles.sort((a,b)=>(b.confidence||0)-(a.confidence||0));
      return validCircles[0];
    }

    const circleHint=validCircles[0]||greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpot(data,w,h,red,circleHint);
    if(referenceGeometryOK(greenSpot,red,w,h))return greenSpot;

    // Safety behaviour: no forced measurement from an unconfirmed reference.
    return null;
  }

  function analyze(imageData,w,h,overrides){
    overrides=overrides||{};
    const red=redRegion(imageData.data,w,h);

    let cross=null;
    try{cross=crossCenter(imageData.data,w,h,red);}catch(_e){cross=null;}

    const reference=chooseReference(imageData.data,w,h,red,cross);
    const greenCircle=detectColoredCircle(imageData.data,w,h,red,'green');
    const yellowCircle=detectColoredCircle(imageData.data,w,h,red,'yellow');
    const circleHint=greenCircle||yellowCircle||null;
    const greenSpot=detectGreenSpot(imageData.data,w,h,red,circleHint);
    const referenceConfirmed=!!reference;

    const ori=detectOrientation(imageData.data,w,h);
    const scale=detectScale(imageData.data,w,h);
    const anatomy=detectAnatomy(imageData.data,w,h);
    const direction=overrides.direction||ori.direction;
    const pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3)throw new Error('5 mm scale could not be calibrated automatically. Tap the top and bottom ruler ticks.');

    const dxPx=referenceConfirmed ? red.component.cx-reference.x : NaN;
    const dyPx=referenceConfirmed ? red.component.cy-reference.y : NaN;

    function componentResult(screenAxis,rawPx,axis){
      let signedPx=rawPx,positiveLabel='?',negativeLabel='?',axisKnown=false,axisName=screenAxis==='horizontal'?'H':'V';
      if(axis){
        axisKnown=true;
        axisName=axis.axis;
        positiveLabel=axis.positiveLabel;
        negativeLabel=axis.negativeLabel;
        const positiveScreenSign=(axis.positiveSide==='right'||axis.positiveSide==='bottom')?1:-1;
        signedPx=rawPx*positiveScreenSign;
      }
      const signedMm=Number.isFinite(signedPx)?signedPx/pxPerMm:NaN;
      return {screenAxis,axis:axisName,axisKnown,rawPx,signedPx,signedMm,positiveLabel,negativeLabel,valid:Number.isFinite(signedMm)};
    }

    const horizontal=componentResult('horizontal',dxPx,anatomy.horizontal);
    const vertical=componentResult('vertical',dyPx,anatomy.vertical);

    const finalComponent=direction==='up'?horizontal:vertical;
    const markerPerpendicular=direction==='up'?'horizontal':'vertical';

    let confidence=referenceConfirmed?Math.max(0,Math.min(1,
      (scale.confidence||.3)*.35+
      (reference.confidence||.5)*.40+
      (ori.confidence||.3)*.15+
      (finalComponent.axisKnown?.90:.35)*.10
    )):0;

    return {
      red,reference,referenceConfirmed,needsAttention:!referenceConfirmed,cross,greenCircle,yellowCircle,greenSpot,
      orientation:ori,direction,scale,anatomy,pxPerMm,
      horizontal,vertical,
      finalComponent,
      markerPerpendicular,
      measurementAxis:finalComponent.axis,
      screenAxis:finalComponent.screenAxis,
      signedMm:finalComponent.signedMm,
      signedPx:finalComponent.signedPx,
      axisKnown:finalComponent.axisKnown,
      positiveLabel:finalComponent.positiveLabel,
      negativeLabel:finalComponent.negativeLabel,
      confidence,
      processing:{
        red:'geometric hotspot centroid',
        referencePriority:'cross > green/yellow circle fit > green spot',
        circle:'hotspot-constrained circle fit + angular evidence validation',
        anatomy:'validated opposite-edge pair (RL/AP/SI)',
        final:'marker-perpendicular component'
      }
    };
  }

  global.LocAccCore={analyze,redRegion,crossCenter,detectColoredCircle,detectGreenSpot,chooseReference,detectOrientation,detectScale,detectAnatomy};
})(window);
