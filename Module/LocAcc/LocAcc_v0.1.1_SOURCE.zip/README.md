# LocAcc v0.1.0

Offline-first iPhone Safari/PWA tool for measuring the perpendicular offset between the thermal red-region geometric centroid and the treatment cross center.

## Measurement rule

- Capture only the square image panel using the on-screen guide.
- Detect the lower-right marker as **Up (↑)** or **Right (→)**.
- Detect the geometric centroid of the largest central red thermal region.
- Detect the yellow/green cross center inside that red region.
- Detect the right-side ruler; adjacent tick marks are treated as **1.0 mm**.
- If marker is **↑**, calculate the **horizontal** centroid-to-cross offset.
- If marker is **→**, calculate the **vertical** centroid-to-cross offset.
- Display the absolute distance rounded to **0.1 mm**.

Automatic results are drawn back onto the captured image. Direction and scale have manual correction controls for low-contrast photos.

## iPhone / offline behavior

The live guide uses `getUserMedia`, so the camera runs inside the web app instead of opening the native camera with no overlay. HTTPS is required for initial camera permission and service-worker installation. After the first successful load, app-shell files are cached and the installed Home Screen PWA can run offline.

## GitHub layout

Recommended repository layout:

```
Module/
  LocAcc/
    LocAcc_v0.1.0_SOURCE.zip
.github/
  workflows/
    build_locacc.yml
```

The workflow finds the newest `Module/LocAcc/LocAcc*_SOURCE.zip`, extracts it, and deploys it as GitHub Pages.


## GitHub Pages deployment path

This package is designed to be deployed at:

`https://<GitHub-user>.github.io/<repository>/Module/LocAcc/`

Keep `manifest.webmanifest`, `sw.js`, JavaScript, CSS and `icons/` beside `index.html`.
All application URLs are relative so the project-repository prefix and `/Module/LocAcc/` are preserved.
The accompanying GitHub Actions workflow expands the latest `LocAcc*_SOURCE.zip` into `_site/Module/LocAcc/`.
