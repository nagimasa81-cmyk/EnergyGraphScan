'use strict';
const $=s=>document.querySelector(s);
const video=$('#video'), guide=$('#guide');
const resultCanvas=$('#resultCanvas'), resultPanel=$('#resultPanel'), cameraPanel=$('#cameraPanel');
let stream=null, sourceCanvas=null, sourceCtx=null, lastImageData=null, lastResult=null;
let overrideDirection=null, overridePxPerMm=null, manualTickPoints=[];

function setStatus(msg){ $('#statusText').textContent=msg||''; }
function setBadge(){ const b=$('#offlineBadge'); b.textContent=navigator.onLine?'Online / offline-ready':'Offline'; }
window.addEventListener('online',setBadge); window.addEventListener('offline',setBadge); setBadge();
fetch('./version.json',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(v=>{if(v&&v.version)$('#versionLabel').textContent=`v${v.version}`;}).catch(()=>{});
async function startCamera(){
  stopCamera();
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:3840},height:{ideal:2160}},audio:false});
    const track=stream.getVideoTracks()[0];
    // Ask Safari for the highest resolution it exposes for this camera. The browser/device
    // may choose a lower supported mode, so we record the actual getSettings() result.
    try{
      if(track&&track.getCapabilities&&track.applyConstraints){
        const cap=track.getCapabilities();
        const maxW=cap.width&&Number.isFinite(cap.width.max)?cap.width.max:null;
        const maxH=cap.height&&Number.isFinite(cap.height.max)?cap.height.max:null;
        if(maxW&&maxH) await track.applyConstraints({width:{ideal:maxW},height:{ideal:maxH}});
      }
    }catch(_e){}
    video.srcObject=stream;await video.play();
    const st=track&&track.getSettings?track.getSettings():{};
    $('#capture').disabled=false;
    setStatus(`Camera ready${st.width&&st.height?` · ${st.width}×${st.height}`:''}. Align the square panel to the guide.`);
  }
  catch(e){setStatus('Camera could not start. Use Photo as a fallback. Camera requires HTTPS and permission.');$('#fileInput').setAttribute('capture','environment');$('#fileInput').click();}
}
function stopCamera(){if(stream){for(const t of stream.getTracks())t.stop();stream=null;}video.srcObject=null;}
function captureGuideFromVideo(){
  if(!video.videoWidth)return;const vr=video.getBoundingClientRect(),gr=guide.getBoundingClientRect(),vw=video.videoWidth,vh=video.videoHeight;
  const scale=Math.max(vr.width/vw,vr.height/vh),renderedW=vw*scale,renderedH=vh*scale,offX=(vr.width-renderedW)/2,offY=(vr.height-renderedH)/2;
  let sx=(gr.left-vr.left-offX)/scale,sy=(gr.top-vr.top-offY)/scale,sw=gr.width/scale,sh=gr.height/scale;
  sx=Math.max(0,Math.min(vw-sw,sx));sy=Math.max(0,Math.min(vh-sh,sy));
  // Preserve as much camera detail as practical. v0.1.6 forced every capture down to
  // 900×900, which made the tiny R/L/A/P/S/I edge annotations only a few pixels high.
  const nativeSide=Math.max(1,Math.floor(Math.min(sw,sh)));
  const out=Math.min(2400,nativeSide);
  sourceCanvas=document.createElement('canvas');sourceCanvas.width=out;sourceCanvas.height=out;sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true});sourceCtx.imageSmoothingEnabled=true;sourceCtx.imageSmoothingQuality='high';sourceCtx.drawImage(video,sx,sy,sw,sh,0,0,out,out);analyzeCurrent();
}
function loadPhoto(file){
  const img=new Image(),url=URL.createObjectURL(file);img.onload=()=>{const side=Math.min(img.naturalWidth,img.naturalHeight),sx=(img.naturalWidth-side)/2,sy=(img.naturalHeight-side)/2,out=Math.min(2400,side);sourceCanvas=document.createElement('canvas');sourceCanvas.width=out;sourceCanvas.height=out;sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true});sourceCtx.drawImage(img,sx,sy,side,side,0,0,out,out);URL.revokeObjectURL(url);analyzeCurrent();};img.src=url;
}
function analyzeCurrent(){
  if(!sourceCanvas)return;lastImageData=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height);
  try{lastResult=LocAccCore.analyze(lastImageData,sourceCanvas.width,sourceCanvas.height,{direction:overrideDirection,pxPerMm:overridePxPerMm});renderResult(lastResult);setStatus(lastResult.axisKnown?'Automatic analysis complete · adaptive image optimization used for each detector.':'Analysis complete · adaptive image optimization used. Anatomy requires a validated opposite-edge pair (RL/AP/SI); unpaired text is ignored.');}
  catch(e){lastResult=null;drawBase();cameraPanel.hidden=true;resultPanel.hidden=false;setStatus(e.message);const ori=LocAccCore.detectOrientation(lastImageData.data,sourceCanvas.width,sourceCanvas.height);const hv=ori.direction==='up'?'H':'V';$('#measurementResult').textContent=`${hv} · —`;$('#confidenceResult').textContent='Low';const sc=LocAccCore.detectScale(lastImageData.data,sourceCanvas.width,sourceCanvas.height);$('#scaleResult').textContent=sc.pxPerMm?`${sc.pxPerMm.toFixed(1)} px/mm`:'Needs manual';}
}
function drawBase(){resultCanvas.width=sourceCanvas.width;resultCanvas.height=sourceCanvas.height;const c=resultCanvas.getContext('2d');c.drawImage(sourceCanvas,0,0);return c;}
function renderResult(r){
  cameraPanel.hidden=true;resultPanel.hidden=false;
  const displayMm=Math.abs(r.signedMm)<0.05?0:r.signedMm;const sign=displayMm>0?'+':displayMm<0?'−':'±';const toward=displayMm>0?r.positiveLabel:displayMm<0?r.negativeLabel:'Centered';
  const axisName=r.measurementAxis;
  const hv=r.screenAxis==='horizontal'?'H':'V';
  const towardText=toward;
  $('#measurementResult').textContent=`${hv} · ${axisName} ${sign}${Math.abs(displayMm).toFixed(1)} mm · ${towardText}`;
  $('#scaleResult').textContent=`${r.pxPerMm.toFixed(1)} px/mm`;
  $('#confidenceResult').textContent=r.confidence>=.72?'High':r.confidence>=.48?'Medium':'Low';
  const c=drawBase(),s=sourceCanvas.width/900;
  c.lineWidth=Math.max(2,3*s);c.font=`${Math.round(20*s)}px -apple-system,sans-serif`;
  c.strokeStyle='#27d3ff';c.beginPath();c.arc(r.red.component.cx,r.red.component.cy,9*s,0,Math.PI*2);c.stroke();c.fillStyle='#27d3ff';c.fillText('Hotspot centroid',r.red.component.cx+13*s,r.red.component.cy-11*s);
  if(r.greenReference){
    c.strokeStyle='#67ff62';c.beginPath();c.arc(r.greenReference.x,r.greenReference.y,10*s,0,Math.PI*2);c.stroke();
    c.fillStyle='#67ff62';c.fillText(r.greenReference.type==='green-point'?'Green point center':'Green circle center',r.greenReference.x+13*s,r.greenReference.y-11*s);
  }
  if(r.cross){
    c.strokeStyle='#fff32e';c.beginPath();c.moveTo(r.cross.x-12*s,r.cross.y);c.lineTo(r.cross.x+12*s,r.cross.y);c.moveTo(r.cross.x,r.cross.y-12*s);c.lineTo(r.cross.x,r.cross.y+12*s);c.stroke();
  }
  c.strokeStyle='#ffffff';c.setLineDash([8*s,5*s]);c.beginPath();if(r.screenAxis==='horizontal'){c.moveTo(r.greenReference.x,r.greenReference.y);c.lineTo(r.red.component.cx,r.greenReference.y);}else{c.moveTo(r.greenReference.x,r.greenReference.y);c.lineTo(r.greenReference.x,r.red.component.cy);}c.stroke();c.setLineDash([]);
  if(r.scale.spineX){c.strokeStyle='rgba(85,210,255,.9)';c.lineWidth=Math.max(1,2*s);c.beginPath();c.moveTo(r.scale.spineX,r.scale.selectedTicks[0]);c.lineTo(r.scale.spineX,r.scale.selectedTicks[5]);c.stroke();}
  c.strokeStyle='rgba(255,190,70,.95)';for(const y of (r.scale.selectedTicks||[])){const x=r.scale.spineX||sourceCanvas.width*.93;c.beginPath();c.moveTo(x-sourceCanvas.width*.055,y);c.lineTo(x+sourceCanvas.width*.012,y);c.stroke();}
  // Highlight the four edge anatomy annotations with yellow rectangles.
  c.save();c.strokeStyle='#ffe600';c.fillStyle='#ffe600';c.lineWidth=Math.max(2,3*s);c.font=`bold ${Math.round(16*s)}px -apple-system,sans-serif`;
  for(const side of ['top','bottom','left','right']){const q=r.anatomy&&r.anatomy.edges?r.anatomy.edges[side]:null;if(!q||!q.bbox)continue;const b=q.bbox,pad=Math.max(5,7*s),x=Math.max(1,b.minX-pad),y=Math.max(1,b.minY-pad),ww=Math.min(sourceCanvas.width-x-1,b.maxX-b.minX+pad*2),hh=Math.min(sourceCanvas.height-y-1,b.maxY-b.minY+pad*2);c.strokeRect(x,y,ww,hh);}
  c.restore();
  c.fillStyle='rgba(0,0,0,.72)';c.fillRect(12*s,12*s,360*s,72*s);c.fillStyle='#fff';c.fillText(`${hv} · ${r.measurementAxis} ${sign}${Math.abs(displayMm).toFixed(1)} mm · ${toward}`,24*s,45*s);c.font=`${Math.round(15*s)}px -apple-system,sans-serif`;c.fillText(`R / S / A = positive`,24*s,69*s);
}
function retake(){resultPanel.hidden=true;cameraPanel.hidden=false;overrideDirection=null;overridePxPerMm=null;manualTickPoints=[];setChipStates();startCamera();}
function setChipStates(){$('#forceAuto').classList.toggle('active',!overrideDirection);$('#forceUp').classList.toggle('active',overrideDirection==='up');$('#forceRight').classList.toggle('active',overrideDirection==='right');$('#autoScale').classList.toggle('active',!overridePxPerMm);$('#manualScale').classList.toggle('active',!!overridePxPerMm);}
function rerun(){if(lastImageData)analyzeCurrent();setChipStates();}
$('#startCamera').onclick=startCamera;$('#capture').onclick=captureGuideFromVideo;$('#choosePhoto').onclick=()=>{$('#fileInput').removeAttribute('capture');$('#fileInput').click();};
$('#fileInput').onchange=e=>{const f=e.target.files&&e.target.files[0];if(f)loadPhoto(f);e.target.value='';};$('#retake').onclick=retake;
$('#forceUp').onclick=()=>{overrideDirection='up';rerun();};$('#forceRight').onclick=()=>{overrideDirection='right';rerun();};$('#forceAuto').onclick=()=>{overrideDirection=null;rerun();};
$('#autoScale').onclick=()=>{overridePxPerMm=null;manualTickPoints=[];$('#manualNote').textContent='';rerun();};
$('#manualScale').onclick=()=>{manualTickPoints=[];overridePxPerMm=null;setChipStates();$('#manualNote').textContent='Tap the TOP tick, then the BOTTOM tick of the complete 5 mm ruler (6 ticks / 5 intervals).';};
resultCanvas.addEventListener('click',e=>{if(!$('#manualNote').textContent.startsWith('Tap the TOP')&&!$('#manualNote').textContent.startsWith('Tap the BOTTOM'))return;const r=resultCanvas.getBoundingClientRect(),y=(e.clientY-r.top)*resultCanvas.height/r.height;manualTickPoints.push(y);if(manualTickPoints.length===1)$('#manualNote').textContent='Tap the BOTTOM tick of the same 5 mm ruler.';else{overridePxPerMm=Math.abs(manualTickPoints[1]-manualTickPoints[0])/5;if(overridePxPerMm<3){manualTickPoints=[];overridePxPerMm=null;$('#manualNote').textContent='The 5 mm span was too small. Tap the TOP tick again.';}else{$('#manualNote').textContent=`Manual 5 mm calibration: ${overridePxPerMm.toFixed(1)} px/mm`;rerun();}}});
if('serviceWorker' in navigator){window.addEventListener('load',async()=>{
  try{
    const reg=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});
    await reg.update();
    if(reg.waiting)reg.waiting.postMessage('SKIP_WAITING');
    navigator.serviceWorker.addEventListener('controllerchange',()=>{
      if(!sessionStorage.getItem('locacc-sw-reloaded')){sessionStorage.setItem('locacc-sw-reloaded','1');location.reload();}
    });
  }catch(_e){}
});}window.addEventListener('beforeunload',stopCamera);startCamera();
