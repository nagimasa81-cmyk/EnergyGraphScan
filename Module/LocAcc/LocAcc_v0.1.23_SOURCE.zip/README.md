# LocAcc v0.1.23

Offline iPhone Safari PWA for thermal hotspot location accuracy measurement.

## Measurement rules
- lower-right `^` marker => measure the **R-L (RL)** axis.
- lower-right `>` marker => measure the vertical anatomical pair detected from the edge annotations: **S-I (SI)** or **A-P (AP)**.
- Red thermal overlay center = geometric centroid of a filled red silhouette (moire gaps are filled before centroid calculation).
- Cross center = intersection of the yellow/green cross arms.
- Ruler = **6 ticks / 5 intervals / 5 mm total**; calibration uses the entire 5 mm span.
- Anatomical edge annotations are used for sign. **R, S and A are positive**; L, I and P are negative.
- Result is displayed to 0.1 mm.

## GitHub Pages path
Deploy the contents to `Module/LocAcc/`. Safari URL:
`https://<GitHub-user>.github.io/<repository>/Module/LocAcc/`

The Service Worker uses relative URLs so the PWA remains scoped to `Module/LocAcc/` and works offline after initial caching.


## Result notation (v0.1.4)
Results use anatomical axis names only: **RL / SI / AP**. R, S and A are positive; L, I and P are negative. Example: `RL +0.1 mm (R)`. Horizontal/Vertical are not used as the user-facing measurement-axis names.


## v0.1.23
- Visible software version in the header.
- Measurement stays on one line: H/V + RL/SI/AP + signed mm + direction.
- Anatomy detection searches border bands for the **actual single-letter glyphs** instead of assuming exact edge midpoints.
- Yellow rectangles are drawn directly around the detected R/L/A/P/S/I glyphs on the source image.
- Opposite-edge pairs are validated as RL, AP, or SI. The ambiguous fallback `SI/AP` has been removed; unresolved vertical anatomy is shown as `Unknown`.
- Distance calculation and 5 mm ruler calibration logic are unchanged.

## v0.1.23 adaptive image optimization
- Hotspot: adaptive red-excess / exposure normalization while preserving geometry.
- Cross: adaptive yellow-green local contrast inside the hotspot.
- 5 mm scale: robust grayscale contrast normalization before edge/tick analysis.
- Direction marker: adaptive cyan + local contrast.
- Anatomy A/P/R/L/S/I: independent adaptive cyan/luminance thresholds for each edge band.
- Photo import now preserves up to 2400 x 2400 pixels, matching the camera-analysis path.
- All processing remains offline and uses only local browser code.

## v0.1.23 anatomy capture correction
- Anatomy search zones are narrowed to the actual vendor annotation positions.
- Patient ID, timing text, temperature labels and ruler text are excluded by geometry.
- Left/right annotations must form a same-height R-L pair.
- Top/bottom annotations must form a same-x A-P or S-I pair.
- Yellow rectangles are drawn only for validated anatomy pairs; unrelated text is never boxed.
- Ambiguous SI/AP fallback remains disabled.

## v0.1.23 measurement reference
- Offset reference changed from the yellow cross to the green target geometry.
- Priority 1: if a small green point is visible, use the center of that point.
- Priority 2: otherwise use the geometric center of the large green circular contour.
- Offset is calculated between that green reference center and the red hotspot geometric centroid.
- Yellow cross remains an optional diagnostic overlay only and no longer affects the calculated value.
- RL / SI / AP axis selection and R/S/A positive-sign convention are unchanged.

## v0.1.23 measurement model
Reference priority is fixed to:
1. Cross center
2. Green or yellow circle-line center (robust circle fitting)
3. Green spot center

The red hotspot geometric centroid is always the measured target.
Both horizontal and vertical offsets are calculated and displayed.
When anatomy annotations are validated, H/V are mapped to RL/SI/AP with R/S/A positive.
When the lower-right marker is detected, the component perpendicular to that marker is the final Measurement.

## v0.1.23 circle candidate hardening
- Green/yellow circle radius is constrained by the detected red-hotspot size, not by the full photo.
- Circle center must remain near the hotspot centroid and the hotspot must lie inside the fitted ring.
- Valid rings require circumference evidence across at least three quadrants and sufficient angular coverage.
- UI text, ruler ticks and very large false fits are rejected before they can become a reference.
- Result overlay no longer draws a complete fitted circle; it shows validated circumference evidence points plus the fitted center only.

## v0.1.23
Red center = equal-area filled visible-red silhouette. Cross requires four confirmed arms inside the red region; invalid cross falls through to circle then green spot.

## v0.1.23 Photo picker fix
- Photo uses a native iOS file input directly under the visible Photo control.
- No programmatic `.click()` is required, avoiding Safari/PWA user-gesture blocking.
- Camera failure no longer changes the Photo picker to `capture=environment`.
- Selecting a photo stops the camera stream and loads the selected image.
- Service Worker cache and asset query versions are synchronized to v0.1.23.

## v0.1.23 reference false-positive guard
- Green spot search is restricted to the local measurement ROI around the hotspot/circle center.
- Left toolbar, right ruler and screen chrome are excluded by geometry.
- Cross/circle/green-spot candidates must pass distance, confidence and geometry validation.
- A green spot farther than the allowed hotspot-centered radius is rejected.
- If no reference passes validation, LocAcc shows `Needs attention` and does not output H/V millimeter values.

## v0.1.23 null-reference UI fix
- `Needs attention` is now a valid terminal analysis state.
- UI/manual-correction code no longer dereferences `reference.type/x/y` when no automatic reference was confirmed.
- No millimeter result is fabricated when the reference is null.

## v0.1.23
Valid green/yellow circle acceptance adjusted for photographed anti-aliased and partially broken rings while retaining hotspot-centered geometry guards. UI false green spots remain rejected.

## v0.1.23 lower-right marker hardening
- Marker ROI widened so photographed/perspective-shifted lower-right carets remain in range.
- Uses local contrast plus optional cyan evidence instead of cyan-only detection.
- Shape scoring distinguishes `^` (top apex + two lower arms) from `>` (right apex + two left arms).
- One-pixel diagonal gaps are bridged for LCD moire/anti-aliasing.
- `Right` is accepted only when it beats `Up` by a clear margin; ambiguous photographed carets conservatively remain `Up`.

## v0.1.23 emergency runtime repair
- Rebased analysis-core on the last runtime-good v0.1.18 core.
- Fixes `Can't find variable: LocAccCore`.
- Restores circle, green-spot, reference, scale and anatomy detector functions that were accidentally removed during v0.1.19 anatomy refactoring.
- Keeps v0.1.18 lower-right caret hardening.
- Anatomy remains pair-validated (RL/AP/SI); no result is promoted from an unconfirmed single edge glyph.

## v0.1.23 cross recovery
- Cross detection no longer requires a single connected cross component.
- Horizontal and vertical line projections are detected independently inside the red hotspot.
- Their intersection defines the Cross center.
- Four-arm evidence is still required, but short LCD/moire gaps are tolerated.
- Outer green/yellow circle cannot qualify as Cross because the Cross ROI is restricted to the hotspot interior.

## v0.1.23 plane-independent anatomy
- All four edges evaluate all six letters R/L/S/I/A/P.
- No letter is hard-coded to top, bottom, left, or right.
- Opposite pairs are accepted only as RL, AP, or SI.
- Horizontal and vertical pairs are selected jointly and cannot use the same anatomical axis.
- Reversed orientation is supported automatically.
- R/S/A are positive; L/I/P are negative.
- Cross, red centroid, circle/spot reference, scale, and lower-right marker are unchanged from v0.1.21.
