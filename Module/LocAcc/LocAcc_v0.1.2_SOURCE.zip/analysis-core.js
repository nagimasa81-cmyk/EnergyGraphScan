(function(global){
  'use strict';

  function rgbToHSV(r,g,b){
    r/=255; g/=255; b/=255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
    let h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return [h, max?d/max:0, max];
  }

  function connectedComponents(mask,w,h,minArea){
    const seen=new Uint8Array(mask.length), comps=[];
    const stackX=new Int32Array(mask.length), stackY=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||seen[idx]) continue;
      let sp=0; stackX[sp]=x; stackY[sp]=y; sp++; seen[idx]=1;
      let area=0,sumX=0,sumY=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        sp--; const cx=stackX[sp], cy=stackY[sp]; area++; sumX+=cx; sumY+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k], ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h) continue;
          const ni=ny*w+nx; if(mask[ni]&&!seen[ni]){seen[ni]=1;stackX[sp]=nx;stackY[sp]=ny;sp++;}
        }
      }
      if(area>=minArea) comps.push({area,cx:sumX/area,cy:sumY/area,minX,maxX,minY,maxY});
    }
    return comps;
  }

  function redRegion(data,w,h){
    const m=new Uint8Array(w*h);
    const xLo=w*.08,xHi=w*.88,yLo=h*.08,yHi=h*.90;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      if(x<xLo||x>xHi||y<yLo||y>yHi) continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,s,v]=rgbToHSV(r,g,b);
      if((hh<20||hh>340)&&s>.40&&v>.46&&r>125) m[y*w+x]=1;
    }
    const comps=connectedComponents(m,w,h,Math.max(100,Math.floor(w*h*.0006)))
      .filter(c=>c.area<w*h*.18)
      .sort((a,b)=>b.area-a.area);
    if(!comps.length) throw new Error('Red thermal region not detected. Re-align the frame and retake.');
    return {component:comps[0],mask:m};
  }

  function crossCenter(data,w,h,red){
    const c=red.component;
    const padX=Math.max(4,Math.floor((c.maxX-c.minX+1)*.08)), padY=Math.max(4,Math.floor((c.maxY-c.minY+1)*.08));
    const x0=Math.max(0,c.minX+padX),x1=Math.min(w-1,c.maxX-padX),y0=Math.max(0,c.minY+padY),y1=Math.min(h-1,c.maxY-padY);
    const col=new Float32Array(w),row=new Float32Array(h);
    let count=0;
    for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,s,v]=rgbToHSV(r,g,b);
      // Yellow/green cross. Green outline is excluded by restricting to the red-region interior.
      if(hh>=35&&hh<=105&&s>.28&&v>.46&&g>95){
        const weight=.5+v+s;
        col[x]+=weight; row[y]+=weight; count++;
      }
    }
    if(count<8) throw new Error('Cross center not detected.');
    let bx=x0,by=y0; for(let x=x0+1;x<=x1;x++)if(col[x]>col[bx])bx=x; for(let y=y0+1;y<=y1;y++)if(row[y]>row[by])by=y;
    // Weighted centroid around the strongest horizontal/vertical projection intersection.
    let sx=0,sy=0,sw=0; const rad=Math.max(5,Math.round(Math.min(w,h)*.018));
    for(let y=Math.max(y0,by-rad);y<=Math.min(y1,by+rad);y++) for(let x=Math.max(x0,bx-rad);x<=Math.min(x1,bx+rad);x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2]; const [hh,s,v]=rgbToHSV(r,g,b);
      if(hh>=35&&hh<=105&&s>.24&&v>.42){ const wt=.3+v+s; sx+=x*wt;sy+=y*wt;sw+=wt; }
    }
    return {x:sw?sx/sw:bx,y:sw?sy/sw:by,rawX:bx,rawY:by,pixelCount:count};
  }

  function localContrastGray(data,w,h,x0,y0,x1,y1){
    const pts=[]; let mean=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4; const r=data[i],g=data[i+1],b=data[i+2]; const lum=.2126*r+.7152*g+.0722*b;
      mean+=lum;n++;pts.push([x,y,lum,r,g,b]);
    }
    mean/=Math.max(1,n); let variance=0; for(const p of pts)variance+=(p[2]-mean)*(p[2]-mean); const sd=Math.sqrt(variance/Math.max(1,n));
    return {pts,mean,sd};
  }

  function detectOrientation(data,w,h){
    // Marker is expected in the lower-right corner of the aligned square crop.
    const x0=Math.floor(w*.91),x1=Math.floor(w*.995),y0=Math.floor(h*.89),y1=Math.floor(h*.995);
    const lc=localContrastGray(data,w,h,x0,y0,x1,y1);
    let sx=0,sy=0,sxx=0,syy=0,n=0,minX=x1,maxX=x0,minY=y1,maxY=y0;
    for(const p of lc.pts){
      const [x,y,lum,r,g,b]=p;
      const blueCyan=(b>r*1.03)||(g>r*1.06);
      if(lum>lc.mean+Math.max(7,lc.sd*.45) && blueCyan){
        sx+=x;sy+=y;sxx+=x*x;syy+=y*y;n++; if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;
      }
    }
    if(n<5) return {direction:'up',confidence:.25,reason:'marker low contrast; defaulted to up'};
    const width=maxX-minX+1,height=maxY-minY+1;
    // A caret ^ is generally wider than tall; a > glyph is generally taller than wide.
    let direction=width>=height?'up':'right';
    let conf=Math.min(.92,.45+Math.abs(width-height)/Math.max(width,height)*.7);
    return {direction,confidence:conf,bbox:{minX,maxX,minY,maxY},width,height};
  }

  function percentile(arr,p){ const a=Array.from(arr).sort((a,b)=>a-b); return a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))]; }

  function detectScale(data,w,h){
    // The on-screen ruler is defined as 6 tick marks spanning 5 equal 1 mm intervals.
    // Calibrate from the full 5 mm span (top selected tick to bottom selected tick) / 5.
    // This intentionally rejects arbitrary horizontal UI/text edges that do not form a regular six-tick set.
    const x0=Math.floor(w*.865),x1=Math.floor(w*.985),y0=Math.floor(h*.18),y1=Math.floor(h*.84);
    const gray=new Float32Array(w*h);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=(y*w+x)*4; gray[y*w+x]=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];
    }

    const scores=new Float32Array(y1-y0);
    for(let y=y0+2;y<y1-2;y++){
      let s=0,n=0;
      for(let x=x0+1;x<x1-1;x++){
        const dv=Math.abs(gray[(y+1)*w+x]-gray[(y-1)*w+x]);
        const dh=Math.abs(gray[y*w+x+1]-gray[y*w+x-1]);
        s+=Math.max(0,dv-dh*.34); n++;
      }
      scores[y-y0]=s/Math.max(1,n);
    }

    const th=percentile(scores,.72), raw=[];
    for(let i=3;i<scores.length-3;i++){
      if(scores[i]<th) continue;
      let mx=true;
      for(let k=-3;k<=3;k++) if(scores[i+k]>scores[i]){mx=false;break;}
      if(mx) raw.push({y:y0+i,score:scores[i]});
    }

    // Collapse double responses from a single printed tick into one center candidate.
    const clustered=[];
    const mergeDist=Math.max(5,Math.round(h*.008));
    for(const q of raw){
      const last=clustered[clustered.length-1];
      if(last&&q.y-last.y<=mergeDist){
        const total=last.weight+q.score;
        last.y=(last.y*last.weight+q.y*q.score)/total;
        last.score=Math.max(last.score,q.score); last.weight=total;
      }else clustered.push({y:q.y,score:q.score,weight:q.score});
    }

    // Find exactly the ruler pattern: six monotonically ordered ticks creating five nearly equal gaps.
    // Test a predicted spacing and snap each expected location to the nearest observed candidate.
    let best=null;
    const minGap=h*.018, maxGap=h*.095;
    for(let a=0;a<clustered.length;a++){
      for(let b=a+1;b<clustered.length;b++){
        const span=clustered[b].y-clustered[a].y;
        // a/b may represent any separation of 1..5 intervals.
        for(let steps=1;steps<=5;steps++){
          const gap=span/steps;
          if(gap<minGap||gap>maxGap) continue;
          // Infer all possible positions of this pair inside a six-tick ruler.
          for(let apos=0;apos<=5-steps;apos++){
            const first=clustered[a].y-apos*gap;
            const selected=[]; let err=0, strength=0, ok=true, lastIdx=-1;
            const tol=Math.max(4,gap*.16);
            for(let k=0;k<6;k++){
              const target=first+k*gap;
              let bi=-1,be=1e9;
              for(let j=lastIdx+1;j<clustered.length;j++){
                const e=Math.abs(clustered[j].y-target);
                if(e<be){be=e;bi=j;}
                if(clustered[j].y>target+tol) break;
              }
              if(bi<0||be>tol){ok=false;break;}
              selected.push(clustered[bi]); lastIdx=bi; err+=be/gap; strength+=clustered[bi].score;
            }
            if(!ok) continue;
            const ys=selected.map(t=>t.y), gaps=[];
            for(let k=0;k<5;k++) gaps.push(ys[k+1]-ys[k]);
            const mean=gaps.reduce((x,y)=>x+y,0)/5;
            const maxDev=Math.max(...gaps.map(g=>Math.abs(g-mean)/mean));
            const fullSpan=ys[5]-ys[0];
            if(maxDev>.18||fullSpan<h*.09||fullSpan>h*.48) continue;
            // Prefer regular spacing, strong edges, and ruler sets toward the right side search area.
            const quality=120 - err*18 - maxDev*150 + Math.min(35,strength/Math.max(1,th)*1.5);
            if(!best||quality>best.quality) best={quality,selected,gaps,fullSpan,maxDev};
          }
        }
      }
    }

    if(!best){
      return {pxPerMm:null,confidence:.15,peaks:clustered.map(p=>Math.round(p.y)),selectedTicks:[],reason:'six-tick / five-interval 5 mm ruler not reliably detected'};
    }

    const selectedTicks=best.selected.map(p=>p.y);
    const pxPerMm=(selectedTicks[5]-selectedTicks[0])/5;
    const regularity=Math.max(0,1-best.maxDev/.18);
    const confidence=Math.min(.97,.58+.35*regularity);
    return {
      pxPerMm,
      confidence,
      peaks:clustered.map(p=>Math.round(p.y)),
      selectedTicks:selectedTicks.map(y=>Math.round(y)),
      fullSpanPx:selectedTicks[5]-selectedTicks[0],
      rulerMm:5,
      intervalCount:5,
      tickCount:6,
      gaps:best.gaps
    };
  }

  function analyze(imageData,w,h,overrides){
    overrides=overrides||{};
    const red=redRegion(imageData.data,w,h);
    const cross=crossCenter(imageData.data,w,h,red);
    const ori=detectOrientation(imageData.data,w,h);
    const scale=detectScale(imageData.data,w,h);
    const direction=overrides.direction||ori.direction;
    const pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3) throw new Error('1 mm scale could not be calibrated automatically. Use “Tap 2 adjacent ticks”.');
    const signedPx=direction==='up' ? red.component.cx-cross.x : red.component.cy-cross.y;
    const mm=Math.abs(signedPx)/pxPerMm;
    const confidence=Math.max(0,Math.min(1,Math.min(.98,ori.confidence*.45+scale.confidence*.55)));
    return {red,cross,orientation:ori,direction,scale,pxPerMm,signedPx,mm,confidence};
  }

  global.LocAccCore={analyze,redRegion,crossCenter,detectOrientation,detectScale};
})(window);
