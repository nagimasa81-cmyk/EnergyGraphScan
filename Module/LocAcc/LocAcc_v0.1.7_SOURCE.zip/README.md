# LocAcc v0.1.7

Offline-first iPhone Safari PWA for thermal hotspot geometric-offset measurement.

## v0.1.7 fixes
- Cache/update repair: app shell is network-first while online, old Service Worker caches are removed, and the new worker forces activation. The visible version is hard-coded as a fallback and `version.json` is still checked.
- Camera: requests the highest resolution exposed by the active Safari camera track through `getCapabilities()` / `applyConstraints()` where supported and displays the actual selected stream size.
- Capture: no longer downsamples every guide crop to 900x900. The crop keeps native detail up to 2400x2400 so tiny R/L/A/P/S/I edge labels remain resolvable.
- Anatomy detection: more tolerant cyan/light annotation segmentation plus one-pixel gap joining for photographed LCD text.
- Manual direction/5 mm calibration always reruns the full measurement pipeline immediately.
- Near-zero results are normalized to 0.0 mm instead of showing -0.0 mm.

## Direction convention
- Axis pairs: RL, SI, AP.
- Positive directions: R, S, A.
- Negative directions: L, I, P.
- Up marker => perpendicular screen measurement is H.
- Right marker => perpendicular screen measurement is V.

## Scale
Six ruler ticks define five 1 mm intervals (5 mm total). Automatic and manual calibration use the full 5 mm span.
