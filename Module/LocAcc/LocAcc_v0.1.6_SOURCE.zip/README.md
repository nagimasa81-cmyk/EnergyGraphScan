# LocAcc v0.1.6

Offline iPhone Safari PWA for thermal hotspot location accuracy measurement.

## Measurement rules
- lower-right `^` marker => measure the **R-L (RL)** axis.
- lower-right `>` marker => measure the vertical anatomical pair detected from the edge annotations: **S-I (SI)** or **A-P (AP)**.
- Red thermal overlay center = geometric centroid of a filled red silhouette (moire gaps are filled before centroid calculation).
- Cross center = intersection of the yellow/green cross arms.
- Ruler = **6 ticks / 5 intervals / 5 mm total**; calibration uses the entire 5 mm span.
- Anatomical edge annotations are used for sign. **R, S and A are positive**; L, I and P are negative.
- Result is displayed to 0.1 mm.

## GitHub Pages path
Deploy the contents to `Module/LocAcc/`. Safari URL:
`https://<GitHub-user>.github.io/<repository>/Module/LocAcc/`

The Service Worker uses relative URLs so the PWA remains scoped to `Module/LocAcc/` and works offline after initial caching.


## Result notation (v0.1.4)
Results use anatomical axis names only: **RL / SI / AP**. R, S and A are positive; L, I and P are negative. Example: `RL +0.1 mm (R)`. Horizontal/Vertical are not used as the user-facing measurement-axis names.


## v0.1.6
- Visible software version in the header.
- Measurement stays on one line: H/V + RL/SI/AP + signed mm + direction.
- Anatomy detection searches border bands for the **actual single-letter glyphs** instead of assuming exact edge midpoints.
- Yellow rectangles are drawn directly around the detected R/L/A/P/S/I glyphs on the source image.
- Opposite-edge pairs are validated as RL, AP, or SI. The ambiguous fallback `SI/AP` has been removed; unresolved vertical anatomy is shown as `Unknown`.
- Distance calculation and 5 mm ruler calibration logic are unchanged.
