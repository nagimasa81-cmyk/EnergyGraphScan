(function(global){
  'use strict';

  function rgbToHSV(r,g,b){
    r/=255; g/=255; b/=255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
    let h=0;
    if(d){
      if(max===r) h=((g-b)/d)%6;
      else if(max===g) h=(b-r)/d+2;
      else h=(r-g)/d+4;
      h*=60; if(h<0) h+=360;
    }
    return [h, max?d/max:0, max];
  }

  function connectedComponents(mask,w,h,minArea){
    const seen=new Uint8Array(mask.length), comps=[];
    const stack=new Int32Array(mask.length);
    const dirs=[-1,0,1,0,-1];
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const idx=y*w+x;
      if(!mask[idx]||seen[idx]) continue;
      let sp=0; stack[sp++]=idx; seen[idx]=1;
      let area=0,sumX=0,sumY=0,minX=x,maxX=x,minY=y,maxY=y;
      while(sp){
        const ci=stack[--sp], cx=ci%w, cy=(ci/w)|0; area++; sumX+=cx; sumY+=cy;
        if(cx<minX)minX=cx;if(cx>maxX)maxX=cx;if(cy<minY)minY=cy;if(cy>maxY)maxY=cy;
        for(let k=0;k<4;k++){
          const nx=cx+dirs[k], ny=cy+dirs[k+1];
          if(nx<0||ny<0||nx>=w||ny>=h) continue;
          const ni=ny*w+nx; if(mask[ni]&&!seen[ni]){seen[ni]=1;stack[sp++]=ni;}
        }
      }
      if(area>=minArea) comps.push({area,cx:sumX/area,cy:sumY/area,minX,maxX,minY,maxY});
    }
    return comps;
  }

  function redRegion(data,w,h){
    const raw=new Uint8Array(w*h);
    const xLo=w*.08,xHi=w*.86,yLo=h*.08,yHi=h*.90;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      if(x<xLo||x>xHi||y<yLo||y>yHi) continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,s,v]=rgbToHSV(r,g,b);
      // Broad red/orange inclusion: photographs of the thermal overlay can shift hue and contain moire gaps.
      const redDominant=r>118 && r>g*1.16 && r>b*1.18;
      if(redDominant && (hh<38||hh>338) && s>.27 && v>.43) raw[y*w+x]=1;
    }
    const comps=connectedComponents(raw,w,h,Math.max(100,Math.floor(w*h*.00055)))
      .filter(c=>c.area<w*h*.20)
      .sort((a,b)=>b.area-a.area);
    if(!comps.length) throw new Error('Red thermal region not detected. Re-align the frame and retake.');
    const seed=comps[0];

    // Build a filled silhouette from row spans. This removes display scan-lines / moire holes that otherwise
    // pull the pixel centroid to one side and exaggerate a sub-millimeter offset.
    const filled=new Uint8Array(w*h);
    let area=0,sx=0,sy=0,minX=w,maxX=0,minY=h,maxY=0;
    for(let y=seed.minY;y<=seed.maxY;y++){
      let lo=w,hi=-1,count=0;
      for(let x=seed.minX;x<=seed.maxX;x++) if(raw[y*w+x]){lo=Math.min(lo,x);hi=Math.max(hi,x);count++;}
      if(hi<lo || count<Math.max(2,(hi-lo+1)*.08)) continue;
      for(let x=lo;x<=hi;x++){
        filled[y*w+x]=1; area++; sx+=x; sy+=y;
      }
      if(lo<minX)minX=lo;if(hi>maxX)maxX=hi;if(y<minY)minY=y;if(y>maxY)maxY=y;
    }
    const component={area,cx:sx/area,cy:sy/area,minX,maxX,minY,maxY,rawCx:seed.cx,rawCy:seed.cy};
    return {component,mask:filled,rawMask:raw};
  }

  function crossCenter(data,w,h,red){
    const c=red.component;
    const padX=Math.max(3,Math.floor((c.maxX-c.minX+1)*.06)), padY=Math.max(3,Math.floor((c.maxY-c.minY+1)*.06));
    const x0=Math.max(0,c.minX+padX),x1=Math.min(w-1,c.maxX-padX),y0=Math.max(0,c.minY+padY),y1=Math.min(h-1,c.maxY-padY);
    const col=new Float32Array(w),row=new Float32Array(h), mask=new Uint8Array(w*h);
    let count=0;
    for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++){
      if(!red.mask[y*w+x]) continue;
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const [hh,s,v]=rgbToHSV(r,g,b);
      if(hh>=32&&hh<=112&&s>.24&&v>.43&&g>92){
        const wt=.5+v+s; col[x]+=wt; row[y]+=wt; mask[y*w+x]=1; count++;
      }
    }
    if(count<8) throw new Error('Cross center not detected.');
    let bx=x0,by=y0; for(let x=x0+1;x<=x1;x++)if(col[x]>col[bx])bx=x; for(let y=y0+1;y<=y1;y++)if(row[y]>row[by])by=y;

    // Estimate the intersection from the strongest horizontal and vertical arms rather than a color centroid.
    // This prevents one long arm or anti-aliased glow from shifting the reported cross center.
    const band=Math.max(2,Math.round(Math.min(w,h)*.0045));
    let sx=0,swx=0,sy=0,swy=0;
    for(let x=Math.max(x0,bx-band*6);x<=Math.min(x1,bx+band*6);x++){
      let wt=0; for(let y=Math.max(y0,by-band);y<=Math.min(y1,by+band);y++) if(mask[y*w+x]) wt++;
      if(wt){sx+=x*wt;swx+=wt;}
    }
    for(let y=Math.max(y0,by-band*6);y<=Math.min(y1,by+band*6);y++){
      let wt=0; for(let x=Math.max(x0,bx-band);x<=Math.min(x1,bx+band);x++) if(mask[y*w+x]) wt++;
      if(wt){sy+=y*wt;swy+=wt;}
    }
    return {x:swx?sx/swx:bx,y:swy?sy/swy:by,rawX:bx,rawY:by,pixelCount:count};
  }

  function localContrastGray(data,w,h,x0,y0,x1,y1){
    const pts=[]; let mean=0,n=0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4; const r=data[i],g=data[i+1],b=data[i+2]; const lum=.2126*r+.7152*g+.0722*b;
      mean+=lum;n++;pts.push([x,y,lum,r,g,b]);
    }
    mean/=Math.max(1,n); let variance=0; for(const p of pts)variance+=(p[2]-mean)*(p[2]-mean); const sd=Math.sqrt(variance/Math.max(1,n));
    return {pts,mean,sd};
  }

  function detectOrientation(data,w,h){
    // Use connected marker components only. The previous bounding-box method could include the panel border,
    // causing a real ^ marker to be misclassified as >.
    const x0=Math.floor(w*.875),x1=Math.floor(w*.992),y0=Math.floor(h*.855),y1=Math.floor(h*.992);
    const rw=x1-x0,rh=y1-y0, m=new Uint8Array(rw*rh);
    const lc=localContrastGray(data,w,h,x0,y0,x1,y1);
    for(const p of lc.pts){
      const [x,y,lum,r,g,b]=p;
      const cyan=(b>r*1.015 || g>r*1.035) && (g+b)>r*2.03;
      const bright=lum>lc.mean+Math.max(5,lc.sd*.34);
      if(cyan&&bright) m[(y-y0)*rw+(x-x0)]=1;
    }
    const comps=connectedComponents(m,rw,rh,2)
      .filter(c=>c.area<rw*rh*.14 && (c.maxX-c.minX)<rw*.72 && (c.maxY-c.minY)<rh*.72)
      .sort((a,b)=>b.area-a.area);
    if(!comps.length) return {direction:'up',confidence:.30,reason:'marker low contrast; defaulted to up'};

    // Prefer a compact glyph in the lower/right half, not long frame/text fragments.
    let best=null,bestScore=-1;
    for(const c of comps.slice(0,12)){
      const ww=c.maxX-c.minX+1,hh=c.maxY-c.minY+1;
      if(ww<2||hh<2) continue;
      const compact=c.area/(ww*hh);
      const score=c.area*(.65+.35*compact) - Math.max(0,ww-rw*.45)*4 - Math.max(0,hh-rh*.45)*4;
      if(score>bestScore){bestScore=score;best=c;}
    }
    if(!best) return {direction:'up',confidence:.30,reason:'marker ambiguous; defaulted to up'};
    const width=best.maxX-best.minX+1,height=best.maxY-best.minY+1;
    const ratio=width/Math.max(1,height);
    // ^ is characteristically wider; > is characteristically taller. Require strong evidence for Right.
    const direction=ratio>=.82?'up':'right';
    const conf=Math.min(.94,.52+Math.abs(Math.log(Math.max(.15,ratio)))*.30);
    return {direction,confidence:conf,bbox:{minX:best.minX+x0,maxX:best.maxX+x0,minY:best.minY+y0,maxY:best.maxY+y0},width,height,ratio};
  }

  function percentile(arr,p){ const a=Array.from(arr).sort((a,b)=>a-b); return a[Math.max(0,Math.min(a.length-1,Math.floor((a.length-1)*p)))]; }

  function findSixRegularTicks(cands,h){
    let best=null;
    const minGap=h*.018,maxGap=h*.095;
    for(let a=0;a<cands.length;a++) for(let b=a+1;b<cands.length;b++){
      const span=cands[b].y-cands[a].y;
      for(let steps=1;steps<=5;steps++){
        const gap=span/steps;if(gap<minGap||gap>maxGap)continue;
        for(let apos=0;apos<=5-steps;apos++){
          const first=cands[a].y-apos*gap,selected=[];let err=0,strength=0,ok=true,lastIdx=-1;
          const tol=Math.max(4,gap*.14);
          for(let k=0;k<6;k++){
            const target=first+k*gap;let bi=-1,be=1e9;
            for(let j=lastIdx+1;j<cands.length;j++){
              const e=Math.abs(cands[j].y-target);if(e<be){be=e;bi=j;}if(cands[j].y>target+tol)break;
            }
            if(bi<0||be>tol){ok=false;break;}selected.push(cands[bi]);lastIdx=bi;err+=be/gap;strength+=cands[bi].score;
          }
          if(!ok)continue;
          const ys=selected.map(t=>t.y),gaps=[];for(let k=0;k<5;k++)gaps.push(ys[k+1]-ys[k]);
          const mean=gaps.reduce((x,y)=>x+y,0)/5,maxDev=Math.max(...gaps.map(g=>Math.abs(g-mean)/mean));
          const fullSpan=ys[5]-ys[0];if(maxDev>.15||fullSpan<h*.09||fullSpan>h*.48)continue;
          const quality=130-err*20-maxDev*190+Math.min(40,strength*.18);
          if(!best||quality>best.quality)best={quality,selected,gaps,fullSpan,maxDev};
        }
      }
    }
    return best;
  }

  function detectScale(data,w,h){
    // First locate the vertical ruler spine, then search ONLY for six ticks attached to that spine.
    // This avoids using text baselines and other horizontal UI edges as a ruler.
    const sx0=Math.floor(w*.78),sx1=Math.floor(w*.965),y0=Math.floor(h*.18),y1=Math.floor(h*.84);
    const lum=new Float32Array(w*h);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;lum[y*w+x]=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];}
    const xScores=[];
    for(let x=sx0+2;x<sx1-2;x++){
      let s=0,n=0;
      for(let y=y0;y<y1;y+=2){
        const edge=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
        const verticalSmooth=Math.abs(lum[(Math.min(h-1,y+1))*w+x]-lum[(Math.max(0,y-1))*w+x]);
        s+=Math.max(0,edge-verticalSmooth*.22);n++;
      }
      xScores.push({x,score:s/Math.max(1,n)});
    }
    xScores.sort((a,b)=>b.score-a.score);
    const spineCandidates=xScores.slice(0,10);
    let globalBest=null;
    for(const sp of spineCandidates){
      const left=Math.max(0,Math.floor(sp.x-w*.075)),right=Math.min(w-1,Math.floor(sp.x+w*.012));
      const scores=[];
      for(let y=y0+2;y<y1-2;y++){
        let s=0,n=0;
        for(let x=left+1;x<right-1;x++){
          const dv=Math.abs(lum[(y+1)*w+x]-lum[(y-1)*w+x]);
          const dh=Math.abs(lum[y*w+x+1]-lum[y*w+x-1]);
          // horizontal tick edge near the detected vertical spine
          s+=Math.max(0,dv-dh*.28);n++;
        }
        scores.push({y,score:s/Math.max(1,n)});
      }
      const vals=scores.map(q=>q.score),th=percentile(vals,.79),raw=[];
      for(let i=3;i<scores.length-3;i++){
        if(scores[i].score<th)continue;let mx=true;for(let k=-3;k<=3;k++)if(scores[i+k].score>scores[i].score){mx=false;break;}
        if(mx)raw.push(scores[i]);
      }
      const clustered=[],mergeDist=Math.max(4,Math.round(h*.007));
      for(const q of raw){const last=clustered[clustered.length-1];if(last&&q.y-last.y<=mergeDist){const wt=last.weight+q.score;last.y=(last.y*last.weight+q.y*q.score)/wt;last.score=Math.max(last.score,q.score);last.weight=wt;}else clustered.push({y:q.y,score:q.score,weight:q.score});}
      const best=findSixRegularTicks(clustered,h);
      if(best){
        // Prefer a regular set and a strong continuous spine.
        best.quality+=Math.min(25,sp.score*.8);best.spineX=sp.x;best.candidates=clustered;
        if(!globalBest||best.quality>globalBest.quality)globalBest=best;
      }
    }
    if(!globalBest)return {pxPerMm:null,confidence:.12,selectedTicks:[],reason:'5 mm ruler spine + six ticks not reliably detected'};
    const ticks=globalBest.selected.map(p=>p.y),pxPerMm=(ticks[5]-ticks[0])/5;
    const regularity=Math.max(0,1-globalBest.maxDev/.15),confidence=Math.min(.98,.64+.32*regularity);
    return {pxPerMm,confidence,selectedTicks:ticks.map(Math.round),fullSpanPx:ticks[5]-ticks[0],rulerMm:5,intervalCount:5,tickCount:6,gaps:globalBest.gaps,spineX:globalBest.spineX};
  }

  // Tiny offline glyph templates for the edge annotations. Recognition is deliberately restricted to
  // the six expected anatomical letters, and opposite-side consistency is used to reject false positives.
  const GLYPHS={
    R:['11110','10001','10001','11110','10100','10010','10001'],
    L:['10000','10000','10000','10000','10000','10000','11111'],
    A:['01110','10001','10001','11111','10001','10001','10001'],
    P:['11110','10001','10001','11110','10000','10000','10000'],
    S:['01111','10000','10000','01110','00001','00001','11110'],
    I:['11111','00100','00100','00100','00100','00100','11111']
  };
  function sampleGlyph(data,w,h,roi){
    const [x0,y0,x1,y1]=roi;const pts=[];
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
      const cyan=(g>r*1.03||b>r*1.03) && lum>65;
      if(cyan)pts.push([x,y]);
    }
    if(pts.length<3)return null;
    let minX=Math.min(...pts.map(p=>p[0])),maxX=Math.max(...pts.map(p=>p[0])),minY=Math.min(...pts.map(p=>p[1])),maxY=Math.max(...pts.map(p=>p[1]));
    // Ignore very large UI fragments; keep the compact component-ish center zone.
    if(maxX-minX> (x1-x0)*.75 || maxY-minY>(y1-y0)*.75)return null;
    const grid=[];
    for(let gy=0;gy<7;gy++){
      let row='';for(let gx=0;gx<5;gx++){
        const ax=minX+(maxX-minX+1)*gx/5,bx=minX+(maxX-minX+1)*(gx+1)/5;
        const ay=minY+(maxY-minY+1)*gy/7,by=minY+(maxY-minY+1)*(gy+1)/7;
        let on=0,tot=0;
        for(let y=Math.floor(ay);y<Math.ceil(by);y++)for(let x=Math.floor(ax);x<Math.ceil(bx);x++){
          if(x<0||y<0||x>=w||y>=h)continue;tot++;const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2],lum=.2126*r+.7152*g+.0722*b;
          if((g>r*1.025||b>r*1.025)&&lum>65)on++;
        }
        row+=on/Math.max(1,tot)>.16?'1':'0';
      }grid.push(row);
    }
    let best=null;
    for(const [label,t] of Object.entries(GLYPHS)){
      let same=0;for(let y=0;y<7;y++)for(let x=0;x<5;x++)if(grid[y][x]===t[y][x])same++;
      const score=same/35;if(!best||score>best.score)best={label,score,grid,bbox:{minX,maxX,minY,maxY}};
    }
    return best;
  }
  function classifyGlyphComponent(data,w,h,bbox){
    // Expand only around one compact connected component.  This is intentionally
    // different from the old whole-ROI sampler which mixed anatomy letters with
    // nearby UI text and often returned SI/AP or no drawable box.
    const padX=Math.max(2,Math.round((bbox.maxX-bbox.minX+1)*.45));
    const padY=Math.max(2,Math.round((bbox.maxY-bbox.minY+1)*.35));
    const roi=[Math.max(0,bbox.minX-padX),Math.max(0,bbox.minY-padY),Math.min(w,bbox.maxX+padX+1),Math.min(h,bbox.maxY+padY+1)];
    const g=sampleGlyph(data,w,h,roi);
    if(!g) return null;
    // Preserve the actual component position for the yellow rectangle.  The
    // classifier may use a padded ROI, but the overlay must surround the letter.
    g.bbox={minX:bbox.minX,maxX:bbox.maxX,minY:bbox.minY,maxY:bbox.maxY};
    return g;
  }

  function anatomyCandidates(data,w,h,side){
    // Search a BORDER BAND, not a fixed center box.  The real vendor anatomy
    // annotation can be displaced from the geometric midpoint by perspective,
    // cropping, or other overlays (as in the supplied AP/RL example).
    let x0=0,y0=0,x1=w,y1=h;
    if(side==='top'){x0=Math.floor(w*.10);x1=Math.floor(w*.86);y0=Math.floor(h*.025);y1=Math.floor(h*.19);}
    else if(side==='bottom'){x0=Math.floor(w*.10);x1=Math.floor(w*.86);y0=Math.floor(h*.79);y1=Math.floor(h*.975);}
    else if(side==='left'){x0=Math.floor(w*.015);x1=Math.floor(w*.205);y0=Math.floor(h*.15);y1=Math.floor(h*.84);}
    else {x0=Math.floor(w*.775);x1=Math.floor(w*.985);y0=Math.floor(h*.15);y1=Math.floor(h*.84);}

    const rw=x1-x0,rh=y1-y0,mask=new Uint8Array(rw*rh);
    for(let y=y0;y<y1;y++) for(let x=x0;x<x1;x++){
      const i=(y*w+x)*4,r=data[i],g=data[i+1],b=data[i+2];
      const lum=.2126*r+.7152*g+.0722*b;
      // Vendor orientation letters are cyan/light-blue. Keep this permissive
      // enough for photographed LCDs while rejecting gray/white panel borders.
      const cyanish=lum>62 && (b>r*1.025 || g>r*1.035) && (g+b)>r*2.02;
      if(cyanish) mask[(y-y0)*rw+(x-x0)]=1;
    }
    const minA=Math.max(2,Math.floor(w*h*.000003));
    const comps=connectedComponents(mask,rw,rh,minA);
    const expected=side==='left'||side==='right'?['R','L']:['A','P','S','I'];
    const candidates=[];
    for(const c of comps){
      const bw=c.maxX-c.minX+1,bh=c.maxY-c.minY+1;
      // Anatomy labels are single compact glyphs. Reject long text/borders but
      // allow small photographed characters down to a few pixels.
      if(bw<2||bh<3||bw>w*.055||bh>h*.070) continue;
      if(c.area>bw*bh*.88 || c.area<2) continue;
      const box={minX:c.minX+x0,maxX:c.maxX+x0,minY:c.minY+y0,maxY:c.maxY+y0};
      const g=classifyGlyphComponent(data,w,h,box); if(!g||!expected.includes(g.label)) continue;
      const cx=(box.minX+box.maxX)/2,cy=(box.minY+box.maxY)/2;
      // Prefer components close to the image edge and roughly around the middle
      // half of that edge, but do NOT force the exact midpoint.
      let edgeDist=0,midDist=0;
      if(side==='top'){edgeDist=cy/h;midDist=Math.abs(cx/w-.5);}
      else if(side==='bottom'){edgeDist=1-cy/h;midDist=Math.abs(cx/w-.5);}
      else if(side==='left'){edgeDist=cx/w;midDist=Math.abs(cy/h-.5);}
      else {edgeDist=1-cx/w;midDist=Math.abs(cy/h-.5);}
      const posScore=Math.max(0,1-edgeDist/.22)*.40 + Math.max(0,1-midDist/.48)*.18;
      const score=g.score*.72+posScore;
      candidates.push({...g,side,scoreRaw:g.score,score,cx,cy});
    }
    candidates.sort((a,b)=>b.score-a.score);
    return candidates;
  }

  function detectAnatomy(data,w,h){
    const all={};
    for(const side of ['top','bottom','left','right']) all[side]=anatomyCandidates(data,w,h,side);

    // Pick a coherent opposite-edge pair first.  Pair consistency has priority
    // over a single high scoring OCR-like match.
    function bestPair(sideA,sideB,pairs){
      let best=null;
      for(const a of all[sideA].slice(0,14)) for(const b of all[sideB].slice(0,14)){
        for(const [x,y,axis,pos,neg] of pairs){
          if(!((a.label===x&&b.label===y)||(a.label===y&&b.label===x))) continue;
          const glyphConf=Math.min(a.scoreRaw,b.scoreRaw);
          const pairScore=a.score+b.score+glyphConf*.65;
          if(!best||pairScore>best.pairScore) best={a,b,axis,positiveLabel:pos,negativeLabel:neg,pairScore,glyphConf};
        }
      }
      return best;
    }
    const hp=bestPair('left','right', [['R','L','RL','R','L']]);
    const vp=bestPair('top','bottom', [['A','P','AP','A','P'],['S','I','SI','S','I']]);

    const out={top:null,bottom:null,left:null,right:null};
    let horizontal=null,vertical=null;
    if(hp){
      out.left=hp.a; out.right=hp.b;
      horizontal={axis:'RL',positiveSide:hp.a.label==='R'?'left':'right',positiveLabel:'R',negativeLabel:'L',confidence:Math.min(.98,.38+hp.glyphConf*.62)};
    }
    if(vp){
      out.top=vp.a; out.bottom=vp.b;
      const pos=vp.positiveLabel;
      vertical={axis:vp.axis,positiveSide:vp.a.label===pos?'top':'bottom',positiveLabel:vp.positiveLabel,negativeLabel:vp.negativeLabel,confidence:Math.min(.98,.38+vp.glyphConf*.62)};
    }

    // If a pair is not complete, expose the strongest *actual* candidate for
    // overlay/manual verification, but do not invent SI/AP as an axis.
    for(const side of ['top','bottom','left','right']) if(!out[side] && all[side].length) out[side]=all[side][0];

    // Conservative one-letter axis inference is allowed only when the label itself
    // is strong. This yields RL/AP/SI, never the ambiguous string "SI/AP".
    if(!horizontal){
      for(const side of ['left','right']){const q=out[side];if(q&&q.scoreRaw>=.72&&['R','L'].includes(q.label)){horizontal={axis:'RL',positiveSide:q.label==='R'?side:(side==='left'?'right':'left'),positiveLabel:'R',negativeLabel:'L',confidence:q.scoreRaw*.68};break;}}
    }
    if(!vertical){
      for(const side of ['top','bottom']){const q=out[side];if(q&&q.scoreRaw>=.72&&['A','P','S','I'].includes(q.label)){const ap=['A','P'].includes(q.label),pos=(q.label==='A'||q.label==='S');vertical={axis:ap?'AP':'SI',positiveSide:pos?side:(side==='top'?'bottom':'top'),positiveLabel:ap?'A':'S',negativeLabel:ap?'P':'I',confidence:q.scoreRaw*.68};break;}}
    }
    return {edges:out,candidates:all,horizontal,vertical};
  }

  function analyze(imageData,w,h,overrides){
    overrides=overrides||{};
    const red=redRegion(imageData.data,w,h),cross=crossCenter(imageData.data,w,h,red);
    const ori=detectOrientation(imageData.data,w,h),scale=detectScale(imageData.data,w,h),anatomy=detectAnatomy(imageData.data,w,h);
    const direction=overrides.direction||ori.direction,pxPerMm=overrides.pxPerMm||scale.pxPerMm;
    if(!pxPerMm||pxPerMm<3) throw new Error('5 mm scale could not be calibrated automatically. Tap the top and bottom ruler ticks.');
    const isHorizontal=direction==='up';
    const rawDeltaPx=isHorizontal ? red.component.cx-cross.x : red.component.cy-cross.y;
    const axis=isHorizontal?anatomy.horizontal:anatomy.vertical;
    // Screen x grows right, screen y grows down. Convert to anatomical sign: R/S/A are positive.
    let signedPx=rawDeltaPx,positiveLabel=isHorizontal?'R':'?',negativeLabel=isHorizontal?'L':'?',axisKnown=false;
    if(axis){
      axisKnown=true;positiveLabel=axis.positiveLabel;negativeLabel=axis.negativeLabel;
      const positiveScreenSign=(axis.positiveSide==='right'||axis.positiveSide==='bottom')?1:-1;
      signedPx=rawDeltaPx*positiveScreenSign;
    } else {
      // Common display fallback only affects the sign label; flag low confidence so it is visible to the user.
      const positiveScreenSign=-1; signedPx=rawDeltaPx*positiveScreenSign;
    }
    const signedMm=signedPx/pxPerMm,mm=Math.abs(signedMm);
    let confidence=Math.max(0,Math.min(1,ori.confidence*.34+scale.confidence*.46+(axis?axis.confidence:.28)*.20));
    return {red,cross,orientation:ori,direction,scale,anatomy,axis,axisKnown,positiveLabel,negativeLabel,pxPerMm,rawDeltaPx,signedPx,signedMm,mm,measurementAxis:axis?axis.axis:(isHorizontal?'RL':'Unknown'),screenAxis:isHorizontal?'horizontal':'vertical',confidence};
  }

  global.LocAccCore={analyze,redRegion,crossCenter,detectOrientation,detectScale,detectAnatomy};
})(window);
