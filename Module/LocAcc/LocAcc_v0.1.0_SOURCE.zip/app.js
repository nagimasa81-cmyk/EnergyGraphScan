'use strict';
const $=s=>document.querySelector(s);
const video=$('#video'), preview=$('#previewCanvas'), guide=$('#guide');
const resultCanvas=$('#resultCanvas'), resultPanel=$('#resultPanel'), cameraPanel=$('#cameraPanel');
let stream=null, sourceCanvas=null, sourceCtx=null, lastImageData=null, lastResult=null;
let overrideDirection=null, overridePxPerMm=null, manualTickPoints=[];

function setStatus(msg){ $('#statusText').textContent=msg||''; }
function setBadge(){ const b=$('#offlineBadge'); b.textContent=navigator.onLine?'Online / offline-ready':'Offline'; }
window.addEventListener('online',setBadge); window.addEventListener('offline',setBadge); setBadge();

async function startCamera(){
  stopCamera();
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1920}},audio:false});
    video.srcObject=stream; await video.play(); $('#capture').disabled=false; setStatus('Camera ready. Align the square panel to the guide.');
  }catch(e){
    setStatus('Camera could not start. Use Photo as a fallback. Camera requires HTTPS and permission.');
    $('#fileInput').setAttribute('capture','environment'); $('#fileInput').click();
  }
}
function stopCamera(){ if(stream){ for(const t of stream.getTracks())t.stop(); stream=null; } video.srcObject=null; }

function captureGuideFromVideo(){
  if(!video.videoWidth) return;
  const vr=video.getBoundingClientRect(), gr=guide.getBoundingClientRect();
  const vw=video.videoWidth,vh=video.videoHeight;
  const scale=Math.max(vr.width/vw, vr.height/vh); // object-fit: cover
  const renderedW=vw*scale,renderedH=vh*scale;
  const offX=(vr.width-renderedW)/2, offY=(vr.height-renderedH)/2;
  let sx=(gr.left-vr.left-offX)/scale, sy=(gr.top-vr.top-offY)/scale;
  let sw=gr.width/scale, sh=gr.height/scale;
  sx=Math.max(0,Math.min(vw-sw,sx)); sy=Math.max(0,Math.min(vh-sh,sy));
  const out=900; sourceCanvas=document.createElement('canvas'); sourceCanvas.width=out;sourceCanvas.height=out; sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true});
  sourceCtx.drawImage(video,sx,sy,sw,sh,0,0,out,out); analyzeCurrent();
}

function loadPhoto(file){
  const img=new Image(); const url=URL.createObjectURL(file);
  img.onload=()=>{
    const side=Math.min(img.naturalWidth,img.naturalHeight); const sx=(img.naturalWidth-side)/2,sy=(img.naturalHeight-side)/2;
    const out=Math.min(1100,side); sourceCanvas=document.createElement('canvas');sourceCanvas.width=out;sourceCanvas.height=out;sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true});
    sourceCtx.drawImage(img,sx,sy,side,side,0,0,out,out); URL.revokeObjectURL(url); analyzeCurrent();
  }; img.src=url;
}

function analyzeCurrent(){
  if(!sourceCanvas)return;
  lastImageData=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height);
  try{
    lastResult=LocAccCore.analyze(lastImageData,sourceCanvas.width,sourceCanvas.height,{direction:overrideDirection,pxPerMm:overridePxPerMm});
    renderResult(lastResult); setStatus('Automatic analysis complete. Verify the overlay before use.');
  }catch(e){
    lastResult=null; drawBase(); cameraPanel.hidden=true;resultPanel.hidden=false; setStatus(e.message); $('#distanceResult').textContent='—';$('#confidenceResult').textContent='Low';
    const ori=LocAccCore.detectOrientation(lastImageData.data,sourceCanvas.width,sourceCanvas.height); $('#orientationResult').textContent=ori.direction==='up'?'↑ Up':'→ Right';
    const sc=LocAccCore.detectScale(lastImageData.data,sourceCanvas.width,sourceCanvas.height); $('#scaleResult').textContent=sc.pxPerMm?`${sc.pxPerMm.toFixed(1)} px/mm`:'Needs manual';
  }
}
function drawBase(){
  resultCanvas.width=sourceCanvas.width;resultCanvas.height=sourceCanvas.height; const c=resultCanvas.getContext('2d'); c.drawImage(sourceCanvas,0,0); return c;
}
function renderResult(r){
  cameraPanel.hidden=true;resultPanel.hidden=false;
  $('#distanceResult').textContent=`${r.mm.toFixed(1)} mm`;
  $('#orientationResult').textContent=r.direction==='up'?'↑ Up':'→ Right';
  $('#scaleResult').textContent=`${r.pxPerMm.toFixed(1)} px/mm`;
  $('#confidenceResult').textContent=r.confidence>=.72?'High':r.confidence>=.48?'Medium':'Low';
  const c=drawBase(), s=sourceCanvas.width/900;
  c.lineWidth=Math.max(2,3*s); c.font=`${Math.round(20*s)}px -apple-system,sans-serif`;
  // thermal centroid
  c.strokeStyle='#27d3ff'; c.beginPath();c.arc(r.red.component.cx,r.red.component.cy,10*s,0,Math.PI*2);c.stroke();
  c.fillStyle='#27d3ff';c.fillText('Red centroid',r.red.component.cx+14*s,r.red.component.cy-12*s);
  // cross center
  c.strokeStyle='#fff32e'; c.beginPath();c.moveTo(r.cross.x-12*s,r.cross.y);c.lineTo(r.cross.x+12*s,r.cross.y);c.moveTo(r.cross.x,r.cross.y-12*s);c.lineTo(r.cross.x,r.cross.y+12*s);c.stroke();
  // perpendicular measurement line
  c.strokeStyle='#ffffff'; c.setLineDash([8*s,5*s]);c.beginPath();
  if(r.direction==='up'){c.moveTo(r.cross.x,r.cross.y);c.lineTo(r.red.component.cx,r.cross.y);} else {c.moveTo(r.cross.x,r.cross.y);c.lineTo(r.cross.x,r.red.component.cy);} c.stroke();c.setLineDash([]);
  // scale tick candidates
  c.strokeStyle='rgba(255,190,70,.9)'; c.lineWidth=Math.max(1,2*s); for(const y of (r.scale.peaks||[])){c.beginPath();c.moveTo(sourceCanvas.width*.90,y);c.lineTo(sourceCanvas.width*.985,y);c.stroke();}
  c.fillStyle='rgba(0,0,0,.68)';c.fillRect(12*s,12*s,250*s,54*s);c.fillStyle='#fff';c.fillText(`${r.direction==='up'?'Horizontal':'Vertical'} offset: ${r.mm.toFixed(1)} mm`,24*s,47*s);
}

function retake(){ resultPanel.hidden=true;cameraPanel.hidden=false;overrideDirection=null;overridePxPerMm=null;manualTickPoints=[]; setChipStates(); startCamera(); }
function setChipStates(){
  $('#forceAuto').classList.toggle('active',!overrideDirection);$('#forceUp').classList.toggle('active',overrideDirection==='up');$('#forceRight').classList.toggle('active',overrideDirection==='right');
  $('#autoScale').classList.toggle('active',!overridePxPerMm);$('#manualScale').classList.toggle('active',!!overridePxPerMm);
}
function rerun(){ if(lastImageData) analyzeCurrent(); setChipStates(); }

$('#startCamera').onclick=startCamera; $('#capture').onclick=captureGuideFromVideo; $('#choosePhoto').onclick=()=>{$('#fileInput').removeAttribute('capture');$('#fileInput').click();};
$('#fileInput').onchange=e=>{const f=e.target.files&&e.target.files[0]; if(f)loadPhoto(f); e.target.value='';}; $('#retake').onclick=retake;
$('#forceUp').onclick=()=>{overrideDirection='up';rerun();}; $('#forceRight').onclick=()=>{overrideDirection='right';rerun();}; $('#forceAuto').onclick=()=>{overrideDirection=null;rerun();};
$('#autoScale').onclick=()=>{overridePxPerMm=null;manualTickPoints=[];$('#manualNote').textContent='';rerun();};
$('#manualScale').onclick=()=>{ manualTickPoints=[]; overridePxPerMm=null; setChipStates(); $('#manualNote').textContent='Tap the centers of two adjacent 1 mm tick marks on the image.'; };
resultCanvas.addEventListener('click',e=>{
  if($('#manualNote').textContent.indexOf('Tap the centers')!==0)return;
  const r=resultCanvas.getBoundingClientRect(), y=(e.clientY-r.top)*resultCanvas.height/r.height; manualTickPoints.push(y);
  if(manualTickPoints.length===1) $('#manualNote').textContent='Tap the center of the adjacent tick mark.';
  else { overridePxPerMm=Math.abs(manualTickPoints[1]-manualTickPoints[0]); if(overridePxPerMm<3){manualTickPoints=[];overridePxPerMm=null;$('#manualNote').textContent='Ticks were too close. Tap two adjacent 1 mm ticks again.';} else {$('#manualNote').textContent=`Manual scale: ${overridePxPerMm.toFixed(1)} px/mm`;rerun();} }
});

if('serviceWorker' in navigator){ window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{})); }
window.addEventListener('beforeunload',stopCamera);
startCamera();
