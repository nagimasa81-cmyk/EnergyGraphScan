# LocAcc v0.1.3

Offline iPhone Safari PWA for thermal hotspot location accuracy measurement.

## Measurement rules
- lower-right `^` marker => measure the **R-L (RL)** axis.
- lower-right `>` marker => measure the vertical anatomical pair detected from the edge annotations: **S-I (SI)** or **A-P (AP)**.
- Red thermal overlay center = geometric centroid of a filled red silhouette (moire gaps are filled before centroid calculation).
- Cross center = intersection of the yellow/green cross arms.
- Ruler = **6 ticks / 5 intervals / 5 mm total**; calibration uses the entire 5 mm span.
- Anatomical edge annotations are used for sign. **R, S and A are positive**; L, I and P are negative.
- Result is displayed to 0.1 mm.

## GitHub Pages path
Deploy the contents to `Module/LocAcc/`. Safari URL:
`https://<GitHub-user>.github.io/<repository>/Module/LocAcc/`

The Service Worker uses relative URLs so the PWA remains scoped to `Module/LocAcc/` and works offline after initial caching.


## Result notation (v0.1.4)
Results use anatomical axis names only: **RL / SI / AP**. R, S and A are positive; L, I and P are negative. Example: `RL +0.1 mm (R)`. Horizontal/Vertical are not used as the user-facing measurement-axis names.
