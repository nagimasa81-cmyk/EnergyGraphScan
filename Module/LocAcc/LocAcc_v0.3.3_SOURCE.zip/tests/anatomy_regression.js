
(() => {
  "use strict";

  const $ = q => document.querySelector(q);
  const filesEl = $("#samples");
  const runEl = $("#run");
  const outEl = $("#out");
  const downloadEl = $("#download");

  function normalizeLibraryImage(img){
    const side=Math.min(img.naturalWidth,img.naturalHeight);
    const sx=(img.naturalWidth-side)/2;
    const sy=(img.naturalHeight-side)/2;
    const out=Math.min(3000,side);

    const c=document.createElement("canvas");
    c.width=out;c.height=out;
    const x=c.getContext("2d",{willReadFrequently:true});
    x.imageSmoothingEnabled=true;
    x.imageSmoothingQuality="high";
    x.drawImage(img,sx,sy,side,side,0,0,out,out);
    return c;
  }

  function loadImage(file){
    return new Promise((resolve,reject)=>{
      const url=URL.createObjectURL(file);
      const img=new Image();
      img.onload=()=>{ URL.revokeObjectURL(url); resolve(img); };
      img.onerror=()=>{ URL.revokeObjectURL(url); reject(new Error("Image load failed")); };
      img.src=url;
    });
  }

  function summarize(r,file){
    const h=r.anatomy&&r.anatomy.horizontal;
    const v=r.anatomy&&r.anatomy.vertical;
    return {
      file:file.name,
      size:file.size,
      horizontal:h?{
        axis:h.axis,
        positiveLabel:h.positiveLabel,
        negativeLabel:h.negativeLabel,
        confidence:h.confidence
      }:null,
      vertical:v?{
        axis:v.axis,
        positiveLabel:v.positiveLabel,
        negativeLabel:v.negativeLabel,
        confidence:v.confidence,
        inferredFromSingleSide:!!v.inferredFromSingleSide,
        inferredSide:v.inferredSide||null,
        inferredLabel:v.inferredLabel||null
      }:null,
      detectedPairCount:r.anatomy&&r.anatomy.detectedPairCount,
      detector:r.anatomy&&r.anatomy.detector,
      geometryConfidence:r.geometryConfidence,
      scalePxPerMm:r.pxPerMm,
      reference:r.reference&&r.reference.type,
      validAxes:(!h||!v||h.axis!==v.axis)
    };
  }

  async function run(){
    const files=[...(filesEl.files||[])];
    if(!files.length){ outEl.textContent="Choose raw source images first."; return; }

    runEl.disabled=true;
    const report={
      harness:"LocAcc Anatomy Regression v0.3.2",
      generatedAt:new Date().toISOString(),
      results:[]
    };

    for(let i=0;i<files.length;i++){
      const file=files[i];
      outEl.textContent=`${i+1}/${files.length} ${file.name}`;
      try{
        const img=await loadImage(file);
        const c=normalizeLibraryImage(img);
        const x=c.getContext("2d",{willReadFrequently:true});
        const data=x.getImageData(0,0,c.width,c.height);
        const r=LocAccCore.analyze(data,c.width,c.height,{inputSourceType:"library"});
        report.results.push({...summarize(r,file),status:"PASS"});
      }catch(e){
        report.results.push({file:file.name,status:"ERROR",error:String(e&&e.message||e)});
      }
      await new Promise(requestAnimationFrame);
    }

    const text=JSON.stringify(report,null,2);
    outEl.textContent=text;
    downloadEl.disabled=false;
    downloadEl.onclick=()=>{
      const blob=new Blob([text],{type:"application/json"});
      const a=document.createElement("a");
      a.href=URL.createObjectURL(blob);
      a.download="LocAcc_Anatomy_Regression.json";
      a.click();
      setTimeout(()=>URL.revokeObjectURL(a.href),2000);
    };
    runEl.disabled=false;
  }

  runEl.addEventListener("click",run);
})();
