(function(){
'use strict';
const core=window.EGSV2Core;
const $=id=>document.getElementById(id);
const camera=$('cameraInput'), file=$('fileInput'), progress=$('progressCard'), previewCard=$('previewCard'), resultCard=$('resultCard');
const preview=$('previewImage'), overlay=$('overlayCanvas');
const APP_VERSION='2.0.7-r5', APP_BRANCH='r5', APP_BUILD='20260818-spectrumreader-2.0.7-r5';
let currentUrl=null, originalSize=null, analysisSize=null;
let worker=null,jobSeq=0,pending=new Map(),activeRun=0;
function createWorker(){
  try{
    const w=new Worker('./worker.js');
    w.onmessage=e=>{const m=e.data||{},p=pending.get(m.id);if(!p)return;pending.delete(m.id);m.ok?p.resolve(m.result):p.reject(Object.assign(new Error(m.error||'Worker analysis failed'),{stack:m.stack||''}));};
    w.onerror=e=>{for(const p of pending.values())p.reject(new Error(e.message||'Worker error'));pending.clear();if(worker===w)worker=null;};
    return w;
  }catch(_){return null;}
}
function resetWorker(){
  if(worker){try{worker.terminate()}catch(_){}}
  for(const p of pending.values())p.reject(Object.assign(new Error('Analysis superseded'),{code:'SUPERSEDED'}));
  pending.clear(); worker=createWorker();
}
worker=createWorker();

function show(el,on=true){el.classList.toggle('hidden',!on)}
function setProgress(text){$('progressText').textContent=text;show(progress,true);show(resultCard,false)}
function nextFrame(){return new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))}

async function fileToRGBA(file,runId){
  const url=URL.createObjectURL(file);
  const img=new Image(); img.decoding='async'; img.src=url; await img.decode();
  if(runId!==activeRun){URL.revokeObjectURL(url);throw Object.assign(new Error('Analysis superseded'),{code:'SUPERSEDED'});}
  if(currentUrl)URL.revokeObjectURL(currentUrl); currentUrl=url;
  originalSize={width:img.naturalWidth,height:img.naturalHeight};
  analysisSize={width:img.naturalWidth,height:img.naturalHeight};
  preview.src=url; show(previewCard,true);
  // Preserve source pixels here. The v2 core owns canonicalization; an extra UI resize
  // can change safe axis margins and therefore is intentionally not performed.
  const c=document.createElement('canvas'); c.width=img.naturalWidth;c.height=img.naturalHeight;
  const x=c.getContext('2d',{willReadFrequently:true,alpha:false});x.drawImage(img,0,0);
  const rgba=x.getImageData(0,0,c.width,c.height);
  // Release the full-resolution canvas backing store immediately. The ImageData buffer
  // is transferred (not copied) to the Worker below, so source pixels remain exact.
  c.width=1;c.height=1;
  return rgba;
}

function analyzeRGBA(rgba){
  if(!worker)return Promise.resolve(core.analyze(rgba));
  const id=++jobSeq, buffer=rgba.data.buffer;
  // Transfer ownership of the original ImageData buffer. Do not allocate a second
  // full-resolution RGBA copy: this preserves pixels exactly and cuts peak memory.
  return new Promise((resolve,reject)=>{pending.set(id,{resolve,reject});worker.postMessage({type:'analyze',id,width:rgba.width,height:rgba.height,buffer},[buffer]);});
}

function canonicalScaleFor(w,h){const s=1200/Math.max(w,h);return Math.abs(s-1)<.01?1:s}
function clearOverlay(){const ctx=overlay.getContext('2d');overlay.width=1;overlay.height=1;ctx.clearRect(0,0,1,1)}
function drawAcceptedLines(result){
  const ctx=overlay.getContext('2d'); const w=analysisSize.width,h=analysisSize.height;overlay.width=w;overlay.height=h;ctx.clearRect(0,0,w,h);
  if(!result.accepted)return;
  const scale=canonicalScaleFor(w,h), p=result.plot, ax=result.axis;
  function line(samples,label,dash){
    if(!samples||samples.length<2)return;
    ctx.save();ctx.lineWidth=Math.max(2,w/700);ctx.strokeStyle=dash?'#55b9ff':'#ffbd4a';ctx.setLineDash(dash?[8,5]:[]);ctx.beginPath();
    let started=false;
    for(const s of samples){
      const xc=p.left+(s.x/500)*(p.right-p.left), yc=(s.value-ax.intercept)/ax.slope, x=xc/scale,y=yc/scale;
      if(!Number.isFinite(x)||!Number.isFinite(y))continue;
      if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y);
    }
    ctx.stroke();ctx.restore();
  }
  line(result.low?.displayLine,'Low',false); line(result.high?.displayLine,'High',true);
}
function friendlyReason(result){
  const r=String(result.reason||'');
  if(result.stage==='geometry')return 'Capture only the black Energy per Band plot. Keep the complete plot, X=0–500 grid, and visible Y-axis labels in frame.';
  if(result.stage==='axis')return 'Y-axis scale could not be read safely. Keep the green numeric Y labels sharp and fully visible.';
  if(result.stage==='trace'){
    if(/sampling consensus/i.test(r))return 'The trace changed too much across internal sampling checks. Retake the photo more sharply and avoid UI overlays or other plotted data.';
    if(/identity mismatch/i.test(r))return 'Low and High appear to come from different foreground traces. Retake the graph without overlapping traces or UI elements.';
    if(/population margin/i.test(r))return 'Two different trace populations were too similar to choose safely. Retake the graph with the Energy trace clearly separated.';
    if(/Low foreground persistence/i.test(r))return 'The Low range looked like a short UI/marker cluster instead of a continuous trace. Retake with only the Energy plot visible.';
    if(/High foreground span/i.test(r))return 'The High range did not span enough of the graph to identify safely. Retake with the full Energy plot visible.';
    if(/Bilateral X lattice|X=500 right-edge|X=0 vertical axis/i.test(r))return 'The Energy grid edges could not be confirmed safely. Keep the complete X=0–500 black plot in frame, including both left and right grid edges.';
    if(/too localized across X/i.test(r))return 'Accepted trace samples were concentrated in only part of the X range. Retake with the full 0–500 Energy plot sharp and unobstructed.';
    if(/Y distribution is unstable/i.test(r))return 'Accepted trace samples were too vertically inconsistent to report a safe average. Retake the Energy plot sharply and without overlapping marks.';
    if(/excessive extrapolation/i.test(r))return 'The trace would require too much extrapolation beyond the visible Y-axis labels. Retake with more Y-axis labels visible.';
    return 'The Energy trace could not be separated safely from UI or other plotted data. Retake the photo with only the Energy per Band plot visible.';
  }
  return result.reason||'Safe validation did not converge.';
}
function summarize(result){
  return JSON.stringify({appVersion:APP_VERSION,branch:APP_BRANCH,build:APP_BUILD,status:result.status,stage:result.stage||'done',reason:result.reason||null,plot:result.plot?{left:result.plot.left,right:result.plot.right,vStep:result.plot.vStep}:null,axis:result.axis?.accepted?{step:result.axis.step,slope:result.axis.slope,intercept:result.axis.intercept,mode:result.axis.diagnostics?.mode}:null,low:result.low?{mean:result.low.mean,count:result.low.count}:null,high:result.high?{mean:result.high.mean,count:result.high.count}:null,traceConfidence:result.traceConfidence||null,traceStability:result.traceStability?{lowStepSpan:result.traceStability.lowStepSpan,highStepSpan:result.traceStability.highStepSpan,marginConsensus:result.traceStability.marginConsensus}:null},null,2)
}
function showConfidence(result){
  const c=result.traceConfidence, card=$('confidenceCard');
  if(!result.accepted||!c){show(card,false);return;}
  show(card,true);card.classList.remove('strong','good','borderline');card.classList.add(c.level);
  $('confidenceValue').textContent=`${c.score}/100 · ${c.level}`;
  $('confidenceBar').style.width=`${c.score}%`;
  const names={sampling:'Sampling',lowPersistence:'Low continuity',highSpan:'High span',identity:'Trace identity',margin:'Population margin',grid:'Grid separation'};
  $('confidenceParts').innerHTML=Object.entries(c.parts||{}).map(([k,v])=>`<span>${names[k]||k}: ${v}</span>`).join('');
}
function resetForNewImage(){
  show(resultCard,false);show($('values'),false);show($('attention'),false);show($('confidenceCard'),false);$('diagText').textContent='';$('lowValue').textContent='—';$('highValue').textContent='—';$('confidenceValue').textContent='—';$('confidenceBar').style.width='0';$('confidenceParts').textContent='';clearOverlay();
}
async function analyzeFile(file){
  if(!file)return;
  const runId=++activeRun; resetWorker(); resetForNewImage();
  try{
    setProgress('Decoding captured image'); await nextFrame();
    const rgba=await fileToRGBA(file,runId); if(runId!==activeRun)return;
    setProgress('Running v2 safe analysis'); await nextFrame();
    const result=await analyzeRGBA(rgba); if(runId!==activeRun)return;
    drawAcceptedLines(result); show(progress,false); show(resultCard,true);
    $('diagText').textContent=summarize(result);showConfidence(result);
    if(result.accepted){
      $('resultState').textContent='Analysis accepted';show($('values'),true);show($('attention'),false);
      $('lowValue').textContent=Number(result.low.mean).toFixed(5);$('highValue').textContent=Number(result.high.mean).toFixed(5);
      resultCard.scrollIntoView({behavior:'smooth',block:'start'});resultCard.focus({preventScroll:true});
    }else{
      $('resultState').textContent='Analysis not accepted';show($('values'),false);show($('attention'),true);
      $('attentionReason').textContent=friendlyReason(result);
      resultCard.scrollIntoView({behavior:'smooth',block:'start'});
    }
  }catch(err){if(runId!==activeRun||err?.code==='SUPERSEDED')return;show(progress,false);show(resultCard,true);show($('values'),false);show($('attention'),true);$('resultState').textContent='Analysis error';$('attentionReason').textContent=String(err&&err.message||err);$('diagText').textContent=String(err&&err.stack||err);resultCard.scrollIntoView({behavior:'smooth',block:'start'});}
}
[camera,file].forEach(inp=>inp.addEventListener('change',()=>{const f=inp.files&&inp.files[0]; if(f)analyzeFile(f); inp.value='';}));
window.addEventListener('resize',()=>{if(preview.naturalWidth){overlay.style.width=preview.clientWidth+'px';overlay.style.height=preview.clientHeight+'px';}});
window.addEventListener('pagehide',()=>{if(currentUrl)URL.revokeObjectURL(currentUrl);if(worker)worker.terminate();});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
})();
