# Energy Graph Scan dev16 numeric5 runtime2 実機 validation

## 目的
このvalidationはfamily/classificationだけでなく、Low/High数値、JPEG decode再現性、Worker/direct、PWA cacheを同時に確認します。

## Online validation
1. HTTPSで `validation.html` をSafari/Chromeで開く。
2. Environmentで Core SHA、Expected cache、Cached core SHA、Worker cached、Validation cached、Fixture cache 8/8 を確認する。初回はService Worker更新のため数秒待って自動判定される。
3. `Run bundled 8-gate numeric suite` を押す。
4. 8/8 PASSを確認する。各画像は2回decodeされ、RGBA pixel SHAが一致しない場合はFAIL。
5. Low/Highはreferenceから0.02 axis-step以内が必須。familyが正しくても数値が外れればFAIL。
6. `Export validation JSON` でオンライン結果を保存する。JSONにはuserAgent、Canvas colorSpace、pixel SHA、decode pixel parity、Worker/direct parity、Low/High、reference、deltaSteps、cache状態が含まれる。

## Offline / PWA validation
1. Online validationを8/8 PASSさせ、Fixture cache 8/8を確認する。
2. iPhoneを機内モードにする。
3. `validation.html` を再読込する。PWAホーム画面版を使う場合も同じ。
4. Core SHA / Cached core SHA / Expected cacheを確認し、再度 bundled 8-gate を実行する。
5. 8/8 PASS後、もう一度JSONをExportする。
6. Online/OfflineのJSONで各gateの `decoded.pixelSha256`、`numericDeltaSteps`、`workerDirectParity` を比較する。

## 重要なPASS条件
- Core SHA: `30f7e76675493ac901b2163e34f66afc132bca8f564298408aaaa3e8db850e2f`
- Expected cache: `egs-v2-pwa-20260826-spectrumreader-dev16-numeric5-30f7e766-runtime2`
- Decode pixel parity: 全8件 true
- Worker/direct parity: 全8件 true
- Numeric tolerance: 0.02 axis-step以内
- IMG_2406: physicalBandRescue=true。ただしlower-envelope diagnostic candidateはreported Low/Highへ適用しない。

production coreはfixture名やexpected値をcontrol-flowに使用しません。reference値はvalidation層だけにあります。
