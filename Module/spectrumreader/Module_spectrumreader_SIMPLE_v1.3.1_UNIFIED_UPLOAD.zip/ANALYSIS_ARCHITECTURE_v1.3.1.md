# Energy Graph Simple v1.3.0 — Unified Core v6

This release is a logic rebase, not an incremental OCR patch.

## Authoritative pipeline

1. **Energy plot isolation**
   - Finds dark graph bands row-by-row.
   - Selects the first graph with a credible green grid.
   - Prevents the lower `Raw Data from A2D` plot from entering trace analysis.

2. **Grid geometry**
   - Grid search occurs only inside the selected Energy plot.
   - Horizontal and vertical line candidates are fitted to regular lattices.
   - Missing grid members are reconstructed from the local lattice.

3. **Y-axis solve**
   - Uses whole-label masks at horizontal-grid locations.
   - Mask normalization preserves aspect ratio.
   - `3.0` and `0.03000` are therefore not stretched into the same apparent width.
   - Complete decimal/compact lattices compete globally.
   - Bottom value is not assumed to be zero.

4. **Trace**
   - Trace pixels are accepted only inside the selected Energy plot.
   - Colored and white traces are handled.
   - White tooltip interiors are rejected using neighborhood darkness.
   - One robust representative is extracted per X bin.

5. **Low/High**
   - X domain is mapped once from Energy-plot left/right to 0..500.
   - Low = 0..260.
   - High = 270..500.
   - Robust mean removes isolated spikes.

6. **Validation**
   - Low/High must remain inside the visible Y-axis range.
   - Trace cannot escape the Energy plot.
   - Overlay pixel positions must invert through the same Y calibration.
   - There is no independent old fallback allowed to generate values.

## Important design rule

The deployed runtime contains one value-producing path only. Old OCR2/OCR3/OCR4 and old pixel fallback calibration paths are not part of the deployed v1.3.0 runtime.

## v1.3.1 / Unified Core v7

- Plot localization no longer uses a narrow aspect ratio as a primary acceptance rule.
- Multiple black graph candidates are refined and ranked by orthogonal green-lattice evidence.
- Y-axis family is inferred first from observed label geometry (width/height), then numeric lattice models compete inside that family.
- Green foreground traces are retained. Grid rejection is geometric: only pixels near already-solved H/V grid lines are removed.
