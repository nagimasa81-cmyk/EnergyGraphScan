Deploy Module PWAs to Pages v2.0

Spectrum Reader input modes supported under Module/spectrumreader/:

A) Normal SOURCE ZIP
   Energy_Graph_..._spectrumreader.zip

B) Loose split set
   Energy_Graph_..._spectrumreader.zip.part01
   Energy_Graph_..._spectrumreader.zip.part02
   ...
   Energy_Graph_..._spectrumreader.zip.parts.json
   Energy_Graph_..._spectrumreader.zip.sha256

C) New convenient packaged split set
   Energy_Graph_..._SPLIT_PACKAGE.zip
   Energy_Graph_..._SPLIT_PACKAGE.zip.sha256

For mode C, only the SPLIT_PACKAGE ZIP and its SHA256 sidecar need to be
uploaded into Module/spectrumreader/.  The workflow verifies the outer SHA256,
safely extracts it, validates the inner manifest, each split-part SHA256/size,
reconstructs the original SOURCE ZIP, validates its SHA256 and ZIP CRC, and
then deploys the newest valid module version.

LocAcc handling remains unchanged.
