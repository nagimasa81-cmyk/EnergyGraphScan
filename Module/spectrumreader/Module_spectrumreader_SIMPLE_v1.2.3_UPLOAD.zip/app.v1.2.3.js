
const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');

let ready=false;
const workCanvas=document.createElement('canvas'),
      workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
let analysisScale=1;
let sourceWidth=1,sourceHeight=1;
let workImageData=null;

function releaseWorkPixels(){ workImageData=null; }
function getWorkPixels(){
  if(!workImageData)
    workImageData=workCtx.getImageData(0,0,workCanvas.width,workCanvas.height);
  return workImageData;
}

function prepareWorkingImage(){
  // 1100px is enough for the visible Y labels while remaining safe on iPhone Safari.
  const maxSide=1100,
        sw=canvas.width,sh=canvas.height,
        scale=Math.min(1,maxSide/Math.max(sw,sh));
  analysisScale=scale;
  workCanvas.width=Math.max(1,Math.round(sw*scale));
  workCanvas.height=Math.max(1,Math.round(sh*scale));
  workCtx.clearRect(0,0,workCanvas.width,workCanvas.height);
  workCtx.drawImage(canvas,0,0,workCanvas.width,workCanvas.height);
  releaseWorkPixels();
  // One pixel-buffer allocation for the entire analysis.
  getWorkPixels();
  return {canvas:workCanvas,ctx:workCtx,scale};
}
function toOriginalX(x){return x/analysisScale}
function toOriginalY(y){return y/analysisScale}


function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){if(!a.length)return NaN;const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden'); $('progressPct').textContent=`${p}%`; $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label; $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');$('lowValue').textContent='—';$('highValue').textContent='—';$('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;releaseWorkPixels();sourceWidth=1;sourceHeight=1;workCanvas.width=1;workCanvas.height=1;canvas.width=1;canvas.height=1;canvas.style.display='none';
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;$('status').textContent='Ready';$('progressCard').classList.add('hidden');clearResult();
}
async function loadFile(file,autoAnalyze=true){
  clearResult();
  releaseWorkPixels();
  $('progressCard').classList.add('hidden');
  $('status').textContent='Loading full-resolution photo…';
  $('analyzeBtn').disabled=true;
  let bmp=null;
  try{
    bmp=await createImageBitmap(file);
    sourceWidth=bmp.width; sourceHeight=bmp.height;

    // IMPORTANT: the capture/file remains full resolution, but the DOM preview canvas
    // is bounded to avoid ~50 MB RGBA allocations on 4032x3024 iPhone photos.
    const previewMaxSide=1600,
          ps=Math.min(1,previewMaxSide/Math.max(sourceWidth,sourceHeight)),
          pw=Math.max(1,Math.round(sourceWidth*ps)),
          ph=Math.max(1,Math.round(sourceHeight*ps));
    canvas.width=pw; canvas.height=ph;
    ctx.clearRect(0,0,pw,ph);
    ctx.drawImage(bmp,0,0,pw,ph);
    if(typeof bmp.close==='function')bmp.close();
    bmp=null;

    canvas.style.display='block';
    document.querySelector('.placeholder').style.display='none';
    ready=true;
    $('analyzeBtn').disabled=false;
    $('status').textContent=`Loaded — source ${sourceWidth}×${sourceHeight}px · analysis preview ${pw}×${ph}px`;

    if(autoAnalyze){
      $('status').textContent=`Loaded — ${sourceWidth}×${sourceHeight}px · starting analysis…`;
      await new Promise(r=>requestAnimationFrame(()=>r()));
      await analyze();
    }
  }catch(e){
    if(bmp&&typeof bmp.close==='function')try{bmp.close()}catch(_){}
    ready=false;
    $('analyzeBtn').disabled=true;
    $('status').textContent=`Image load failed: ${e.message||e}`;
    setProgress(100,'Needs attention',`Image load failed: ${e.message||e}`);
  }
}
$('cameraBtn').onclick=()=>{ $('fileCamera').value=''; $('fileCamera').click(); };
$('libraryBtn').onclick=()=>{ $('fileLibrary').value=''; $('fileLibrary').click(); };
$('fileCamera').onchange=async e=>{ const file=e.target.files&&e.target.files[0]; if(file) await loadFile(file,true); };
$('fileLibrary').onchange=async e=>{ const file=e.target.files&&e.target.files[0]; if(file) await loadFile(file,true); };
$('resetBtn').onclick=reset;

function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h;
  if(mx===r)h=60*(((g-b)/d)%6);else if(mx===g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function isGreen(r,g,b){return g>55&&g>r*1.12&&g>b*1.12}
function preprocess(){
  const im=getWorkPixels(),d=im.data,hist=new Uint32Array(256);
  let n=0;
  for(let i=0;i<d.length;i+=4){
    const lum=Math.max(0,Math.min(255,Math.round(.299*d[i]+.587*d[i+1]+.114*d[i+2])));
    hist[lum]++;n++;
  }
  function q(frac){
    const target=Math.max(0,Math.floor((n-1)*frac));let acc=0;
    for(let i=0;i<256;i++){acc+=hist[i];if(acc>target)return i}
    return 255;
  }
  const lo=q(.04),hi=q(.98),span=Math.max(20,hi-lo);
  return {im,lo,hi,span};
}
function lineScores(axis){
  const {width:W,height:H}=workCanvas,im=getWorkPixels().data;
  const N=axis==='h'?H:W,scores=new Array(N).fill(0);
  for(let p=0;p<N;p++){
    let green=0,dark=0,n=0;
    const M=axis==='h'?W:H;
    for(let k=0;k<M;k+=Math.max(1,Math.floor(M/700))){
      const x=axis==='h'?k:p,y=axis==='h'?p:k,i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],lum=(r+g+b)/3;
      n++; if(isGreen(r,g,b))green++; if(lum<100)dark++;
    }
    scores[p]=green/n*.8+dark/n*.2;
  }
  return scores;
}
function peaks(scores,minGap){
  const cand=[];for(let i=2;i<scores.length-2;i++)if(scores[i]>scores[i-1]&&scores[i]>=scores[i+1])cand.push({i,s:scores[i]});
  cand.sort((a,b)=>b.s-a.s);const out=[];
  for(const c of cand){if(out.every(x=>Math.abs(x-c.i)>minGap))out.push(c.i);if(out.length>=18)break}
  return out.sort((a,b)=>a-b);
}
function detectPlot(){
  const hp=peaks(lineScores('h'),Math.max(4,workCanvas.height*.03));
  const vp=peaks(lineScores('v'),Math.max(5,workCanvas.width*.035));
  if(hp.length<3||vp.length<4) throw Error('Grid detection failed. Include the full black graph.');
  // choose densest regularly spaced runs
  function regular(arr){
    let best=null;
    for(let i=0;i<arr.length;i++)for(let j=i+2;j<arr.length;j++){
      const sub=arr.slice(i,j+1),ds=sub.slice(1).map((v,k)=>v-sub[k]),m=median(ds),e=median(ds.map(x=>Math.abs(x-m)));
      const score=sub.length/(1+e/Math.max(1,m));
      if(!best||score>best.score)best={arr:sub,step:m,score};
    } return best;
  }
  const H=regular(hp),V=regular(vp); if(!H||!V) throw Error('Grid lattice unresolved.');
  return {left:V.arr[0],right:V.arr.at(-1),top:H.arr[0],bottom:H.arr.at(-1),h:H.arr,v:V.arr};
}
function estimateY(plot){
  // Infer numeric step primarily from green horizontal-grid spacing + image label morphology.
  // For simple version support the two families actually used in these graphs:
  // Gain usually step 1; Noise commonly .005 or .01.
  const stepPx=median(plot.h.slice(1).map((y,i)=>y-plot.h[i]));
  const W=canvas.width,im=ctx.getImageData(0,0,W,canvas.height).data;
  // Find decimal-label ink/green activity left of y-axis.
  const lx0=Math.max(0,plot.left-Math.round((plot.right-plot.left)*.25)),lx1=plot.left;
  let tiny=0,total=0;
  for(let y=plot.top;y<=plot.bottom;y++)for(let x=lx0;x<lx1;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2]; if(isGreen(r,g,b)){total++; if(g<190)tiny++}
  }
  // Use plot height/trace location as family-independent scale candidate set.
  // We score candidates using visible horizontal grid count and trace plausibility.
  const candidates=[1,.5,.02,.01,.005,.001];
  return {stepPx,candidates};
}

async function traceHue(plot,onProgress){
  const W=workCanvas.width,H=workCanvas.height,
        im=getWorkPixels().data,
        bins=new Array(36).fill(0),
        xStep=Math.max(2,Math.round((plot.right-plot.left)/220)),
        yStep=Math.max(2,Math.round((plot.bottom-plot.top)/140)),
        total=Math.max(1,Math.ceil((plot.right-plot.left+1)/xStep)),
        yieldEvery=28;
  let xi=0;
  for(let x=plot.left;x<=plot.right;x+=xStep){
    for(let y=plot.top;y<=plot.bottom;y+=yStep){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
            mx=Math.max(r,g,b),mn=Math.min(r,g,b),
            sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.20&&lum>55&&!isGreen(r,g,b))
        bins[Math.floor(rgb2hue(r,g,b)/10)]++;
    }
    xi++;
    if(xi%yieldEvery===0){
      if(onProgress)onProgress(xi/total);
      await new Promise(r=>setTimeout(r,0));
    }
  }
  let bi=0;
  for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  if(onProgress)onProgress(1);
  return bi*10+5;
}

function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}

function rgbStats(r,g,b){
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3;
  return {mx,mn,lum,sat:(mx-mn)/Math.max(1,mx),h:rgb2hue(r,g,b)};
}
function greenStrength(r,g,b){return g-Math.max(r,b)*0.82}
function integralMask(mask,W,H){
  const I=new Uint32Array((W+1)*(H+1));
  for(let y=1;y<=H;y++){
    let row=0;
    for(let x=1;x<=W;x++){
      row+=mask[(y-1)*W+(x-1)];
      I[y*(W+1)+x]=I[(y-1)*(W+1)+x]+row;
    }
  }
  return I;
}
function rectSum(I,W,x0,y0,x1,y1){
  const H=(I.length/(W+1))-1,S=W+1;
  x0=Math.max(0,Math.min(W,x0));x1=Math.max(0,Math.min(W,x1));
  y0=Math.max(0,Math.min(H,y0));y1=Math.max(0,Math.min(H,y1));
  return I[y1*S+x1]-I[y0*S+x1]-I[y1*S+x0]+I[y0*S+x0];
}
function detectBlackPlot(){
  const W=workCanvas.width,H=workCanvas.height,im=getWorkPixels().data,
        dark=new Uint8Array(W*H),green=new Uint8Array(W*H);
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    if(st.lum<95)dark[y*W+x]=1;
    if(greenStrength(r,g,b)>18&&g>55)green[y*W+x]=1;
  }
  const D=integralMask(dark,W,H),G=integralMask(green,W,H);
  let best=null;
  const minW=Math.max(140,Math.round(W*.30)),maxW=Math.round(W*.76),
        minH=Math.max(90,Math.round(H*.15)),maxH=Math.round(H*.50),
        sx=Math.max(10,Math.round(W/50)),sy=Math.max(10,Math.round(H/50));
  for(let h=minH;h<=maxH;h+=sy)for(let w=minW;w<=maxW;w+=sx)
    for(let y=Math.round(H*.08);y+h<=H;y+=sy)for(let x=Math.round(W*.08);x+w<=W;x+=sx){
      const area=w*h,d=rectSum(D,W,x,y,x+w,y+h)/area;
      if(d<.50)continue;
      const gr=rectSum(G,W,x,y,x+w,y+h)/area,
            score=d*2.5+gr*1.1+(x/W)*.15-Math.abs(w/h-1.8)*.08;
      if(!best||score>best.score)best={left:x,top:y,right:x+w,bottom:y+h,score};
    }
  if(!best)throw Error('Black Energy per Band plot could not be localized.');
  return best;
}
function detectGreenGrid(plot){
  const W=workCanvas.width,im=getWorkPixels().data,
        rows=[],cols=[];
  for(let y=plot.top;y<=plot.bottom;y++){
    let c=0,n=0;
    for(let x=plot.left;x<=plot.right;x+=2){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenStrength(r,g,b)>14&&g>45)c++;
      n++;
    }
    rows.push({p:y,s:c/Math.max(1,n)});
  }
  for(let x=plot.left;x<=plot.right;x++){
    let c=0,n=0;
    for(let y=plot.top;y<=plot.bottom;y+=2){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenStrength(r,g,b)>14&&g>45)c++;
      n++;
    }
    cols.push({p:x,s:c/Math.max(1,n)});
  }
  function peaks(arr,minSep,thr,maxN){
    const out=[];
    for(const q of [...arr].sort((a,b)=>b.s-a.s)){
      if(q.s<thr)break;
      if(out.some(p=>Math.abs(p-q.p)<minSep))continue;
      out.push(q.p);
      if(out.length>=maxN)break;
    }
    return out.sort((a,b)=>a-b);
  }
  let h=peaks(rows,Math.max(6,Math.round((plot.bottom-plot.top)/18)),.075,12),
        v=peaks(cols,Math.max(6,Math.round((plot.right-plot.left)/22)),.075,14);
  // photographed displays can make thin grid lines sparse; retry with a lower threshold
  if(h.length<2) h=peaks(rows,Math.max(6,Math.round((plot.bottom-plot.top)/18)),.040,12);
  if(v.length<3) v=peaks(cols,Math.max(6,Math.round((plot.right-plot.left)/22)),.040,14);
  if(h.length<2)throw Error('Horizontal green grid could not be resolved.');
  if(v.length<3)throw Error('Vertical green grid could not be resolved.');
  return {h,v};
}


// ======================= Y-axis OCR Engine 3 =======================
// Family-first numeric recognition for photographed Energy per Band axes.
// The image decides decimal (0.02000) vs compact (1.0 / 2.0) BEFORE value matching.
// No bottom=zero assumption is used.

function axisLabelRegion(plot,grid,y,rowStep){
  const axisX=(grid.v&&grid.v.length)?grid.v[0]:Math.round(plot.left+(plot.right-plot.left)*.20),
        x0=Math.max(plot.left+1,Math.round(plot.left+(axisX-plot.left)*.01)),
        x1=Math.max(x0+12,axisX-1),
        half=Math.max(5,Math.round(rowStep*.43)),
        y0=Math.max(0,Math.round(y-half)),
        y1=Math.min(workCanvas.height,Math.round(y+half));
  return {axisX,x0,x1,y0,y1,W:Math.max(1,x1-x0),H:Math.max(1,y1-y0)};
}

function numericMaskVariants(plot,grid,y,rowStep){
  const R=axisLabelRegion(plot,grid,y,rowStep),
        data=getWorkPixels().data,WW=workCanvas.width,
        variants=[[],[],[]],lums=[];
  for(let yy=R.y0;yy<R.y1;yy++)for(let x=R.x0;x<R.x1;x++){
    const i=(yy*WW+x)*4,r=data[i],g=data[i+1],b=data[i+2],
          mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=.299*r+.587*g+.114*b,
          gs=g-Math.max(r,b);
    lums.push(lum);
    if(gs>6&&g>34)variants[0].push([x-R.x0,yy-R.y0]);
    if(lum>115&&mx-mn<90)variants[1].push([x-R.x0,yy-R.y0]);
  }
  lums.sort((a,b)=>a-b);
  const med=lums.length?lums[Math.floor(lums.length*.5)]:100;
  for(let yy=R.y0;yy<R.y1;yy++)for(let x=R.x0;x<R.x1;x++){
    const i=(yy*WW+x)*4,r=data[i],g=data[i+1],b=data[i+2],
          lum=.299*r+.587*g+.114*b,gs=g-Math.max(r,b);
    if((gs>3&&g>med*.75)||lum>med+35)variants[2].push([x-R.x0,yy-R.y0]);
  }
  return variants.map(normMask).filter(Boolean);
}

function labelGeometryFeatures(plot,grid,y,rowStep){
  const R=axisLabelRegion(plot,grid,y,rowStep),
        data=getWorkPixels().data,WW=workCanvas.width,
        occ=new Uint8Array(R.W);
  let count=0,minx=R.W,maxx=-1;
  for(let yy=R.y0;yy<R.y1;yy++)for(let x=R.x0;x<R.x1;x++){
    const i=(yy*WW+x)*4,r=data[i],g=data[i+1],b=data[i+2],
          lum=.299*r+.587*g+.114*b,gs=g-Math.max(r,b);
    if((gs>5&&g>35)||(lum>145&&Math.max(r,g,b)-Math.min(r,g,b)<70)){
      const xx=x-R.x0;occ[xx]=1;count++;minx=Math.min(minx,xx);maxx=Math.max(maxx,xx);
    }
  }
  if(maxx<minx)return null;
  // Count occupied X runs; long fixed-decimal strings have more character strokes/runs.
  let runs=0,inRun=false;
  for(let x=0;x<R.W;x++){
    if(occ[x]){
      if(!inRun){runs++;inRun=true;}
    }else inRun=false;
  }
  const width=maxx-minx+1,
        widthRatio=width/Math.max(1,R.W),
        density=count/Math.max(1,R.W*R.H);
  return {runs,width,widthRatio,density};
}

function classifyYAxisFamily(plot,grid){
  const hs=[...grid.h].sort((a,b)=>a-b),
        rowStep=median(hs.slice(1).map((y,i)=>y-hs[i]))||20,
        feats=hs.map(y=>labelGeometryFeatures(plot,grid,y,rowStep)).filter(Boolean);
  if(!feats.length)return {family:'decimal',confidence:0,reason:'no-geometry'};
  const medRuns=median(feats.map(f=>f.runs))||0,
        medWidth=median(feats.map(f=>f.widthRatio))||0,
        medDensity=median(feats.map(f=>f.density))||0;

  // Fixed-decimal labels such as 0.02000 / 0.00500 are visibly long in the Y label strip.
  // Compact 1.0 / 2.0 labels are much shorter.
  let decScore=0,compScore=0;
  if(medRuns>=5)decScore+=3; else compScore+=1;
  if(medWidth>=.58)decScore+=4;
  else if(medWidth<=.44)compScore+=3;
  if(medDensity>.055)decScore+=1;
  // In ambiguous cases prefer decimal: publishing 1/2/5-scale nonsense is worse than
  // failing a true compact image, and decimal is the dominant Energy per Band format.
  const family=decScore>=compScore?'decimal':'compact';
  return {family,confidence:Math.abs(decScore-compScore),medRuns,medWidth,medDensity,reason:`d${decScore}-c${compScore}`};
}

function decimalCandidates(){
  const out=new Map();
  // Canonical Energy-per-Band lattice. Values are multiples of common grid steps;
  // this covers the observed 0.00500/0.01000/0.02000/0.03000/0.04000 families.
  const steps=[0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02,0.025];
  for(const st of steps){
    for(let k=-10;k<=20;k++){
      const v=st*k;
      if(Math.abs(v)>.08+1e-12)continue;
      out.set(v.toFixed(5),v);
    }
  }
  return [...out].map(([text,value])=>({text,value,family:'decimal'}));
}

function compactCandidates(){
  const out=new Map();
  // Compact axes used by Gain-like captures. Keep to realistic plot labels.
  for(let i=-12;i<=20;i++){
    const v=i*.5;
    for(const t of [v.toFixed(1),Number.isInteger(v)?String(v):v.toFixed(1)])
      out.set(t,v);
  }
  return [...out].map(([text,value])=>({text,value,family:'compact'}));
}
const OCR3_DECIMAL=decimalCandidates(), OCR3_COMPACT=compactCandidates();

function ocr3RowHypotheses(plot,grid,y,rowStep,family){
  const masks=numericMaskVariants(plot,grid,y,rowStep);
  if(!masks.length)return [];
  const candidates=family==='decimal'?OCR3_DECIMAL:OCR3_COMPACT,
        sizes=[...new Set([
          Math.max(8,Math.min(24,Math.round(rowStep*.25))),
          Math.max(8,Math.min(24,Math.round(rowStep*.33))),
          Math.max(8,Math.min(24,Math.round(rowStep*.42))),
          Math.max(8,Math.min(24,Math.round(rowStep*.52))),
          Math.max(8,Math.min(24,Math.round(rowStep*.62)))
        ])],
        hyps=[];
  for(const c of candidates){
    let scores=[];
    for(const mask of masks){
      let best=0;
      for(const font of ['Arial','Verdana'])
        for(const size of sizes)
          best=Math.max(best,directMaskScore(mask,yLineTemplate(c.text,font,size)));
      scores.push(best);
    }
    scores.sort((a,b)=>b-a);
    const conf=(scores[0]||0)*.72+(scores[1]||0)*.20+(scores[2]||0)*.08;
    if(conf>.10)hyps.push({...c,conf});
  }
  hyps.sort((a,b)=>b.conf-a.conf);
  return hyps.slice(0,20);
}

function ocr3FitFamily(plot,grid,family){
  const hs=[...grid.h].sort((a,b)=>a-b),
        stepPx=median(hs.slice(1).map((y,i)=>y-hs[i]))||20,
        rows=[];
  for(const y of hs){
    const hyps=ocr3RowHypotheses(plot,grid,y,stepPx,family);
    if(hyps.length)rows.push({y,hyps});
  }
  if(rows.length<2)return null;

  const canonical=family==='decimal'
    ? [0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02,0.025]
    : [0.5,1,2,2.5,5],
        maxStep=family==='decimal'?.03:5;
  let best=null;

  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const A=rows[i],B=rows[j],dy=B.y-A.y;
    if(dy<4)continue;
    for(const a of A.hyps.slice(0,10))for(const b of B.hyps.slice(0,10)){
      const slope=(b.value-a.value)/dy;
      if(!Number.isFinite(slope)||slope>=0)continue;
      const intercept=a.value-slope*A.y,
            step=Math.abs(slope*stepPx);
      if(step<1e-7||step>maxStep)continue;

      const rel=Math.min(...canonical.map(v=>Math.abs(Math.log(Math.max(step,1e-12)/v))));
      let score=-rel*10,support=0,used=[];

      for(const row of rows){
        const pred=slope*row.y+intercept;
        let q=null;
        for(const h of row.hyps){
          const err=Math.abs(h.value-pred)/Math.max(step,1e-12),
                qscore=(h.conf||0)*4-err*6;
          if(!q||qscore>q.qscore)q={...h,err,qscore};
        }
        if(q&&q.err<.12){
          support++;
          score+=8+q.qscore;
          used.push({y:row.y,value:q.value,text:q.text,conf:q.conf});
        }
      }

      used.sort((a,b)=>a.y-b.y);
      // Strong lattice check across all accepted grid labels.
      for(let k=1;k<used.length;k++){
        const rowsApart=Math.max(1,Math.round((used[k].y-used[k-1].y)/Math.max(stepPx,1))),
              expected=step*rowsApart,
              actual=Math.abs(used[k].value-used[k-1].value),
              latticeErr=Math.abs(actual-expected)/Math.max(step,1e-12);
        score-=Math.min(24,latticeErr*8);
      }

      // Prefer more directly recognized rows and high OCR confidence.
      score+=support*4;
      if(family==='decimal'&&used.some(u=>Math.abs(u.value)>.08))score-=100;

      if(support>=2&&(!best||score>best.score))
        best={slope,intercept,step,support,score,used,
              formatHint:family==='decimal'?'ocr3-decimal':'ocr3-compact'};
    }
  }
  return best;
}

function renderAxisLabelScore(masks,text,rowStep){
  const sizes=[...new Set([
    Math.max(8,Math.min(24,Math.round(rowStep*.25))),
    Math.max(8,Math.min(24,Math.round(rowStep*.33))),
    Math.max(8,Math.min(24,Math.round(rowStep*.42))),
    Math.max(8,Math.min(24,Math.round(rowStep*.52))),
    Math.max(8,Math.min(24,Math.round(rowStep*.62)))
  ])];
  let prepScores=[];
  for(const mask of masks){
    let best=0;
    for(const font of ['Arial','Verdana'])
      for(const size of sizes)
        best=Math.max(best,directMaskScore(mask,yLineTemplate(text,font,size)));
    prepScores.push(best);
  }
  prepScores.sort((a,b)=>b-a);
  return (prepScores[0]||0)*.72+(prepScores[1]||0)*.20+(prepScores[2]||0)*.08;
}

function axisModelCandidates(family,rowsCount){
  const out=[];
  if(family==='decimal'){
    // Canonical Energy per Band grid steps observed in the application.
    const steps=[0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02];
    for(const step of steps){
      // top line value; remaining lines decrease by one step.
      for(let k=1;k<=12;k++){
        const top=step*k;
        if(top>.08+1e-12)continue;
        // allow negative lower grid labels, but not absurd ranges
        const bottom=top-step*(rowsCount-1);
        if(bottom<-.04)continue;
        out.push({family,step,top});
      }
    }
  }else{
    const steps=[0.5,1,2,2.5,5];
    for(const step of steps){
      for(let k=1;k<=8;k++){
        const top=step*k;
        if(top>20)continue;
        const bottom=top-step*(rowsCount-1);
        if(bottom<-10)continue;
        out.push({family,step,top});
      }
    }
  }
  return out;
}

function formatAxisValue(v,family){
  if(family==='decimal'){
    // photographed app commonly renders 5 decimals
    return Math.abs(v)<0.0000005 ? '0.00000' : v.toFixed(5);
  }
  if(Math.abs(v-Math.round(v))<1e-9)return String(Math.round(v));
  return v.toFixed(1);
}

function ocr4ScoreModel(model,rows,rowStep){
  let total=0,used=[],good=0;
  for(let idx=0;idx<rows.length;idx++){
    const row=rows[idx],
          value=model.top-model.step*idx,
          text=formatAxisValue(value,model.family),
          score=renderAxisLabelScore(row.masks,text,rowStep);
    // Reward consistent evidence but do not let one lucky row dominate.
    total+=Math.min(score,.50)*6;
    if(score>.105){good++;used.push({y:row.y,value,text,conf:score});}
    else total-=.35;
  }
  // Whole-axis support is the key. 3+ lines is strongly preferred.
  total+=good*2.5;
  if(good<2)total-=20;
  if(rows.length>=3 && good<3)total-=7;
  // Prefer canonical decimal scales over compact unless compact is very clearly better.
  if(model.family==='decimal')total+=1.5;
  return {...model,score:total,support:good,used};
}

function ocr4FitYAxis(plot,grid){
  const hs=[...grid.h].sort((a,b)=>a-b),
        rowStep=median(hs.slice(1).map((y,i)=>y-hs[i]))||20,
        rows=hs.map(y=>({y,masks:numericMaskVariants(plot,grid,y,rowStep)}))
               .filter(r=>r.masks.length);
  if(rows.length<2)throw Error('Y-axis grid labels are insufficient.');

  // Score DECIMAL globally first.
  let decBest=null, compBest=null;
  for(const m of axisModelCandidates('decimal',rows.length)){
    const q=ocr4ScoreModel(m,rows,rowStep);
    if(!decBest||q.score>decBest.score)decBest=q;
  }

  // Compact is still supported for genuinely 1.0/2.0/3.0 axes, but must win clearly.
  for(const m of axisModelCandidates('compact',rows.length)){
    const q=ocr4ScoreModel(m,rows,rowStep);
    if(!compBest||q.score>compBest.score)compBest=q;
  }

  let best=decBest;
  if(compBest && (!best || compBest.score>best.score+12))best=compBest;

  if(!best || best.support<2)
    throw Error('Y-axis global lattice could not be resolved.');

  // If the model says compact but decimal has comparable support, reject compact.
  if(best.family==='compact' && decBest &&
     decBest.support>=2 && compBest.score<decBest.score+12)
    best=decBest;

  // Build affine pixel->value directly from the global lattice.
  const slope=-best.step/rowStep,
        intercept=best.top-slope*rows[0].y;

  // Publication sanity checks.
  if(best.family==='decimal'){
    if(best.step>.02 || best.step<0.00005 || Math.abs(best.top)>.08)
      throw Error('Y-axis decimal lattice rejected as implausible.');
  }else{
    if(best.step<.5 || best.step>5)
      throw Error('Y-axis compact lattice rejected as implausible.');
  }

  return {
    slope,intercept,step:best.step,
    support:best.support,
    score:best.score,
    used:best.used,
    formatHint:best.family==='decimal'?'ocr4-decimal':'ocr4-compact',
    familyDecision:{
      family:best.family,
      reason:`global-${best.support}/${rows.length}; d=${decBest?decBest.score.toFixed(1):'NA'} c=${compBest?compBest.score.toFixed(1):'NA'}`
    }
  };
}
function observedLabelStrip(plot,grid,y,rowStep){
  const axisX=(grid.v&&grid.v.length)?grid.v[0]:Math.round(plot.left+(plot.right-plot.left)*.20),
        // Y numbers are INSIDE the black plot and end immediately before the Y axis.
        x0=Math.max(plot.left+1,Math.round(plot.left+(axisX-plot.left)*.015)),
        x1=Math.max(x0+10,axisX-1),
        half=Math.max(5,Math.round(rowStep*.40)),
        y0=Math.max(0,Math.round(y-half)),
        y1=Math.min(workCanvas.height,Math.round(y+half)),
        W=Math.max(1,x1-x0),H=Math.max(1,y1-y0),
        im=workCtx.getImageData(x0,y0,W,H).data,pts=[];
  for(let yy=0;yy<H;yy++)for(let xx=0;xx<W;xx++){
    const i=(yy*W+xx)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    // Numeric labels are green. Avoid white trace/tooltip contamination.
    if(greenStrength(r,g,b)>7 && g>38 && st.lum>32)pts.push([xx,yy]);
  }
  return normMask(pts);
}
function visualYLabels(){
  const out=new Map();
  // Energy-per-band axes observed in the supplied treatment screenshots.
  // Keep a broad but bounded decimal family; bottom is NOT assumed to be zero.
  for(let i=-40;i<=120;i++){
    const v=i/10000;
    for(const t of [v.toFixed(5),v.toFixed(4)])out.set(t,v);
  }
  // Retain compact scales for genuinely non-decimal captures, but score them separately.
  for(let i=-40;i<=80;i++){
    const v=i/10;
    for(const t of [v.toFixed(1),v.toFixed(2),String(v)])out.set(t,v);
  }
  return [...out].map(([text,value])=>({text,value,fixed:/^-?0\.\d{4,5}$/.test(text)}));
}
const VIS_LABELS=visualYLabels();

function labelHypothesesAtRow(plot,grid,y,rowStep){
  const obs=observedLabelStrip(plot,grid,y,rowStep);
  if(!obs)return [];
  const hyps=[];
  // v1.2.3 only tried 22/26 px. On the internal downscaled canvas the photographed
  // labels are often ~9–18 px high, which caused 0.02000 -> 0.1170 etc.
  for(const c of VIS_LABELS){
    let best=0;
    for(const font of ['Arial','Verdana'])
      for(const size of [...new Set([
        Math.max(8,Math.min(22,Math.round(rowStep*.28))),
        Math.max(8,Math.min(22,Math.round(rowStep*.38))),
        Math.max(8,Math.min(22,Math.round(rowStep*.48))),
        Math.max(8,Math.min(22,Math.round(rowStep*.58)))
      ])])
        best=Math.max(best,directMaskScore(obs,yLineTemplate(c.text,font,size)));
    if(best>.115)hyps.push({...c,conf:best});
  }
  hyps.sort((a,b)=>b.conf-a.conf);
  return hyps.slice(0,18);
}

function recognizeGridAnchors(plot,grid){
  const hs=[...grid.h].sort((a,b)=>a-b),
        stepPx=median(hs.slice(1).map((y,i)=>y-hs[i])),
        rows=[];
  for(const y of hs){
    const hyps=labelHypothesesAtRow(plot,grid,y,stepPx);
    if(hyps.length)rows.push({y,hyps});
  }

  // Fit both label families. Geometry, monotonicity and canonical grid steps decide.
  function fitFamily(fixed){
    const rr=rows.map(r=>({y:r.y,hyps:r.hyps.filter(h=>h.fixed===fixed)})).filter(r=>r.hyps.length);
    if(rr.length<2)return null;
    let best=null;
    const canonical=fixed
      ? [0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02,0.025,0.05]
      : [0.1,0.2,0.5,1,2,2.5,5,10];
    for(let i=0;i<rr.length;i++)for(let j=i+1;j<rr.length;j++){
      const A=rr[i],B=rr[j],dy=B.y-A.y;if(dy<4)continue;
      for(const a of A.hyps.slice(0,10))for(const b of B.hyps.slice(0,10)){
        const slope=(b.value-a.value)/dy;
        if(!Number.isFinite(slope)||slope>=0)continue;
        const intercept=a.value-slope*A.y,
              step=Math.abs(slope*stepPx);
        if(step<1e-7||step>(fixed?.06:20))continue;
        const near=Math.min(...canonical.map(v=>Math.abs(Math.log(Math.max(step,1e-12)/v))));
        let support=0,score=-near*5,used=[];
        for(const row of rr){
          const pred=slope*row.y+intercept;
          let q=null;
          for(const h of row.hyps){
            const err=Math.abs(h.value-pred)/Math.max(step,1e-12);
            if(!q||err<q.err)q={...h,err};
          }
          if(q&&q.err<.16){
            support++;
            score+=5+(q.conf||0)*3-q.err*3;
            used.push({y:row.y,value:q.value,text:q.text,conf:q.conf});
          }
        }
        // Adjacent horizontal grid lines should differ by an integer number of grid steps.
        used.sort((a,b)=>a.y-b.y);
        for(let k=1;k<used.length;k++){
          const rowsApart=Math.max(1,Math.round((used[k].y-used[k-1].y)/Math.max(stepPx,1))),
                expected=step*rowsApart,
                actual=Math.abs(used[k].value-used[k-1].value);
          score-=Math.min(12,Math.abs(actual-expected)/Math.max(step,1e-12)*4);
        }
        if(support>=2 && (!best||score>best.score))
          best={slope,intercept,step,support,score,used,formatHint:fixed?'fixed5':'compact'};
      }
    }
    return best;
  }

  const fixed=fitFamily(true), compact=fitFamily(false);
  // Energy-per-band photographed axes overwhelmingly use 5-decimal labels.
  // Prefer fixed when it has credible support; compact must win by a large margin.
  let best=fixed;
  if(compact && (!best || compact.score>best.score+10))best=compact;
  if(!best)throw Error('Y-axis numeric anchors could not be resolved.');

  // Reject obviously impossible OCR rather than publishing nonsense.
  if(best.formatHint==='fixed5'){
    if(best.step>.05 || best.step<0.00005 ||
       best.used.some(a=>Math.abs(a.value)>.10))
      throw Error('Y-axis decimal calibration rejected as implausible.');
  }
  return best;
}
function dominantForegroundHue(plot){
  const W=workCanvas.width,im=getWorkPixels().data,
        bins=new Array(72).fill(0),
        xs=Math.max(1,Math.ceil((plot.right-plot.left)/260)),
        ys=Math.max(1,Math.ceil((plot.bottom-plot.top)/160));
  for(let y=plot.top;y<=plot.bottom;y+=ys)for(let x=plot.left;x<=plot.right;x+=xs){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    if(st.sat>.18&&st.lum>45&&greenStrength(r,g,b)<12)bins[Math.floor(st.h/5)%72]++;
  }
  let bi=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  return bi*5+2.5;
}

function tracePointsUnified(plot){
  const W=workCanvas.width,H=workCanvas.height,
        im=getWorkPixels().data,
        hue=dominantForegroundHue(plot),
        pts=[],
        xStep=Math.max(1,Math.ceil((plot.right-plot.left)/380));

  // One representative trace point per X column.
  // This avoids requiring a dense cloud of foreground pixels.
  for(let x=plot.left;x<=plot.right;x+=xStep){
    const ys=[];
    for(let y=plot.top;y<=plot.bottom;y++){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
      const colored=(hueDist(st.h,hue)<30&&st.sat>.12&&st.lum>38),
            achromatic=(st.sat<.18&&st.lum>135),
            notGrid=greenStrength(r,g,b)<16;
      if((colored||achromatic)&&notGrid)ys.push(y);
    }
    if(!ys.length)continue;

    ys.sort((a,b)=>a-b);
    let bestCluster=[],cur=[ys[0]];
    const gap=Math.max(3,Math.round((plot.bottom-plot.top)/40));
    for(let i=1;i<ys.length;i++){
      if(ys[i]-ys[i-1]<=gap)cur.push(ys[i]);
      else{
        if(cur.length>bestCluster.length)bestCluster=cur;
        cur=[ys[i]];
      }
    }
    if(cur.length>bestCluster.length)bestCluster=cur;
    const use=bestCluster.length?bestCluster:ys;
    pts.push({x,y:median(use),support:use.length});
  }

  return {hue,pts};
}

function xDomain(plot,x){return (x-plot.left)/Math.max(1,plot.right-plot.left)*500}

function robustMeanByRange(plot,scale,trace,x0,x1){
  const inRange=trace.pts.filter(p=>{
    const x=xDomain(plot,p.x);
    return x>=x0&&x<=x1;
  });

  function valuesFrom(points){
    return points.map(p=>scale.slope*p.y+scale.intercept);
  }

  function robust(values,mode){
    if(!values.length)return null;
    const m=median(values),
          M=mad(values)||Math.max(1e-9,Math.abs(m)*.015,scale.step*.10),
          mult=mode==='primary'?3.5:mode==='relaxed'?6.0:10.0,
          floor=mode==='primary'?scale.step*.40:mode==='relaxed'?scale.step*.75:scale.step*1.20,
          lim=Math.max(M*mult,Math.abs(m)*(mode==='primary'?.08:.15),floor),
          clean=values.filter(v=>Math.abs(v-m)<=lim);
    if(!clean.length)return null;
    return {
      mean:clean.reduce((a,b)=>a+b,0)/clean.length,
      count:clean.length,
      median:m,
      mode
    };
  }

  let out=robust(valuesFrom(inRange),'primary');
  if(out&&out.count>=5)return out;

  out=robust(valuesFrom(inRange),'relaxed');
  if(out&&out.count>=3)return out;

  // Final fallback: direct hue-matched pixel scan inside this X range.
  const W=workCanvas.width,H=workCanvas.height,
        im=getWorkPixels().data,
        hue=trace.hue,
        xa=plot.left+(x0/500)*(plot.right-plot.left),
        xb=plot.left+(x1/500)*(plot.right-plot.left),
        raw=[],
        xs=Math.max(1,Math.ceil((xb-xa)/220)),
        ys=Math.max(1,Math.ceil((plot.bottom-plot.top)/180));

  for(let y=plot.top;y<=plot.bottom;y+=ys){
    for(let x=Math.round(xa);x<=Math.round(xb);x+=xs){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
      const colored=st.sat>.10&&st.lum>34&&hueDist(st.h,hue)<34;
      const achromatic=st.sat<.18&&st.lum>135;
      if((colored||achromatic)&&greenStrength(r,g,b)<18){
        raw.push(scale.slope*y+scale.intercept);
      }
    }
  }

  out=robust(raw,'pixel-fallback');
  if(out&&out.count>=3)return out;

  throw Error(`Not enough trace samples in ${x0===0?'Low':'High'} range.`);
}

function unifiedAnalyzeCore(){
  const plot=detectBlackPlot(),grid=detectGreenGrid(plot),
        scale=recognizeGridAnchors(plot,grid),trace=tracePointsUnified(plot),
        low=robustMeanByRange(plot,scale,trace,0,260),
        high=robustMeanByRange(plot,scale,trace,270,500);
  return {plot,grid,scale,trace,low,high};
}




const yLineTemplateCache=new Map();

function normMask(points,tw=128,th=28){
  if(!points||points.length<4)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const p of points){minx=Math.min(minx,p[0]);miny=Math.min(miny,p[1]);maxx=Math.max(maxx,p[0]);maxy=Math.max(maxy,p[1])}
  const w=Math.max(1,maxx-minx+1),h=Math.max(1,maxy-miny+1),
        sc=Math.min((tw-4)/w,(th-4)/h),
        nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc)),
        ox=2,oy=Math.floor((th-nh)/2),arr=new Uint8Array(tw*th);
  for(const p of points){
    const x=ox+Math.min(nw-1,Math.max(0,Math.round((p[0]-minx)*sc))),
          y=oy+Math.min(nh-1,Math.max(0,Math.round((p[1]-miny)*sc)));
    arr[y*tw+x]=1;
  }
  arr._aspect=w/Math.max(1,h);arr._w=w;arr._h=h;
  return arr;
}

function yLineTemplate(text,font='Arial',size=24){
  const key=`${text}|${font}|${size}`;
  if(yLineTemplateCache.has(key))return yLineTemplateCache.get(key);
  const c=document.createElement('canvas');c.width=180;c.height=44;
  const q=c.getContext('2d');
  q.fillStyle='#000';q.fillRect(0,0,c.width,c.height);
  q.fillStyle='#fff';q.font=`${size}px ${font}`;q.textBaseline='top';q.fillText(text,2,2);
  const im=q.getImageData(0,0,c.width,c.height).data,pts=[];
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
    const i=(y*c.width+x)*4;if(im[i]>80)pts.push([x,y]);
  }
  const n=normMask(pts);yLineTemplateCache.set(key,n);return n;
}

function directMaskScore(a,b){
  if(!a||!b)return 0;
  let inter=0,uni=0,aa=0,bb=0;
  for(let i=0;i<a.length;i++){
    const A=a[i],B=b[i];
    if(A&&B)inter++;
    if(A||B)uni++;
    aa+=A;bb+=B;
  }
  const iou=uni?inter/uni:0,
        fill=1-Math.min(1,Math.abs(aa-bb)/Math.max(1,Math.max(aa,bb))),
        arA=Math.max(.05,a._aspect||1),arB=Math.max(.05,b._aspect||1),
        aspect=Math.exp(-Math.abs(Math.log(arA/arB))*1.1);
  return .66*iou+.20*fill+.14*aspect;
}

function observedYLabelMask(plot,rowY,rowStep){
  const x1=Math.max(2,Math.floor(plot.left-3)),
        span=Math.max(56,Math.min(132,Math.round((plot.right-plot.left)*.26))),
        x0=Math.max(0,x1-span),
        half=Math.max(7,Math.round(rowStep*.32)),
        y0=Math.max(0,Math.round(rowY-half)),
        y1=Math.min(workCanvas.height-1,Math.round(rowY+half)),
        W=Math.max(1,x1-x0),H=Math.max(1,y1-y0),
        im=workCtx.getImageData(x0,y0,W,H).data,pts=[];
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
          mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3,
          greenish=g>42&&g>=r*.94&&g>=b*.88&&(g-Math.min(r,b)>2),
          bright=lum>145&&(mx-mn)<75;
    if(greenish||bright)pts.push([x,y]);
  }
  return normMask(pts);
}

function candidateYLabels(){
  const out=new Map();
  function add(v,formats){
    for(const t of formats){
      const n=Number(t);
      if(Number.isFinite(n))out.set(t,n);
    }
  }
  // Fine/noise-like scales: deliberately dense but still small.
  for(let i=-20;i<=120;i++){
    const v=i/1000;
    add(v,[v.toFixed(5),v.toFixed(4),v.toFixed(3)]);
  }
  // Gain-like scales.
  for(let i=-20;i<=40;i++){
    const v=i/2;
    add(v,[v.toFixed(1),v.toFixed(2),String(v)]);
  }
  // Exact zero forms.
  add(0,['0','0.0','0.00','0.000','0.0000','0.00000']);
  return [...out].map(([text,value])=>({text,value}));
}
const Y_LINE_CANDIDATES=candidateYLabels();

function rowLabelHypotheses(plot,rowY,rowStep){
  const obs=observedYLabelMask(plot,rowY,rowStep);
  if(!obs)return [];
  const out=[];
  for(const c of Y_LINE_CANDIDATES){
    let best=0;
    for(const font of ['Arial','Verdana'])
      for(const size of [22,26])
        best=Math.max(best,directMaskScore(obs,yLineTemplate(c.text,font,size)));
    if(best>.18)out.push({...c,conf:best});
  }
  out.sort((a,b)=>b.conf-a.conf);
  const uniq=[];
  for(const q of out){
    if(uniq.some(u=>Math.abs(u.value-q.value)<Math.max(1e-6,Math.abs(q.value)*.001)))continue;
    uniq.push(q);
    if(uniq.length>=8)break;
  }
  return uniq;
}

function fitYAxisFromVisibleNumbers(plot){
  const ys=[...plot.h].sort((a,b)=>a-b),
        stepPx=median(ys.slice(1).map((y,i)=>y-ys[i])),
        rows=[];
  for(const y of ys){
    const hyps=rowLabelHypotheses(plot,y,stepPx);
    if(hyps.length)rows.push({y,hyps});
  }
  if(rows.length<2)throw Error('Y-axis: fewer than two numeric labels were read.');

  let best=null;
  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const A=rows[i],B=rows[j],dy=B.y-A.y;
    if(dy<4)continue;
    for(const ha of A.hyps.slice(0,6))for(const hb of B.hyps.slice(0,6)){
      const slope=(hb.value-ha.value)/dy;
      if(!Number.isFinite(slope)||slope>=0)continue;
      const intercept=ha.value-slope*A.y,
            step=Math.abs(slope*stepPx);
      if(step<1e-6||step>20)continue;

      let support=0,score=0,used=[];
      for(const row of rows){
        const pred=slope*row.y+intercept;
        let qbest=null;
        for(const h of row.hyps.slice(0,8)){
          const err=Math.abs(h.value-pred)/Math.max(step,1e-9);
          if(!qbest||err<qbest.err)qbest={...h,err};
        }
        if(qbest&&qbest.err<.22){
          support++;
          score+=4+(qbest.conf||0)*2-qbest.err*2;
          used.push({y:row.y,value:qbest.value,text:qbest.text,conf:qbest.conf});
        }
      }

      // Prefer common grid increments without assuming any bottom value.
      const common=[5,2,1,.5,.2,.1,.05,.02,.01,.005,.002,.001,.0005,.0002,.0001];
      const near=Math.min(...common.map(v=>Math.abs(Math.log(step/v))));
      score-=near*.35;

      if(!best||score>best.score)best={slope,intercept,step,support,score,used};
    }
  }

  if(!best||best.support<2)
    throw Error('Y-axis numeric labels do not form a consistent grid scale.');

  return {...best,source:'fast-line-label-affine-v1.2.3'};
}

async function extractTrace(plot,onProgress){
  const W=workCanvas.width,H=workCanvas.height,
        im=getWorkPixels().data;

  if(onProgress)onProgress('hue',0);
  const hue=await traceHue(plot,p=>onProgress&&onProgress('hue',p));

  if(onProgress)onProgress('scan',0);

  // One-pass bounded trace extraction.
  // Instead of scanning/refining each X column, sample the plot once and
  // accumulate matching foreground pixels into fixed X bins.
  const xSpan=Math.max(1,plot.right-plot.left),
        ySpan=Math.max(1,plot.bottom-plot.top),
        binCount=Math.min(180,Math.max(80,Math.round(xSpan/2))),
        sumY=new Float64Array(binCount),
        count=new Uint32Array(binCount),
        xStep=Math.max(1,Math.ceil(xSpan/300)),
        yStep=Math.max(1,Math.ceil(ySpan/180)),
        totalRows=Math.max(1,Math.ceil((ySpan+1)/yStep));

  let rowN=0;
  for(let y=plot.top;y<=plot.bottom;y+=yStep){
    for(let x=plot.left;x<=plot.right;x+=xStep){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
            mx=Math.max(r,g,b),mn=Math.min(r,g,b),
            sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.16&&lum>48&&!isGreen(r,g,b)&&hueDist(rgb2hue(r,g,b),hue)<30){
        const bidx=Math.min(binCount-1,Math.max(0,Math.floor((x-plot.left)/xSpan*binCount)));
        sumY[bidx]+=y;
        count[bidx]++;
      }
    }
    rowN++;
    if(rowN%24===0){
      if(onProgress)onProgress('scan',Math.min(1,rowN/totalRows));
      await new Promise(r=>setTimeout(r,0));
    }
  }

  const pts=[];
  for(let b=0;b<binCount;b++){
    if(!count[b])continue;
    const x=plot.left+(b+.5)/binCount*xSpan,
          y=sumY[b]/count[b];
    pts.push({x,y,count:count[b]});
  }
  if(onProgress)onProgress('scan',1);

  if(onProgress)onProgress('filter',0);
  if(pts.length<10)throw Error('Trace could not be isolated.');

  // Robust rejection on the binned trace.
  const ys=pts.map(p=>p.y),m=median(ys),M=mad(ys)||1,
        lim=Math.max(4,4*M),
        clean=pts.filter(p=>Math.abs(p.y-m)<=lim);

  if(clean.length<8)throw Error('Trace samples were removed as outliers.');
  if(onProgress)onProgress('filter',1);
  return {hue,pts:clean};
}



function chooseYScale(plot,trace){
  const fit=fitYAxisFromVisibleNumbers(plot);
  return {slope:fit.slope,intercept:fit.intercept,step:fit.step,
          support:fit.support,anchors:fit.used,source:'global-grid-numeric-sequence-v1.2.3'};
}

function xToSample(plot,x){return 500*(x-plot.left)/(plot.right-plot.left)}
function yToValue(plot,scale,y){return scale.slope*y+scale.intercept}
function robustMean(vals){
  if(!vals.length)return NaN;const m=median(vals),M=mad(vals)||1e-9,kept=vals.filter(v=>Math.abs(v-m)<=Math.max(M*3,Math.abs(m)*.12+1e-6));
  return mean(kept);
}

async function analyze(){
  const t0=performance.now();
  if(!ready)return;
  $('analyzeBtn').disabled=true;
  try{
    setProgress(8,'Processing…','Preparing memory-safe analysis image');
    await new Promise(r=>setTimeout(r,0));
    prepareWorkingImage();
    yLineTemplateCache.clear();

    setProgress(18,'Plot','Locating black Energy per Band region');
    await new Promise(r=>setTimeout(r,0));
    preprocess();
    const plot=detectBlackPlot();

    setProgress(30,'Grid','Detecting green grid geometry');
    await new Promise(r=>setTimeout(r,0));
    const grid=detectGreenGrid(plot);

    setProgress(48,'Y-axis','Reading numeric anchors tied to grid lines');
    await new Promise(r=>setTimeout(r,0));
    const scale=ocr4FitYAxis(plot,grid);

    setProgress(68,'Trace','Separating foreground trace');
    await new Promise(r=>setTimeout(r,0));
    const trace=tracePointsUnified(plot);

    setProgress(84,'Low / High','Computing Low 0–260 / High 270–500');
    await new Promise(r=>setTimeout(r,0));
    const lowObj=robustMeanByRange(plot,scale,trace,0,260),
          highObj=robustMeanByRange(plot,scale,trace,270,500),
          low=lowObj.mean,high=highObj.mean;

    $('lowValue').textContent=low.toFixed(scale.step<.1?4:2);
    $('highValue').textContent=high.toFixed(scale.step<.1?4:2);

    resultCanvas.width=canvas.width;resultCanvas.height=canvas.height;
    rctx.clearRect(0,0,resultCanvas.width,resultCanvas.height);
    rctx.drawImage(canvas,0,0);
    rctx.strokeStyle='#26d7ff';rctx.fillStyle='#26d7ff';
    rctx.lineWidth=Math.max(2,resultCanvas.width/700);
    rctx.font=`${Math.max(20,resultCanvas.width/35)}px Arial`;

    const lowYw=(low-scale.intercept)/scale.slope,
          highYw=(high-scale.intercept)/scale.slope,
          pLeft=toOriginalX(plot.left),pRight=toOriginalX(plot.right),
          lowY=toOriginalY(lowYw),highY=toOriginalY(highYw);

    rctx.beginPath();rctx.moveTo(pLeft,lowY);rctx.lineTo(pLeft+(pRight-pLeft)*.52,lowY);rctx.stroke();
    rctx.fillText(`Low ${low.toFixed(scale.step<.1?4:2)}`,pLeft+10,lowY-10);
    rctx.beginPath();rctx.moveTo(pLeft+(pRight-pLeft)*.54,highY);rctx.lineTo(pRight,highY);rctx.stroke();
    rctx.fillText(`High ${high.toFixed(scale.step<.1?4:2)}`,pLeft+(pRight-pLeft)*.56,highY-10);

    $('detail').textContent=`Memory-safe OCR4 global-lattice core; source ${sourceWidth}×${sourceHeight}; work ${workCanvas.width}×${workCanvas.height}; Y ${scale.formatHint}; family ${scale.familyDecision.family}(${scale.familyDecision.reason}); step ${Number(scale.step.toPrecision(6))}; anchors ${scale.used.map(a=>a.text).join(' / ')}; Low ${lowObj.mode} ${lowObj.count}; High ${highObj.mode} ${highObj.count}; X 0–500.`;
    const elapsed=((performance.now()-t0)/1000).toFixed(1);

    $('resultCard').classList.remove('hidden');
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{
      $('resultCard').scrollIntoView({behavior:'smooth',block:'start'});
    }catch(_){
      $('resultCard').scrollIntoView();
    }
    setProgress(100,'Complete',`Total ${elapsed}s`);
    $('status').textContent=`Analysis complete — ${elapsed}s`;
  }catch(e){
    $('status').textContent=e.message||String(e);
    setProgress(100,'Needs attention',e.message||String(e));
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{$('progressCard').scrollIntoView({behavior:'smooth',block:'center'});}catch(_){}
  }finally{
    releaseWorkPixels();
    $('analyzeBtn').disabled=false;
  }
}

$('analyzeBtn').onclick=analyze;
reset();


// v1.2.3 deliberately runs without an application service worker.
// Remove stale v1.0.1/v1.0.2 workers/caches so GitHub Pages always serves current JS.
// Offline support will be re-enabled only after numeric validation is stable.
(async()=>{
  try{
    if('serviceWorker' in navigator){
      const regs=await navigator.serviceWorker.getRegistrations();
      for(const r of regs){
        if(r.scope.includes('/Module/spectrumreader/')) await r.unregister();
      }
    }
    if('caches' in window){
      const ks=await caches.keys();
      for(const k of ks)if(k.startsWith('energy-graph'))await caches.delete(k);
    }
  }catch(_){}
})();
