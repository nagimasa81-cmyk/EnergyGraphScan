// Simple v1.2.3 compatibility worker. It intentionally caches nothing.
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil((async()=>{
  await self.registration.unregister();
  const ks=await caches.keys();
  await Promise.all(ks.filter(k=>k.startsWith('energy-graph')).map(k=>caches.delete(k)));
  await self.clients.claim();
})()));
self.addEventListener('fetch',()=>{});
