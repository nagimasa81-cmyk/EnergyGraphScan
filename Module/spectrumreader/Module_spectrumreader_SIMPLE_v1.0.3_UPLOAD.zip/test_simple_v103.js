
const fs=require('fs'),a=fs.readFileSync('app.v1.0.3.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function fitYAxisFromVisibleNumbers(plot)'),'Y fit missing');
ok(a.includes("source:'global-grid-numeric-sequence-v1.0.3'"),'global sequence source missing');
ok(!a.includes('bottomValue:0'),'bottom zero assumption present');
ok(a.includes("getRegistrations()"),'stale worker cleanup missing');
ok(h.includes('iPhone v1.0.3 Simple · build 1705'),'build stamp missing');
ok(h.includes('app.v1.0.3.js?build=20260816-1705'),'versioned runtime missing');
console.log('Simple v1.0.3 regression PASS');
