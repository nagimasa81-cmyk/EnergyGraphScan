
const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function fitYAxisFromVisibleNumbers('),'visible numeric fit missing');
ok(a.includes("source:'visible-numeric-anchor-affine-v1.0.2'"),'new Y source missing');
ok(a.includes('function yToValue(plot,scale,y){return scale.slope*y+scale.intercept}'),'affine y conversion missing');
ok(!a.includes('bottomValue:0'),'bottom=0 assumption still present');
ok(a.includes('No bottom=0 assumption.'),'diagnostic missing');
console.log('Simple v1.0.2 arbitrary-Y-origin regression PASS');
