# Energy Graph Simple v1.0.2

黒い Energy per Band グラフだけを撮影して Low / High 平均値だけを読む軽量版です。

- Channel判定なし
- Gain / Noise判定なし
- Channel ROIなし
- X軸は 0–500
- Low = 0–260
- High = 270–500
- スパイク除外後の平均
- オフラインPWA対応
- 撮影/ライブラリ画像はネイティブ解像度で解析


既存の `deploy-spectrumreader-zip-pages.yml` が要求する4つの互換JSを同梱しています。Simple版の解析本体は `app.js` のみです。

- v1.0.2: Y軸下辺=0仮定を完全撤廃。見えているY軸数値2点以上からpixel→値を直接回帰。

- v1.0.2 cachefix: Safari旧Service Workerがv1.0.1を返し続ける問題を修正。
- HTML/runtimeはnetwork-first。
- 旧Energy Graph cacheをactivation時に削除。
- app.v1.0.2.jsをバージョン付きURLでロード。

- v1.0.3: Y軸を全水平グリッドの数値系列として同時判定。下辺値の仮定なし。
- 数値精度検証中はService Worker/オフラインキャッシュを一時停止。旧v1.0.1が残る問題を排除。
- 画面ヘッダに build 1705 を表示。
