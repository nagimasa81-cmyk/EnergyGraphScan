# Energy Graph Simple v1.3.0 — Unified Core v6

This release is a logic rebase, not an incremental OCR patch.

## Authoritative pipeline

1. **Energy plot isolation**
   - Finds dark graph bands row-by-row.
   - Selects the first graph with a credible green grid.
   - Prevents the lower `Raw Data from A2D` plot from entering trace analysis.

2. **Grid geometry**
   - Grid search occurs only inside the selected Energy plot.
   - Horizontal and vertical line candidates are fitted to regular lattices.
   - Missing grid members are reconstructed from the local lattice.

3. **Y-axis solve**
   - Uses whole-label masks at horizontal-grid locations.
   - Mask normalization preserves aspect ratio.
   - `3.0` and `0.03000` are therefore not stretched into the same apparent width.
   - Complete decimal/compact lattices compete globally.
   - Bottom value is not assumed to be zero.

4. **Trace**
   - Trace pixels are accepted only inside the selected Energy plot.
   - Colored and white traces are handled.
   - White tooltip interiors are rejected using neighborhood darkness.
   - One robust representative is extracted per X bin.

5. **Low/High**
   - X domain is mapped once from Energy-plot left/right to 0..500.
   - Low = 0..260.
   - High = 270..500.
   - Robust mean removes isolated spikes.

6. **Validation**
   - Low/High must remain inside the visible Y-axis range.
   - Trace cannot escape the Energy plot.
   - Overlay pixel positions must invert through the same Y calibration.
   - There is no independent old fallback allowed to generate values.

## Important design rule

The deployed runtime contains one value-producing path only. Old OCR2/OCR3/OCR4 and old pixel fallback calibration paths are not part of the deployed v1.3.0 runtime.

## v1.3.1 / Unified Core v7

- Plot localization no longer uses a narrow aspect ratio as a primary acceptance rule.
- Multiple black graph candidates are refined and ranked by orthogonal green-lattice evidence.
- Y-axis family is inferred first from observed label geometry (width/height), then numeric lattice models compete inside that family.
- Green foreground traces are retained. Grid rejection is geometric: only pixels near already-solved H/V grid lines are removed.

## v1.3.2 / Unified Core v8

The pipeline is now fail-safe rather than fail-fast at the two weak stages seen in v1.3.1.

### Plot localization
1. Refined orthogonal lattice.
2. Coarse robust lattice recovered from pairwise spacing.
3. Projection fallback when camera perspective/moiré hides individual grid lines.

A photographed Energy panel is no longer discarded solely because a formal lattice is incomplete.

### Y axis
- Label pixels use adaptive green/yellow/pale detection.
- Family geometry, grid spacing, and label-template evidence are fused.
- One strong readable label can seed a whole regular lattice.
- Zero is never assumed to be the bottom value.

### Trace
- Grid suppression is geometric, not color-based.
- Green/white trace points overlapping a grid line are retained when local foreground thickness supports a trace.

## v1.3.3 / Unified Core v9

This release closes the coordinate-system split that remained visible in v1.3.2.

- `plot.left/right/top/bottom` defines the only valid analysis space.
- `makeYTransform()` creates the only pixel-to-value and value-to-pixel mapping.
- Low/High calculation, validation, and overlay all use that same transform.
- Overlay rendering is clipped to the Energy plot, so it cannot appear over Raw Data.
- Y family selection prioritizes observed text-length geometry.
- A compact axis made entirely negative is heavily penalized unless strong evidence demands it.
- Final values are rejected if value->pixel->value round trip, visible range, or plot containment fails.

## v1.3.4 / Unified Core v10

- Plot-localization now rejects tiny inner-lattice solutions that came from partial grid locking.
- Y label crops use connected components so the vertical "Energy" title does not masquerade as a numeric label.
- Family selection uses width/height and lit-pixel-count together.
- All Y-axis candidates are restricted to non-negative Energy ranges.

## v1.3.5 / Unified Core v11

- Replaced component-aggregation label pickup with row-local horizontal segment selection.
- Reduced false compact-family picks on decimal axes like 0.02000 / 0.01000.
- High-range mean now allows sparse but stable sample sets.

## v1.3.6 / Unified Core v12

- Multi-glyph reconstruction for Y-axis labels.
- Stronger decimal-vs-compact family gating.
- Wider row-local label strip; same algorithm for all trace colors.

## v1.3.7 / Unified Core v13

- Horizontal lattice is restricted to 2–5 major Y grid lines and physically plausible major spacing.
- Zero OCR-support scale solutions are forbidden.
- Dense false Y sub-lattices from trace/moire can no longer create arbitrary compact scales.
- Decimal label glyphs are merged across wider inter-glyph gaps.
