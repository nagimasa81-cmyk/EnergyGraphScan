// Energy Graph Simple v1.0.1 deployment compatibility shim.
// The Simple app is self-contained in app.js and does not import this file.
window.EGSCoreCompat = true;
