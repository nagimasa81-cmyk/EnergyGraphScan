// Energy Graph Simple v1.0.1 deployment compatibility shim.
// Intentionally not loaded by index.html.
window.EGSCanonicalRegistrationCompat = true;
