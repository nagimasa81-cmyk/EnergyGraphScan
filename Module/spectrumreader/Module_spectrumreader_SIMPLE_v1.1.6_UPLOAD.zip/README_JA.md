# Energy Graph Simple v1.0.2

黒い Energy per Band グラフだけを撮影して Low / High 平均値だけを読む軽量版です。

- Channel判定なし
- Gain / Noise判定なし
- Channel ROIなし
- X軸は 0–500
- Low = 0–260
- High = 270–500
- スパイク除外後の平均
- オフラインPWA対応
- 撮影/ライブラリ画像はネイティブ解像度で解析


既存の `deploy-spectrumreader-zip-pages.yml` が要求する4つの互換JSを同梱しています。Simple版の解析本体は `app.js` のみです。

- v1.0.2: Y軸下辺=0仮定を完全撤廃。見えているY軸数値2点以上からpixel→値を直接回帰。

- v1.0.2 cachefix: Safari旧Service Workerがv1.0.1を返し続ける問題を修正。
- HTML/runtimeはnetwork-first。
- 旧Energy Graph cacheをactivation時に削除。
- app.v1.0.2.jsをバージョン付きURLでロード。

- v1.0.3: Y軸を全水平グリッドの数値系列として同時判定。下辺値の仮定なし。
- 数値精度検証中はService Worker/オフラインキャッシュを一時停止。旧v1.0.1が残る問題を排除。
- 画面ヘッダに build 1705 を表示。

- v1.0.4: 4032×3024等の最大解像度画像は原画として保持し、解析だけ最大辺1280pxのワーキング画像で実行。
- Trace色分離は最大約900列×500行相当へ制限。iPhoneで50%停止に見える問題を解消。
- 結果ラインは原画像座標へ戻して描画。

- v1.0.5: Trace処理を5段階表示へ分解。
- 色探索は最大約220×140点の粗探索。
- Trace列探索は最大420列、各列は粗Y探索後に局所精査のみ。
- 20列ごとにUIへ制御を返すため、iPhoneで50%固定に見えない。
- 完了時に総解析秒数を表示。

- v1.0.6: Trace 3/5の列ごと局所精査を廃止。
- 最大辺800pxの解析画像上で、色候補画素を1回走査して最大180個のX-binへ集約。
- 解析量を約300×180サンプル以内に固定し、iPhone Safariでの長時間停止を防止。

- v1.1.0: Simple解析を一本化。
- Black plot → Green grid → Y anchors → foreground trace → Low/High。
- 表示ラインと計算値は完全に同じ座標変換を使用。

- v1.1.1: Analyze/Low/High DOM ID不整合を修正。
- JavaScriptの全DOM参照IDをHTMLと照合。
- Node VM上で実アプリJSをロードし、Analyzeクリック→進捗表示までランタイム検証。

- v1.1.2: 撮影または写真選択後、画像デコード完了から自動でAnalyzeまで進む。
- プレビュー表示を1フレーム反映してから解析開始。
- Analyzeボタンは再解析用として残す。
- 同じ写真を再度選べるようfile inputを毎回クリア。

- v1.1.3: 細いLow水平線・疎なHigh点群向けにTrace抽出を変更。
- 各X列から代表Yを1点取得。
- Primary → Relaxed → Pixel fallbackの3段階。
- 5サンプル未満でも3サンプル以上なら継続。

- v1.1.6: Y軸数値ROIの根本バグを修正。従来は黒グラフの左外側を読んでいたため、0.01000等を実際には読めていなかった。
- 数値ROIを黒グラフ内、左端〜最初の縦グリッド線の間へ変更。
- fixed5軸は0.0001/0.0002/0.0005/0.001/0.002/0.0025/0.005/0.01/0.02/0.025/0.05の標準step整合性を評価。
- 代表Trace点が少なくてもpixel fallbackへ進む。
- 結果詳細に実際に採用したY anchor文字列を表示。
