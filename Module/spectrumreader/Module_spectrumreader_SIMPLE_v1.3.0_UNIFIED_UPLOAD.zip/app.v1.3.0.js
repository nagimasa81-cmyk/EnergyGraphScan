
const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');

let ready=false, sourceWidth=1, sourceHeight=1;
const workCanvas=document.createElement('canvas'),
      workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
let workImageData=null,analysisScale=1;

const VERSION='1.3.0';
const BUILD='20260816-2355';

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){
  if(!a.length)return NaN;
  const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);
  return b.length%2?b[m]:(b[m-1]+b[m])/2;
}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;
  if(!d)return 0;
  let h;
  if(mx===r)h=60*(((g-b)/d)%6);
  else if(mx===g)h=60*((b-r)/d+2);
  else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function stats(r,g,b){
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=.299*r+.587*g+.114*b;
  return {mx,mn,lum,sat:(mx-mn)/Math.max(1,mx),h:rgb2hue(r,g,b)};
}
function greenStrength(r,g,b){return g-Math.max(r,b)*.84}
function isGridGreen(r,g,b){return g>45&&greenStrength(r,g,b)>9}

function releasePixels(){workImageData=null}
function pixels(){
  if(!workImageData)workImageData=workCtx.getImageData(0,0,workCanvas.width,workCanvas.height);
  return workImageData;
}
function idx(x,y){return (y*workCanvas.width+x)*4}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden');
  $('progressPct').textContent=`${p}%`;
  $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label;
  $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');
  $('lowValue').textContent='—';
  $('highValue').textContent='—';
  $('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;releasePixels();
  sourceWidth=sourceHeight=1;
  workCanvas.width=workCanvas.height=1;
  canvas.width=canvas.height=1;
  canvas.style.display='none';
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;
  $('status').textContent='Ready';
  $('progressCard').classList.add('hidden');
  clearResult();
}
function prepareWork(){
  // One controlled-resolution image is used by EVERY analysis stage.
  // No stage is allowed to silently switch coordinate systems.
  const maxSide=1800,sw=canvas.width,sh=canvas.height,
        scale=Math.min(1,maxSide/Math.max(sw,sh));
  analysisScale=scale;
  workCanvas.width=Math.max(1,Math.round(sw*scale));
  workCanvas.height=Math.max(1,Math.round(sh*scale));
  workCtx.clearRect(0,0,workCanvas.width,workCanvas.height);
  workCtx.drawImage(canvas,0,0,workCanvas.width,workCanvas.height);
  releasePixels(); pixels();
}
function toOriginalX(x){return x/analysisScale}
function toOriginalY(y){return y/analysisScale}

async function loadFile(file,autoAnalyze=true){
  clearResult();releasePixels();
  $('progressCard').classList.add('hidden');
  $('analyzeBtn').disabled=true;
  $('status').textContent='Loading full-resolution photo…';
  let bmp=null;
  try{
    bmp=await createImageBitmap(file);
    sourceWidth=bmp.width;sourceHeight=bmp.height;
    const previewMax=1800,
          s=Math.min(1,previewMax/Math.max(sourceWidth,sourceHeight)),
          w=Math.max(1,Math.round(sourceWidth*s)),
          h=Math.max(1,Math.round(sourceHeight*s));
    canvas.width=w;canvas.height=h;
    ctx.clearRect(0,0,w,h);
    ctx.drawImage(bmp,0,0,w,h);
    if(typeof bmp.close==='function')bmp.close();
    bmp=null;
    canvas.style.display='block';
    document.querySelector('.placeholder').style.display='none';
    ready=true;$('analyzeBtn').disabled=false;
    $('status').textContent=`Loaded — ${sourceWidth}×${sourceHeight}px`;
    if(autoAnalyze){
      await new Promise(r=>requestAnimationFrame(()=>r()));
      await analyze();
    }
  }catch(e){
    if(bmp&&typeof bmp.close==='function')try{bmp.close()}catch(_){}
    ready=false;
    $('status').textContent=`Image load failed: ${e.message||e}`;
    setProgress(100,'Needs attention',`Image load failed: ${e.message||e}`);
  }
}

/* ------------------------------------------------------------------
   STAGE 1 — locate the upper Energy-per-Band black plot
   ------------------------------------------------------------------ */

function longestDarkRun(y){
  const W=workCanvas.width,d=pixels().data;
  let bestLen=0,bestA=0,bestB=0,a=-1,gap=0;
  for(let x=0;x<W;x++){
    const i=idx(x,y),st=stats(d[i],d[i+1],d[i+2]);
    const dark=st.lum<92;
    if(dark){
      if(a<0)a=x;
      gap=0;
    }else if(a>=0){
      gap++;
      if(gap>3){
        const b=x-gap,len=b-a+1;
        if(len>bestLen){bestLen=len;bestA=a;bestB=b}
        a=-1;gap=0;
      }
    }
  }
  if(a>=0){
    const len=W-a;
    if(len>bestLen){bestLen=len;bestA=a;bestB=W-1}
  }
  return {len:bestLen,a:bestA,b:bestB};
}

function plotBandCandidates(){
  const W=workCanvas.width,H=workCanvas.height,minLen=Math.round(W*.25);
  const rows=[];
  for(let y=0;y<H;y++){
    const r=longestDarkRun(y);
    rows.push(r.len>=minLen?{y,...r}:null);
  }
  const groups=[];
  let cur=[];
  for(let y=0;y<H;y++){
    if(rows[y])cur.push(rows[y]);
    else if(cur.length){
      if(cur.length>=Math.max(24,Math.round(H*.035)))groups.push(cur);
      cur=[];
    }
  }
  if(cur.length>=Math.max(24,Math.round(H*.035)))groups.push(cur);

  const d=pixels().data,cands=[];
  for(const g of groups){
    const top=g[0].y,bottom=g.at(-1).y,
          left=Math.round(median(g.map(r=>r.a))),
          right=Math.round(median(g.map(r=>r.b))),
          w=right-left+1,h=bottom-top+1;
    if(w<120||h<65)continue;
    let dark=0,green=0,n=0;
    const xs=Math.max(1,Math.round(w/220)),ys=Math.max(1,Math.round(h/120));
    for(let y=top;y<=bottom;y+=ys)for(let x=left;x<=right;x+=xs){
      const i=idx(x,y),r=d[i],gg=d[i+1],b=d[i+2],st=stats(r,gg,b);
      n++;if(st.lum<100)dark++;if(isGridGreen(r,gg,b))green++;
    }
    const darkFrac=dark/Math.max(1,n),greenFrac=green/Math.max(1,n),
          aspect=w/Math.max(1,h);
    if(darkFrac<.46||greenFrac<.003||aspect<1.3)continue;
    // Energy-per-Band is the first qualifying graph in the photo.
    // Score slightly favors an upper, compact, grid-rich black panel.
    const score=darkFrac*4+greenFrac*16-Math.abs(aspect-2.1)*.12-(top/H)*.25;
    cands.push({left,top,right,bottom,w,h,darkFrac,greenFrac,score});
  }
  cands.sort((a,b)=>a.top-b.top || b.score-a.score);
  if(!cands.length)throw Error('Energy per Band black plot could not be localized.');
  return cands;
}

function smooth1(a,r=2){
  return a.map((_,i)=>{
    let s=0,n=0;
    for(let k=Math.max(0,i-r);k<=Math.min(a.length-1,i+r);k++){s+=a[k];n++}
    return s/n;
  });
}
function localPeaks(vals,minSep,minScore){
  const c=[];
  for(let i=1;i<vals.length-1;i++)
    if(vals[i]>=minScore&&vals[i]>=vals[i-1]&&vals[i]>=vals[i+1])c.push({i,s:vals[i]});
  c.sort((a,b)=>b.s-a.s);
  const keep=[];
  for(const q of c){
    if(keep.every(p=>Math.abs(p.i-q.i)>=minSep))keep.push(q);
    if(keep.length>=20)break;
  }
  return keep.sort((a,b)=>a.i-b.i);
}

function greenProfiles(box){
  const d=pixels().data,w=box.right-box.left+1,h=box.bottom-box.top+1;
  let hs=new Array(h).fill(0),vs=new Array(w).fill(0);
  for(let yy=0;yy<h;yy++){
    let c=0,n=0;
    // ignore extreme label/title edges when evaluating horizontal grid support
    const xa=box.left+Math.round(w*.12),xb=box.right-Math.round(w*.03);
    for(let x=xa;x<=xb;x+=2){
      const i=idx(x,box.top+yy);
      if(isGridGreen(d[i],d[i+1],d[i+2]))c++;
      n++;
    }
    hs[yy]=c/Math.max(1,n);
  }
  for(let xx=0;xx<w;xx++){
    let c=0,n=0;
    const ya=box.top+Math.round(h*.08),yb=box.bottom-Math.round(h*.12);
    for(let y=ya;y<=yb;y+=2){
      const i=idx(box.left+xx,y);
      if(isGridGreen(d[i],d[i+1],d[i+2]))c++;
      n++;
    }
    vs[xx]=c/Math.max(1,n);
  }
  return {hs:smooth1(hs,1),vs:smooth1(vs,1)};
}

function bestRegularLattice(peaks,minCount,maxCount){
  if(peaks.length<minCount)return null;
  let best=null;
  const pos=peaks.map(p=>p.i);
  for(let a=0;a<pos.length;a++)for(let b=a+1;b<pos.length;b++){
    const diff=pos[b]-pos[a];
    for(let div=1;div<=Math.min(5,maxCount-1);div++){
      const step=diff/div;
      if(step<6)continue;
      const start=pos[a]-Math.round((a>0?1:0)*0); // explicit for clarity
      const matched=[];
      for(let k=-2;k<maxCount+3;k++){
        const target=start+k*step;
        if(target<pos[0]-step||target>pos.at(-1)+step)continue;
        let q=null;
        for(const p of peaks){
          const e=Math.abs(p.i-target);
          if(e<=Math.max(2.5,step*.11)&&(!q||e<q.e))q={p,e};
        }
        if(q&&!matched.some(m=>m.i===q.p.i))matched.push(q.p);
      }
      matched.sort((x,y)=>x.i-y.i);
      if(matched.length<minCount)continue;
      const ds=matched.slice(1).map((p,i)=>p.i-matched[i].i),
            md=median(ds),err=median(ds.map(v=>Math.abs(v-md)))/Math.max(1,md),
            score=matched.length*4-err*20+mean(matched.map(p=>p.s))*4;
      if(!best||score>best.score)best={matched,step:md,score,err};
    }
  }
  return best;
}

function refinePlot(box){
  const {hs,vs}=greenProfiles(box),
        hp=localPeaks(hs,Math.max(5,Math.round(box.h/18)),.035),
        vp=localPeaks(vs,Math.max(5,Math.round(box.w/24)),.035),
        H=bestRegularLattice(hp,2,8),
        V=bestRegularLattice(vp,5,14);
  if(!H||!V)throw Error('Energy plot grid lattice could not be resolved.');

  let hy=H.matched.map(p=>box.top+p.i),
      vx=V.matched.map(p=>box.left+p.i);

  // Reconstruct missing members of a regular lattice instead of treating text/trace as grid.
  function reconstruct(arr,step,minV,maxV,maxN){
    arr=[...arr].sort((a,b)=>a-b);
    const origin=arr[0],out=[];
    for(let k=0;k<maxN;k++){
      const p=origin+k*step;
      if(p>maxV+step*.25)break;
      if(p>=minV-step*.25)out.push(p);
    }
    return out;
  }
  hy=reconstruct(hy,H.step,box.top,box.bottom,8);
  vx=reconstruct(vx,V.step,box.left,box.right,14);

  // Energy graphs supplied here use a dense X lattice. If the black candidate includes
  // the lower Raw Data plot, this condition rejects it rather than contaminating trace values.
  if(vx.length<6||hy.length<2)throw Error('Energy plot grid geometry is incomplete.');

  return {
    box,
    left:vx[0],right:vx.at(-1),
    top:hy[0],bottom:hy.at(-1),
    h:hy,v:vx,
    hStep:H.step,vStep:V.step
  };
}

function locateEnergyPlot(){
  const cands=plotBandCandidates();
  let failures=[];
  for(const b of cands.slice(0,5)){
    try{
      const p=refinePlot(b);
      const aspect=(p.right-p.left)/Math.max(1,p.bottom-p.top);
      if(aspect<1.4||aspect>4.5)throw Error('grid aspect');
      return p;
    }catch(e){failures.push(e.message)}
  }
  throw Error(`Energy plot localization failed (${failures.join('; ')}).`);
}

/* ------------------------------------------------------------------
   STAGE 2 — Y axis: aspect-preserving whole-label templates + lattice
   ------------------------------------------------------------------ */

const tplCanvas=document.createElement('canvas'),
      tplCtx=tplCanvas.getContext('2d',{willReadFrequently:true}),
      tplCache=new Map();

function normalizeMask(points,tw=144,th=36){
  if(!points.length)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const [x,y] of points){minx=Math.min(minx,x);miny=Math.min(miny,y);maxx=Math.max(maxx,x);maxy=Math.max(maxy,y)}
  const bw=maxx-minx+1,bh=maxy-miny+1;
  if(bw<2||bh<2)return null;
  // Preserve aspect ratio. Earlier versions stretched every string to the same width,
  // making "3.0" look artificially similar to "0.03000".
  const s=Math.min((tw-6)/bw,(th-4)/bh),
        ox=(tw-bw*s)/2,oy=(th-bh*s)/2,
        out=new Uint8Array(tw*th);
  for(const [x,y] of points){
    const xx=Math.round(ox+(x-minx)*s),yy=Math.round(oy+(y-miny)*s);
    for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
      const X=xx+dx,Y=yy+dy;
      if(X>=0&&X<tw&&Y>=0&&Y<th)out[Y*tw+X]=1;
    }
  }
  return out;
}
function maskScore(a,b){
  if(!a||!b)return 0;
  let inter=0,ua=0,ub=0;
  for(let i=0;i<a.length;i++){
    if(a[i])ua++;if(b[i])ub++;if(a[i]&&b[i])inter++;
  }
  if(!ua||!ub)return 0;
  const precision=inter/ub,recall=inter/ua;
  return precision+recall?2*precision*recall/(precision+recall):0;
}
function translatedScore(a,b,tw=144,th=36){
  let best=0;
  for(let sy=-2;sy<=2;sy++)for(let sx=-3;sx<=3;sx++){
    let inter=0,ua=0,ub=0;
    for(let y=0;y<th;y++)for(let x=0;x<tw;x++){
      const av=a[y*tw+x];
      const xx=x-sx,yy=y-sy;
      const bv=(xx>=0&&xx<tw&&yy>=0&&yy<th)?b[yy*tw+xx]:0;
      if(av)ua++;if(bv)ub++;if(av&&bv)inter++;
    }
    if(ua&&ub){
      const p=inter/ub,r=inter/ua,f=2*p*r/(p+r||1);
      if(f>best)best=f;
    }
  }
  return best;
}
function textTemplate(text){
  if(tplCache.has(text))return tplCache.get(text);
  tplCanvas.width=220;tplCanvas.height=60;
  tplCtx.clearRect(0,0,220,60);
  tplCtx.fillStyle='black';tplCtx.fillRect(0,0,220,60);
  tplCtx.fillStyle='white';
  tplCtx.font='26px Arial';
  tplCtx.textBaseline='middle';
  tplCtx.fillText(text,4,30);
  const im=tplCtx.getImageData(0,0,220,60).data,pts=[];
  for(let y=0;y<60;y++)for(let x=0;x<220;x++){
    const i=(y*220+x)*4;
    if(im[i]>90)pts.push([x,y]);
  }
  const m=normalizeMask(pts);
  tplCache.set(text,m);
  return m;
}
function observedLabelMask(plot,y){
  const d=pixels().data,
        axisX=plot.left,
        rowStep=plot.hStep,
        x0=Math.max(plot.box.left,Math.round(axisX-(plot.right-plot.left)*.28)),
        x1=Math.max(x0+8,axisX-2),
        y0=Math.max(plot.box.top,Math.round(y-rowStep*.38)),
        y1=Math.min(plot.box.bottom,Math.round(y+rowStep*.38)),
        pts=[];
  for(let yy=y0;yy<=y1;yy++)for(let x=x0;x<=x1;x++){
    // Remove the exact horizontal grid line; only label glyphs should remain.
    if(Math.abs(yy-y)<=1)continue;
    const i=idx(x,yy),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
    if(isGridGreen(r,g,b)&&st.lum>35)pts.push([x-x0,yy-y0]);
  }
  return normalizeMask(pts);
}
function fmtAxis(v,family){
  if(family==='decimal')return Math.abs(v)<5e-8?'0.00000':v.toFixed(5);
  return v.toFixed(1);
}
function axisModels(n){
  const out=[];
  const decimalSteps=[0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02];
  for(const step of decimalSteps){
    for(let k=-4;k<=20;k++){
      const top=step*k,bottom=top-step*(n-1);
      if(top>.10||bottom<-.05)continue;
      out.push({family:'decimal',step,top});
    }
  }
  const compactSteps=[0.1,0.2,0.5,1,2,2.5,5];
  for(const step of compactSteps){
    for(let k=-4;k<=20;k++){
      const top=step*k,bottom=top-step*(n-1);
      if(top>30||bottom<-15)continue;
      out.push({family:'compact',step,top});
    }
  }
  return out;
}
function modelPrior(m){
  if(m.family==='compact')return 0;
  if(m.step===.01)return 1.8;
  if(m.step===.005)return 1.6;
  if(m.step===.0025)return .7;
  if(m.step===.001)return .3;
  if(m.step<=.0002)return -.9;
  return 0;
}
function solveYAxis(plot){
  const obs=plot.h.map(y=>observedLabelMask(plot,y)),
        usable=obs.filter(Boolean).length;
  if(usable<2)throw Error('Y-axis labels are not clear enough.');

  let ranked=[];
  for(const m of axisModels(plot.h.length)){
    let score=modelPrior(m),support=0,rowScores=[];
    for(let i=0;i<plot.h.length;i++){
      if(!obs[i]){rowScores.push(0);continue}
      const value=m.top-m.step*i,text=fmtAxis(value,m.family),
            sc=translatedScore(obs[i],textTemplate(text));
      rowScores.push(sc);
      score+=sc*5;
      if(sc>.16)support++;
    }

    // Whole-lattice support: two accidental rows are not enough when more are visible.
    score+=support*1.8;
    if(support<2)score-=8;
    if(plot.h.length>=4&&support<3)score-=3;

    // Aspect-family evidence is naturally contained in aspect-preserving masks.
    // Add an explicit top-vs-second discrimination term after ranking.
    ranked.push({...m,score,support,rowScores});
  }
  ranked.sort((a,b)=>b.score-a.score);
  const best=ranked[0],second=ranked[1];
  if(!best||best.support<2)throw Error('Y-axis numeric lattice could not be resolved.');
  const margin=best.score-(second?.score??-Infinity);
  if(margin<.35)throw Error('Y-axis scale is ambiguous; retake closer to the graph.');

  // Tiny decimal steps are allowed only when they win clearly.
  if(best.family==='decimal'&&best.step<=.0005&&margin<1.2)
    throw Error('Tiny decimal Y-axis lacks enough digit evidence.');

  const slope=-best.step/plot.hStep,
        intercept=best.top-slope*plot.h[0],
        values=plot.h.map((y,i)=>best.top-best.step*i);
  return {
    family:best.family,step:best.step,top:best.top,
    slope,intercept,values,
    score:best.score,margin,support:best.support,rowScores:best.rowScores
  };
}

/* ------------------------------------------------------------------
   STAGE 3 — trace extraction strictly INSIDE the selected Energy plot
   ------------------------------------------------------------------ */

function foregroundModel(plot){
  const d=pixels().data,bins=new Array(72).fill(0);
  let colored=0,white=0;
  const xs=Math.max(1,Math.round((plot.right-plot.left)/260)),
        ys=Math.max(1,Math.round((plot.bottom-plot.top)/160));
  for(let y=Math.round(plot.top+3);y<=plot.bottom-3;y+=ys)
    for(let x=Math.round(plot.left+3);x<=plot.right-3;x+=xs){
      const i=idx(x,y),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
      if(isGridGreen(r,g,b))continue;
      if(st.sat>.20&&st.lum>42){
        bins[Math.floor(st.h/5)%72]++;colored++;
      }else if(st.sat<.17&&st.lum>145)white++;
    }
  let bi=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  const hue=bi*5+2.5;
  return {mode:white>colored*.65?'white':'color',hue,colored,white};
}
function isWhitePoint(x,y){
  const d=pixels().data,i=idx(x,y),st=stats(d[i],d[i+1],d[i+2]);
  if(!(st.sat<.20&&st.lum>145))return false;
  // Reject interiors of large white tooltip rectangles: trace squares have dark neighborhood.
  let dark=0,n=0;
  for(let dy=-2;dy<=2;dy+=2)for(let dx=-2;dx<=2;dx+=2){
    const X=clamp(x+dx,0,workCanvas.width-1),Y=clamp(y+dy,0,workCanvas.height-1),
          j=idx(X,Y),q=stats(d[j],d[j+1],d[j+2]);
    n++;if(q.lum<100)dark++;
  }
  return dark/n>.20;
}
function isTracePixel(x,y,fm){
  const d=pixels().data,i=idx(x,y),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
  if(isGridGreen(r,g,b)||st.lum<32)return false;
  if(fm.mode==='white')return isWhitePoint(x,y);
  return st.sat>.14&&st.lum>40&&hueDist(st.h,fm.hue)<32;
}
function traceByColumns(plot){
  const fm=foregroundModel(plot),
        span=plot.right-plot.left,
        bins=Math.max(120,Math.min(420,Math.round(span/2))),
        out=[];
  for(let bi=0;bi<bins;bi++){
    const xa=Math.round(plot.left+bi/bins*span),
          xb=Math.max(xa,Math.round(plot.left+(bi+1)/bins*span)-1),
          ys=[];
    for(let x=xa;x<=xb;x++)for(let y=Math.round(plot.top+2);y<=plot.bottom-2;y++){
      if(isTracePixel(x,y,fm))ys.push(y);
    }
    if(!ys.length)continue;
    ys.sort((a,b)=>a-b);

    // Cluster vertically. Pick the densest compact cluster; tooltip/background blocks are broad.
    let clusters=[],cur=[ys[0]],gap=Math.max(2,Math.round(plot.hStep*.12));
    for(let i=1;i<ys.length;i++){
      if(ys[i]-ys[i-1]<=gap)cur.push(ys[i]);
      else{clusters.push(cur);cur=[ys[i]]}
    }
    clusters.push(cur);
    clusters.sort((a,b)=>b.length-a.length || (a.at(-1)-a[0])-(b.at(-1)-b[0]));
    const c=clusters[0];
    out.push({x:(xa+xb)/2,y:median(c),support:c.length});
  }
  if(out.length<12)throw Error('Foreground trace could not be isolated inside Energy plot.');
  return {fm,points:out};
}
function xValue(plot,x){return 500*(x-plot.left)/Math.max(1,plot.right-plot.left)}
function yValue(scale,y){return scale.slope*y+scale.intercept}

function robustRangeMean(plot,scale,trace,a,b){
  let pts=trace.points.filter(p=>{
    const x=xValue(plot,p.x);return x>=a&&x<=b;
  });
  if(pts.length<3)throw Error(`Not enough trace samples in ${a===0?'Low':'High'} range.`);
  let vals=pts.map(p=>yValue(scale,p.y)),
      m=median(vals),M=mad(vals)||Math.max(scale.step*.03,1e-9),
      lim=Math.max(M*4,scale.step*.35),
      keep=vals.filter(v=>Math.abs(v-m)<=lim);
  if(keep.length<3){
    keep=vals.filter(v=>Math.abs(v-m)<=Math.max(M*7,scale.step*.65));
  }
  if(keep.length<3)throw Error(`Trace is unstable in ${a===0?'Low':'High'} range.`);
  return {mean:mean(keep),count:keep.length,median:m};
}

/* ------------------------------------------------------------------
   STAGE 4 — one authoritative calibration/trace consistency gate
   ------------------------------------------------------------------ */

function validateResult(plot,scale,low,high,trace){
  const axisMin=Math.min(...scale.values),axisMax=Math.max(...scale.values),
        tol=scale.step*.22;
  for(const [name,obj] of [['Low',low],['High',high]]){
    if(!Number.isFinite(obj.mean))throw Error(`${name} is not finite.`);
    if(obj.mean<axisMin-tol||obj.mean>axisMax+tol)
      throw Error(`${name} contradicts the visible Y-axis range.`);
  }

  // Ensure every accepted trace point is actually inside this Energy plot.
  const bad=trace.points.filter(p=>p.y<plot.top-2||p.y>plot.bottom+2).length;
  if(bad)throw Error('Trace escaped Energy plot geometry.');

  // Overlay inversion must map back into the same plot.
  for(const v of [low.mean,high.mean]){
    const y=(v-scale.intercept)/scale.slope;
    if(y<plot.top-plot.hStep*.3||y>plot.bottom+plot.hStep*.3)
      throw Error('Pixel/value calibration is internally inconsistent.');
  }
}

function decimalsFor(scale){
  if(scale.family==='compact')return 2;
  return 4;
}
function drawResult(plot,scale,low,high){
  resultCanvas.width=canvas.width;resultCanvas.height=canvas.height;
  rctx.clearRect(0,0,resultCanvas.width,resultCanvas.height);
  rctx.drawImage(canvas,0,0);
  rctx.strokeStyle='#26d7ff';rctx.fillStyle='#26d7ff';
  rctx.lineWidth=Math.max(2,resultCanvas.width/700);
  rctx.font=`${Math.max(18,resultCanvas.width/38)}px Arial`;

  const pL=toOriginalX(plot.left),pR=toOriginalX(plot.right),
        ly=toOriginalY((low.mean-scale.intercept)/scale.slope),
        hy=toOriginalY((high.mean-scale.intercept)/scale.slope),
        dec=decimalsFor(scale);

  rctx.beginPath();rctx.moveTo(pL,ly);rctx.lineTo(pL+(pR-pL)*.52,ly);rctx.stroke();
  rctx.fillText(`Low ${low.mean.toFixed(dec)}`,pL+8,ly-8);
  rctx.beginPath();rctx.moveTo(pL+(pR-pL)*.54,hy);rctx.lineTo(pR,hy);rctx.stroke();
  rctx.fillText(`High ${high.mean.toFixed(dec)}`,pL+(pR-pL)*.56,hy-8);
}

async function analyze(){
  if(!ready)return;
  const t0=performance.now();
  $('analyzeBtn').disabled=true;
  clearResult();
  try{
    setProgress(8,'Prepare','Building one authoritative analysis image');
    await new Promise(r=>setTimeout(r,0));
    prepareWork();

    setProgress(24,'Energy plot','Separating upper Energy per Band plot from Raw Data');
    await new Promise(r=>setTimeout(r,0));
    const plot=locateEnergyPlot();

    setProgress(46,'Y-axis','Solving one aspect-preserving numeric lattice');
    await new Promise(r=>setTimeout(r,0));
    const scale=solveYAxis(plot);

    setProgress(66,'Trace','Extracting trace only inside the Energy plot');
    await new Promise(r=>setTimeout(r,0));
    const trace=traceByColumns(plot);

    setProgress(82,'Low / High','Computing robust Low 0–260 / High 270–500 means');
    await new Promise(r=>setTimeout(r,0));
    const low=robustRangeMean(plot,scale,trace,0,260),
          high=robustRangeMean(plot,scale,trace,270,500);

    setProgress(92,'Validation','Cross-checking ROI, axis, trace and value mapping');
    validateResult(plot,scale,low,high,trace);

    const dec=decimalsFor(scale);
    $('lowValue').textContent=low.mean.toFixed(dec);
    $('highValue').textContent=high.mean.toFixed(dec);
    drawResult(plot,scale,low,high);

    $('detail').textContent=
      `Unified Core v6; source ${sourceWidth}×${sourceHeight}; work ${workCanvas.width}×${workCanvas.height}; `+
      `Energy plot ${Math.round(plot.right-plot.left)}×${Math.round(plot.bottom-plot.top)}; `+
      `Y ${scale.family}; step ${Number(scale.step.toPrecision(6))}; grid ${scale.values.map(v=>fmtAxis(v,scale.family)).join(' / ')}; `+
      `model margin ${scale.margin.toFixed(2)}; support ${scale.support}; `+
      `trace ${trace.fm.mode}; Low n=${low.count}; High n=${high.count}; X 0–500.`;

    $('resultCard').classList.remove('hidden');
    setProgress(100,'Complete',`Total ${((performance.now()-t0)/1000).toFixed(1)}s`);
    $('status').textContent='Analysis complete';
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{$('resultCard').scrollIntoView({behavior:'smooth',block:'start'})}
    catch(_){$('resultCard').scrollIntoView()}
  }catch(e){
    const msg=e?.message||String(e);
    $('status').textContent=msg;
    setProgress(100,'Needs attention',msg);
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{$('progressCard').scrollIntoView({behavior:'smooth',block:'center'})}catch(_){}
  }finally{
    releasePixels();
    $('analyzeBtn').disabled=false;
  }
}

$('cameraBtn').onclick=()=>{$('fileCamera').value='';$('fileCamera').click()};
$('libraryBtn').onclick=()=>{$('fileLibrary').value='';$('fileLibrary').click()};
$('fileCamera').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(f)await loadFile(f,true)};
$('fileLibrary').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(f)await loadFile(f,true)};
$('resetBtn').onclick=reset;
$('analyzeBtn').onclick=analyze;
reset();

// Keep Pages deterministic while numeric validation is active.
(async()=>{
  try{
    if('serviceWorker' in navigator){
      const regs=await navigator.serviceWorker.getRegistrations();
      for(const r of regs)if(r.scope.includes('/Module/spectrumreader/'))await r.unregister();
    }
    if('caches' in window){
      const ks=await caches.keys();
      for(const k of ks)if(k.startsWith('energy-graph'))await caches.delete(k);
    }
  }catch(_){}
})();
