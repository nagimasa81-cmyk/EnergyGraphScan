// Simple v1.1.0 unified visual core

const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');

let ready=false;
const workCanvas=document.createElement('canvas'),
      workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
let analysisScale=1;

function prepareWorkingImage(){
  const maxSide=800,
        sw=canvas.width,sh=canvas.height,
        scale=Math.min(1,maxSide/Math.max(sw,sh));
  analysisScale=scale;
  workCanvas.width=Math.max(1,Math.round(sw*scale));
  workCanvas.height=Math.max(1,Math.round(sh*scale));
  workCtx.clearRect(0,0,workCanvas.width,workCanvas.height);
  workCtx.drawImage(canvas,0,0,workCanvas.width,workCanvas.height);
  return {canvas:workCanvas,ctx:workCtx,scale};
}
function toOriginalX(x){return x/analysisScale}
function toOriginalY(y){return y/analysisScale}


function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){if(!a.length)return NaN;const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden'); $('progressPct').textContent=`${p}%`; $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label; $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');$('lowValue').textContent='—';$('highValue').textContent='—';$('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;canvas.width=1;canvas.height=1;canvas.style.display='none';$('.placeholder');
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;$('status').textContent='Ready';$('progressCard').classList.add('hidden');clearResult();
}
async function loadFile(file){
  clearResult(); $('progressCard').classList.add('hidden'); $('status').textContent='Loading full-resolution image…';
  const bmp=await createImageBitmap(file);
  canvas.width=bmp.width;canvas.height=bmp.height;ctx.drawImage(bmp,0,0);
  canvas.style.display='block';document.querySelector('.placeholder').style.display='none';
  ready=true;$('analyzeBtn').disabled=false;$('status').textContent=`Ready — ${bmp.width}×${bmp.height}px`;
}
$('cameraBtn').onclick=()=>$('fileCamera').click();
$('libraryBtn').onclick=()=>$('fileLibrary').click();
$('fileCamera').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('fileLibrary').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('resetBtn').onclick=reset;

function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h;
  if(mx===r)h=60*(((g-b)/d)%6);else if(mx===g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function isGreen(r,g,b){return g>55&&g>r*1.12&&g>b*1.12}
function preprocess(){
  const im=workCtx.getImageData(0,0,workCanvas.width,workCanvas.height),d=im.data,l=[];
  for(let i=0;i<d.length;i+=4)l.push(.299*d[i]+.587*d[i+1]+.114*d[i+2]);
  l.sort((a,b)=>a-b);const q=x=>l[Math.floor((l.length-1)*x)],lo=q(.04),hi=q(.98),span=Math.max(20,hi-lo);
  return {im,lo,hi,span};
}
function lineScores(axis){
  const {width:W,height:H}=workCanvas,im=workCtx.getImageData(0,0,W,H).data;
  const N=axis==='h'?H:W,scores=new Array(N).fill(0);
  for(let p=0;p<N;p++){
    let green=0,dark=0,n=0;
    const M=axis==='h'?W:H;
    for(let k=0;k<M;k+=Math.max(1,Math.floor(M/700))){
      const x=axis==='h'?k:p,y=axis==='h'?p:k,i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],lum=(r+g+b)/3;
      n++; if(isGreen(r,g,b))green++; if(lum<100)dark++;
    }
    scores[p]=green/n*.8+dark/n*.2;
  }
  return scores;
}
function peaks(scores,minGap){
  const cand=[];for(let i=2;i<scores.length-2;i++)if(scores[i]>scores[i-1]&&scores[i]>=scores[i+1])cand.push({i,s:scores[i]});
  cand.sort((a,b)=>b.s-a.s);const out=[];
  for(const c of cand){if(out.every(x=>Math.abs(x-c.i)>minGap))out.push(c.i);if(out.length>=18)break}
  return out.sort((a,b)=>a-b);
}
function detectPlot(){
  const hp=peaks(lineScores('h'),Math.max(4,workCanvas.height*.03));
  const vp=peaks(lineScores('v'),Math.max(5,workCanvas.width*.035));
  if(hp.length<3||vp.length<4) throw Error('Grid detection failed. Include the full black graph.');
  // choose densest regularly spaced runs
  function regular(arr){
    let best=null;
    for(let i=0;i<arr.length;i++)for(let j=i+2;j<arr.length;j++){
      const sub=arr.slice(i,j+1),ds=sub.slice(1).map((v,k)=>v-sub[k]),m=median(ds),e=median(ds.map(x=>Math.abs(x-m)));
      const score=sub.length/(1+e/Math.max(1,m));
      if(!best||score>best.score)best={arr:sub,step:m,score};
    } return best;
  }
  const H=regular(hp),V=regular(vp); if(!H||!V) throw Error('Grid lattice unresolved.');
  return {left:V.arr[0],right:V.arr.at(-1),top:H.arr[0],bottom:H.arr.at(-1),h:H.arr,v:V.arr};
}
function estimateY(plot){
  // Infer numeric step primarily from green horizontal-grid spacing + image label morphology.
  // For simple version support the two families actually used in these graphs:
  // Gain usually step 1; Noise commonly .005 or .01.
  const stepPx=median(plot.h.slice(1).map((y,i)=>y-plot.h[i]));
  const W=canvas.width,im=ctx.getImageData(0,0,W,canvas.height).data;
  // Find decimal-label ink/green activity left of y-axis.
  const lx0=Math.max(0,plot.left-Math.round((plot.right-plot.left)*.25)),lx1=plot.left;
  let tiny=0,total=0;
  for(let y=plot.top;y<=plot.bottom;y++)for(let x=lx0;x<lx1;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2]; if(isGreen(r,g,b)){total++; if(g<190)tiny++}
  }
  // Use plot height/trace location as family-independent scale candidate set.
  // We score candidates using visible horizontal grid count and trace plausibility.
  const candidates=[1,.5,.02,.01,.005,.001];
  return {stepPx,candidates};
}

async function traceHue(plot,onProgress){
  const W=workCanvas.width,H=workCanvas.height,
        im=workCtx.getImageData(0,0,W,H).data,
        bins=new Array(36).fill(0),
        xStep=Math.max(2,Math.round((plot.right-plot.left)/220)),
        yStep=Math.max(2,Math.round((plot.bottom-plot.top)/140)),
        total=Math.max(1,Math.ceil((plot.right-plot.left+1)/xStep)),
        yieldEvery=28;
  let xi=0;
  for(let x=plot.left;x<=plot.right;x+=xStep){
    for(let y=plot.top;y<=plot.bottom;y+=yStep){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
            mx=Math.max(r,g,b),mn=Math.min(r,g,b),
            sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.20&&lum>55&&!isGreen(r,g,b))
        bins[Math.floor(rgb2hue(r,g,b)/10)]++;
    }
    xi++;
    if(xi%yieldEvery===0){
      if(onProgress)onProgress(xi/total);
      await new Promise(r=>setTimeout(r,0));
    }
  }
  let bi=0;
  for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  if(onProgress)onProgress(1);
  return bi*10+5;
}

function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}

function rgbStats(r,g,b){
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3;
  return {mx,mn,lum,sat:(mx-mn)/Math.max(1,mx),h:rgb2hue(r,g,b)};
}
function greenStrength(r,g,b){return g-Math.max(r,b)*0.82}
function integralMask(mask,W,H){
  const I=new Uint32Array((W+1)*(H+1));
  for(let y=1;y<=H;y++){
    let row=0;
    for(let x=1;x<=W;x++){
      row+=mask[(y-1)*W+(x-1)];
      I[y*(W+1)+x]=I[(y-1)*(W+1)+x]+row;
    }
  }
  return I;
}
function rectSum(I,W,x0,y0,x1,y1){
  const H=(I.length/(W+1))-1,S=W+1;
  x0=Math.max(0,Math.min(W,x0));x1=Math.max(0,Math.min(W,x1));
  y0=Math.max(0,Math.min(H,y0));y1=Math.max(0,Math.min(H,y1));
  return I[y1*S+x1]-I[y0*S+x1]-I[y1*S+x0]+I[y0*S+x0];
}
function detectBlackPlot(){
  const W=workCanvas.width,H=workCanvas.height,im=workCtx.getImageData(0,0,W,H).data,
        dark=new Uint8Array(W*H),green=new Uint8Array(W*H);
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    if(st.lum<95)dark[y*W+x]=1;
    if(greenStrength(r,g,b)>18&&g>55)green[y*W+x]=1;
  }
  const D=integralMask(dark,W,H),G=integralMask(green,W,H);
  let best=null;
  const minW=Math.max(140,Math.round(W*.30)),maxW=Math.round(W*.76),
        minH=Math.max(90,Math.round(H*.15)),maxH=Math.round(H*.50),
        sx=Math.max(10,Math.round(W/50)),sy=Math.max(10,Math.round(H/50));
  for(let h=minH;h<=maxH;h+=sy)for(let w=minW;w<=maxW;w+=sx)
    for(let y=Math.round(H*.08);y+h<=H;y+=sy)for(let x=Math.round(W*.08);x+w<=W;x+=sx){
      const area=w*h,d=rectSum(D,W,x,y,x+w,y+h)/area;
      if(d<.50)continue;
      const gr=rectSum(G,W,x,y,x+w,y+h)/area,
            score=d*2.5+gr*1.1+(x/W)*.15-Math.abs(w/h-1.8)*.08;
      if(!best||score>best.score)best={left:x,top:y,right:x+w,bottom:y+h,score};
    }
  if(!best)throw Error('Black Energy per Band plot could not be localized.');
  return best;
}
function detectGreenGrid(plot){
  const W=workCanvas.width,im=workCtx.getImageData(0,0,W,workCanvas.height).data,
        rows=[],cols=[];
  for(let y=plot.top;y<=plot.bottom;y++){
    let c=0,n=0;
    for(let x=plot.left;x<=plot.right;x+=2){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenStrength(r,g,b)>14&&g>45)c++;
      n++;
    }
    rows.push({p:y,s:c/Math.max(1,n)});
  }
  for(let x=plot.left;x<=plot.right;x++){
    let c=0,n=0;
    for(let y=plot.top;y<=plot.bottom;y+=2){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2];
      if(greenStrength(r,g,b)>14&&g>45)c++;
      n++;
    }
    cols.push({p:x,s:c/Math.max(1,n)});
  }
  function peaks(arr,minSep,thr,maxN){
    const out=[];
    for(const q of [...arr].sort((a,b)=>b.s-a.s)){
      if(q.s<thr)break;
      if(out.some(p=>Math.abs(p-q.p)<minSep))continue;
      out.push(q.p);
      if(out.length>=maxN)break;
    }
    return out.sort((a,b)=>a-b);
  }
  const h=peaks(rows,Math.max(6,Math.round((plot.bottom-plot.top)/18)),.10,12),
        v=peaks(cols,Math.max(6,Math.round((plot.right-plot.left)/22)),.10,14);
  if(h.length<2)throw Error('Horizontal green grid could not be resolved.');
  if(v.length<3)throw Error('Vertical green grid could not be resolved.');
  return {h,v};
}
function observedLabelStrip(plot,y,rowStep){
  const x1=Math.max(2,plot.left-3),
        span=Math.max(60,Math.min(150,Math.round((plot.right-plot.left)*.28))),
        x0=Math.max(0,x1-span),half=Math.max(8,Math.round(rowStep*.34)),
        y0=Math.max(0,Math.round(y-half)),
        y1=Math.min(workCanvas.height,Math.round(y+half)),
        W=Math.max(1,x1-x0),H=Math.max(1,y1-y0),
        im=workCtx.getImageData(x0,y0,W,H).data,pts=[];
  for(let yy=0;yy<H;yy++)for(let xx=0;xx<W;xx++){
    const i=(yy*W+xx)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    const greenish=greenStrength(r,g,b)>12&&g>50,
          bright=st.lum>140&&(st.mx-st.mn)<80;
    if(greenish||bright)pts.push([xx,yy]);
  }
  return normMask(pts);
}
function visualYLabels(){
  const out=new Map();
  for(let i=-30;i<=120;i++){
    const v=i/1000;
    for(const t of [v.toFixed(5),v.toFixed(4),v.toFixed(3)])out.set(t,v);
  }
  for(let i=-30;i<=60;i++){
    const v=i/2;
    for(const t of [v.toFixed(1),v.toFixed(2),String(v)])out.set(t,v);
  }
  for(const t of ['0','0.0','0.00','0.000','0.0000','0.00000'])out.set(t,0);
  return [...out].map(([text,value])=>({text,value}));
}
const VIS_LABELS=visualYLabels();
function recognizeGridAnchors(plot,grid){
  const stepPx=median(grid.h.slice(1).map((y,i)=>y-grid.h[i])),rows=[];
  for(const y of grid.h){
    const obs=observedLabelStrip(plot,y,stepPx);if(!obs)continue;
    const hyps=[];
    for(const c of VIS_LABELS){
      let best=0;
      for(const font of ['Arial','Verdana'])for(const size of [22,26])
        best=Math.max(best,directMaskScore(obs,yLineTemplate(c.text,font,size)));
      if(best>.17)hyps.push({...c,conf:best});
    }
    hyps.sort((a,b)=>b.conf-a.conf);
    if(hyps.length)rows.push({y,hyps:hyps.slice(0,8)});
  }
  if(rows.length<2)throw Error('Y-axis numeric anchors could not be resolved.');
  let best=null;
  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const A=rows[i],B=rows[j],dy=B.y-A.y;if(dy<4)continue;
    for(const a of A.hyps)for(const b of B.hyps){
      const slope=(b.value-a.value)/dy;if(!(slope<0))continue;
      const intercept=a.value-slope*A.y,step=Math.abs(slope*stepPx);
      if(step<1e-6||step>20)continue;
      let support=0,score=0,used=[];
      for(const row of rows){
        const pred=slope*row.y+intercept;let q=null;
        for(const h of row.hyps){
          const err=Math.abs(h.value-pred)/Math.max(step,1e-9);
          if(!q||err<q.err)q={...h,err};
        }
        if(q&&q.err<.2){
          support++;score+=4+(q.conf||0)*2-q.err*2;
          used.push({y:row.y,value:q.value,text:q.text,conf:q.conf});
        }
      }
      if(!best||score>best.score)best={slope,intercept,step,support,score,used};
    }
  }
  if(!best||best.support<2)throw Error('Y-axis numeric anchors are inconsistent.');
  return best;
}
function dominantForegroundHue(plot){
  const W=workCanvas.width,im=workCtx.getImageData(0,0,W,workCanvas.height).data,
        bins=new Array(72).fill(0),
        xs=Math.max(1,Math.ceil((plot.right-plot.left)/260)),
        ys=Math.max(1,Math.ceil((plot.bottom-plot.top)/160));
  for(let y=plot.top;y<=plot.bottom;y+=ys)for(let x=plot.left;x<=plot.right;x+=xs){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    if(st.sat>.18&&st.lum>45&&greenStrength(r,g,b)<12)bins[Math.floor(st.h/5)%72]++;
  }
  let bi=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  return bi*5+2.5;
}
function tracePointsUnified(plot){
  const W=workCanvas.width,im=workCtx.getImageData(0,0,W,workCanvas.height).data,
        hue=dominantForegroundHue(plot),pts=[],
        xs=Math.max(1,Math.ceil((plot.right-plot.left)/420)),
        ys=Math.max(1,Math.ceil((plot.bottom-plot.top)/220));
  for(let y=plot.top;y<=plot.bottom;y+=ys)for(let x=plot.left;x<=plot.right;x+=xs){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],st=rgbStats(r,g,b);
    if(st.sat>.16&&st.lum>45&&greenStrength(r,g,b)<14&&hueDist(st.h,hue)<28)pts.push({x,y});
  }
  if(pts.length<20)throw Error('Foreground trace could not be isolated.');
  return {hue,pts};
}
function xDomain(plot,x){return (x-plot.left)/Math.max(1,plot.right-plot.left)*500}
function robustMeanByRange(plot,scale,trace,x0,x1){
  const vals=trace.pts.filter(p=>{const x=xDomain(plot,p.x);return x>=x0&&x<=x1})
                      .map(p=>scale.slope*p.y+scale.intercept);
  if(vals.length<8)throw Error('Not enough trace samples in Low/High range.');
  const m=median(vals),M=mad(vals)||Math.max(1e-9,Math.abs(m)*.02),
        lim=Math.max(M*4,Math.abs(m)*.12,scale.step*.6),
        clean=vals.filter(v=>Math.abs(v-m)<=lim);
  if(clean.length<5)throw Error('Trace samples rejected as spikes.');
  return {mean:clean.reduce((a,b)=>a+b,0)/clean.length,count:clean.length};
}
function unifiedAnalyzeCore(){
  const plot=detectBlackPlot(),grid=detectGreenGrid(plot),
        scale=recognizeGridAnchors(plot,grid),trace=tracePointsUnified(plot),
        low=robustMeanByRange(plot,scale,trace,0,260),
        high=robustMeanByRange(plot,scale,trace,270,500);
  return {plot,grid,scale,trace,low,high};
}




const yLineTemplateCache=new Map();

function normMask(points,tw=128,th=28){
  if(!points||points.length<4)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const p of points){minx=Math.min(minx,p[0]);miny=Math.min(miny,p[1]);maxx=Math.max(maxx,p[0]);maxy=Math.max(maxy,p[1])}
  const w=Math.max(1,maxx-minx+1),h=Math.max(1,maxy-miny+1),
        sc=Math.min((tw-4)/w,(th-4)/h),
        nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc)),
        ox=2,oy=Math.floor((th-nh)/2),arr=new Uint8Array(tw*th);
  for(const p of points){
    const x=ox+Math.min(nw-1,Math.max(0,Math.round((p[0]-minx)*sc))),
          y=oy+Math.min(nh-1,Math.max(0,Math.round((p[1]-miny)*sc)));
    arr[y*tw+x]=1;
  }
  arr._aspect=w/Math.max(1,h);arr._w=w;arr._h=h;
  return arr;
}

function yLineTemplate(text,font='Arial',size=24){
  const key=`${text}|${font}|${size}`;
  if(yLineTemplateCache.has(key))return yLineTemplateCache.get(key);
  const c=document.createElement('canvas');c.width=180;c.height=44;
  const q=c.getContext('2d');
  q.fillStyle='#000';q.fillRect(0,0,c.width,c.height);
  q.fillStyle='#fff';q.font=`${size}px ${font}`;q.textBaseline='top';q.fillText(text,2,2);
  const im=q.getImageData(0,0,c.width,c.height).data,pts=[];
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
    const i=(y*c.width+x)*4;if(im[i]>80)pts.push([x,y]);
  }
  const n=normMask(pts);yLineTemplateCache.set(key,n);return n;
}

function directMaskScore(a,b){
  if(!a||!b)return 0;
  let inter=0,uni=0,aa=0,bb=0;
  for(let i=0;i<a.length;i++){
    const A=a[i],B=b[i];
    if(A&&B)inter++;
    if(A||B)uni++;
    aa+=A;bb+=B;
  }
  const iou=uni?inter/uni:0,
        fill=1-Math.min(1,Math.abs(aa-bb)/Math.max(1,Math.max(aa,bb))),
        arA=Math.max(.05,a._aspect||1),arB=Math.max(.05,b._aspect||1),
        aspect=Math.exp(-Math.abs(Math.log(arA/arB))*1.1);
  return .66*iou+.20*fill+.14*aspect;
}

function observedYLabelMask(plot,rowY,rowStep){
  const x1=Math.max(2,Math.floor(plot.left-3)),
        span=Math.max(56,Math.min(132,Math.round((plot.right-plot.left)*.26))),
        x0=Math.max(0,x1-span),
        half=Math.max(7,Math.round(rowStep*.32)),
        y0=Math.max(0,Math.round(rowY-half)),
        y1=Math.min(workCanvas.height-1,Math.round(rowY+half)),
        W=Math.max(1,x1-x0),H=Math.max(1,y1-y0),
        im=workCtx.getImageData(x0,y0,W,H).data,pts=[];
  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
          mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3,
          greenish=g>42&&g>=r*.94&&g>=b*.88&&(g-Math.min(r,b)>2),
          bright=lum>145&&(mx-mn)<75;
    if(greenish||bright)pts.push([x,y]);
  }
  return normMask(pts);
}

function candidateYLabels(){
  const out=new Map();
  function add(v,formats){
    for(const t of formats){
      const n=Number(t);
      if(Number.isFinite(n))out.set(t,n);
    }
  }
  // Fine/noise-like scales: deliberately dense but still small.
  for(let i=-20;i<=120;i++){
    const v=i/1000;
    add(v,[v.toFixed(5),v.toFixed(4),v.toFixed(3)]);
  }
  // Gain-like scales.
  for(let i=-20;i<=40;i++){
    const v=i/2;
    add(v,[v.toFixed(1),v.toFixed(2),String(v)]);
  }
  // Exact zero forms.
  add(0,['0','0.0','0.00','0.000','0.0000','0.00000']);
  return [...out].map(([text,value])=>({text,value}));
}
const Y_LINE_CANDIDATES=candidateYLabels();

function rowLabelHypotheses(plot,rowY,rowStep){
  const obs=observedYLabelMask(plot,rowY,rowStep);
  if(!obs)return [];
  const out=[];
  for(const c of Y_LINE_CANDIDATES){
    let best=0;
    for(const font of ['Arial','Verdana'])
      for(const size of [22,26])
        best=Math.max(best,directMaskScore(obs,yLineTemplate(c.text,font,size)));
    if(best>.18)out.push({...c,conf:best});
  }
  out.sort((a,b)=>b.conf-a.conf);
  const uniq=[];
  for(const q of out){
    if(uniq.some(u=>Math.abs(u.value-q.value)<Math.max(1e-6,Math.abs(q.value)*.001)))continue;
    uniq.push(q);
    if(uniq.length>=8)break;
  }
  return uniq;
}

function fitYAxisFromVisibleNumbers(plot){
  const ys=[...plot.h].sort((a,b)=>a-b),
        stepPx=median(ys.slice(1).map((y,i)=>y-ys[i])),
        rows=[];
  for(const y of ys){
    const hyps=rowLabelHypotheses(plot,y,stepPx);
    if(hyps.length)rows.push({y,hyps});
  }
  if(rows.length<2)throw Error('Y-axis: fewer than two numeric labels were read.');

  let best=null;
  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const A=rows[i],B=rows[j],dy=B.y-A.y;
    if(dy<4)continue;
    for(const ha of A.hyps.slice(0,6))for(const hb of B.hyps.slice(0,6)){
      const slope=(hb.value-ha.value)/dy;
      if(!Number.isFinite(slope)||slope>=0)continue;
      const intercept=ha.value-slope*A.y,
            step=Math.abs(slope*stepPx);
      if(step<1e-6||step>20)continue;

      let support=0,score=0,used=[];
      for(const row of rows){
        const pred=slope*row.y+intercept;
        let qbest=null;
        for(const h of row.hyps.slice(0,8)){
          const err=Math.abs(h.value-pred)/Math.max(step,1e-9);
          if(!qbest||err<qbest.err)qbest={...h,err};
        }
        if(qbest&&qbest.err<.22){
          support++;
          score+=4+(qbest.conf||0)*2-qbest.err*2;
          used.push({y:row.y,value:qbest.value,text:qbest.text,conf:qbest.conf});
        }
      }

      // Prefer common grid increments without assuming any bottom value.
      const common=[5,2,1,.5,.2,.1,.05,.02,.01,.005,.002,.001,.0005,.0002,.0001];
      const near=Math.min(...common.map(v=>Math.abs(Math.log(step/v))));
      score-=near*.35;

      if(!best||score>best.score)best={slope,intercept,step,support,score,used};
    }
  }

  if(!best||best.support<2)
    throw Error('Y-axis numeric labels do not form a consistent grid scale.');

  return {...best,source:'fast-line-label-affine-v1.1.0'};
}

async function extractTrace(plot,onProgress){
  const W=workCanvas.width,H=workCanvas.height,
        im=workCtx.getImageData(0,0,W,H).data;

  if(onProgress)onProgress('hue',0);
  const hue=await traceHue(plot,p=>onProgress&&onProgress('hue',p));

  if(onProgress)onProgress('scan',0);

  // One-pass bounded trace extraction.
  // Instead of scanning/refining each X column, sample the plot once and
  // accumulate matching foreground pixels into fixed X bins.
  const xSpan=Math.max(1,plot.right-plot.left),
        ySpan=Math.max(1,plot.bottom-plot.top),
        binCount=Math.min(180,Math.max(80,Math.round(xSpan/2))),
        sumY=new Float64Array(binCount),
        count=new Uint32Array(binCount),
        xStep=Math.max(1,Math.ceil(xSpan/300)),
        yStep=Math.max(1,Math.ceil(ySpan/180)),
        totalRows=Math.max(1,Math.ceil((ySpan+1)/yStep));

  let rowN=0;
  for(let y=plot.top;y<=plot.bottom;y+=yStep){
    for(let x=plot.left;x<=plot.right;x+=xStep){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
            mx=Math.max(r,g,b),mn=Math.min(r,g,b),
            sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.16&&lum>48&&!isGreen(r,g,b)&&hueDist(rgb2hue(r,g,b),hue)<30){
        const bidx=Math.min(binCount-1,Math.max(0,Math.floor((x-plot.left)/xSpan*binCount)));
        sumY[bidx]+=y;
        count[bidx]++;
      }
    }
    rowN++;
    if(rowN%24===0){
      if(onProgress)onProgress('scan',Math.min(1,rowN/totalRows));
      await new Promise(r=>setTimeout(r,0));
    }
  }

  const pts=[];
  for(let b=0;b<binCount;b++){
    if(!count[b])continue;
    const x=plot.left+(b+.5)/binCount*xSpan,
          y=sumY[b]/count[b];
    pts.push({x,y,count:count[b]});
  }
  if(onProgress)onProgress('scan',1);

  if(onProgress)onProgress('filter',0);
  if(pts.length<10)throw Error('Trace could not be isolated.');

  // Robust rejection on the binned trace.
  const ys=pts.map(p=>p.y),m=median(ys),M=mad(ys)||1,
        lim=Math.max(4,4*M),
        clean=pts.filter(p=>Math.abs(p.y-m)<=lim);

  if(clean.length<8)throw Error('Trace samples were removed as outliers.');
  if(onProgress)onProgress('filter',1);
  return {hue,pts:clean};
}



function chooseYScale(plot,trace){
  const fit=fitYAxisFromVisibleNumbers(plot);
  return {slope:fit.slope,intercept:fit.intercept,step:fit.step,
          support:fit.support,anchors:fit.used,source:'global-grid-numeric-sequence-v1.1.0'};
}

function xToSample(plot,x){return 500*(x-plot.left)/(plot.right-plot.left)}
function yToValue(plot,scale,y){return scale.slope*y+scale.intercept}
function robustMean(vals){
  if(!vals.length)return NaN;const m=median(vals),M=mad(vals)||1e-9,kept=vals.filter(v=>Math.abs(v-m)<=Math.max(M*3,Math.abs(m)*.12+1e-6));
  return mean(kept);
}

async function analyze(){
  const t0=performance.now();
  if(!ready)return;
  $('analyze').disabled=true;
  try{
    setProgress(8,'Processing…','Preparing high-resolution working image');await new Promise(r=>setTimeout(r,0));
    const wk=prepareWorkingImage();
    setProgress(16,'Plot','Locating black Energy per Band region');await new Promise(r=>setTimeout(r,0));
    preprocess();
    setProgress(30,'Grid','Detecting green grid geometry');await new Promise(r=>setTimeout(r,0));
    setProgress(48,'Y-axis','Reading numeric anchors tied to grid lines');await new Promise(r=>setTimeout(r,0));
    setProgress(64,'Trace','Separating dominant foreground marker color');await new Promise(r=>setTimeout(r,0));
    setProgress(80,'Low / High','Computing Low 0–260 / High 270–500');await new Promise(r=>setTimeout(r,0));

    const unified=unifiedAnalyzeCore(),
          plot=unified.plot,scale=unified.scale,
          low=unified.low.mean,high=unified.high.mean;

    $('low').textContent=low.toFixed(scale.step<.1?4:2);
    $('high').textContent=high.toFixed(scale.step<.1?4:2);

    result.width=canvas.width;result.height=canvas.height;
    rctx.clearRect(0,0,result.width,result.height);
    rctx.drawImage(canvas,0,0);
    rctx.strokeStyle='#26d7ff';rctx.fillStyle='#26d7ff';
    rctx.lineWidth=Math.max(2,result.width/700);
    rctx.font=`${Math.max(20,result.width/35)}px Arial`;

    const lowYw=(low-scale.intercept)/scale.slope,
          highYw=(high-scale.intercept)/scale.slope,
          pLeft=toOriginalX(plot.left),pRight=toOriginalX(plot.right),
          lowY=toOriginalY(lowYw),highY=toOriginalY(highYw);

    rctx.beginPath();rctx.moveTo(pLeft,lowY);rctx.lineTo(pLeft+(pRight-pLeft)*.52,lowY);rctx.stroke();
    rctx.fillText(`Low ${low.toFixed(scale.step<.1?4:2)}`,pLeft+10,lowY-10);
    rctx.beginPath();rctx.moveTo(pLeft+(pRight-pLeft)*.54,highY);rctx.lineTo(pRight,highY);rctx.stroke();
    rctx.fillText(`High ${high.toFixed(scale.step<.1?4:2)}`,pLeft+(pRight-pLeft)*.56,highY-10);

    $('detail').textContent=`Unified visual core; Y step ${Number(scale.step.toPrecision(6))}; anchors ${scale.support}; Low samples ${unified.low.count}; High samples ${unified.high.count}; X 0–500; Low 0–260 / High 270–500; no bottom-value assumption.`;
    const elapsed=((performance.now()-t0)/1000).toFixed(1);
    $('resultCard').classList.remove('hidden');
    setProgress(100,'Complete',`Total ${elapsed}s`);
    $('status').textContent=`Analysis complete — ${elapsed}s`;
  }catch(e){
    $('status').textContent=e.message||String(e);
    setProgress(100,'Needs attention',e.message||String(e));
  }finally{
    $('analyze').disabled=false;
  }
}

$('analyzeBtn').onclick=analyze;
reset();


// v1.1.0 deliberately runs without an application service worker.
// Remove stale v1.0.1/v1.0.2 workers/caches so GitHub Pages always serves current JS.
// Offline support will be re-enabled only after numeric validation is stable.
(async()=>{
  try{
    if('serviceWorker' in navigator){
      const regs=await navigator.serviceWorker.getRegistrations();
      for(const r of regs){
        if(r.scope.includes('/Module/spectrumreader/')) await r.unregister();
      }
    }
    if('caches' in window){
      const ks=await caches.keys();
      for(const k of ks)if(k.startsWith('energy-graph'))await caches.delete(k);
    }
  }catch(_){}
})();
