# Energy Graph Simple v1.0.1

黒い Energy per Band グラフだけを撮影して Low / High 平均値だけを読む軽量版です。

- Channel判定なし
- Gain / Noise判定なし
- Channel ROIなし
- X軸は 0–500
- Low = 0–260
- High = 270–500
- スパイク除外後の平均
- オフラインPWA対応
- 撮影/ライブラリ画像はネイティブ解像度で解析


既存の `deploy-spectrumreader-zip-pages.yml` が要求する4つの互換JSを同梱しています。Simple版の解析本体は `app.js` のみです。
