(function(){
'use strict';
const EXPECTED_SHA='bb5cacfe4405199446244912d32edd0b0a6e74e433d598acd394e79547daf333';
const CORE_URL='egs-v2-core.bundle.js?v=2.0.7-r25-RC2-dev16-wip-bb5cacfe';
const WORKER_URL='./worker.js?v=2.0.7-r25-RC2-dev16-wip-bb5cacfe';
const core=window.EGSV2Core;
const gates=[
 {id:'exif6',title:'EXIF orientation / compact',hint:'IMG_2415',fixture:'device_fixtures/01_IMG_2415_EXIF6.jpeg',test:r=>r.accepted&&axisEq(r,[3,2,1]),extra:(d)=>d.width===3024&&d.height===4032?'orientation=3024×4032':'expected browser-oriented 3024×4032'},
 {id:'popup2406',title:'Popup physical-band rescue',hint:'IMG_2406',fixture:'device_fixtures/02_IMG_2406_POPUP.jpeg',test:r=>r.accepted&&axisEq(r,[.02,.01])&&r.physicalBandRescue===true},
 {id:'four2410',title:'True 4-anchor decimal',hint:'IMG_2410',fixture:'device_fixtures/03_IMG_2410_4ANCHOR.jpeg',test:r=>r.accepted&&axisEq(r,[.04,.03,.02,.01])&&r.physicalBandRescue!==true},
 {id:'compact09',title:'Compact Gain 3/2/1',hint:'field_09',fixture:'device_fixtures/04_field_09_COMPACT.jpeg',test:r=>r.accepted&&axisEq(r,[3,2,1])},
 {id:'decimal005',title:'0.010 / 0.005 positional invariant',hint:'field_16 / blue 0.005',fixture:'device_fixtures/05_field_16_0005.jpeg',test:r=>r.accepted&&axisEq(r,[.01,.005])&&r.low?.mean<.005&&r.high?.mean<.005},
 {id:'partial2638',title:'Partial Low must reject',hint:'IMG_2638',fixture:'device_fixtures/06_IMG_2638_PARTIAL.jpeg',test:r=>!r.accepted&&axisEq(r,[.03,.02,.01])&&/partially present in the Low 0-260 range/i.test(String(r.reason||''))}
];
const state={environment:{},gates:{},started:new Date().toISOString(),userAgent:navigator.userAgent};
function axisValues(r){return Array.isArray(r?.axis?.values)?r.axis.values.map(Number):(r?.axis?.anchors?.map(a=>Number(a.value))||r?.axis?.diagnostics?.family||[])}
function axisEq(r,vals){const a=axisValues(r);return a.length===vals.length&&a.every((v,i)=>Math.abs(v-vals[i])<1e-8)}
function stable(v){if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v).sort())o[k]=stable(v[k]);return o}return v}
function sameResult(a,b){return JSON.stringify(stable(a))===JSON.stringify(stable(b))}
async function sha256Text(t){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function envCheck(){
 const e={secureContext:isSecureContext,cryptoSubtle:!!crypto?.subtle,worker:typeof Worker==='function',serviceWorker:'serviceWorker' in navigator,standalone:matchMedia('(display-mode: standalone)').matches||navigator.standalone===true,online:navigator.onLine,coreLoaded:!!core?.analyze};
 try{const text=await fetch(CORE_URL,{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.text()});e.coreSha=await sha256Text(text);e.coreShaPass=e.coreSha===EXPECTED_SHA}catch(err){e.coreShaPass=false;e.coreShaError=String(err)}
 try{const vr=await fetch('version.json',{cache:'no-store'});e.versionHttp=vr.status;e.versionHttpPass=vr.ok}catch(err){e.versionHttpPass=false;e.versionHttpError=String(err)}
 try{const wr=await fetch(WORKER_URL,{cache:'no-store'});e.workerHttp=wr.status;e.workerHttpPass=wr.ok}catch(err){e.workerHttpPass=false;e.workerHttpError=String(err)}
 try{
  if('serviceWorker' in navigator){
    const reg=await navigator.serviceWorker.register('./sw.js');
    await navigator.serviceWorker.ready;
    e.serviceWorkerRegistered=!!reg;
    e.serviceWorkerControlled=!!navigator.serviceWorker.controller;
    if('caches' in window){
      const names=await caches.keys();e.cacheNames=names;
      let coreCached=false,validationCached=false;
      for(const n of names){
        const c=await caches.open(n);
        if(await c.match(CORE_URL))coreCached=true;
        if(await c.match('./validation.html'))validationCached=true;
      }
      e.coreCached=coreCached;e.validationCached=validationCached;
    }
  }
 }catch(err){e.serviceWorkerRegistered=false;e.serviceWorkerError=String(err)}
 state.environment=e;renderEnv();renderSummary();
}
function metric(label,value,pass){return `<div class="metric ${pass===true?'pass':pass===false?'fail':'pending'}"><strong>${label}</strong><span>${escapeHtml(String(value))}</span></div>`}
function renderEnv(){const e=state.environment;document.getElementById('envGrid').innerHTML=[
 metric('Core SHA',e.coreSha||e.coreShaError||'checking',e.coreShaPass),metric('Core loaded',e.coreLoaded,e.coreLoaded===true),metric('Worker API',e.worker,e.worker===true),metric('Worker HTTP',e.workerHttp??e.workerHttpError??'checking',e.workerHttpPass),metric('Version HTTP',e.versionHttp??e.versionHttpError??'checking',e.versionHttpPass),metric('Secure context',e.secureContext,e.secureContext===true),metric('Service Worker API',e.serviceWorker,e.serviceWorker===true),metric('SW registered',e.serviceWorkerRegistered,e.serviceWorkerRegistered===true),metric('SW controls page',e.serviceWorkerControlled,e.serviceWorkerControlled===true?true:null),metric('Core cached',e.coreCached,e.coreCached===true),metric('Validation cached',e.validationCached,e.validationCached===true),metric('Standalone PWA',e.standalone,e.standalone===true?true:null),metric('Online now',e.online,null)
 ].join('')}
function renderGates(){const host=document.getElementById('gateList');host.innerHTML=gates.map(g=>`<div class="gate pending" id="gate-${g.id}"><div class="gatehead"><div><strong>${g.title}</strong><p>Select: ${g.hint}</p></div><span class="status">Not run</span></div><input type="file" accept="image/*" data-gate="${g.id}"><div class="details" hidden></div></div>`).join('');host.querySelectorAll('input[type=file]').forEach(i=>i.addEventListener('change',()=>runGate(i.dataset.gate,i.files?.[0]))) }
async function decode(file){const u=URL.createObjectURL(file);try{const img=new Image();img.decoding='async';img.src=u;await img.decode();const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const x=c.getContext('2d',{willReadFrequently:true,alpha:false});x.drawImage(img,0,0);const rgba=x.getImageData(0,0,c.width,c.height);c.width=1;c.height=1;return {rgba,width:img.naturalWidth,height:img.naturalHeight}}finally{URL.revokeObjectURL(u)}}
function workerAnalyze(rgba){return new Promise((resolve,reject)=>{const w=new Worker(WORKER_URL),id=1,t=setTimeout(()=>{w.terminate();reject(Error('Worker timeout'))},45000);w.onmessage=e=>{if(e.data?.id!==id)return;clearTimeout(t);w.terminate();e.data.ok?resolve(e.data.result):reject(Error(e.data.error||'Worker failed'))};w.onerror=e=>{clearTimeout(t);w.terminate();reject(Error(e.message||'Worker error'))};w.postMessage({type:'analyze',id,width:rgba.width,height:rgba.height,buffer:rgba.data.buffer},[rgba.data.buffer])})}
async function runGate(id,file){if(!file)return;const g=gates.find(x=>x.id===id),el=document.getElementById('gate-'+id),st=el.querySelector('.status'),det=el.querySelector('.details');el.className='gate pending';st.textContent='Running…';det.hidden=true;const began=performance.now();try{
 const d1=await decode(file),direct=core.analyze(d1.rgba);const d2=await decode(file),worker=await workerAnalyze(d2.rgba);const parity=sameResult(direct,worker);let semantic=!!g.test(direct);let extraPass=true,extra='';if(g.extra){extra=g.extra(d1);extraPass=extra.startsWith('orientation=')}
 const pass=semantic&&parity&&extraPass;const rec={file:{name:file.name,size:file.size,type:file.type,lastModified:file.lastModified},decoded:{width:d1.width,height:d1.height},semanticPass:semantic,workerDirectParity:parity,extra,extraPass,pass,elapsedMs:Math.round(performance.now()-began),result:direct};state.gates[id]=rec;el.className='gate '+(pass?'pass':'fail');st.textContent=pass?'PASS':'FAIL';det.hidden=false;det.textContent=JSON.stringify({decoded:rec.decoded,semanticPass:semantic,workerDirectParity:parity,extra,axis:axisValues(direct),accepted:direct.accepted,low:direct.low?.mean,high:direct.high?.mean,physicalBandRescue:direct.physicalBandRescue,stage:direct.stage,reason:direct.reason,elapsedMs:rec.elapsedMs},null,2)
 }catch(err){state.gates[id]={pass:false,error:String(err?.stack||err),elapsedMs:Math.round(performance.now()-began)};el.className='gate fail';st.textContent='FAIL';det.hidden=false;det.textContent=String(err?.stack||err)}renderSummary()}
function environmentRequiredPass(){const e=state.environment;return e.coreShaPass===true&&e.coreLoaded===true&&e.worker===true&&e.workerHttpPass===true&&e.versionHttpPass===true&&e.secureContext===true&&e.serviceWorkerRegistered===true&&e.coreCached===true&&e.validationCached===true}
function renderSummary(){const done=gates.filter(g=>state.gates[g.id]).length,pass=gates.filter(g=>state.gates[g.id]?.pass).length,env=environmentRequiredPass(),all=done===gates.length&&pass===gates.length&&env;const s=document.getElementById('summary');s.className='summary '+(all?'pass':done===gates.length||!env?'fail':'pending');s.textContent=all?`PASS — environment + ${pass}/${gates.length} image gates`:`${env?'Environment PASS':'Environment NOT PASS'} · image gates ${pass}/${done}/${gates.length} (pass/run/total)`;state.completed=new Date().toISOString();state.summary={environmentPass:env,imagePass:pass,imageRun:done,imageTotal:gates.length,allPass:all};document.getElementById('reportPreview').textContent=JSON.stringify(report(),null,2)}
function report(){return {schema:'egs-dev16-device-validation-v1',expectedCoreSha256:EXPECTED_SHA,version:'2.0.7-r25-RC2-dev16-wip-bb5cacfe',...state}}
function exportReport(){const b=new Blob([JSON.stringify(report(),null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`EGS_dev16_device_validation_${new Date().toISOString().replace(/[:.]/g,'-')}.json`;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1000)}

async function runBundledSuite(){
 const btn=document.getElementById('runBundled');btn.disabled=true;btn.textContent='Running bundled suite…';
 try{
  for(const g of gates){
   const resp=await fetch(g.fixture);if(!resp.ok)throw new Error(`${g.fixture}: HTTP ${resp.status}`);
   const blob=await resp.blob();const file=new File([blob],g.fixture.split('/').pop(),{type:blob.type||'image/jpeg',lastModified:0});
   await runGate(g.id,file);
  }
 }catch(err){state.bundledSuiteError=String(err?.stack||err);renderSummary()}finally{btn.disabled=false;btn.textContent='Run bundled 6-gate suite'}
}
function clearGates(){state.gates={};renderGates();renderSummary()}

function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
document.getElementById('rerunEnv').addEventListener('click',envCheck);document.getElementById('exportReport').addEventListener('click',exportReport);document.getElementById('runBundled').addEventListener('click',runBundledSuite);document.getElementById('clearGates').addEventListener('click',clearGates);window.addEventListener('online',envCheck);window.addEventListener('offline',envCheck);renderGates();envCheck();
})();
