# Energy Graph Scan dev16 実機 validation

1. HTTPS または localhost でこのフォルダを配信し、`validation.html` をSafari/Chromeで開く。
2. Environment の Core SHA / Core loaded / Worker / Worker HTTP / Version HTTP / Secure context / SW registered / Core cached / Validation cached がPASSであることを確認する。
3. 最短手順では `Run bundled 6-gate suite` を1回押す。validation専用に同梱した6 fixtureを順に実行する。手動で確認したい場合は6つのスロットに対応する元画像を1枚ずつ選ぶ。
   - EXIF orientation / compact: IMG_2415
   - Popup physical-band rescue: IMG_2406
   - True 4-anchor decimal: IMG_2410
   - Compact Gain 3/2/1: field_09
   - 0.010 / 0.005 positional invariant: field_16
   - Partial Low must reject: IMG_2638
4. 各スロットは同じファイルを2回decodeし、production coreをdirectとWorkerで独立実行して結果を比較する。
5. Summary が `PASS — environment + 6/6 image gates` になればdevice validation PASS。
6. `Export validation JSON` を押し、結果JSONを保存する。JSONにはuserAgent、core SHA、decode後寸法、direct/worker parity、axis、Low/High、rescue、Reject reasonが保存される。
7. PWA/offline確認は、一度オンラインでvalidation.htmlを開いてcache完了後、機内モードにしページを再読込する。同じCore SHAと6 gateが再度PASSすればoffline runtime parityを確認できる。

注意: このvalidation pageはproduction coreの判定ロジックを変更しない。fixture名はUIの案内にのみ使い、core control-flowには渡さない。
