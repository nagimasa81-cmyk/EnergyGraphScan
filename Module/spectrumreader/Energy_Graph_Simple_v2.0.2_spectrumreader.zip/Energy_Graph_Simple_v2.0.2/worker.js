'use strict';
importScripts('./egs-v2-core.bundle.js');
self.onmessage=function(e){
  const m=e.data||{};
  if(m.type!=='analyze')return;
  try{
    const img={width:m.width,height:m.height,data:new Uint8ClampedArray(m.buffer)};
    const result=self.EGSV2Core.analyze(img);
    // Drop the transferred full-resolution input reference before posting the result.
    // The core result contains only analysis outputs, not the source RGBA image.
    img.data=null; m.buffer=null;
    self.postMessage({id:m.id,ok:true,result});
  }catch(err){
    self.postMessage({id:m.id,ok:false,error:String(err&&err.message||err),stack:String(err&&err.stack||'')});
  }
};
