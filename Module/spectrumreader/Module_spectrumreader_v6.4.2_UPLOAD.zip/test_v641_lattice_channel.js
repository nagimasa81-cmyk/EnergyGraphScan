const fs=require('fs');
const a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v641RecoverPeriodicLattice('),'periodic lattice recovery missing');
ok(a.includes('function v641GridLines('),'robust grid line detector missing');
ok(a.includes("source:'v6.4.1-periodic-lattice-recovery'"),'lattice source missing');
ok(a.includes('minTwoRowHeight'),'two-row channel ROI height guard missing');
ok(a.includes("source:'v6.4.1-detected-checkbox-grid'"),'actual checkbox detector is not primary');
ok(a.includes('v631DetectCheckboxGrid(C)'),'checkbox geometry detector not called');
ok(a.includes("reason:'horizontal grid lattice could not be reconstructed'"),'new Y lattice failure reason missing');
console.log('v6.4.1 lattice + channel regression PASS');
