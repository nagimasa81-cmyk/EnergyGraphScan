const fs=require('fs');
const a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
const auto=a.slice(a.indexOf("$('autoDetectBtn').onclick"),a.indexOf("$('manualBtn').onclick"));
ok(auto.includes("roiEditorState.target='energy'"),'Auto ROI does not force Energy target');
ok(auto.includes("$('editEnergyROI').classList.add('active')"),'Energy edit UI not synchronized');
ok(a.includes('function v642ChannelROIFromEnergy('),'geometry Channel ROI missing');
ok(a.includes("source:'v6.4.2-energy-geometry-channel-band'"),'geometry Channel source missing');
ok(a.includes('medianLabelAspect'),'Y glyph aspect discriminator missing');
ok(a.includes("cand.family==='Gain'?10:-10"),'compact-label Gain prior missing');
ok(a.includes('compact labels contradict Noise scale'),'Noise decimal ambiguity guard missing');
ok(a.includes('wide labels contradict Gain scale'),'Gain decimal ambiguity guard missing');
ok(a.includes("source:'v6.4.2-grid+numeric-shape-consensus'"),'new Y calibration source missing');
console.log('v6.4.2 structural scale regression PASS');
