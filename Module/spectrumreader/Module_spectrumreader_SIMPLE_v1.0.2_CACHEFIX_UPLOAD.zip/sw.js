const CACHE='energy-graph-simple-v1.0.2-cachefix-20260816';
const ASSETS=[
  './',
  './index.html',
  './styles.css',
  './app.v1.0.2.js?v=20260816-1700',
  './manifest.webmanifest',
  './version.json'
];

self.addEventListener('install',event=>{
  event.waitUntil(
    caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())
  );
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys
      .filter(k=>k!==CACHE && k.startsWith('energy-graph'))
      .map(k=>caches.delete(k)));
    await self.clients.claim();

    // Existing v1.0.1 pages can remain visible even after a new SW activates.
    // Navigate controlled browser clients once to a cache-busting URL.
    const list=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    for(const client of list){
      try{
        const u=new URL(client.url);
        if(u.searchParams.get('runtime')!=='1.0.2'){
          u.searchParams.set('runtime','1.0.2');
          await client.navigate(u.href);
        }
      }catch(_){}
    }
  })());
});

async function networkFirst(req){
  try{
    const fresh=await fetch(req,{cache:'no-store'});
    if(fresh && fresh.ok){
      const c=await caches.open(CACHE);
      c.put(req,fresh.clone()).catch(()=>{});
    }
    return fresh;
  }catch(_){
    return (await caches.match(req)) || (await caches.match('./index.html'));
  }
}

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  const isDocument=event.request.mode==='navigate' || event.request.destination==='document';
  const isRuntime=
    url.pathname.endsWith('/index.html') ||
    url.pathname.endsWith('/app.js') ||
    url.pathname.endsWith('/app.v1.0.2.js') ||
    url.pathname.endsWith('/version.json');

  if(isDocument || isRuntime){
    event.respondWith(networkFirst(event.request));
    return;
  }

  event.respondWith(
    caches.match(event.request).then(hit=>hit || fetch(event.request).then(res=>{
      if(res && res.ok){
        const copy=res.clone();
        caches.open(CACHE).then(c=>c.put(event.request,copy)).catch(()=>{});
      }
      return res;
    }))
  );
});
