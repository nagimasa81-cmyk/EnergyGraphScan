# Energy Graph Simple v1.0.2

黒い Energy per Band グラフだけを撮影して Low / High 平均値だけを読む軽量版です。

- Channel判定なし
- Gain / Noise判定なし
- Channel ROIなし
- X軸は 0–500
- Low = 0–260
- High = 270–500
- スパイク除外後の平均
- オフラインPWA対応
- 撮影/ライブラリ画像はネイティブ解像度で解析


既存の `deploy-spectrumreader-zip-pages.yml` が要求する4つの互換JSを同梱しています。Simple版の解析本体は `app.js` のみです。

- v1.0.2: Y軸下辺=0仮定を完全撤廃。見えているY軸数値2点以上からpixel→値を直接回帰。

- v1.0.2 cachefix: Safari旧Service Workerがv1.0.1を返し続ける問題を修正。
- HTML/runtimeはnetwork-first。
- 旧Energy Graph cacheをactivation時に削除。
- app.v1.0.2.jsをバージョン付きURLでロード。

- v1.0.3: Y軸を全水平グリッドの数値系列として同時判定。下辺値の仮定なし。
- 数値精度検証中はService Worker/オフラインキャッシュを一時停止。旧v1.0.1が残る問題を排除。
- 画面ヘッダに build 1705 を表示。

- v1.0.4: 4032×3024等の最大解像度画像は原画として保持し、解析だけ最大辺1280pxのワーキング画像で実行。
- Trace色分離は最大約900列×500行相当へ制限。iPhoneで50%停止に見える問題を解消。
- 結果ラインは原画像座標へ戻して描画。

- v1.0.5: Trace処理を5段階表示へ分解。
- 色探索は最大約220×140点の粗探索。
- Trace列探索は最大420列、各列は粗Y探索後に局所精査のみ。
- 20列ごとにUIへ制御を返すため、iPhoneで50%固定に見えない。
- 完了時に総解析秒数を表示。

- v1.0.6: Trace 3/5の列ごと局所精査を廃止。
- 最大辺800pxの解析画像上で、色候補画素を1回走査して最大180個のX-binへ集約。
- 解析量を約300×180サンプル以内に固定し、iPhone Safariでの長時間停止を防止。
