
const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');
let ready=false;

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){if(!a.length)return NaN;const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden'); $('progressPct').textContent=`${p}%`; $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label; $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');$('lowValue').textContent='—';$('highValue').textContent='—';$('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;canvas.width=1;canvas.height=1;canvas.style.display='none';$('.placeholder');
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;$('status').textContent='Ready';$('progressCard').classList.add('hidden');clearResult();
}
async function loadFile(file){
  clearResult(); $('progressCard').classList.add('hidden'); $('status').textContent='Loading full-resolution image…';
  const bmp=await createImageBitmap(file);
  canvas.width=bmp.width;canvas.height=bmp.height;ctx.drawImage(bmp,0,0);
  canvas.style.display='block';document.querySelector('.placeholder').style.display='none';
  ready=true;$('analyzeBtn').disabled=false;$('status').textContent=`Ready — ${bmp.width}×${bmp.height}px`;
}
$('cameraBtn').onclick=()=>$('fileCamera').click();
$('libraryBtn').onclick=()=>$('fileLibrary').click();
$('fileCamera').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('fileLibrary').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('resetBtn').onclick=reset;

function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h;
  if(mx===r)h=60*(((g-b)/d)%6);else if(mx===g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function isGreen(r,g,b){return g>55&&g>r*1.12&&g>b*1.12}
function preprocess(){
  // task-specific adaptive contrast on a working copy only
  const im=ctx.getImageData(0,0,canvas.width,canvas.height),d=im.data,l=[];
  for(let i=0;i<d.length;i+=4)l.push(.299*d[i]+.587*d[i+1]+.114*d[i+2]);
  l.sort((a,b)=>a-b);const q=x=>l[Math.floor((l.length-1)*x)],lo=q(.04),hi=q(.98),span=Math.max(20,hi-lo);
  return {im,lo,hi,span};
}
function lineScores(axis){
  const {width:W,height:H}=canvas,im=ctx.getImageData(0,0,W,H).data;
  const N=axis==='h'?H:W,scores=new Array(N).fill(0);
  for(let p=0;p<N;p++){
    let green=0,dark=0,n=0;
    const M=axis==='h'?W:H;
    for(let k=0;k<M;k+=Math.max(1,Math.floor(M/700))){
      const x=axis==='h'?k:p,y=axis==='h'?p:k,i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],lum=(r+g+b)/3;
      n++; if(isGreen(r,g,b))green++; if(lum<100)dark++;
    }
    scores[p]=green/n*.8+dark/n*.2;
  }
  return scores;
}
function peaks(scores,minGap){
  const cand=[];for(let i=2;i<scores.length-2;i++)if(scores[i]>scores[i-1]&&scores[i]>=scores[i+1])cand.push({i,s:scores[i]});
  cand.sort((a,b)=>b.s-a.s);const out=[];
  for(const c of cand){if(out.every(x=>Math.abs(x-c.i)>minGap))out.push(c.i);if(out.length>=18)break}
  return out.sort((a,b)=>a-b);
}
function detectPlot(){
  const hp=peaks(lineScores('h'),Math.max(6,canvas.height*.03));
  const vp=peaks(lineScores('v'),Math.max(8,canvas.width*.035));
  if(hp.length<3||vp.length<4) throw Error('Grid detection failed. Include the full black graph.');
  // choose densest regularly spaced runs
  function regular(arr){
    let best=null;
    for(let i=0;i<arr.length;i++)for(let j=i+2;j<arr.length;j++){
      const sub=arr.slice(i,j+1),ds=sub.slice(1).map((v,k)=>v-sub[k]),m=median(ds),e=median(ds.map(x=>Math.abs(x-m)));
      const score=sub.length/(1+e/Math.max(1,m));
      if(!best||score>best.score)best={arr:sub,step:m,score};
    } return best;
  }
  const H=regular(hp),V=regular(vp); if(!H||!V) throw Error('Grid lattice unresolved.');
  return {left:V.arr[0],right:V.arr.at(-1),top:H.arr[0],bottom:H.arr.at(-1),h:H.arr,v:V.arr};
}
function estimateY(plot){
  // Infer numeric step primarily from green horizontal-grid spacing + image label morphology.
  // For simple version support the two families actually used in these graphs:
  // Gain usually step 1; Noise commonly .005 or .01.
  const stepPx=median(plot.h.slice(1).map((y,i)=>y-plot.h[i]));
  const W=canvas.width,im=ctx.getImageData(0,0,W,canvas.height).data;
  // Find decimal-label ink/green activity left of y-axis.
  const lx0=Math.max(0,plot.left-Math.round((plot.right-plot.left)*.25)),lx1=plot.left;
  let tiny=0,total=0;
  for(let y=plot.top;y<=plot.bottom;y++)for(let x=lx0;x<lx1;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2]; if(isGreen(r,g,b)){total++; if(g<190)tiny++}
  }
  // Use plot height/trace location as family-independent scale candidate set.
  // We score candidates using visible horizontal grid count and trace plausibility.
  const candidates=[1,.5,.02,.01,.005,.001];
  return {stepPx,candidates};
}
function traceHue(plot){
  const im=ctx.getImageData(0,0,canvas.width,canvas.height).data,bins=new Array(36).fill(0);
  for(let y=plot.top;y<=plot.bottom;y++)for(let x=plot.left;x<=plot.right;x+=2){
    const i=(y*canvas.width+x)*4,r=im[i],g=im[i+1],b=im[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
    if(sat>.22&&lum>65&&!isGreen(r,g,b))bins[Math.floor(rgb2hue(r,g,b)/10)]++;
  }
  let bi=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;return bi*10+5;
}
function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function extractTrace(plot){
  const hue=traceHue(plot),W=canvas.width,im=ctx.getImageData(0,0,W,canvas.height).data,pts=[];
  for(let x=plot.left;x<=plot.right;x++){
    const ys=[];
    for(let y=plot.top;y<=plot.bottom;y++){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.18&&lum>60&&!isGreen(r,g,b)&&hueDist(rgb2hue(r,g,b),hue)<28)ys.push(y);
    }
    if(ys.length)pts.push({x,y:median(ys)});
  }
  if(pts.length<20) throw Error('Trace could not be isolated.');
  // robust spike removal in y
  const ys=pts.map(p=>p.y),m=median(ys),M=mad(ys)||1,clean=pts.filter(p=>Math.abs(p.y-m)<Math.max(5,4*M));
  return {hue,pts:clean};
}
function chooseYScale(plot,trace){
  const stepPx=median(plot.h.slice(1).map((y,i)=>y-plot.h[i]));
  const candidates=[1,.5,.02,.01,.005,.001];
  // baseline is bottom grid line; candidate is chosen from trace vertical spread plausibility.
  // Gain trace usually spans units; Noise trace stays within hundredths.
  const ymed=median(trace.pts.map(p=>p.y)),gridFromBottom=(plot.bottom-ymed)/stepPx;
  let best=null;
  for(const step of candidates){
    const medVal=gridFromBottom*step;
    let score=0;
    // prefer realistic display ranges but do not classify Gain/Noise explicitly
    if(medVal>=0&&medVal<=4)score+=3;
    if(step<=.02&&medVal<=.08)score+=2;
    if(step>=.5&&medVal>=.08)score+=2;
    // horizontal grid count typical 3-6
    score-=Math.abs(plot.h.length-4)*.15;
    if(!best||score>best.score)best={step,score};
  }
  return {step:best.step,stepPx,bottomValue:0};
}
function xToSample(plot,x){return 500*(x-plot.left)/(plot.right-plot.left)}
function yToValue(plot,scale,y){return scale.bottomValue+(plot.bottom-y)/scale.stepPx*scale.step}
function robustMean(vals){
  if(!vals.length)return NaN;const m=median(vals),M=mad(vals)||1e-9,kept=vals.filter(v=>Math.abs(v-m)<=Math.max(M*3,Math.abs(m)*.12+1e-6));
  return mean(kept);
}
async function analyze(){
  if(!ready)return;clearResult();
  try{
    setProgress(10,'Processing…','Adaptive image preparation');await new Promise(r=>setTimeout(r,0));
    preprocess();
    setProgress(30,'Grid','Detecting plot geometry');const plot=detectPlot();await new Promise(r=>setTimeout(r,0));
    setProgress(50,'Trace','Separating foreground marker/line color');const trace=extractTrace(plot);await new Promise(r=>setTimeout(r,0));
    setProgress(65,'Y-axis','Reconstructing numeric scale');const scale=chooseYScale(plot,trace);
    setProgress(80,'Low / High','Computing robust means with spike rejection');

    const lowVals=[],highVals=[],lowPts=[],highPts=[];
    for(const p of trace.pts){
      const sx=xToSample(plot,p.x),v=yToValue(plot,scale,p.y);
      if(sx>=0&&sx<=260){lowVals.push(v);lowPts.push(p)}
      else if(sx>=270&&sx<=500){highVals.push(v);highPts.push(p)}
    }
    if(lowVals.length<5||highVals.length<5)throw Error('Low or High region has insufficient trace samples.');
    const low=robustMean(lowVals),high=robustMean(highVals);

    setProgress(95,'Rendering','Drawing Low/High mean lines');
    resultCanvas.width=canvas.width;resultCanvas.height=canvas.height;rctx.drawImage(canvas,0,0);
    rctx.lineWidth=Math.max(3,canvas.width/450);rctx.strokeStyle='#00d9ff';rctx.fillStyle='#00d9ff';rctx.font=`${Math.max(24,canvas.width/32)}px sans-serif`;
    const lowY=plot.bottom-(low-scale.bottomValue)/scale.step*scale.stepPx;
    const highY=plot.bottom-(high-scale.bottomValue)/scale.step*scale.stepPx;
    rctx.beginPath();rctx.moveTo(plot.left,lowY);rctx.lineTo(plot.left+(plot.right-plot.left)*.52,lowY);rctx.stroke();
    rctx.fillText(`Low ${low.toFixed(scale.step<.1?4:2)}`,plot.left+10,lowY-10);
    rctx.beginPath();rctx.moveTo(plot.left+(plot.right-plot.left)*.54,highY);rctx.lineTo(plot.right,highY);rctx.stroke();
    rctx.fillText(`High ${high.toFixed(scale.step<.1?4:2)}`,plot.left+(plot.right-plot.left)*.56,highY-10);

    $('lowValue').textContent=low.toFixed(scale.step<.1?4:2);
    $('highValue').textContent=high.toFixed(scale.step<.1?4:2);
    $('detail').textContent=`Y grid step ${scale.step}; Low samples ${lowVals.length}; High samples ${highVals.length}; X domain 0–500; split Low 0–260 / High 270–500.`;
    $('resultCard').classList.remove('hidden');setProgress(100,'Complete','');$('status').textContent='Analysis complete.';
  }catch(e){
    setProgress(100,'Needs attention',e.message);$('status').textContent=e.message;
  }
}
$('analyzeBtn').onclick=analyze;
reset();
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
