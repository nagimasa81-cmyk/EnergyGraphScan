
const fs=require('fs');
const a=fs.readFileSync('app.v1.0.6.js','utf8');
const h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('const maxSide=800'),'800 working cap missing');
ok(a.includes('binCount=Math.min(180'),'fixed x bins missing');
ok(a.includes('xSpan/300'),'x sampling bound missing');
ok(a.includes('ySpan/180'),'y sampling bound missing');
ok(!a.includes('bestY=null,bestScore=-Infinity'),'old per-column refinement still present');
ok(a.includes('One-pass trace binning'),'progress wording missing');
ok(h.includes('v1.0.6 Simple · build 1745'),'build stamp missing');
console.log('Simple v1.0.6 bounded trace regression PASS');
