
const fs=require('fs');
const a=fs.readFileSync('app.v1.1.0.js','utf8');
const h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
for(const fn of ['detectBlackPlot','detectGreenGrid','recognizeGridAnchors','tracePointsUnified','robustMeanByRange','unifiedAnalyzeCore'])
  ok(a.includes(`function ${fn}(`),`${fn} missing`);
ok(a.includes('const unified=unifiedAnalyzeCore()'),'unified core not called');
ok(a.includes('robustMeanByRange(plot,scale,trace,0,260)'),'low range');
ok(a.includes('robustMeanByRange(plot,scale,trace,270,500)'),'high range');
ok(h.includes('v1.1.0 Simple · build 1900'),'build stamp');
console.log('v1.1.0 unified core PASS');
