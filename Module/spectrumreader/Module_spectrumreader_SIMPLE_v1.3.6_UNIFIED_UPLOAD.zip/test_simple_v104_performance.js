
const fs=require('fs'),a=fs.readFileSync('app.v1.0.4.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function prepareWorkingImage()'),'working image missing');
ok(a.includes('maxSide=1280'),'analysis cap missing');
ok(a.includes('xStep=Math.max(1,Math.round((plot.right-plot.left)/900))'),'x scan cap missing');
ok(a.includes('yStep=Math.max(1,Math.round((plot.bottom-plot.top)/500))'),'y scan cap missing');
ok(a.includes('toOriginalY(lowYw)'),'result coordinate mapping missing');
ok(h.includes('v1.0.4 Simple · build 1715'),'build stamp missing');
console.log('Simple v1.0.4 performance regression PASS');
