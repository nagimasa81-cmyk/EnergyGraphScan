
const fs=require('fs'),a=fs.readFileSync('app.v1.0.8.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok((a.match(/async function traceHue\(/g)||[]).length===1,'traceHue');
ok((a.match(/async function extractTrace\(/g)||[]).length===1,'extractTrace');
ok((a.match(/function chooseYScale\(/g)||[]).length===1,'chooseYScale');
ok((a.match(/function fitYAxisFromVisibleNumbers\(/g)||[]).length===1,'fitYAxis');
ok(a.includes("await extractTrace("),'analyze does not call extractTrace');
ok(h.includes('v1.0.8 Simple · build 1815'),'build stamp');
console.log('v1.0.8 critical runtime PASS');
