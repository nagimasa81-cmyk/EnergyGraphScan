
const fs=require('fs');
const a=fs.readFileSync('app.v1.1.3.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes("pts.push({x,y:median(use),support:use.length});"),'column representative missing');
ok(a.includes("robust(valuesFrom(inRange),'primary')"),'primary path missing');
ok(a.includes("robust(valuesFrom(inRange),'relaxed')"),'relaxed path missing');
ok(a.includes("robust(raw,'pixel-fallback')"),'pixel fallback missing');
ok(a.includes("out&&out.count>=3"),'3 sample continuation missing');
ok(a.includes("robustMeanByRange(plot,scale,trace,0,260)"),'Low range wrong');
ok(a.includes("robustMeanByRange(plot,scale,trace,270,500)"),'High range wrong');
ok(a.includes("await loadFile(file,true);"),'auto-analysis after photo missing');
console.log('v1.1.3 sparse trace regression PASS');
