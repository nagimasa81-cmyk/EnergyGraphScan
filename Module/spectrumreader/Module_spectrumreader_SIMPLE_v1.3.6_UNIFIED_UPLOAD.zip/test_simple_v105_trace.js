
const fs=require('fs'),a=fs.readFileSync('app.v1.0.5.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('async function traceHue('),'async traceHue missing');
ok(a.includes('async function extractTrace('),'async extractTrace missing');
ok(a.includes('/220'),'coarse hue bound missing');
ok(a.includes('/420'),'column bound missing');
ok(a.includes("Trace 2/5"),'granular progress missing');
ok(a.includes("Trace 3/5"),'granular progress missing');
ok(a.includes("await extractTrace("),'analyze does not await trace');
ok(a.includes("setTimeout(r,0)"),'UI yielding missing');
ok(h.includes('v1.0.5 Simple · build 1730'),'build stamp missing');
console.log('Simple v1.0.5 trace regression PASS');
