# Energy Graph Simple v1.0.2

黒い Energy per Band グラフだけを撮影して Low / High 平均値だけを読む軽量版です。

- Channel判定なし
- Gain / Noise判定なし
- Channel ROIなし
- X軸は 0–500
- Low = 0–260
- High = 270–500
- スパイク除外後の平均
- オフラインPWA対応
- 撮影/ライブラリ画像はネイティブ解像度で解析


既存の `deploy-spectrumreader-zip-pages.yml` が要求する4つの互換JSを同梱しています。Simple版の解析本体は `app.js` のみです。

- v1.0.2: Y軸下辺=0仮定を完全撤廃。見えているY軸数値2点以上からpixel→値を直接回帰。

- v1.0.2 cachefix: Safari旧Service Workerがv1.0.1を返し続ける問題を修正。
- HTML/runtimeはnetwork-first。
- 旧Energy Graph cacheをactivation時に削除。
- app.v1.0.2.jsをバージョン付きURLでロード。

- v1.0.3: Y軸を全水平グリッドの数値系列として同時判定。下辺値の仮定なし。
- 数値精度検証中はService Worker/オフラインキャッシュを一時停止。旧v1.0.1が残る問題を排除。
- 画面ヘッダに build 1705 を表示。

- v1.0.4: 4032×3024等の最大解像度画像は原画として保持し、解析だけ最大辺1280pxのワーキング画像で実行。
- Trace色分離は最大約900列×500行相当へ制限。iPhoneで50%停止に見える問題を解消。
- 結果ラインは原画像座標へ戻して描画。

- v1.0.5: Trace処理を5段階表示へ分解。
- 色探索は最大約220×140点の粗探索。
- Trace列探索は最大420列、各列は粗Y探索後に局所精査のみ。
- 20列ごとにUIへ制御を返すため、iPhoneで50%固定に見えない。
- 完了時に総解析秒数を表示。

- v1.0.6: Trace 3/5の列ごと局所精査を廃止。
- 最大辺800pxの解析画像上で、色候補画素を1回走査して最大180個のX-binへ集約。
- 解析量を約300×180サンプル以内に固定し、iPhone Safariでの長時間停止を防止。

- v1.1.0: Simple解析を一本化。
- Black plot → Green grid → Y anchors → foreground trace → Low/High。
- 表示ラインと計算値は完全に同じ座標変換を使用。

- v1.1.1: Analyze/Low/High DOM ID不整合を修正。
- JavaScriptの全DOM参照IDをHTMLと照合。
- Node VM上で実アプリJSをロードし、Analyzeクリック→進捗表示までランタイム検証。

- v1.1.2: 撮影または写真選択後、画像デコード完了から自動でAnalyzeまで進む。
- プレビュー表示を1フレーム反映してから解析開始。
- Analyzeボタンは再解析用として残す。
- 同じ写真を再度選べるようfile inputを毎回クリア。

- v1.1.3: 細いLow水平線・疎なHigh点群向けにTrace抽出を変更。
- 各X列から代表Yを1点取得。
- Primary → Relaxed → Pixel fallbackの3段階。
- 5サンプル未満でも3サンプル以上なら継続。

- v1.1.6: Y軸数値ROIの根本バグを修正。従来は黒グラフの左外側を読んでいたため、0.01000等を実際には読めていなかった。
- 数値ROIを黒グラフ内、左端〜最初の縦グリッド線の間へ変更。
- fixed5軸は0.0001/0.0002/0.0005/0.001/0.002/0.0025/0.005/0.01/0.02/0.025/0.05の標準step整合性を評価。
- 代表Trace点が少なくてもpixel fallbackへ進む。
- 結果詳細に実際に採用したY anchor文字列を表示。

- v1.1.8: iPhone Safariの30%付近クラッシュ対策。
- 撮影ファイル自体は最大解像度のまま受け取るが、4032x3024のDOM canvasは生成しない。
- Previewは最大1600px、解析は最大1100px。
- createImageBitmapは縮小描画後にcloseしてメモリ解放。
- 解析用ImageDataは1回だけ取得して全ステージで再利用。
- preprocessは全輝度配列sortを廃止し256-bin histogram化。
- Y軸テンプレート候補とfont/sizeを削減し、実グリッド間隔から文字サイズを選ぶ。
- 進捗30/48/68/84%は実際のGrid/Y-axis/Trace/Low-High処理位置に一致。

- v1.1.9: v1.1.8の重大回帰を修正。
- getWorkPixels() 内が誤って getWorkPixels() 自身を呼ぶ再帰になっており、解析開始直後に Maximum call stack size exceeded が発生していた。
- workCtx.getImageData(...) を1回だけ実行してキャッシュする本来の実装へ修正。
- 再帰回帰テストを追加。

- v1.2.0: Y-axis OCR Engine 2。
- グリッド線位置ごとにY軸数値ROIを固定し、green/bright/adaptiveの3種類の前処理を統合。
- 数字専用候補を複数スケールで照合し、複数グリッドのaffine整合性とcanonical stepで最終決定。
- compact整数スケールは強い整合性がない限り採用せず、誤った1/2/5/7などを結果として出さない。
- 下辺=0は仮定しない。
- 撮影/写真選択後は自動解析。
- 解析成功時は結果カードまで自動スクロール。失敗時もNeeds attentionまで自動スクロール。

- v1.2.1: OCR Engine 3。
- Y軸の文字形状から先に decimal (0.02000型) / compact (1.0型) を判定。
- 判定後は原則そのfamilyだけを認識し、0.02000→2.1/1.9等のcross-family誤認経路を遮断。
- decimalはEnergy per Bandで実際に使うcanonical grid step/値だけでaffine fit。
- decimal形状なのにcompact解が出た場合は結果を公開せずNeeds attention。
- 下辺=0は仮定しない。
- 撮影後自動解析・結果への自動スクロールを維持。

- v1.2.2 hotfix: v1.2.1 OCR3内に混入したJavaScriptでは無効な `False` / `True` を `false` / `true` に修正。
- iPhone Safariで表示された `Can't find variable: False` の直接原因を除去。
- 配布対象JavaScript全体を構文検査し、Python形式boolean/nullの残存チェックを追加。
- OCR3 decimal/compact family-first判定、自動解析、結果への自動スクロールは維持。

- v1.2.3: OCR Engine 4 global lattice。
- 各Y軸ラベルを独立OCRする方式を廃止。
- 0.02000→0.01000… / 0.01000→0.00500…など、Y軸全体の連続数値格子を画像全行に同時照合。
- 一文字の誤認で0.02000→0.00130等へ飛ぶ経路を削減。
- compact軸はdecimalモデルを大きく上回った場合のみ採用。
- 下辺=0は仮定しない。
- 自動解析・結果への自動スクロールを維持。

- v1.2.4: OCR4.1。
- 解析画像を1100px→1600pxへ変更し、小数点以下5桁のY軸文字情報を保持。
- 0.005 / 0.010 grid stepを優先し、0.0001 / 0.0002等の極小stepには強いpenalty。
- 選択ラベルと10倍/1/10倍等のdecoyを各行で比較し、桁識別marginを導入。
- 0.0005以下を採用する場合、複数行の明確なdigit evidenceが必須。
- 誤値を出すよりNeeds attentionを優先。
- 自動解析と結果への自動スクロールを維持。
