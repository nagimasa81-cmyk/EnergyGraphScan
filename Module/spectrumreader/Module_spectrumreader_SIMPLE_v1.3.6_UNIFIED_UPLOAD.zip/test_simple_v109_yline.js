
const fs=require('fs'),a=fs.readFileSync('app.v1.0.9.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function observedYLabelMask('),'row mask missing');
ok(a.includes('function rowLabelHypotheses('),'row hypotheses missing');
ok(a.includes("source:'fast-line-label-affine-v1.0.9'"),'new source missing');
ok(!a.includes('function classifyGlyph('),'old glyph segmentation still present');
ok(a.includes('async function extractTrace('),'extractTrace missing');
ok(a.includes('function chooseYScale('),'chooseYScale missing');
ok(h.includes('v1.0.9 Simple · build 1835'),'build stamp missing');
console.log('v1.0.9 Y-line regression PASS');
