
const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}

ok(a.includes('function v656ResetGeometryState('),'central reset missing');
ok(a.includes('function v656SetAutoGeometry('),'central Auto geometry setter missing');

const use=a.slice(a.indexOf('function useImage('),a.indexOf('function v61MakeRotatedCanvas'));
ok(use.includes('v656ResetGeometryState();'),'new image does not reset geometry state');

const auto=a.slice(a.indexOf("$('autoDetectBtn').onclick"),a.indexOf("$('manualBtn').onclick"));
ok(auto.includes('v656SetAutoGeometry(found);'),'Auto button does not synchronize state');
ok(!auto.includes('roiEditorState.active=true'),'Auto still activates manual editor');

const commit=a.slice(a.indexOf('function v655CommitVisibleROIForAnalysis('),a.indexOf('async function analyzeV6'));
ok(commit.includes('!roiEditorState.active||!roiManual||!roi'),'Analyze commit is not manual-only');
ok(!commit.includes('roiManual=true'),'Analyze commit still reclassifies Auto as Manual');

const post=a.slice(a.indexOf('function runPostCapturePipeline('),a.indexOf('function useImage('));
ok(post.includes('v656SetAutoGeometry(refined);'),'post-capture direct Auto not synchronized');
ok(post.includes('v656SetAutoGeometry(activeDetectedPanel);'),'registration fallback not synchronized');

console.log('v6.5.6 ROI state triple-check PASS');
