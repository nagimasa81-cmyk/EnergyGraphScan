
const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v652GainLowContinuousBaseline('),'Gain Low baseline detector missing');
ok(a.includes("source:'v6.5.2-continuous-horizontal-gain-low'"),'Gain Low source missing');
ok(a.includes('function v652RefineEightCheckboxes('),'local CH0-7 checkbox refinement missing');
ok(a.includes("source:'v6.5.2-CH0-7-local-checkbox-refinement'"),'CH0-7 refinement source missing');
ok(a.includes('function v652GrowEnergyROIByGrid('),'grid-grown Auto ROI missing');
ok(a.includes("Gain Low trace is geometrically above High"),'Gain Low/High geometry guard missing');
console.log('v6.5.2 Low/Channel/Auto regression PASS');
