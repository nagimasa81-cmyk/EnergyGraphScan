
const fs=require('fs');
const a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v650ExpandEnergyROIToFullPanel('),'full Energy panel expansion missing');
ok(a.includes('function v650WeightedYAxisRegression('),'direct Y regression missing');
ok(a.includes('function v650DetectCH0to7('),'CH0-7 detector missing');
ok(a.includes("source:'v6.5-CH0-7-only-top-row'"),'CH0-7-only source missing');
ok(a.includes("source:'v6.5-direct-numeric-anchor-regression+grid'"),'direct anchor Y source missing');
ok(a.includes('const candidates=coloredCount>=8'),'colored trace must exclude white text');
ok(!a.includes("source:'v6.4.2-detected-checkbox-grid'"),'old 16-channel detector still authoritative');
console.log('v6.5.0 CH0-7 + axis + trace regression PASS');
