const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v657FullEnergyPanelBoundary('),'missing full panel');
ok(a.includes('function v657CompletePlotDomain('),'missing plot completion');
ok(a.includes('function v657ReconcileGainLowWithGrid('),'missing low reconcile');
console.log('v6.5.7 regression PASS');