const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v659ClearPreviousAnalysisUI('),'new-image clear missing');
const ui=a.slice(a.indexOf('function useImage('),a.indexOf('function v61MakeRotatedCanvas'));
ok(ui.includes('v659ClearPreviousAnalysisUI();'),'useImage does not clear prior result');
ok(a.includes("source:'v6.5.9-channel-strip-left-of-energy'"),'channel layout fallback missing');
const seed=a.slice(a.indexOf('function v632ChannelSeed()'),a.indexOf('function v63StoreROI'));
ok(seed.indexOf('v62DetectChannelROI(energy)')>=0,'Channels/Select All anchor not first-class');
ok(a.includes('function v659CanonicalYAxisCalibration('),'canonical Y adapter missing');
ok(a.includes("source:'v6.5.9-grid-first-numeric-anchor-affine'"),'grid-first Y path not active');
const an=a.slice(a.indexOf('async function analyzeV6(){'),a.indexOf('function detectGraph(){'));
ok(an.includes('v659CanonicalYAxisCalibration'),'Analyze does not call new Y calibration');
ok(an.includes('v659FinalizePopulationValue(lowPop,yCal)'),'Low final value not tied to line Y');
ok(an.includes('v659FinalizePopulationValue(highPop,yCal)'),'High final value not tied to line Y');
console.log('v6.5.9 clear/channel/axis/line regression PASS');
