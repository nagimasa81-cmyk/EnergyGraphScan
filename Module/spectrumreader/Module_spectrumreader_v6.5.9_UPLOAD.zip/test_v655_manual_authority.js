
const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v655CommitVisibleROIForAnalysis('),'helper missing');
const an=a.slice(a.indexOf('async function analyzeV6(){'),a.indexOf('function detectGraph(){'));
ok(an.indexOf('v655CommitVisibleROIForAnalysis();') < an.indexOf('let energy=v632EnergySeed();'),
   'visible ROI not committed before actual Energy seed');
ok(a.includes('manualEnergyROI={...q}'),'manual Energy mirror missing');
ok(a.includes('activeDetectedPanel=null'),'stale Auto geometry invalidation missing');
ok(a.includes('Using committed Manual Energy ROI; rebuilding all geometry.'),'manual rebuild missing');
console.log('v6.5.5 manual ROI authority regression PASS');
