const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(x,m){if(!x)throw Error(m)}
ok(a.includes("width:{ideal:4096}"),"4096 request missing");
ok(a.includes("height:{ideal:3072}"),"3072 request missing");
ok(a.includes("getCapabilities"),"capability max missing");
ok(a.includes("adv.width=caps.width.max"),"width max missing");
ok(a.includes("const scale=1;"),"native scale missing");
ok(!a.includes("const maxOutW=2800"),"capture still downscales");
ok(!a.includes("const maxW=2800"),"useImage still downscales");
console.log("v6.5.3 maximum-resolution camera regression PASS");