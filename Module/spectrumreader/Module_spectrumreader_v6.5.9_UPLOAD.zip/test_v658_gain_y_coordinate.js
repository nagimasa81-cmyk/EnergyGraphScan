const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('app.js','utf8');
const a=src.indexOf('function refineGainAxisZeroFromFullGeometry');
const b=src.indexOf('\nfunction gainPixelLevelSummary',a);
if(a<0||b<0)throw Error('v6.5.8 helper missing');
const sandbox={EGSCore:{median:a=>{a=[...a].sort((x,y)=>x-y);return a[Math.floor(a.length/2)]},robust:a=>a,geometry:()=>({x0:0,x1:500,y0:0,y1:400})},Number,Math};
vm.createContext(sandbox); vm.runInContext(src.slice(a,b),sandbox);
let cal={family:'Gain',stepPx:100,stepValue:1,source:'test',anchors:[{y:100,value:3},{y:200,value:2},{y:300,value:1}]};
let xs=[],ys=[]; for(let x=0;x<=330;x++){xs.push(x);ys.push(400)}
let tr={xs,ys,width:501,height:401};
let r=sandbox.refineGainAxisZeroFromFullGeometry(cal,tr,{x:0,y:0,w:500,h:400},{},{lowMeasureRange:{x0:0,x1:330}});
if(Math.abs(r.zeroY-400)>1e-6)throw Error('zero reconstruction failed '+r.zeroY);
if(!r.zeroEvidence.baselineConfirmed)throw Error('baseline should corroborate');
// A wildly wrong trace must never redefine zero.
tr.ys=tr.ys.map(()=>180);
r=sandbox.refineGainAxisZeroFromFullGeometry(cal,tr,{x:0,y:0,w:500,h:400},{},{lowMeasureRange:{x0:0,x1:330}});
if(Math.abs(r.zeroY-400)>1e-6||r.zeroEvidence.baselineConfirmed)throw Error('trace improperly defined zero');
console.log('v6.5.8 Gain Y-coordinate reconstruction PASS');
