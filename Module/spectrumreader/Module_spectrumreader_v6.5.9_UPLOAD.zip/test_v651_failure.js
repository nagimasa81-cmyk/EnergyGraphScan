
const fs=require('fs'),a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function v651CorrectGainAxis('),'missing Y fix');
ok(a.includes('function v651ChannelByFixedEightSlots('),'missing CH0-7 fixed slots');
ok(a.includes("source:'v6.5.1-direct-visible-numeric-anchor-fit'"),'missing direct Y source');
ok(a.includes("source:'v6.5.1-fixed-eight-CH0-7'"),'missing CH source');
ok(!a.includes("...[.5,1,2].map(step=>({family:'Gain',step}))"),'0.5 Gain alias remains');
ok(a.includes('found.w/found.h<1.65'),'auto ROI narrow guard missing');
console.log('v6.5.1 regression PASS');
