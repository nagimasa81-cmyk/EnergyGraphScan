
const fs=require('fs');
const a=fs.readFileSync('app.js','utf8');
function ok(v,m){if(!v)throw Error(m)}

ok(a.includes('function v640AutoEnergyROI('),'new Auto Energy ROI missing');
ok(a.includes('function v640PlotFromEnergyROI('),'plot geometry stage missing');
ok(a.includes('function v640YAxisCalibration('),'canonical Y calibration missing');
ok(a.includes('function v640RecognizeXAxis('),'canonical X calibration missing');
ok(a.includes('function v640ChannelSlots('),'16-slot channel detector missing');
ok(a.includes("source:'v6.4-grid-first-two-anchor-validated'"),'validated Y source missing');
ok(a.includes("rows.length<2)return{ok:false"),'two Y-anchor minimum missing');
ok(a.includes("cand.family==='Noise'&&h.value>.20"),'Noise magnitude gate missing');
ok(a.includes("cand.family==='Gain'&&h.value<.30"),'Gain magnitude gate missing');
ok(a.includes("source:'v6.4-full-grid-0-500'"),'validated X grid fallback missing');
ok(a.includes("if(!yCal.ok)"),'Y calibration failure gate missing');
ok(a.includes("if(!xCal.ok)"),'X calibration failure gate missing');
ok(a.includes("Calibration unresolved"),'withhold-on-failure behavior missing');

const analyze=a.slice(a.indexOf('async function analyzeV6('),a.indexOf('function detectGraph('));
ok(analyze.includes('v640PlotFromEnergyROI'),'Analyze bypasses canonical plot stage');
ok(analyze.includes('v640YAxisCalibration'),'Analyze bypasses canonical Y stage');
ok(analyze.includes('v640RecognizeXAxis'),'Analyze bypasses canonical X stage');
ok(!analyze.includes('v6AxisDecision('),'legacy Y decision still used by Analyze');
ok(!analyze.includes('v6XAxisCalibration('),'legacy X calibration still used by Analyze');
ok(!analyze.includes('v621DetectCheckedChannelsFromKnownLayout'),'legacy Channel detector still used by Analyze');

console.log('v6.4.0 canonical geometry regression PASS');
