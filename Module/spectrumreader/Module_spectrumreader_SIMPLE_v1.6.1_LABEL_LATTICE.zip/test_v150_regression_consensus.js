const assert=require('assert');
function canonical(f){return f==='decimal'?[.0001,.0002,.0005,.001,.002,.0025,.005,.01,.02]:[.1,.2,.5,1,2,2.5,5]}
function fit(step,family){return Math.min(...canonical(family).map(x=>Math.abs(x-step)/x))<=.18}
assert(fit(.01,'decimal'));
assert(fit(.005,'decimal'));
assert(fit(1,'compact'));
assert(!fit(.0025,'compact'));
// Regression policy: no single-read publication.
function publishable(visibleGridCount,inliers,strong){return !(visibleGridCount>=3&&inliers<3&&strong<2) && inliers>=2}
assert(!publishable(4,1,1));
assert(!publishable(4,2,1));
assert(publishable(4,3,1));
assert(publishable(3,2,2));
console.log('v1.5.0 regression-consensus policy PASS');
