# v1.6.1 regression target

Added a guarded multi-row visible-label lattice solver after the two independent OCR paths.

Acceptance requires:
- at least two actual Y-label row masks;
- a fixed family inferred only from observed label geometry/text evidence;
- monotonic canonical step;
- at least two strong row-template supports;
- a strict winner margin over the second-best complete lattice.

This specifically addresses clear axes such as 0.02000/0.01000 and 0.04000/0.03000/0.02000/0.01000 that v1.6.0 safely rejected because each single row failed the independent margin.
The lower plot edge is never assumed to be zero.
