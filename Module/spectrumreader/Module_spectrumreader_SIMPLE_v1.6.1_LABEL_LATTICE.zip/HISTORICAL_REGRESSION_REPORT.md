# Historical Regression Report — v1.6.0

## Corpus inventory
- 249 historical image assets were available in the active conversation runtime.
- 175 screenshots/photos contained a detectable dark Energy-per-Band-like region with green grid content and were extracted into the offline analysis corpus during development.
- The corpus spans compact axes (e.g. 1/2/3) and fixed-decimal axes (e.g. 0.00500/0.01000/0.02000/0.03000), multiple trace colors, perspective/moire, sparse and dense traces, tooltip overlays, and prior false-positive outputs.

## Baseline finding
The previous v1.5.0/v1.3.x family was not sufficiently validated. A representative historical-photo batch showed that the dominant failure modes were:
1. plot localization rejecting valid graph panels;
2. Y-axis labels failing independent evidence checks;
3. older builds publishing plausible but wrong synthetic Y scales.

## v1.6.0 design changes
- Historical-corpus-first regression architecture.
- Multi-font whole-label template ensemble: Arial, Tahoma, Verdana, Trebuchet MS, sans-serif; two font weights.
- Independent glyph OCR remains separate from the whole-label decoder.
- RANSAC-style affine Y-axis consensus across rows.
- Canonical-step and monotonic-grid consistency gate.
- Direct black Energy-panel localization fallback for photos where surrounding Windows UI confuses the primary detector.
- Fail-closed policy remains: unsupported axes return Needs attention instead of a plausible wrong number.

## Required release gates
A future release is not considered numerically validated until all of the following are reported from the historical corpus:
- numeric-correct rate;
- safe-fail rate;
- wrong-number publication rate;
- plot-localization failure rate;
- Y-axis-family confusion rate;
- trace extraction failure rate.

Priority metric: wrong-number publication rate must be minimized before optimizing completion rate.
