"""Developer regression harness for Energy Graph Simple.
Run outside the iPhone runtime against a folder of historical screenshots/photos.
It extracts candidate Energy-per-Band regions and records corpus metadata.
Browser execution is intentionally separate so the shipped PWA stays lightweight.
"""
from pathlib import Path
import json, cv2, numpy as np, sys

root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
out=Path(sys.argv[2] if len(sys.argv)>2 else 'historical_corpus_manifest.json')
rows=[]
for p in sorted(root.rglob('*')):
    if p.suffix.lower() not in {'.png','.jpg','.jpeg'}: continue
    im=cv2.imread(str(p))
    if im is None: continue
    h,w=im.shape[:2]
    hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
    dark=(hsv[:,:,2] < 85).astype(np.uint8)
    n,lab,stats,cent=cv2.connectedComponentsWithStats(dark,8)
    best=None
    for i in range(1,n):
        x,y,bw,bh,area=[int(v) for v in stats[i]]
        if bw<120 or bh<45 or bw/bh<1.15: continue
        roi=im[y:y+bh,x:x+bw]
        b,g,r=cv2.split(roi)
        green=float(((g>55)&(g>r*1.15)&(g>b*1.15)).mean())
        if green<0.002: continue
        score=float(area*green*(bw/max(1,bh)))
        if best is None or score>best['score']:
            best={'box':[x,y,bw,bh],'green_fraction':green,'score':score}
    rows.append({'file':str(p),'width':w,'height':h,'energy_candidate':best})
out.write_text(json.dumps({'count':len(rows),'items':rows},indent=2),encoding='utf-8')
print(f'wrote {out} ({len(rows)} images)')
