
const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');

let ready=false, sourceWidth=1, sourceHeight=1;
const workCanvas=document.createElement('canvas'),
      workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
let workImageData=null,analysisScale=1;

const VERSION='1.3.8';
const BUILD='20260817-0235';

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){
  if(!a.length)return NaN;
  const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);
  return b.length%2?b[m]:(b[m-1]+b[m])/2;
}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;
  if(!d)return 0;
  let h;
  if(mx===r)h=60*(((g-b)/d)%6);
  else if(mx===g)h=60*((b-r)/d+2);
  else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function stats(r,g,b){
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=.299*r+.587*g+.114*b;
  return {mx,mn,lum,sat:(mx-mn)/Math.max(1,mx),h:rgb2hue(r,g,b)};
}
function greenStrength(r,g,b){return g-Math.max(r,b)*.84}
function isGridGreen(r,g,b){return g>45&&greenStrength(r,g,b)>9}

function isAxisGlyph(r,g,b){
  const st=stats(r,g,b);
  // Green/yellow label, anti-aliased pale label, or bright text on a black plot.
  const greenish=(g>38 && g>=r*.72 && g>=b*.72 && st.lum>34);
  const yellowish=(r>55 && g>55 && b<Math.max(r,g)*.82 && st.lum>48);
  const pale=(st.lum>115 && st.sat<.34);
  return greenish||yellowish||pale;
}

function releasePixels(){workImageData=null}
function pixels(){
  if(!workImageData)workImageData=workCtx.getImageData(0,0,workCanvas.width,workCanvas.height);
  return workImageData;
}
function idx(x,y){return (y*workCanvas.width+x)*4}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden');
  $('progressPct').textContent=`${p}%`;
  $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label;
  $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');
  $('lowValue').textContent='—';
  $('highValue').textContent='—';
  $('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;releasePixels();
  sourceWidth=sourceHeight=1;
  workCanvas.width=workCanvas.height=1;
  canvas.width=canvas.height=1;
  canvas.style.display='none';
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;
  $('status').textContent='Ready';
  $('progressCard').classList.add('hidden');
  clearResult();
}
function prepareWork(){
  // One controlled-resolution image is used by EVERY analysis stage.
  // No stage is allowed to silently switch coordinate systems.
  const maxSide=1800,sw=canvas.width,sh=canvas.height,
        scale=Math.min(1,maxSide/Math.max(sw,sh));
  analysisScale=scale;
  workCanvas.width=Math.max(1,Math.round(sw*scale));
  workCanvas.height=Math.max(1,Math.round(sh*scale));
  workCtx.clearRect(0,0,workCanvas.width,workCanvas.height);
  workCtx.drawImage(canvas,0,0,workCanvas.width,workCanvas.height);
  releasePixels(); pixels();
}
function toOriginalX(x){return x/analysisScale}
function toOriginalY(y){return y/analysisScale}

async function loadFile(file,autoAnalyze=true){
  clearResult();releasePixels();
  $('progressCard').classList.add('hidden');
  $('analyzeBtn').disabled=true;
  $('status').textContent='Loading full-resolution photo…';
  let bmp=null;
  try{
    bmp=await createImageBitmap(file);
    sourceWidth=bmp.width;sourceHeight=bmp.height;
    const previewMax=1800,
          s=Math.min(1,previewMax/Math.max(sourceWidth,sourceHeight)),
          w=Math.max(1,Math.round(sourceWidth*s)),
          h=Math.max(1,Math.round(sourceHeight*s));
    canvas.width=w;canvas.height=h;
    ctx.clearRect(0,0,w,h);
    ctx.drawImage(bmp,0,0,w,h);
    if(typeof bmp.close==='function')bmp.close();
    bmp=null;
    canvas.style.display='block';
    document.querySelector('.placeholder').style.display='none';
    ready=true;$('analyzeBtn').disabled=false;
    $('status').textContent=`Loaded — ${sourceWidth}×${sourceHeight}px`;
    if(autoAnalyze){
      await new Promise(r=>requestAnimationFrame(()=>r()));
      await analyze();
    }
  }catch(e){
    if(bmp&&typeof bmp.close==='function')try{bmp.close()}catch(_){}
    ready=false;
    $('status').textContent=`Image load failed: ${e.message||e}`;
    setProgress(100,'Needs attention',`Image load failed: ${e.message||e}`);
  }
}

/* ------------------------------------------------------------------
   STAGE 1 — locate the upper Energy-per-Band black plot
   ------------------------------------------------------------------ */

function longestDarkRun(y){
  const W=workCanvas.width,d=pixels().data;
  let bestLen=0,bestA=0,bestB=0,a=-1,gap=0;
  for(let x=0;x<W;x++){
    const i=idx(x,y),st=stats(d[i],d[i+1],d[i+2]);
    const dark=st.lum<92;
    if(dark){
      if(a<0)a=x;
      gap=0;
    }else if(a>=0){
      gap++;
      if(gap>3){
        const b=x-gap,len=b-a+1;
        if(len>bestLen){bestLen=len;bestA=a;bestB=b}
        a=-1;gap=0;
      }
    }
  }
  if(a>=0){
    const len=W-a;
    if(len>bestLen){bestLen=len;bestA=a;bestB=W-1}
  }
  return {len:bestLen,a:bestA,b:bestB};
}

function plotBandCandidates(){
  const W=workCanvas.width,H=workCanvas.height,minLen=Math.round(W*.25);
  const rows=[];
  for(let y=0;y<H;y++){
    const r=longestDarkRun(y);
    rows.push(r.len>=minLen?{y,...r}:null);
  }
  const groups=[];
  let cur=[];
  for(let y=0;y<H;y++){
    if(rows[y])cur.push(rows[y]);
    else if(cur.length){
      if(cur.length>=Math.max(24,Math.round(H*.035)))groups.push(cur);
      cur=[];
    }
  }
  if(cur.length>=Math.max(24,Math.round(H*.035)))groups.push(cur);

  const d=pixels().data,cands=[];
  for(const g of groups){
    const top=g[0].y,bottom=g.at(-1).y,
          left=Math.round(median(g.map(r=>r.a))),
          right=Math.round(median(g.map(r=>r.b))),
          w=right-left+1,h=bottom-top+1;
    if(w<120||h<65)continue;
    let dark=0,green=0,n=0;
    const xs=Math.max(1,Math.round(w/220)),ys=Math.max(1,Math.round(h/120));
    for(let y=top;y<=bottom;y+=ys)for(let x=left;x<=right;x+=xs){
      const i=idx(x,y),r=d[i],gg=d[i+1],b=d[i+2],st=stats(r,gg,b);
      n++;if(st.lum<100)dark++;if(isGridGreen(r,gg,b))green++;
    }
    const darkFrac=dark/Math.max(1,n),greenFrac=green/Math.max(1,n),
          aspect=w/Math.max(1,h);
    if(darkFrac<.46||greenFrac<.003||aspect<1.3)continue;
    // Energy-per-Band is the first qualifying graph in the photo.
    // Score slightly favors an upper, compact, grid-rich black panel.
    const score=darkFrac*4+greenFrac*16-Math.abs(aspect-2.1)*.12-(top/H)*.25;
    cands.push({left,top,right,bottom,w,h,darkFrac,greenFrac,score});
  }
  cands.sort((a,b)=>a.top-b.top || b.score-a.score);
  if(!cands.length)throw Error('Energy per Band black plot could not be localized.');
  return cands;
}

function smooth1(a,r=2){
  return a.map((_,i)=>{
    let s=0,n=0;
    for(let k=Math.max(0,i-r);k<=Math.min(a.length-1,i+r);k++){s+=a[k];n++}
    return s/n;
  });
}
function localPeaks(vals,minSep,minScore){
  const c=[];
  for(let i=1;i<vals.length-1;i++)
    if(vals[i]>=minScore&&vals[i]>=vals[i-1]&&vals[i]>=vals[i+1])c.push({i,s:vals[i]});
  c.sort((a,b)=>b.s-a.s);
  const keep=[];
  for(const q of c){
    if(keep.every(p=>Math.abs(p.i-q.i)>=minSep))keep.push(q);
    if(keep.length>=20)break;
  }
  return keep.sort((a,b)=>a.i-b.i);
}

function greenProfiles(box){
  const d=pixels().data,w=box.right-box.left+1,h=box.bottom-box.top+1;
  let hs=new Array(h).fill(0),vs=new Array(w).fill(0);
  for(let yy=0;yy<h;yy++){
    let c=0,n=0;
    // ignore extreme label/title edges when evaluating horizontal grid support
    const xa=box.left+Math.round(w*.12),xb=box.right-Math.round(w*.03);
    for(let x=xa;x<=xb;x+=2){
      const i=idx(x,box.top+yy);
      if(isGridGreen(d[i],d[i+1],d[i+2]))c++;
      n++;
    }
    hs[yy]=c/Math.max(1,n);
  }
  for(let xx=0;xx<w;xx++){
    let c=0,n=0;
    const ya=box.top+Math.round(h*.08),yb=box.bottom-Math.round(h*.12);
    for(let y=ya;y<=yb;y+=2){
      const i=idx(box.left+xx,y);
      if(isGridGreen(d[i],d[i+1],d[i+2]))c++;
      n++;
    }
    vs[xx]=c/Math.max(1,n);
  }
  return {hs:smooth1(hs,1),vs:smooth1(vs,1)};
}


function plotOccupancyLooksPhysical(plot){
  const bw=Math.max(1,plot.box.w||((plot.box.right??plot.box.left)-plot.box.left+1)),
        bh=Math.max(1,plot.box.h||((plot.box.bottom??plot.box.top)-plot.box.top+1)),
        pw=Math.max(1,plot.right-plot.left),
        ph=Math.max(1,plot.bottom-plot.top),
        wr=pw/bw,hr=ph/bh;
  // A valid Energy plot usually occupies a broad interior region of the black panel.
  return wr>=0.52 && hr>=0.22 && hr<=0.90;
}

function bestRegularLattice(peaks,minCount,maxCount,minStep=6,maxStep=Infinity){
  if(peaks.length<minCount)return null;
  let best=null;
  const pos=peaks.map(p=>p.i);
  for(let a=0;a<pos.length;a++)for(let b=a+1;b<pos.length;b++){
    const diff=pos[b]-pos[a];
    for(let div=1;div<=Math.min(5,maxCount-1);div++){
      const step=diff/div;
      if(step<minStep||step>maxStep)continue;
      const start=pos[a]-Math.round((a>0?1:0)*0); // explicit for clarity
      const matched=[];
      for(let k=-2;k<maxCount+3;k++){
        const target=start+k*step;
        if(target<pos[0]-step||target>pos.at(-1)+step)continue;
        let q=null;
        for(const p of peaks){
          const e=Math.abs(p.i-target);
          if(e<=Math.max(2.5,step*.11)&&(!q||e<q.e))q={p,e};
        }
        if(q&&!matched.some(m=>m.i===q.p.i))matched.push(q.p);
      }
      matched.sort((x,y)=>x.i-y.i);
      if(matched.length<minCount)continue;
      const ds=matched.slice(1).map((p,i)=>p.i-matched[i].i),
            md=median(ds),err=median(ds.map(v=>Math.abs(v-md)))/Math.max(1,md),
            score=matched.length*4-err*20+mean(matched.map(p=>p.s))*4;
      if(!best||score>best.score)best={matched,step:md,score,err};
    }
  }
  return best;
}

function refinePlot(box){
  const {hs,vs}=greenProfiles(box),
        hp=localPeaks(hs,Math.max(4,Math.round(box.h/22)),.018),
        vp=localPeaks(vs,Math.max(4,Math.round(box.w/28)),.018),
        H=bestRegularLattice(hp,2,5,Math.max(6,box.h*.11),box.h*.68),
        V=bestRegularLattice(vp,5,14,Math.max(6,box.w*.035),box.w*.32);
  if(!H||!V)throw Error('Energy plot grid lattice could not be resolved.');
  if(H.step<box.h*.11||H.step>box.h*.68)throw Error('horizontal lattice is not a major Y-grid spacing');

  let hy=H.matched.map(p=>box.top+p.i),
      vx=V.matched.map(p=>box.left+p.i);

  // Reconstruct missing members of a regular lattice instead of treating text/trace as grid.
  function reconstruct(arr,step,minV,maxV,maxN){
    arr=[...arr].sort((a,b)=>a-b);
    const origin=arr[0],out=[];
    for(let k=0;k<maxN;k++){
      const p=origin+k*step;
      if(p>maxV+step*.25)break;
      if(p>=minV-step*.25)out.push(p);
    }
    return out;
  }
  hy=reconstruct(hy,H.step,box.top,box.bottom,5);
  vx=reconstruct(vx,V.step,box.left,box.right,14);

  // Energy graphs supplied here use a dense X lattice. If the black candidate includes
  // the lower Raw Data plot, this condition rejects it rather than contaminating trace values.
  if(vx.length<6||hy.length<2)throw Error('Energy plot grid geometry is incomplete.');

  return {
    box,
    left:vx[0],right:vx.at(-1),
    top:hy[0],bottom:hy.at(-1),
    h:hy,v:vx,
    hStep:H.step,vStep:V.step
  };
}

function coarseGridFromBox(box){
  const {hs,vs}=greenProfiles(box),
        hp=localPeaks(hs,Math.max(3,Math.round(box.h/28)),.010),
        vp=localPeaks(vs,Math.max(3,Math.round(box.w/34)),.010);

  function regularize(peaks,minCount,axisMin,axisMax,minStep=5,maxStep=Infinity){
    const a=peaks.map(p=>p.i).sort((x,y)=>x-y);
    if(a.length<minCount)return null;
    const diffs=[];
    for(let i=1;i<a.length;i++){
      const d=a[i]-a[i-1];
      if(d>=5)diffs.push(d);
    }
    if(!diffs.length)return null;

    // Search robustly over pairwise spacings; camera moire can hide every 2nd line.
    const candidates=[];
    for(const d of diffs)for(const div of [1,2,3]){
      const st=d/div;
      if(st>=minStep&&st<=maxStep)candidates.push(st);
    }
    let best=null;
    for(const st of candidates){
      for(const origin of a){
        const hits=[];
        for(let k=-20;k<40;k++){
          const t=origin+k*st;
          if(t<axisMin-st*.3||t>axisMax+st*.3)continue;
          let q=null;
          for(const x of a){
            const e=Math.abs(x-t);
            if(e<=Math.max(2.5,st*.13)&&(!q||e<q.e))q={x,e};
          }
          if(q&&!hits.includes(q.x))hits.push(q.x);
        }
        hits.sort((x,y)=>x-y);
        if(hits.length<minCount)continue;
        const err=hits.slice(1).map((x,i)=>Math.abs((x-hits[i])-st));
        const score=hits.length*5-(err.length?median(err):0)*1.4;
        if(!best||score>best.score)best={step:st,hits,score};
      }
    }
    return best;
  }

  const H=regularize(hp,2,0,box.h-1,Math.max(5,box.h*.11),box.h*.68),
        V=regularize(vp,4,0,box.w-1,Math.max(5,box.w*.035),box.w*.32);
  if(!H||!V)return null;
  if(H.step<box.h*.11||H.step>box.h*.68)return null;

  function complete(origin,step,minV,maxV,maxN){
    const out=[];
    let k0=Math.floor((minV-origin)/step)-1;
    for(let k=k0;k<k0+maxN+6;k++){
      const v=origin+k*step;
      if(v>=minV-step*.18&&v<=maxV+step*.18)out.push(v);
    }
    return out.slice(0,maxN);
  }
  const hy=complete(H.hits[0],H.step,0,box.h-1,5).map(v=>box.top+v),
        vx=complete(V.hits[0],V.step,0,box.w-1,14).map(v=>box.left+v);
  if(hy.length<2||vx.length<5)return null;

  return {
    box,
    left:vx[0],right:vx.at(-1),
    top:hy[0],bottom:hy.at(-1),
    h:hy,v:vx,
    hStep:H.step,vStep:V.step,
    confidence:'coarse-lattice'
  };
}

function locateEnergyPlot(){
  const cands=plotBandCandidates();
  let failures=[],valid=[];

  // Tier 1: full regular-lattice refinement.
  for(const b of cands.slice(0,10)){
    try{
      const p=refinePlot(b),
            aspect=(p.right-p.left)/Math.max(1,p.bottom-p.top);
      if(p.v.length<5||p.h.length<2)throw Error('insufficient orthogonal lattice support');
      if(aspect<.55||aspect>12)throw Error('implausible geometry');
      if(!plotOccupancyLooksPhysical(p))throw Error('localized grid does not occupy a physical Energy-plot area');
      const score=p.v.length*6+p.h.length*5+b.darkFrac*4+b.greenFrac*18
        -(p.top/workCanvas.height)*1.2;
      valid.push({p:{...p,confidence:'refined-lattice'},score});
    }catch(e){failures.push(e.message)}
  }

  // Tier 2: a valid black Energy panel must not be discarded only because
  // perspective / trace overlap / moire damaged one lattice line.
  if(!valid.length){
    for(const b of cands.slice(0,10)){
      try{
        const p=coarseGridFromBox(b);
        if(!p)throw Error('coarse lattice unresolved');
        if(!plotOccupancyLooksPhysical(p))throw Error('coarse lattice occupancy is not physical');
        const score=p.v.length*5+p.h.length*4+b.darkFrac*3+b.greenFrac*12
          -(p.top/workCanvas.height);
        valid.push({p,score});
      }catch(e){failures.push(e.message)}
    }
  }

  // Tier 3: black-panel fallback. Still derives axes from green projections,
  // but does not require a formally complete lattice.
  if(!valid.length){
    for(const b of cands.slice(0,6)){
      const {hs,vs}=greenProfiles(b),
            hp=localPeaks(hs,Math.max(3,Math.round(b.h/30)),.006),
            vp=localPeaks(vs,Math.max(3,Math.round(b.w/36)),.006);
      if(hp.length>=2&&vp.length>=4){
        const hy=hp.map(q=>b.top+q.i).sort((a,b)=>a-b),
              vx=vp.map(q=>b.left+q.i).sort((a,b)=>a-b),
              hd=hy.slice(1).map((q,i)=>q-hy[i]),
              vd=vx.slice(1).map((q,i)=>q-vx[i]),
              hStep=median(hd),vStep=median(vd);
        if(Number.isFinite(hStep)&&Number.isFinite(vStep)&&hStep>4&&vStep>4&&hStep>=b.h*.11&&hStep<=b.h*.68){
          const hMajor=hy.slice(0,5);
          const p={box:b,left:vx[0],right:vx.at(-1),top:hMajor[0],bottom:hMajor.at(-1),h:hMajor,v:vx,hStep,vStep,confidence:'projection-fallback'};
          if(plotOccupancyLooksPhysical(p))valid.push({p,score:hp.length*3+vp.length*3+b.darkFrac*2});
        }
      }
    }
  }

  if(valid.length){
    valid.sort((a,b)=>b.score-a.score);
    return valid[0].p;
  }
  throw Error(`Energy plot could not be localized safely (${failures.slice(0,4).join('; ')}).`);
}


function makePlotSpace(plot){
  const width=Math.max(1,plot.right-plot.left),
        height=Math.max(1,plot.bottom-plot.top);
  return {
    left:plot.left,right:plot.right,top:plot.top,bottom:plot.bottom,
    width,height,
    toLocalX:x=>x-plot.left,
    toLocalY:y=>y-plot.top,
    toGlobalX:x=>plot.left+x,
    toGlobalY:y=>plot.top+y,
    contains:(x,y,pad=0)=>x>=plot.left-pad&&x<=plot.right+pad&&y>=plot.top-pad&&y<=plot.bottom+pad
  };
}
/* ------------------------------------------------------------------
   STAGE 2 — Y axis: aspect-preserving whole-label templates + lattice
   ------------------------------------------------------------------ */

const tplCanvas=document.createElement('canvas'),
      tplCtx=tplCanvas.getContext('2d',{willReadFrequently:true}),
      tplCache=new Map();

function normalizeMask(points,tw=144,th=36){
  if(!points.length)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const [x,y] of points){minx=Math.min(minx,x);miny=Math.min(miny,y);maxx=Math.max(maxx,x);maxy=Math.max(maxy,y)}
  const bw=maxx-minx+1,bh=maxy-miny+1;
  if(bw<2||bh<2)return null;
  // Preserve aspect ratio. Earlier versions stretched every string to the same width,
  // making "3.0" look artificially similar to "0.03000".
  const s=Math.min((tw-6)/bw,(th-4)/bh),
        ox=(tw-bw*s)/2,oy=(th-bh*s)/2,
        out=new Uint8Array(tw*th);
  for(const [x,y] of points){
    const xx=Math.round(ox+(x-minx)*s),yy=Math.round(oy+(y-miny)*s);
    for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
      const X=xx+dx,Y=yy+dy;
      if(X>=0&&X<tw&&Y>=0&&Y<th)out[Y*tw+X]=1;
    }
  }
  return out;
}
function maskScore(a,b){
  if(!a||!b)return 0;
  let inter=0,ua=0,ub=0;
  for(let i=0;i<a.length;i++){
    if(a[i])ua++;if(b[i])ub++;if(a[i]&&b[i])inter++;
  }
  if(!ua||!ub)return 0;
  const precision=inter/ub,recall=inter/ua;
  return precision+recall?2*precision*recall/(precision+recall):0;
}
function translatedScore(a,b,tw=144,th=36){
  let best=0;
  for(let sy=-2;sy<=2;sy++)for(let sx=-3;sx<=3;sx++){
    let inter=0,ua=0,ub=0;
    for(let y=0;y<th;y++)for(let x=0;x<tw;x++){
      const av=a[y*tw+x];
      const xx=x-sx,yy=y-sy;
      const bv=(xx>=0&&xx<tw&&yy>=0&&yy<th)?b[yy*tw+xx]:0;
      if(av)ua++;if(bv)ub++;if(av&&bv)inter++;
    }
    if(ua&&ub){
      const p=inter/ub,r=inter/ua,f=2*p*r/(p+r||1);
      if(f>best)best=f;
    }
  }
  return best;
}
function textTemplate(text){
  if(tplCache.has(text))return tplCache.get(text);
  tplCanvas.width=220;tplCanvas.height=60;
  tplCtx.clearRect(0,0,220,60);
  tplCtx.fillStyle='black';tplCtx.fillRect(0,0,220,60);
  tplCtx.fillStyle='white';
  tplCtx.font='26px Arial';
  tplCtx.textBaseline='middle';
  tplCtx.fillText(text,4,30);
  const im=tplCtx.getImageData(0,0,220,60).data,pts=[];
  for(let y=0;y<60;y++)for(let x=0;x<220;x++){
    const i=(y*220+x)*4;
    if(im[i]>90)pts.push([x,y]);
  }
  const m=normalizeMask(pts);
  tplCache.set(text,m);
  return m;
}

function rowLabelMaskData(plot,y){
  const d=pixels().data,
        axisX=plot.left,rowStep=plot.hStep,
        // Y-axis labels can be wider than expected; use a generous strip left of the axis.
        x0=Math.max(plot.box.left,Math.round(axisX-(plot.right-plot.left)*.62)),
        x1=Math.max(x0+16,axisX-2),
        y0=Math.max(plot.box.top,Math.round(y-rowStep*.48)),
        y1=Math.min(plot.box.bottom,Math.round(y+rowStep*.48)),
        w=x1-x0+1,h=y1-y0+1;
  if(w<6||h<4)return null;
  const mask=new Uint8Array(w*h),cols=new Int16Array(w);
  for(let yy=y0;yy<=y1;yy++)for(let x=x0;x<=x1;x++){
    // Do not let the horizontal grid line itself bridge all digits together.
    if(Math.abs(yy-y)<=Math.max(1,Math.round(rowStep*.035)))continue;
    const i=idx(x,yy),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
    if(isAxisGlyph(r,g,b)&&st.lum>28){
      const off=(yy-y0)*w+(x-x0);mask[off]=1;cols[x-x0]++;
    }
  }

  // First find individual glyph-like runs. Digit gaps are intentionally NOT treated
  // as separators of whole labels; the next stage merges nearby runs into a label string.
  const runs=[];
  let a=-1,gap=0;
  for(let x=0;x<w;x++){
    if(cols[x]>0){if(a<0)a=x;gap=0}
    else if(a>=0){gap++;if(gap>1){runs.push([a,x-gap]);a=-1;gap=0}}
  }
  if(a>=0)runs.push([a,w-1-gap]);
  if(!runs.length)return null;

  // Merge glyphs into numeric strings. At the working resolution, inter-digit gaps are
  // often 3-8 px; v1.3.5 incorrectly split 0.01000 into isolated digits and then called
  // the axis "compact". Merge based on row height so the rule scales with camera distance.
  const maxGap=Math.max(7,Math.round(h*.72),Math.round(rowStep*.30));
  const groups=[];
  let cur=[...runs[0]];
  for(let i=1;i<runs.length;i++){
    const r=runs[i],g=r[0]-cur[1]-1;
    if(g<=maxGap)cur[1]=r[1];
    else{groups.push(cur);cur=[...r]}
  }
  groups.push(cur);

  const candidates=[];
  for(const [sx,ex] of groups){
    let minx=Infinity,maxx=-Infinity,miny=Infinity,maxy=-Infinity,count=0;
    for(let yy=0;yy<h;yy++)for(let xx=sx;xx<=ex;xx++)if(mask[yy*w+xx]){
      count++;minx=Math.min(minx,xx);maxx=Math.max(maxx,xx);miny=Math.min(miny,yy);maxy=Math.max(maxy,yy);
    }
    if(count<7||maxx<0)continue;
    const bw=maxx-minx+1,bh=maxy-miny+1,cx=(minx+maxx)/2,cy=(miny+maxy)/2,
          aspect=bw/Math.max(1,bh),rightness=cx/Math.max(1,w),
          verticalCenter=1-Math.min(1,Math.abs(cy-h/2)/Math.max(1,h/2)),
          // Prefer a multi-digit horizontal string immediately left of the Y axis.
          axisDistance=Math.max(0,(w-1)-maxx),
          nearAxis=1-Math.min(1,axisDistance/Math.max(1,w*.45));
    let score=count+bw*1.7+rightness*8+verticalCenter*6+nearAxis*18;
    if(aspect<1.15)score-=25;       // rejects vertical Energy title fragments
    if(bw<h*1.45)score-=12;         // too narrow to be a useful numeric label
    candidates.push({minx,maxx,miny,maxy,bw,bh,cx,cy,aspect,count,score});
  }
  if(!candidates.length)return null;
  candidates.sort((a,b)=>b.score-a.score||b.bw-a.bw||b.count-a.count);
  const c=candidates[0],pts=[];
  for(let yy=c.miny;yy<=c.maxy;yy++)for(let xx=c.minx;xx<=c.maxx;xx++)if(mask[yy*w+xx])pts.push([xx-c.minx,yy-c.miny]);
  return {pts,w:c.bw,h:c.bh,aspect:c.aspect,count:c.count};
}
function observedLabelGeometry(plot,y){
  const data=rowLabelMaskData(plot,y);
  if(!data)return null;
  return {w:data.w,h:data.h,aspect:data.aspect,count:data.count};
}

function inferAxisTextFamily(plot){
  const rows=plot.h.map(y=>observedLabelGeometry(plot,y)).filter(Boolean);
  if(!rows.length)return {family:'unknown',confidence:0,reason:'no-label-geometry'};
  const ratios=rows.map(g=>g.w/Math.max(1,g.h)).filter(Number.isFinite),
        counts=rows.map(g=>g.count).filter(Number.isFinite),
        r=median(ratios),c=median(counts);
  if(r>=3.35||c>=118)return {family:'decimal',confidence:.995,reason:`long-label(${r.toFixed(2)})`};
  if(r<=2.35&&c<72)return {family:'compact',confidence:.94,reason:`short-label(${r.toFixed(2)})`};
  if(r>=2.85||c>=96)return {family:'decimal',confidence:.88,reason:`likely-long(${r.toFixed(2)})`};
  if(r<=2.55&&c<84)return {family:'compact',confidence:.76,reason:`likely-short(${r.toFixed(2)})`};
  return {family:'unknown',confidence:.35,reason:`neutral(${r.toFixed(2)})`};
}
function inferAxisFamily(plot){
  const gs=plot.h.map(y=>observedLabelGeometry(plot,y)).filter(Boolean);
  if(!gs.length)return {family:'unknown',confidence:0,aspect:NaN};
  const aspects=gs.map(g=>g.aspect).filter(Number.isFinite),counts=gs.map(g=>g.count),
        a=median(aspects),ct=median(counts);
  if(a>=3.20||ct>=112)return {family:'decimal',confidence:clamp((a-2.6)/1.0+.72,0,1),aspect:a};
  if(a<2.45&&ct<78)return {family:'compact',confidence:clamp((2.55-a)/.8+.62,0,1),aspect:a};
  if(a>=2.80||ct>=94)return {family:'decimal',confidence:.82,aspect:a};
  return {family:'unknown',confidence:.30,aspect:a};
}

function observedLabelMask(plot,y){
  const data=rowLabelMaskData(plot,y);
  return data?normalizeMask(data.pts):null;
}
function fmtAxis(v,family){
  if(family==='decimal')return Math.abs(v)<5e-8?'0.00000':v.toFixed(5);
  return v.toFixed(1);
}
function axisModels(n){
  const out=[];
  const decimalSteps=[0.0001,0.0002,0.0005,0.001,0.002,0.0025,0.005,0.01,0.02];
  for(const step of decimalSteps){
    for(let k=-4;k<=20;k++){
      const top=step*k,bottom=top-step*(n-1);
      if(top>.10||bottom<0)continue;
      out.push({family:'decimal',step,top,countHint:n});
    }
  }
  const compactSteps=[0.1,0.2,0.5,1,2,2.5,5];
  for(const step of compactSteps){
    for(let k=-4;k<=20;k++){
      const top=step*k,bottom=top-step*(n-1);
      if(top>30||bottom<0)continue;
      out.push({family:'compact',step,top,countHint:n});
    }
  }
  return out;
}
function modelPrior(m){
  // Energy per Band values are non-negative in the supplied workflows.
  const bottom=m.top-m.step*((m.countHint||8)-1);
  if(bottom<0)return -8.0;
  if(m.family==='compact') return 0;
  if(m.family==='decimal') return 0;
  return 0;
}
function solveYAxis(plot){
  const obs=plot.h.map(y=>observedLabelMask(plot,y)),
        usable=obs.filter(Boolean).length,
        shapeHint=inferAxisFamily(plot),
        textHint=inferAxisTextFamily(plot),
        familyHint=textHint.family!=='unknown'?textHint:shapeHint;

  if(usable<1 && familyHint.family==='unknown')
    throw Error('Y-axis labels are not usable after plot-local enhancement.');

  let ranked=[];
  for(const m of axisModels(plot.h.length)){
    let score=modelPrior(m),support=0,rowScores=[];
    if(familyHint.family!=='unknown'){
      const weight=familyHint===textHint?12.0:8.0;
      if(m.family===familyHint.family)score+=weight*familyHint.confidence;
      else score-=weight*familyHint.confidence*1.6;
    }
    for(let i=0;i<plot.h.length;i++){
      if(!obs[i]){rowScores.push(0);continue}
      const value=m.top-m.step*i,text=fmtAxis(value,m.family),
            sc=translatedScore(obs[i],textTemplate(text));
      rowScores.push(sc);
      score+=sc*5;
      if(sc>.125)support++;
    }

    // Whole-lattice support: two accidental rows are not enough when more are visible.
    score+=support*1.8;
    if(support<1)score-=18; else if(support<2)score-=(familyHint.confidence>=.65?3.5:8);
    if(plot.h.length>=4&&support<2)score-=2;

    // Aspect-family evidence is naturally contained in aspect-preserving masks.
    // Add an explicit top-vs-second discrimination term after ranking.
    ranked.push({...m,score,support,rowScores});
  }
  ranked.sort((a,b)=>b.score-a.score);
  const best=ranked[0];
  if(!best)throw Error('Y-axis numeric lattice could not be resolved.');
  if(best.support<1)
    throw Error('Y-axis numeric labels could not be matched to the visible grid.');
  if(plot.h.length>=2 && best.support<2)
    throw Error('Y-axis calibration requires two numeric-label matches.');

  const sameFamily=ranked.filter(q=>q.family===best.family),
        secondSame=sameFamily[1],
        familyMargin=best.score-(secondSame?.score??-Infinity),
        globalSecond=ranked[1],
        globalMargin=best.score-(globalSecond?.score??-Infinity);

  // Strong geometric family evidence means "3.0" must not be rejected merely because
  // a stretched decimal template also scores similarly.
  const requiredMargin=(familyHint.family===best.family&&familyHint.confidence>=.60)?0.025:.22;
  if(familyMargin<requiredMargin && best.support<2)
    throw Error('Y-axis scale remains ambiguous after family/grid fusion.');

  if(best.family==='decimal'&&best.step<=0.0005&&familyMargin<.55&&best.support<2)
    throw Error('Tiny decimal Y-axis lacks enough digit evidence.');

  const slope=-best.step/plot.hStep,
        intercept=best.top-slope*plot.h[0],
        values=plot.h.map((y,i)=>best.top-best.step*i);
  return {
    family:best.family,step:best.step,top:best.top,
    slope,intercept,values,
    score:best.score,margin:familyMargin,globalMargin,
    support:best.support,rowScores:best.rowScores,
    familyHint,textHint,shapeHint
  };
}

/* ------------------------------------------------------------------
   STAGE 3 — trace extraction strictly INSIDE the selected Energy plot
   ------------------------------------------------------------------ */


function isNearKnownGrid(plot,x,y){
  const ht=Math.max(1.2,plot.hStep*.035),
        vt=Math.max(1.2,plot.vStep*.030);
  for(const gy of plot.h)if(Math.abs(y-gy)<=ht)return true;
  for(const gx of plot.v)if(Math.abs(x-gx)<=vt)return true;
  return false;
}
function hasTraceThickness(x,y,fm){
  const d=pixels().data;
  let c=0,n=0;
  for(let dy=-3;dy<=3;dy++)for(let dx=-2;dx<=2;dx++){
    if(!dx&&!dy)continue;
    const X=clamp(x+dx,0,workCanvas.width-1),Y=clamp(y+dy,0,workCanvas.height-1),
          i=idx(X,Y),st=stats(d[i],d[i+1],d[i+2]);
    n++;
    if(fm.mode==='white'){
      if(st.sat<.22&&st.lum>125)c++;
    }else if(st.sat>.10&&st.lum>35&&hueDist(st.h,fm.hue)<38)c++;
  }
  return c>=Math.max(3,Math.round(n*.10));
}
function foregroundModel(plot){
  const d=pixels().data,bins=new Array(72).fill(0);
  let colored=0,white=0;
  const xs=Math.max(1,Math.round((plot.right-plot.left)/260)),
        ys=Math.max(1,Math.round((plot.bottom-plot.top)/160));
  for(let y=Math.round(plot.top+3);y<=plot.bottom-3;y+=ys)
    for(let x=Math.round(plot.left+3);x<=plot.right-3;x+=xs){
      const i=idx(x,y),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
      if(isNearKnownGrid(plot,x,y))continue;
      if(st.sat>.20&&st.lum>42){
        bins[Math.floor(st.h/5)%72]++;colored++;
      }else if(st.sat<.17&&st.lum>145)white++;
    }
  let bi=0;for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  const hue=bi*5+2.5;
  return {mode:white>colored*.65?'white':'color',hue,colored,white};
}
function isWhitePoint(x,y){
  const d=pixels().data,i=idx(x,y),st=stats(d[i],d[i+1],d[i+2]);
  if(!(st.sat<.20&&st.lum>145))return false;
  // Reject interiors of large white tooltip rectangles: trace squares have dark neighborhood.
  let dark=0,n=0;
  for(let dy=-2;dy<=2;dy+=2)for(let dx=-2;dx<=2;dx+=2){
    const X=clamp(x+dx,0,workCanvas.width-1),Y=clamp(y+dy,0,workCanvas.height-1),
          j=idx(X,Y),q=stats(d[j],d[j+1],d[j+2]);
    n++;if(q.lum<100)dark++;
  }
  return dark/n>.20;
}
function isTracePixel(plot,x,y,fm){
  const d=pixels().data,i=idx(x,y),r=d[i],g=d[i+1],b=d[i+2],st=stats(r,g,b);
  if(st.lum<32)return false;
  const onGrid=isNearKnownGrid(plot,x,y);
  if(fm.mode==='white'){
    if(!isWhitePoint(x,y))return false;
    return !onGrid||hasTraceThickness(x,y,fm);
  }
  const match=st.sat>.10&&st.lum>36&&hueDist(st.h,fm.hue)<36;
  if(!match)return false;
  // A trace may legitimately sit on a horizontal grid. Reject only a thin,
  // isolated grid-like pixel; retain locally thick/variable foreground.
  return !onGrid||hasTraceThickness(x,y,fm);
}
function traceByColumns(plot){
  const fm=foregroundModel(plot),
        span=plot.right-plot.left,
        bins=Math.max(120,Math.min(420,Math.round(span/2))),
        out=[];
  for(let bi=0;bi<bins;bi++){
    const xa=Math.round(plot.left+bi/bins*span),
          xb=Math.max(xa,Math.round(plot.left+(bi+1)/bins*span)-1),
          ys=[];
    for(let x=xa;x<=xb;x++)for(let y=Math.round(plot.top+2);y<=plot.bottom-2;y++){
      if(isTracePixel(plot,x,y,fm))ys.push(y);
    }
    if(!ys.length)continue;
    ys.sort((a,b)=>a-b);

    // Cluster vertically. Pick the densest compact cluster; tooltip/background blocks are broad.
    let clusters=[],cur=[ys[0]],gap=Math.max(2,Math.round(plot.hStep*.12));
    for(let i=1;i<ys.length;i++){
      if(ys[i]-ys[i-1]<=gap)cur.push(ys[i]);
      else{clusters.push(cur);cur=[ys[i]]}
    }
    clusters.push(cur);
    clusters.sort((a,b)=>b.length-a.length || (a.at(-1)-a[0])-(b.at(-1)-b[0]));
    const c=clusters[0];
    out.push({x:(xa+xb)/2,y:median(c),support:c.length});
  }
  if(out.length<12)throw Error('Foreground trace could not be isolated inside Energy plot.');
  return {fm,points:out};
}
function xValue(plot,x){return 500*(x-plot.left)/Math.max(1,plot.right-plot.left)}
function yValue(scale,y){return scale.slope*y+scale.intercept}


function makeYTransform(plot,scale){
  const ps=makePlotSpace(plot);
  const pixelToValue=y=>scale.slope*y+scale.intercept;
  const valueToPixel=v=>(v-scale.intercept)/scale.slope;
  const t={
    pixelToValue,
    valueToPixel,
    containsPixel:y=>y>=ps.top-1&&y<=ps.bottom+1,
    containsValue:v=>{
      const y=valueToPixel(v);
      return y>=ps.top-1&&y<=ps.bottom+1;
    },
    plotSpace:ps
  };

  // Verify transform is actually invertible at every visible horizontal grid.
  for(let i=0;i<plot.h.length;i++){
    const y=plot.h[i],v=scale.values[i],
          yy=valueToPixel(v),
          vv=pixelToValue(y);
    if(Math.abs(yy-y)>Math.max(1.5,plot.hStep*.08))
      throw Error('Y transform failed inverse-grid validation.');
    if(Math.abs(vv-v)>Math.max(Math.abs(scale.step)*.08,1e-8))
      throw Error('Y transform failed forward-grid validation.');
  }
  return t;
}
function robustRangeMean(plot,transform,trace,a,b){
  const ps=transform.plotSpace;
  let pts=trace.points.filter(p=>{
    const x=xValue(plot,p.x);
    return x>=a&&x<=b&&ps.contains(p.x,p.y,0);
  });
  if(pts.length<2)throw Error(`Not enough plot-local trace samples in ${a===0?'Low':'High'} range.`);
  let vals=pts.map(p=>transform.pixelToValue(p.y)),
      m=median(vals),M=mad(vals)||Math.max(Math.abs((transform.pixelToValue(plot.h[0])-transform.pixelToValue(plot.h[1])))*.03,1e-9),
      lim=Math.max(M*4,Math.abs(transform.pixelToValue(plot.h[0])-transform.pixelToValue(plot.h[1]))*.35),
      keep=vals.filter(v=>Math.abs(v-m)<=lim);
  if(keep.length<2){
    keep=vals.filter(v=>Math.abs(v-m)<=Math.max(M*7,Math.abs(transform.pixelToValue(plot.h[0])-transform.pixelToValue(plot.h[1]))*.65));
  }
  if(keep.length<2)throw Error(`Trace is unstable in ${a===0?'Low':'High'} range.`);
  return {mean:mean(keep),count:keep.length,median:m};
}

/* ------------------------------------------------------------------
   STAGE 4 — one authoritative calibration/trace consistency gate
   ------------------------------------------------------------------ */

function validateResult(plot,scale,transform,low,high,trace){
  const axisMin=Math.min(...scale.values),axisMax=Math.max(...scale.values),
        tol=Math.abs(scale.step)*.25,
        ps=transform.plotSpace;

  for(const [name,obj] of [['Low',low],['High',high]]){
    if(!Number.isFinite(obj.mean))throw Error(`${name} is not finite.`);
    if(obj.mean<axisMin-tol||obj.mean>axisMax+tol)
      throw Error(`${name} contradicts visible Y-axis range.`);
    const y=transform.valueToPixel(obj.mean);
    if(!ps.contains((ps.left+ps.right)/2,y,2))
      throw Error(`${name} overlay falls outside Energy plot.`);
    const roundTrip=transform.pixelToValue(y);
    if(Math.abs(roundTrip-obj.mean)>Math.max(Math.abs(scale.step)*.02,1e-8))
      throw Error(`${name} pixel/value round-trip is inconsistent.`);
  }

  const escaped=trace.points.filter(p=>!ps.contains(p.x,p.y,0)).length;
  if(escaped>0)
    throw Error('Trace escaped Energy plot coordinate system.');

  // Trace medians and reported means must occupy plausible plot-local rows.
  const visibleRange=Math.max(1e-9,axisMax-axisMin);
  if(Math.abs(low.mean-low.median)>visibleRange*.45)
    throw Error('Low mean is inconsistent with its trace median.');
  if(Math.abs(high.mean-high.median)>visibleRange*.45)
    throw Error('High mean is inconsistent with its trace median.');
}

function decimalsFor(scale){
  if(scale.family==='compact')return 2;
  return 4;
}
function drawResult(plot,scale,transform,low,high){
  resultCanvas.width=canvas.width;resultCanvas.height=canvas.height;
  rctx.clearRect(0,0,resultCanvas.width,resultCanvas.height);
  rctx.drawImage(canvas,0,0);

  // Work canvas and preview canvas can differ. Convert explicitly.
  const sx=canvas.width/workCanvas.width,
        sy=canvas.height/workCanvas.height,
        pL=plot.left*sx,
        pR=plot.right*sx,
        ly=transform.valueToPixel(low.mean)*sy,
        hy=transform.valueToPixel(high.mean)*sy,
        dec=decimalsFor(scale);

  rctx.save();
  rctx.beginPath();
  rctx.rect(plot.left*sx,plot.top*sy,
            (plot.right-plot.left)*sx,
            (plot.bottom-plot.top)*sy);
  rctx.clip();

  rctx.strokeStyle='#26d7ff';
  rctx.fillStyle='#26d7ff';
  rctx.lineWidth=Math.max(2,resultCanvas.width/700);
  rctx.font=`${Math.max(18,resultCanvas.width/38)}px Arial`;

  rctx.beginPath();
  rctx.moveTo(pL,ly);
  rctx.lineTo(pL+(pR-pL)*.52,ly);
  rctx.stroke();
  rctx.fillText(`Low ${low.mean.toFixed(dec)}`,pL+8,Math.max(plot.top*sy+22,ly-8));

  rctx.beginPath();
  rctx.moveTo(pL+(pR-pL)*.54,hy);
  rctx.lineTo(pR,hy);
  rctx.stroke();
  rctx.fillText(`High ${high.mean.toFixed(dec)}`,pL+(pR-pL)*.56,Math.max(plot.top*sy+22,hy-8));
  rctx.restore();
}

async function analyze(){
  if(!ready)return;
  const t0=performance.now();
  $('analyzeBtn').disabled=true;
  clearResult();
  try{
    setProgress(8,'Prepare','Building one authoritative analysis image');
    await new Promise(r=>setTimeout(r,0));
    prepareWork();

    setProgress(24,'Energy plot','Separating upper Energy per Band plot from Raw Data');
    await new Promise(r=>setTimeout(r,0));
    const plot=locateEnergyPlot();

    setProgress(46,'Y-axis','Solving one aspect-preserving numeric lattice');
    await new Promise(r=>setTimeout(r,0));
    const scale=solveYAxis(plot);
    const transform=makeYTransform(plot,scale);

    setProgress(66,'Trace','Extracting trace only inside the Energy plot');
    await new Promise(r=>setTimeout(r,0));
    const trace=traceByColumns(plot);

    setProgress(82,'Low / High','Computing robust Low 0–260 / High 270–500 means');
    await new Promise(r=>setTimeout(r,0));
    const low=robustRangeMean(plot,transform,trace,0,260),
          high=robustRangeMean(plot,transform,trace,270,500);

    setProgress(92,'Validation','Cross-checking one plot-local coordinate/value transform');
    validateResult(plot,scale,transform,low,high,trace);

    const dec=decimalsFor(scale);
    $('lowValue').textContent=low.mean.toFixed(dec);
    $('highValue').textContent=high.mean.toFixed(dec);
    drawResult(plot,scale,transform,low,high);

    $('detail').textContent=
      `Unified Core v14; source ${sourceWidth}×${sourceHeight}; work ${workCanvas.width}×${workCanvas.height}; `+
      `Energy plot ${Math.round(plot.right-plot.left)}×${Math.round(plot.bottom-plot.top)} (${plot.confidence||'unknown'}); `+
      `Y ${scale.family}; step ${Number(scale.step.toPrecision(6))}; grid ${scale.values.map(v=>fmtAxis(v,scale.family)).join(' / ')}; `+
      `family ${scale.family}; text hint ${scale.textHint.family}/${scale.textHint.reason}; model margin ${scale.margin.toFixed(2)}; support ${scale.support}; `+
      `trace ${trace.fm.mode}; Low n=${low.count}; High n=${high.count}; X 0–500.`;

    $('resultCard').classList.remove('hidden');
    setProgress(100,'Complete',`Total ${((performance.now()-t0)/1000).toFixed(1)}s`);
    $('status').textContent='Analysis complete';
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{$('resultCard').scrollIntoView({behavior:'smooth',block:'start'})}
    catch(_){$('resultCard').scrollIntoView()}
  }catch(e){
    const msg=e?.message||String(e);
    $('status').textContent=msg;
    setProgress(100,'Needs attention',msg);
    await new Promise(r=>requestAnimationFrame(()=>r()));
    try{$('progressCard').scrollIntoView({behavior:'smooth',block:'center'})}catch(_){}
  }finally{
    releasePixels();
    $('analyzeBtn').disabled=false;
  }
}

$('cameraBtn').onclick=()=>{$('fileCamera').value='';$('fileCamera').click()};
$('libraryBtn').onclick=()=>{$('fileLibrary').value='';$('fileLibrary').click()};
$('fileCamera').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(f)await loadFile(f,true)};
$('fileLibrary').onchange=async e=>{const f=e.target.files&&e.target.files[0];if(f)await loadFile(f,true)};
$('resetBtn').onclick=reset;
$('analyzeBtn').onclick=analyze;
reset();

// Keep Pages deterministic while numeric validation is active.
(async()=>{
  try{
    if('serviceWorker' in navigator){
      const regs=await navigator.serviceWorker.getRegistrations();
      for(const r of regs)if(r.scope.includes('/Module/spectrumreader/'))await r.unregister();
    }
    if('caches' in window){
      const ks=await caches.keys();
      for(const k of ks)if(k.startsWith('energy-graph'))await caches.delete(k);
    }
  }catch(_){}
})();
