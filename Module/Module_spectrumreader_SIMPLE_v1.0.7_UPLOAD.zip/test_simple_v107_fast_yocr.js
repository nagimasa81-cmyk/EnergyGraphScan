
const fs=require('fs'),a=fs.readFileSync('app.v1.0.7.js','utf8'),h=fs.readFileSync('index.html','utf8');
function ok(v,m){if(!v)throw Error(m)}
ok(a.includes('function axisLabelGlyphs('),'glyph segmentation missing');
ok(a.includes('function classifyGlyph('),'glyph classifier missing');
ok(a.includes("source:'fast-glyph-grid-affine-v1.0.7'"),'fast affine source missing');
ok(!a.includes('Y_LABELS=yLabelCandidates()'),'exhaustive full-number list still present');
ok(a.includes("Y-axis 1/2"),'Y progress missing');
ok(a.includes("const scale=chooseYScale(plot,trace);"),'scale call missing');
ok(h.includes('v1.0.7 Simple · build 1800'),'build stamp missing');
console.log('Simple v1.0.7 fast Y-OCR regression PASS');
