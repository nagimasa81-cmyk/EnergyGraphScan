// Simple v1.0.7 compatibility entry

const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
const resultCanvas=$('resultCanvas'),rctx=resultCanvas.getContext('2d');

let ready=false;
const workCanvas=document.createElement('canvas'),
      workCtx=workCanvas.getContext('2d',{willReadFrequently:true});
let analysisScale=1;

function prepareWorkingImage(){
  const maxSide=800,
        sw=canvas.width,sh=canvas.height,
        scale=Math.min(1,maxSide/Math.max(sw,sh));
  analysisScale=scale;
  workCanvas.width=Math.max(1,Math.round(sw*scale));
  workCanvas.height=Math.max(1,Math.round(sh*scale));
  workCtx.clearRect(0,0,workCanvas.width,workCanvas.height);
  workCtx.drawImage(canvas,0,0,workCanvas.width,workCanvas.height);
  return {canvas:workCanvas,ctx:workCtx,scale};
}
function toOriginalX(x){return x/analysisScale}
function toOriginalY(y){return y/analysisScale}


function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function median(a){if(!a.length)return NaN;const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}
function mean(a){return a.length?a.reduce((s,v)=>s+v,0)/a.length:NaN}
function mad(a){const m=median(a);return median(a.map(v=>Math.abs(v-m)))}
function setProgress(p,label,detail=''){
  $('progressCard').classList.remove('hidden'); $('progressPct').textContent=`${p}%`; $('barFill').style.width=`${p}%`;
  $('progressLabel').textContent=label; $('progressDetail').textContent=detail;
}
function clearResult(){
  $('resultCard').classList.add('hidden');$('lowValue').textContent='—';$('highValue').textContent='—';$('detail').textContent='';
  resultCanvas.width=1;resultCanvas.height=1;
}
function reset(){
  ready=false;canvas.width=1;canvas.height=1;canvas.style.display='none';$('.placeholder');
  document.querySelector('.placeholder').style.display='block';
  $('analyzeBtn').disabled=true;$('status').textContent='Ready';$('progressCard').classList.add('hidden');clearResult();
}
async function loadFile(file){
  clearResult(); $('progressCard').classList.add('hidden'); $('status').textContent='Loading full-resolution image…';
  const bmp=await createImageBitmap(file);
  canvas.width=bmp.width;canvas.height=bmp.height;ctx.drawImage(bmp,0,0);
  canvas.style.display='block';document.querySelector('.placeholder').style.display='none';
  ready=true;$('analyzeBtn').disabled=false;$('status').textContent=`Ready — ${bmp.width}×${bmp.height}px`;
}
$('cameraBtn').onclick=()=>$('fileCamera').click();
$('libraryBtn').onclick=()=>$('fileLibrary').click();
$('fileCamera').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('fileLibrary').onchange=e=>e.target.files[0]&&loadFile(e.target.files[0]);
$('resetBtn').onclick=reset;

function rgb2hue(r,g,b){
  r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;if(!d)return 0;let h;
  if(mx===r)h=60*(((g-b)/d)%6);else if(mx===g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);
  return(h+360)%360;
}
function isGreen(r,g,b){return g>55&&g>r*1.12&&g>b*1.12}
function preprocess(){
  const im=workCtx.getImageData(0,0,workCanvas.width,workCanvas.height),d=im.data,l=[];
  for(let i=0;i<d.length;i+=4)l.push(.299*d[i]+.587*d[i+1]+.114*d[i+2]);
  l.sort((a,b)=>a-b);const q=x=>l[Math.floor((l.length-1)*x)],lo=q(.04),hi=q(.98),span=Math.max(20,hi-lo);
  return {im,lo,hi,span};
}
function lineScores(axis){
  const {width:W,height:H}=workCanvas,im=workCtx.getImageData(0,0,W,H).data;
  const N=axis==='h'?H:W,scores=new Array(N).fill(0);
  for(let p=0;p<N;p++){
    let green=0,dark=0,n=0;
    const M=axis==='h'?W:H;
    for(let k=0;k<M;k+=Math.max(1,Math.floor(M/700))){
      const x=axis==='h'?k:p,y=axis==='h'?p:k,i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],lum=(r+g+b)/3;
      n++; if(isGreen(r,g,b))green++; if(lum<100)dark++;
    }
    scores[p]=green/n*.8+dark/n*.2;
  }
  return scores;
}
function peaks(scores,minGap){
  const cand=[];for(let i=2;i<scores.length-2;i++)if(scores[i]>scores[i-1]&&scores[i]>=scores[i+1])cand.push({i,s:scores[i]});
  cand.sort((a,b)=>b.s-a.s);const out=[];
  for(const c of cand){if(out.every(x=>Math.abs(x-c.i)>minGap))out.push(c.i);if(out.length>=18)break}
  return out.sort((a,b)=>a-b);
}
function detectPlot(){
  const hp=peaks(lineScores('h'),Math.max(4,workCanvas.height*.03));
  const vp=peaks(lineScores('v'),Math.max(5,workCanvas.width*.035));
  if(hp.length<3||vp.length<4) throw Error('Grid detection failed. Include the full black graph.');
  // choose densest regularly spaced runs
  function regular(arr){
    let best=null;
    for(let i=0;i<arr.length;i++)for(let j=i+2;j<arr.length;j++){
      const sub=arr.slice(i,j+1),ds=sub.slice(1).map((v,k)=>v-sub[k]),m=median(ds),e=median(ds.map(x=>Math.abs(x-m)));
      const score=sub.length/(1+e/Math.max(1,m));
      if(!best||score>best.score)best={arr:sub,step:m,score};
    } return best;
  }
  const H=regular(hp),V=regular(vp); if(!H||!V) throw Error('Grid lattice unresolved.');
  return {left:V.arr[0],right:V.arr.at(-1),top:H.arr[0],bottom:H.arr.at(-1),h:H.arr,v:V.arr};
}
function estimateY(plot){
  // Infer numeric step primarily from green horizontal-grid spacing + image label morphology.
  // For simple version support the two families actually used in these graphs:
  // Gain usually step 1; Noise commonly .005 or .01.
  const stepPx=median(plot.h.slice(1).map((y,i)=>y-plot.h[i]));
  const W=canvas.width,im=ctx.getImageData(0,0,W,canvas.height).data;
  // Find decimal-label ink/green activity left of y-axis.
  const lx0=Math.max(0,plot.left-Math.round((plot.right-plot.left)*.25)),lx1=plot.left;
  let tiny=0,total=0;
  for(let y=plot.top;y<=plot.bottom;y++)for(let x=lx0;x<lx1;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2]; if(isGreen(r,g,b)){total++; if(g<190)tiny++}
  }
  // Use plot height/trace location as family-independent scale candidate set.
  // We score candidates using visible horizontal grid count and trace plausibility.
  const candidates=[1,.5,.02,.01,.005,.001];
  return {stepPx,candidates};
}

async function traceHue(plot,onProgress){
  const W=workCanvas.width,H=workCanvas.height,
        im=workCtx.getImageData(0,0,W,H).data,
        bins=new Array(36).fill(0),
        xStep=Math.max(2,Math.round((plot.right-plot.left)/220)),
        yStep=Math.max(2,Math.round((plot.bottom-plot.top)/140)),
        total=Math.max(1,Math.ceil((plot.right-plot.left+1)/xStep)),
        yieldEvery=28;
  let xi=0;
  for(let x=plot.left;x<=plot.right;x+=xStep){
    for(let y=plot.top;y<=plot.bottom;y+=yStep){
      const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
            mx=Math.max(r,g,b),mn=Math.min(r,g,b),
            sat=(mx-mn)/Math.max(1,mx),lum=(r+g+b)/3;
      if(sat>.20&&lum>55&&!isGreen(r,g,b))
        bins[Math.floor(rgb2hue(r,g,b)/10)]++;
    }
    xi++;
    if(xi%yieldEvery===0){
      if(onProgress)onProgress(xi/total);
      await new Promise(r=>setTimeout(r,0));
    }
  }
  let bi=0;
  for(let i=1;i<bins.length;i++)if(bins[i]>bins[bi])bi=i;
  if(onProgress)onProgress(1);
  return bi*10+5;
}

function hueDist(a,b){let d=Math.abs(a-b)%360;return Math.min(d,360-d)}


const glyphTemplateCache=new Map();

function normGlyph(points,tw=24,th=32){
  if(!points||points.length<2)return null;
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
  for(const p of points){minx=Math.min(minx,p[0]);miny=Math.min(miny,p[1]);maxx=Math.max(maxx,p[0]);maxy=Math.max(maxy,p[1])}
  const w=Math.max(1,maxx-minx+1),h=Math.max(1,maxy-miny+1),
        sc=Math.min((tw-4)/w,(th-4)/h),
        nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc)),
        ox=Math.floor((tw-nw)/2),oy=Math.floor((th-nh)/2),
        arr=new Uint8Array(tw*th);
  for(const p of points){
    const x=ox+Math.min(nw-1,Math.max(0,Math.round((p[0]-minx)*sc))),
          y=oy+Math.min(nh-1,Math.max(0,Math.round((p[1]-miny)*sc)));
    arr[y*tw+x]=1;
  }
  arr._w=w;arr._h=h;arr._aspect=w/Math.max(1,h);
  return arr;
}

function glyphTemplate(ch,font='Arial',size=28){
  const key=`${ch}|${font}|${size}`;
  if(glyphTemplateCache.has(key))return glyphTemplateCache.get(key);
  const c=document.createElement('canvas');c.width=46;c.height=48;
  const q=c.getContext('2d');
  q.fillStyle='#000';q.fillRect(0,0,c.width,c.height);
  q.fillStyle='#fff';q.font=`${size}px ${font}`;q.textBaseline='top';q.fillText(ch,4,2);
  const im=q.getImageData(0,0,c.width,c.height).data,pts=[];
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
    const i=(y*c.width+x)*4;if(im[i]>80)pts.push([x,y]);
  }
  const n=normGlyph(pts);glyphTemplateCache.set(key,n);return n;
}

function glyphIoU(a,b){
  if(!a||!b)return 0;
  const tw=24,th=32;
  let best=0;
  for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){
    let inter=0,uni=0;
    for(let y=0;y<th;y++)for(let x=0;x<tw;x++){
      const A=a[y*tw+x],xx=x-dx,yy=y-dy,
            B=(xx>=0&&xx<tw&&yy>=0&&yy<th)?b[yy*tw+xx]:0;
      if(A&&B)inter++;if(A||B)uni++;
    }
    if(uni)best=Math.max(best,inter/uni);
  }
  const arA=Math.max(.05,a._aspect||1),arB=Math.max(.05,b._aspect||1),
        ar=Math.exp(-Math.abs(Math.log(arA/arB))*1.2);
  return .82*best+.18*ar;
}

function axisLabelGlyphs(plot,rowY,rowStep){
  const x1=Math.max(2,Math.floor(plot.left-3)),
        span=Math.max(54,Math.min(120,Math.round((plot.right-plot.left)*.23))),
        x0=Math.max(0,x1-span),
        half=Math.max(7,Math.round(rowStep*.34)),
        y0=Math.max(0,Math.round(rowY-half)),
        y1=Math.min(workCanvas.height-1,Math.round(rowY+half)),
        W=Math.max(1,x1-x0),H=Math.max(1,y1-y0),
        im=workCtx.getImageData(x0,y0,W,H).data,
        mask=new Uint8Array(W*H),col=new Uint16Array(W);

  for(let y=0;y<H;y++)for(let x=0;x<W;x++){
    const i=(y*W+x)*4,r=im[i],g=im[i+1],b=im[i+2],
          mx=Math.max(r,g,b),mn=Math.min(r,g,b),lum=(r+g+b)/3,
          greenish=g>45&&g>=r*.95&&g>=b*.90&&(g-Math.min(r,b)>3),
          bright=lum>125&&(mx-mn)<95;
    if(greenish||bright){mask[y*W+x]=1;col[x]++}
  }

  const runs=[];let st=-1,last=-99;
  for(let x=0;x<W;x++){
    if(col[x]>0){
      if(st<0)st=x;
      last=x;
    }else if(st>=0&&x-last>1){
      runs.push([st,last]);st=-1;
    }
  }
  if(st>=0)runs.push([st,last]);

  const glyphs=[];
  for(const [a,b] of runs){
    const pts=[];
    for(let y=0;y<H;y++)for(let x=a;x<=b;x++)if(mask[y*W+x])pts.push([x-a,y]);
    if(pts.length<2)continue;
    const n=normGlyph(pts);
    if(!n)continue;
    glyphs.push({norm:n,x0:a,x1:b,w:b-a+1,h:n._h});
  }
  return glyphs;
}

function classifyGlyph(g){
  const a=g.norm;
  if(a._h<=5 && a._w<=7)return [{ch:'.',score:.98}];
  if(a._h<=6 && a._w>=6)return [{ch:'-',score:.92},{ch:'.',score:.25}];

  const out=[];
  for(const ch of '0123456789'){
    let best=0;
    for(const font of ['Arial','Verdana','Tahoma'])
      for(const size of [24,28,32])
        best=Math.max(best,glyphIoU(a,glyphTemplate(ch,font,size)));
    out.push({ch,score:best});
  }
  out.sort((x,y)=>y.score-x.score);
  return out.slice(0,3);
}

function numericHypothesesForRow(plot,rowY,rowStep){
  const glyphs=axisLabelGlyphs(plot,rowY,rowStep);
  if(glyphs.length<2||glyphs.length>10)return [];
  let beam=[{text:'',score:0}];
  for(const g of glyphs){
    const opts=classifyGlyph(g),next=[];
    for(const b of beam)for(const o of opts)
      next.push({text:b.text+o.ch,score:b.score+Math.log(Math.max(.03,o.score))});
    next.sort((a,b)=>b.score-a.score);
    beam=next.slice(0,18);
  }

  const out=[];
  for(const b of beam){
    const t=b.text.replace(/^\.+/,'').replace(/\.+$/,'');
    if(!/^-?\d+(?:\.\d+)?$/.test(t))continue;
    const value=Number(t);
    if(!Number.isFinite(value))continue;
    out.push({text:t,value,conf:Math.exp(b.score/Math.max(1,glyphs.length))});
  }
  out.sort((a,b)=>b.conf-a.conf);
  const uniq=[];
  for(const q of out){
    if(uniq.some(u=>Math.abs(u.value-q.value)<Math.max(1e-6,Math.abs(q.value)*.002)))continue;
    uniq.push(q);if(uniq.length>=6)break;
  }
  return uniq;
}

function recognizeYRowsFast(plot){
  const ys=[...plot.h].sort((a,b)=>a-b),
        stepPx=median(ys.slice(1).map((y,i)=>y-ys[i])),
        rows=[];
  for(const y of ys){
    const hyps=numericHypothesesForRow(plot,y,stepPx);
    if(hyps.length)rows.push({y,hyps});
  }
  return {rows,stepPx};
}

function fitYAxisFromVisibleNumbers(plot){
  const R=recognizeYRowsFast(plot),rows=R.rows;
  if(rows.length<2)throw Error('Y-axis: fewer than two numeric labels were read.');

  let best=null;
  for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){
    const A=rows[i],B=rows[j],dy=B.y-A.y;
    if(dy<4)continue;
    for(const ha of A.hyps)for(const hb of B.hyps){
      const slope=(hb.value-ha.value)/dy;
      if(!Number.isFinite(slope)||slope>=0)continue;
      const intercept=ha.value-slope*A.y,
            step=Math.abs(slope*R.stepPx);
      if(step<1e-6||step>20)continue;

      let support=0,score=0,used=[];
      for(const row of rows){
        const pred=slope*row.y+intercept;
        let qbest=null;
        for(const h of row.hyps){
          const err=Math.abs(h.value-pred)/Math.max(step,1e-9);
          const q={...h,err};
          if(!qbest||q.err<qbest.err)qbest=q;
        }
        if(qbest&&qbest.err<.18){
          support++;score+=3+(qbest.conf||0)*2-qbest.err*2;
          used.push({y:row.y,value:qbest.value,text:qbest.text,conf:qbest.conf});
        }
      }
      const common=[5,2,1,.5,.2,.1,.05,.02,.01,.005,.002,.001,.0005,.0002,.0001];
      const near=Math.min(...common.map(v=>Math.abs(Math.log(step/v))));
      score-=near*.35;
      if(!best||score>best.score)best={slope,intercept,step,support,score,used};
    }
  }

  if(!best||best.support<2)
    throw Error('Y-axis numeric labels do not form a consistent grid scale.');

  return {...best,source:'fast-glyph-grid-affine-v1.0.7'};
}

function chooseYScale(plot,trace){
  const fit=fitYAxisFromVisibleNumbers(plot);
  return {slope:fit.slope,intercept:fit.intercept,step:fit.step,
          support:fit.support,anchors:fit.used,source:'global-grid-numeric-sequence-v1.0.7'};
}

function xToSample(plot,x){return 500*(x-plot.left)/(plot.right-plot.left)}
function yToValue(plot,scale,y){return scale.slope*y+scale.intercept}
function robustMean(vals){
  if(!vals.length)return NaN;const m=median(vals),M=mad(vals)||1e-9,kept=vals.filter(v=>Math.abs(v-m)<=Math.max(M*3,Math.abs(m)*.12+1e-6));
  return mean(kept);
}
async function analyze(){
  const t0=performance.now();

  if(!ready)return;clearResult();
  try{
    setProgress(8,'Processing…','Preparing high-resolution working image');await new Promise(r=>setTimeout(r,0));
    const wk=prepareWorkingImage();
    setProgress(15,'Processing…',`Analysis working image ${wk.canvas.width}×${wk.canvas.height}; original ${canvas.width}×${canvas.height}`);await new Promise(r=>setTimeout(r,0));
    preprocess();
    setProgress(32,'Grid','Detecting plot geometry');const plot=detectPlot();await new Promise(r=>setTimeout(r,0));
    setProgress(42,'Trace 1/5','Preparing trace detector');await new Promise(r=>setTimeout(r,0));
    const trace=await extractTrace(plot,(phase,p)=>{
      if(phase==='hue')setProgress(44+Math.round(p*8),'Trace 2/5','Coarse foreground-color search');
      else if(phase==='scan')setProgress(52+Math.round(p*10),'Trace 3/5','One-pass trace binning');
      else if(phase==='filter')setProgress(62+Math.round(p*3),'Trace 4/5','Spike/noise rejection');
    });
    setProgress(66,'Trace 5/5',`Trace ready — ${trace.pts.length} columns`);await new Promise(r=>setTimeout(r,0));
    setProgress(70,'Y-axis 1/2','Reading numeric labels');await new Promise(r=>setTimeout(r,0));
    const scale=chooseYScale(plot,trace);
    setProgress(80,'Y-axis 2/2',`Scale ready — step ${Number(scale.step.toPrecision(6))}, anchors ${scale.support}`);await new Promise(r=>setTimeout(r,0));
    setProgress(86,'Low / High','Computing robust means with spike rejection');

    const lowVals=[],highVals=[],lowPts=[],highPts=[];
    for(const p of trace.pts){
      const sx=xToSample(plot,p.x),v=yToValue(plot,scale,p.y);
      if(sx>=0&&sx<=260){lowVals.push(v);lowPts.push(p)}
      else if(sx>=270&&sx<=500){highVals.push(v);highPts.push(p)}
    }
    if(lowVals.length<5||highVals.length<5)throw Error('Low or High region has insufficient trace samples.');
    const low=robustMean(lowVals),high=robustMean(highVals);

    setProgress(95,'Rendering','Drawing Low/High mean lines');
    resultCanvas.width=canvas.width;resultCanvas.height=canvas.height;rctx.drawImage(canvas,0,0);
    rctx.lineWidth=Math.max(3,canvas.width/450);rctx.strokeStyle='#00d9ff';rctx.fillStyle='#00d9ff';rctx.font=`${Math.max(24,canvas.width/32)}px sans-serif`;
    const lowYw=(low-scale.intercept)/scale.slope,
          highYw=(high-scale.intercept)/scale.slope,
          pLeft=toOriginalX(plot.left),pRight=toOriginalX(plot.right),
          lowY=toOriginalY(lowYw),highY=toOriginalY(highYw);
    rctx.beginPath();rctx.moveTo(pLeft,lowY);rctx.lineTo(pLeft+(pRight-pLeft)*.52,lowY);rctx.stroke();
    rctx.fillText(`Low ${low.toFixed(scale.step<.1?4:2)}`,pLeft+10,lowY-10);
    rctx.beginPath();rctx.moveTo(pLeft+(pRight-pLeft)*.54,highY);rctx.lineTo(pRight,highY);rctx.stroke();
    rctx.fillText(`High ${high.toFixed(scale.step<.1?4:2)}`,pLeft+(pRight-pLeft)*.56,highY-10);

    $('lowValue').textContent=low.toFixed(scale.step<.1?4:2);
    $('highValue').textContent=high.toFixed(scale.step<.1?4:2);
    $('detail').textContent=`Y scale from visible numbers; grid step ${Number(scale.step.toPrecision(6))}; anchors ${scale.support}; Low samples ${lowVals.length}; High samples ${highVals.length}; X domain 0–500; split Low 0–260 / High 270–500. No bottom=0 assumption.`;
    const elapsed=((performance.now()-t0)/1000).toFixed(1);
    $('resultCard').classList.remove('hidden');setProgress(100,'Complete',`Total ${elapsed}s`);$('status').textContent=`Analysis complete — ${elapsed}s`;
  }catch(e){
    setProgress(100,'Needs attention',e.message);$('status').textContent=e.message;
  }
}
$('analyzeBtn').onclick=analyze;
reset();


// v1.0.7 deliberately runs without an application service worker.
// Remove stale v1.0.1/v1.0.2 workers/caches so GitHub Pages always serves current JS.
// Offline support will be re-enabled only after numeric validation is stable.
(async()=>{
  try{
    if('serviceWorker' in navigator){
      const regs=await navigator.serviceWorker.getRegistrations();
      for(const r of regs){
        if(r.scope.includes('/Module/spectrumreader/')) await r.unregister();
      }
    }
    if('caches' in window){
      const ks=await caches.keys();
      for(const k of ks)if(k.startsWith('energy-graph'))await caches.delete(k);
    }
  }catch(_){}
})();
