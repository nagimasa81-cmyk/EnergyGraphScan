const $=id=>document.getElementById(id); const canvas=$('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
let sourceImage=null,roi=null,roiManual=false,currentResult=null;
const els={stage:$('stage'),guide:$('guide'),roi:$('roi'),status:$('status'),mode:$('modeSelect'),result:$('resultCard'),camera:$('cameraInput'),photo:$('photoInput')};
$('guideToggle').addEventListener('change',e=>els.guide.classList.toggle('hidden',!e.target.checked));
$('resetBtn').onclick=reset;
$('autoDetectBtn').onclick=()=>{if(sourceImage){redrawSource();roi=detectGraph();roiManual=false;els.roi.classList.remove('manual');renderROI();setStatus('Auto ROI updated.');}};
$('manualBtn').onclick=()=>{if(!roi)return;roiManual=true;els.roi.classList.remove('hidden');els.roi.classList.add('manual');setStatus('ROI adjustment enabled. Drag inside to move; drag a corner to resize.');};
$('analyzeBtn').onclick=analyze;
[els.camera,els.photo].forEach(inp=>inp.addEventListener('change',e=>{const f=e.target.files?.[0];if(f)loadFile(f)}));
function setStatus(s){els.status.textContent=s}
function redrawSource(){if(sourceImage)ctx.drawImage(sourceImage,0,0,canvas.width,canvas.height)}
function reset(){sourceImage=null;roi=null;currentResult=null;ctx.clearRect(0,0,canvas.width,canvas.height);els.stage.classList.add('empty');els.roi.classList.add('hidden');els.roi.classList.remove('manual');els.result.classList.add('hidden');$('placeholder').classList.remove('hidden');['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=true);els.camera.value='';els.photo.value='';setStatus('Ready')}
async function loadFile(file){setStatus('Loading image…');const url=URL.createObjectURL(file),img=new Image();img.onload=()=>{URL.revokeObjectURL(url);sourceImage=img;const maxW=1800,scale=Math.min(1,maxW/img.naturalWidth);canvas.width=Math.round(img.naturalWidth*scale);canvas.height=Math.round(img.naturalHeight*scale);redrawSource();els.stage.classList.remove('empty');$('placeholder').classList.add('hidden');roi=detectGraph();renderROI();['autoDetectBtn','manualBtn','analyzeBtn'].forEach(id=>$(id).disabled=false);setStatus('Image loaded. Auto ROI detected.');analyze();};img.onerror=()=>setStatus('Could not read image.');img.src=url}
const lum=(d,i)=>(d[i]+d[i+1]+d[i+2])/3;
function isGreen(r,g,b){return g>42&&g>r*1.24&&g>b*1.12&&(g-Math.min(r,b))>18}
function rectStats(src,W,H,x0,y0,x1,y1,step=2){
  let n=0,dark=0,green=0,warm=0,color=0;
  for(let y=y0;y<y1;y+=step)for(let x=x0;x<x1;x+=step){const i=(y*W+x)*4,r=src[i],g=src[i+1],b=src[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b);n++;if((r+g+b)/3<92)dark++;if(isGreen(r,g,b))green++;const hsv=rgbToHsv(r,g,b);if(hsv.s>.32&&hsv.v>.38)color++;if(hsv.s>.38&&hsv.v>.42&&(hsv.h<58||hsv.h>345))warm++}
  return{dark:dark/Math.max(1,n),green:green/Math.max(1,n),color:color/Math.max(1,n),warm:warm/Math.max(1,n)}
}
function detectGraph(){
  // Multi-cue detector: compact dark chart + green grid + warm foreground signal.
  // This intentionally prefers Energy per Band over the much larger Raw Data/Spectrum charts.
  const W=canvas.width,H=canvas.height,src=ctx.getImageData(0,0,W,H).data;
  const ds=Math.max(2,Math.ceil(Math.max(W,H)/620)),cands=[];
  const minW=Math.max(120,Math.floor(W*.18)),maxW=Math.floor(W*.56);
  const minH=Math.max(70,Math.floor(H*.055)),maxH=Math.floor(H*.30);
  for(let h=minH;h<=maxH;h=Math.round(h*1.28)+1){
    for(const asp of [1.45,1.7,1.95,2.2,2.5,2.85,3.15]){
      const w=Math.round(h*asp);if(w<minW||w>maxW)continue;
      const sx=Math.max(ds*4,Math.round(w*.18)),sy=Math.max(ds*4,Math.round(h*.22));
      for(let y=0;y+h<=H*.76;y+=sy)for(let x=Math.floor(W*.12);x+w<=W;x+=sx){
        const st=rectStats(src,W,H,x,y,x+w,y+h,ds);
        if(st.dark<.34||st.green<.006||st.color<.010)continue;
        const sizeFrac=(w*h)/(W*H),compact=Math.exp(-Math.pow((sizeFrac-.055)/.07,2));
        const upper=1-EGSCore.clamp(y/(H*.72),0,1),right=.72+.55*(x/W);
        const cue=2.0*st.dark+8.5*st.green+2.5*st.warm+1.0*st.color;
        // Warm trace is a strong cue for the visible Energy per Band foreground line.
        const score=cue*(.72+1.25*compact)*(.82+.45*upper)*right;
        cands.push({x,y,w,h,score,st});
      }
    }
  }
  if(cands.length){
    cands.sort((a,b)=>b.score-a.score);let best=cands[0];
    // Local refinement around the best scanning window using green line geometry.
    let bx=best.x,by=best.y,bw=best.w,bh=best.h;
    const padX=Math.round(bw*.10),padY=Math.round(bh*.13);
    bx=Math.max(0,bx-padX);by=Math.max(0,by-padY);bw=Math.min(W-bx,bw+padX*2);bh=Math.min(H-by,bh+padY*2);
    return{x:bx,y:by,w:bw,h:bh};
  }
  return{x:Math.floor(W*.55),y:Math.floor(H*.12),w:Math.floor(W*.40),h:Math.floor(H*.20)}
}
function renderROI(){if(!roi)return;const r=canvas.getBoundingClientRect(),sx=r.width/canvas.width,sy=r.height/canvas.height;Object.assign(els.roi.style,{left:`${roi.x*sx}px`,top:`${roi.y*sy}px`,width:`${roi.w*sx}px`,height:`${roi.h*sy}px`});els.roi.classList.remove('hidden')}
window.addEventListener('resize',renderROI);
let drag=null;
els.roi.addEventListener('pointerdown',e=>{if(!roiManual)return;e.preventDefault();els.roi.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,orig:{...roi},handle:e.target?.dataset?.handle||'move'}});
els.roi.addEventListener('pointermove',e=>{if(!drag||!roiManual)return;const r=canvas.getBoundingClientRect(),dx=(e.clientX-drag.x)*canvas.width/r.width,dy=(e.clientY-drag.y)*canvas.height/r.height,o=drag.orig,minW=Math.max(70,canvas.width*.10),minH=Math.max(45,canvas.height*.05);if(drag.handle==='move'){roi.x=EGSCore.clamp(o.x+dx,0,canvas.width-o.w);roi.y=EGSCore.clamp(o.y+dy,0,canvas.height-o.h);roi.w=o.w;roi.h=o.h}else{let left=o.x,top=o.y,right=o.x+o.w,bottom=o.y+o.h;if(drag.handle.includes('l'))left=EGSCore.clamp(o.x+dx,0,right-minW);if(drag.handle.includes('r'))right=EGSCore.clamp(o.x+o.w+dx,left+minW,canvas.width);if(drag.handle.includes('t'))top=EGSCore.clamp(o.y+dy,0,bottom-minH);if(drag.handle.includes('b'))bottom=EGSCore.clamp(o.y+o.h+dy,top+minH,canvas.height);roi={x:left,y:top,w:right-left,h:bottom-top}}renderROI()});
els.roi.addEventListener('pointerup',()=>drag=null);els.roi.addEventListener('pointercancel',()=>drag=null);
function lineGroups(values,threshold){const idx=[];for(let i=0;i<values.length;i++)if(values[i]>=threshold)idx.push(i);const groups=[];for(const v of idx){if(!groups.length||v-groups.at(-1).at(-1)>2)groups.push([v]);else groups.at(-1).push(v)}return groups.map(g=>g.reduce((a,b)=>a+b,0)/g.length)}
function bestEvenRun(groups,minGap,maxGap){
  if(groups.length<2)return null;let best=null;
  for(let i=0;i<groups.length-1;i++)for(let j=i+1;j<groups.length;j++){
    const gap=groups[j]-groups[i];if(gap<minGap||gap>maxGap)continue;const seq=[groups[i],groups[j]];let last=groups[j];
    for(let k=j+1;k<groups.length;k++){const d=groups[k]-last;if(Math.abs(d-gap)<=Math.max(2,gap*.28)){seq.push(groups[k]);last=groups[k]}}
    if(seq.length<2)continue;const span=seq.at(-1)-seq[0],score=seq.length*3+span/Math.max(1,gap);
    if(!best||score>best.score)best={seq,gap,score}
  }return best
}
function plotInsets(box){
  const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h),col=new Uint32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2])){row[y]++;col[x]++}}
  // Long-line thresholds suppress green title/axis-label text.
  const rows=lineGroups(row,Math.max(7,w*.30)),cols=lineGroups(col,Math.max(7,h*.30));
  const rr=bestEvenRun(rows,Math.max(5,h*.055),h*.38),cc=bestEvenRun(cols,Math.max(6,w*.055),w*.30);
  let ty,by,lx,rx;
  if(rr&&rr.seq.length>=3){ty=rr.seq[0];by=rr.seq.at(-1)}else if(rows.length>=2){ty=rows[0];by=rows.at(-1)}
  if(cc&&cc.seq.length>=3){lx=cc.seq[0];rx=cc.seq.at(-1)}else if(cols.length>=2){lx=cols[0];rx=cols.at(-1)}
  if([ty,by,lx,rx].every(Number.isFinite)&&rx-lx>w*.38&&by-ty>h*.25){
    return{left:EGSCore.clamp(lx/w,.01,.38),right:EGSCore.clamp(1-rx/w,.002,.26),top:EGSCore.clamp(ty/h,.002,.35),bottom:EGSCore.clamp(1-by/h,.01,.48),source:'major-grid',rows,cols};
  }
  // Dark-plot fallback: locate the densest contiguous dark rectangle inside the ROI.
  const rscore=new Float32Array(h),cscore=new Float32Array(w);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,d=(im[i]+im[i+1]+im[i+2])/3;if(d<105){rscore[y]++;cscore[x]++}}
  const rids=[];for(let y=0;y<h;y++)if(rscore[y]>w*.48)rids.push(y);const cids=[];for(let x=0;x<w;x++)if(cscore[x]>h*.40)cids.push(x);
  if(rids.length&&cids.length){ty=Math.min(...rids);by=Math.max(...rids);lx=Math.min(...cids);rx=Math.max(...cids);if(rx-lx>w*.38&&by-ty>h*.24)return{left:lx/w,right:1-rx/w,top:ty/h,bottom:1-by/h,source:'dark-plot'}}
  return{left:.14,top:.12,right:.035,bottom:.20,source:'fallback'}
}
function checkedChannels(box){
  // Search the checkbox row relative to the graph rather than a fixed 320px offset.
  const d=ctx.getImageData(0,0,canvas.width,canvas.height).data,left=Math.max(0,box.x-box.w*1.22),right=Math.max(left+8,box.x-box.w*.06),top=Math.max(0,box.y+box.h*.52),bottom=Math.min(canvas.height,box.y+box.h*1.35),rw=right-left,rh=bottom-top;if(rw<40||rh<15)return[];
  const out=[],slot=rw/8;for(let ch=0;ch<8;ch++){const sx=Math.floor(left+slot*ch+slot*.16),ex=Math.floor(left+slot*(ch+1)-slot*.16);let best=0;for(let yy=Math.floor(top);yy<bottom;yy+=Math.max(1,Math.floor(rh/18))){let dark=0,total=0;for(let y=yy;y<Math.min(bottom,yy+Math.max(4,rh*.16));y++)for(let x=sx;x<ex;x++){const i=(y*canvas.width+x)*4;if(d[i]<82&&d[i+1]<82&&d[i+2]<82)dark++;total++}best=Math.max(best,dark/Math.max(1,total))}if(best>.16)out.push(ch)}return out
}
function greenRowGroups(box){const x0=Math.max(0,Math.floor(box.x)),y0=Math.max(0,Math.floor(box.y)),w=Math.max(1,Math.min(canvas.width-x0,Math.floor(box.w))),h=Math.max(1,Math.min(canvas.height-y0,Math.floor(box.h))),im=ctx.getImageData(x0,y0,w,h).data,row=new Uint32Array(h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(isGreen(im[i],im[i+1],im[i+2]))row[y]++}const centers=lineGroups(row,Math.max(8,w*.20));return{groups:centers.map(v=>[v]),centers,w,h}}
function normalizedModeFeatures(track){
  const lv=EGSCore.horizontalLevels(track.xs,track.vals,1,track.width),low=lv.low,high=lv.high,delta=high-low,absDelta=Math.abs(delta);
  // Gain pattern: low baseline near the lower axis and a clear positive step after Sample#270.
  const gainLow=EGSCore.clamp((.20-low)/.20,0,1),gainHigh=EGSCore.clamp(1-Math.abs(high-.40)/.30,0,1),gainStep=EGSCore.clamp((delta-.10)/.30,0,1);
  const gainScore=.46*gainLow+.32*gainHigh+.22*gainStep;
  // Noise is generally low-amplitude and comparatively flat in normalized coordinates.
  const mean=(low+high)/2,noiseLowBand=EGSCore.clamp((.42-mean)/.42,0,1),noiseFlat=EGSCore.clamp((.18-absDelta)/.18,0,1),noiseNoStep=EGSCore.clamp((.12-delta)/.22,0,1);
  const noiseScore=.42*noiseLowBand+.38*noiseFlat+.20*noiseNoStep;
  return{low,high,delta,gainScore,noiseScore,levelConfidence:lv.confidence}
}
function inferModeFromTrace(track,requested){
  if(requested!=='Auto')return{mode:requested,note:'',confidence:1,features:null};
  const f=normalizedModeFeatures(track),margin=Math.abs(f.gainScore-f.noiseScore),best=Math.max(f.gainScore,f.noiseScore);
  if(best<.50||margin<.08)return{mode:'Unknown',note:`Auto mode uncertain (Gain ${Math.round(f.gainScore*100)}% / Noise ${Math.round(f.noiseScore*100)}%). Select Gain or Noise manually.`,confidence:Math.max(.18,margin),features:f};
  const mode=f.gainScore>f.noiseScore?'Gain':'Noise';return{mode,note:`Auto mode: ${mode} from foreground signal shape (${Math.round(best*100)}%)`,confidence:EGSCore.clamp(.58+.42*margin,0,1),features:f}
}
function modeTop(mode){return mode==='Noise'?.04:mode==='Gain'?3.0:1}
function scaleTrack(track,top){return{...track,vals:track.vals.map(v=>v*top)}}
function rgbToHsv(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=((h*60)%360+360)%360}return{h,s:mx?d/mx:0,v:mx}}
function hueDistance(a,b){const d=Math.abs(a-b)%360;return Math.min(d,360-d)}
function colorSamples(box,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,s=[];for(let y=0;y<h;y+=2)for(let x=0;x<w;x+=2){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],hsv=rgbToHsv(r,gg,b);if(isGreen(r,gg,b))continue;if(hsv.v>.34&&hsv.s>.22)s.push({h:hsv.h,s:hsv.s,v:hsv.v,r,g:gg,b})}return s}
function clusterTraceColors(box,insets){const pts=colorSamples(box,insets);if(!pts.length)return[];const bins=Array.from({length:24},()=>({n:0,s:0,v:0,rs:0,gs:0,bs:0}));for(const p of pts){const k=Math.floor(((p.h+7.5)%360)/15)%24,b=bins[k];b.n++;b.s+=p.s;b.v+=p.v;b.rs+=p.r;b.gs+=p.g;b.bs+=p.b}let peaks=bins.map((b,k)=>({k,...b})).filter(b=>b.n>=Math.max(8,pts.length*.008)&&b.s/b.n>.27&&b.v/b.n>.38).sort((a,b)=>b.n-a.n);const out=[];for(const p of peaks){const h=(p.k*15+7.5)%360;if(out.some(o=>hueDistance(o.h,h)<24))continue;out.push({h,n:p.n,s:p.s/p.n,v:p.v/p.n,r:p.rs/p.n,g:p.gs/p.n,b:p.bs/p.n});if(out.length>=8)break}return out}
function foregroundTraceForHue(box,top,mode,hue,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[],ysOut=[];let prev=null,miss=0,totalVisible=0,jumps=0;for(let x=0;x<w;x++){const ys=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2];if(isGreen(r,gg,b))continue;const q=rgbToHsv(r,gg,b);if(q.v>.34&&q.s>.23&&hueDistance(q.h,hue)<=22)ys.push({y,score:q.s*q.v*(1-hueDistance(q.h,hue)/30)});else if(prev!=null&&q.v>.72&&q.s<.22&&Math.abs(y-prev)<Math.max(3,h*.035))ys.push({y,score:.18})}if(!ys.length){miss++;continue}let chosen;if(prev==null||miss>9){ys.sort((a,b)=>b.score-a.score);const bestScore=ys[0].score;const cand=ys.filter(z=>z.score>=bestScore*.75).map(z=>z.y).sort((a,b)=>a-b);chosen=EGSCore.median(cand)}else{let best=null,bestCost=1e9;for(const z of ys){const dist=Math.abs(z.y-prev),cost=dist-Math.min(7,z.score*8);if(cost<bestCost){bestCost=cost;best=z}}chosen=best.y;if(Math.abs(chosen-prev)>h*.12)jumps++}prev=chosen;miss=0;totalVisible++;xs.push(x);ysOut.push(chosen);vals.push((1-chosen/Math.max(1,h-1))*top)}const coverage=totalVisible/Math.max(1,w),continuity=1-EGSCore.clamp(jumps/Math.max(1,totalVisible),0,1),sp=EGSCore.splitPixel(w),ln=xs.filter(x=>x<sp).length,rn=xs.filter(x=>x>=sp).length,leftCoverage=ln/Math.max(1,sp),rightCoverage=rn/Math.max(1,w-sp),balance=Math.sqrt(EGSCore.clamp(leftCoverage,0,1)*EGSCore.clamp(rightCoverage,0,1)),leftVals=vals.filter((_,i)=>xs[i]<sp),rightVals=vals.filter((_,i)=>xs[i]>=sp),lm=EGSCore.median(leftVals),rm=EGSCore.median(rightVals),shape=mode==='Gain'?(EGSCore.clamp((.45-(lm/top))/.45,0,1)*.55+EGSCore.clamp((rm/top)/.18,0,1)*.45):.65;return{hue,xs,vals,ys:ysOut,width:w,coverage,leftCoverage,rightCoverage,continuity,shape,score:.42*coverage+.22*continuity+.22*balance+.14*shape}}
function chooseForegroundTrace(box,top,mode,insets){const colors=clusterTraceColors(box,insets),tracks=[];for(const c of colors){const t=foregroundTraceForHue(box,1,'Auto',c.h,insets);if(t.vals.length<Math.max(22,t.width*.07))continue;let mf;try{mf=normalizedModeFeatures(t)}catch(_){mf={gainScore:.2,noiseScore:.2}}const plausible=mode==='Gain'?mf.gainScore:mode==='Noise'?mf.noiseScore:Math.max(mf.gainScore,mf.noiseScore);const dominance=EGSCore.clamp(c.n/Math.max(12,t.width*.35),0,1);t.score=.34*t.coverage+.23*t.continuity+.18*Math.sqrt(EGSCore.clamp(t.leftCoverage,0,1)*EGSCore.clamp(t.rightCoverage,0,1))+.15*dominance+.10*plausible;tracks.push({...t,color:c,modeFeatures:mf,dominance})}if(!tracks.length)throw Error('Foreground signal trace could not be isolated');tracks.sort((a,b)=>b.score-a.score);const best=tracks[0];best.alternates=tracks.slice(1,4).map(t=>({hue:Math.round(t.hue),coverage:t.coverage,score:t.score}));return best}
function genericTrace(box,top,mode,insets){const g=EGSCore.geometry(box,insets),x0=Math.max(0,Math.floor(g.x0)),y0=Math.max(0,Math.floor(g.y0)),x1=Math.min(canvas.width-1,Math.floor(g.x1)),y1=Math.min(canvas.height-1,Math.floor(g.y1)),w=x1-x0+1,h=y1-y0+1,img=ctx.getImageData(x0,y0,w,h).data,xs=[],vals=[];let prev=null,miss=0;for(let x=0;x<w;x++){const yy=[];for(let y=0;y<h;y++){const i=(y*w+x)*4,r=img[i],gg=img[i+1],b=img[i+2],mx=Math.max(r,gg,b),mn=Math.min(r,gg,b),sat=mx-mn,white=(r+gg+b)>385&&mx>138&&sat<72,colored=mx>108&&sat>42;if(!isGreen(r,gg,b)&&(white||colored))yy.push(y)}if(!yy.length){miss++;continue}let py;if(prev==null||miss>6)py=EGSCore.median(yy);else{let best=yy[0],bd=Math.abs(best-prev);for(const y of yy){const d=Math.abs(y-prev);if(d<bd){best=y;bd=d}}py=bd<h*.18?best:EGSCore.median(yy)}prev=py;miss=0;xs.push(x);vals.push((1-py/Math.max(1,h-1))*top)}if(vals.length<Math.max(25,w*.08))throw Error('Not enough signal pixels were found');return{xs,vals,width:w,coverage:vals.length/Math.max(1,w),continuity:.5,score:.5,hue:null}}
function channelDecision(channels,track){if(channels.length===1)return{channel:channels[0],source:'single checkbox',confidence:1};if(channels.length>1){return{channel:null,source:'foreground trace among checked channels',confidence:track.score,candidates:[...channels]}}return{channel:null,source:'foreground trace color',confidence:track.score,candidates:[]}}
function overlay(result){
  redrawSource();const b=result.box,g=EGSCore.geometry(b,result.insets),split=EGSCore.splitX(b,result.insets);ctx.lineWidth=Math.max(2,canvas.width/500);ctx.strokeStyle='#ff3c4b';ctx.strokeRect(b.x,b.y,b.w,b.h);
  ctx.strokeStyle='#ffd23f';ctx.setLineDash([8,7]);ctx.beginPath();ctx.moveTo(split,g.y0);ctx.lineTo(split,g.y1);ctx.stroke();ctx.setLineDash([]);
  // Show the actually tracked foreground trace, so the user can verify which line was measured.
  if(result.trace&&result.trace.ys&&result.trace.ys.length){const tw=Math.max(1,g.x1-g.x0),th=Math.max(1,g.y1-g.y0);ctx.fillStyle='rgba(255,255,255,.78)';const step=Math.max(1,Math.floor(result.trace.xs.length/90));for(let i=0;i<result.trace.xs.length;i+=step){const x=g.x0+(result.trace.xs[i]/Math.max(1,result.trace.width-1))*tw,y=g.y0+(result.trace.ys[i]/Math.max(1,th-1))*th;ctx.fillRect(x-1,y-1,2,2)}}
  const ly=EGSCore.valueY(b,result.low,result.top,result.insets),hy=EGSCore.valueY(b,result.high,result.top,result.insets);
  ctx.strokeStyle='#00bff3';ctx.beginPath();ctx.moveTo(g.x0,ly);ctx.lineTo(split,ly);ctx.stroke();ctx.strokeStyle='#ff7f27';ctx.beginPath();ctx.moveTo(split,hy);ctx.lineTo(g.x1,hy);ctx.stroke();
}
function analyze(){if(!sourceImage||!roi)return;try{
  redrawSource();const insets=plotInsets(roi),channels=checkedChannels(roi);
  let normTrack,fgUsed=false;try{normTrack=chooseForegroundTrace(roi,1,els.mode.value==='Auto'?'Auto':els.mode.value,insets);fgUsed=true}catch(_){normTrack=genericTrace(roi,1,'Auto',insets)}
  let mi=inferModeFromTrace(normTrack,els.mode.value);
  if(mi.mode==='Unknown'){
    const msg=[];if(mi.note)msg.push(mi.note);if(insets.source==='fallback')msg.push('Plot geometry fallback used');
    currentResult={mode:'Unknown',channels,channel:null,channelSource:'unresolved',low:NaN,high:NaN,confidence:mi.confidence,box:{...roi},top:1,insets,diagnostics:{mode_features:mi.features,foreground_hue:normTrack.hue,foreground_coverage:normTrack.coverage,foreground_continuity:normTrack.continuity},message:msg.join('; ')};redrawSource();renderROI();showResult(currentResult);setStatus('Auto mode is uncertain. Select Gain or Noise manually.');return
  }
  // Once mode is known, re-rank color traces with that mode's expected shape. This prevents a broad background color from beating the actual foreground trace.
  if(fgUsed){try{normTrack=chooseForegroundTrace(roi,1,mi.mode,insets)}catch(_){}}
  const top=modeTop(mi.mode),tr=scaleTrack(normTrack,top),decision=channelDecision(channels,tr),lv=EGSCore.horizontalLevels(tr.xs,tr.vals,top,tr.width),digits=mi.mode==='Noise'?4:2,msg=[];
  if(mi.note)msg.push(mi.note);msg.push(`Plot geometry: ${insets.source}`);if(channels.length===1)msg.push(`Single checked channel CH${channels[0]} prioritized`);else if(channels.length>1){msg.push(`Checked candidates: ${channels.map(c=>'CH'+c).join(', ')}`);msg.push(fgUsed?'Foreground trace only used for calculation':'Foreground isolation fallback used')}else msg.push(fgUsed?'No checkbox resolved; foreground trace used':'Channel unknown; signal analysis continued');if(fgUsed&&Number.isFinite(tr.hue))msg.push(`Foreground hue ${Math.round(tr.hue)}°, visibility ${Math.round(tr.coverage*100)}%`);
  const modeConfidence=els.mode.value==='Auto'?mi.confidence:1,confidence=EGSCore.clamp(lv.confidence*(fgUsed?(.72+.28*tr.score):.72)*(.72+.28*modeConfidence),0,1);
  currentResult={mode:mi.mode,channels,channel:decision.channel,channelSource:decision.source,low:+lv.low.toFixed(digits),high:+lv.high.toFixed(digits),confidence,box:{...roi},top,insets,trace:{xs:[...tr.xs],ys:[...tr.ys||[]],width:tr.width},diagnostics:{...lv.diagnostics,mode_features:mi.features,foreground_hue:tr.hue,foreground_coverage:tr.coverage,foreground_continuity:tr.continuity},message:msg.join('; ')};
  overlay(currentResult);showResult(currentResult);setStatus('Analysis complete.');
}catch(e){redrawSource();renderROI();setStatus(e.message||String(e));}}
function showResult(r){els.result.classList.remove('hidden');$('modeOut').textContent=r.mode;$('channelOut').textContent=r.channel!=null?`CH${r.channel}`:(r.channels.length?r.channels.map(c=>'CH'+c).join(' / '):'Unknown');$('confidenceOut').textContent=`${Math.round(r.confidence*100)}%`;if(r.mode==='Unknown'||!Number.isFinite(r.low)||!Number.isFinite(r.high)){$('lowOut').textContent='—';$('highOut').textContent='—';const sp=$('specOut');sp.textContent='—';sp.className='';$('messageOut').textContent=r.message||'Select Gain or Noise manually.';return}$('lowOut').textContent=r.mode==='Noise'?r.low.toFixed(4):r.low.toFixed(2);$('highOut').textContent=r.mode==='Noise'?r.high.toFixed(4):r.high.toFixed(2);const ok=EGSCore.spec(r.mode,r.low,r.high),sp=$('specOut');sp.textContent=ok?'IN':'OUT';sp.className=ok?'spec-in':'spec-out';$('messageOut').textContent=r.message||'—'}
if('serviceWorker' in navigator){
  window.addEventListener('load',async()=>{
    try{
      const reg=await navigator.serviceWorker.register('./sw.js',{scope:'./'});
      await navigator.serviceWorker.ready;
      // Ask the browser to check for an updated offline bundle whenever the app opens online.
      if(navigator.onLine)reg.update().catch(()=>{});
    }catch(e){console.warn('Offline service worker unavailable',e)}
  });
}
window.addEventListener('online',()=>setStatus(sourceImage?'Online — analysis ready':'Online — app ready'));
window.addEventListener('offline',()=>setStatus(sourceImage?'Offline — local analysis ready':'Offline — app ready'));
