# Energy Graph Scan iPhone v1.6.6

## v1.6.6 Foreground trace isolation
- 複数Channelが重なって表示される場合、色クラスタごとにトレースを分離し、横方向の可視率と連続性から前面トレースを選択します。
- Low/High計算は前面トレース1本だけを使用し、背面トレースを平均・混合しません。
- Channel checkboxが1個だけ検出された場合はそのChannelを最優先します。
- 複数checkboxの場合は候補集合を保持し、foreground traceを解析対象とします。色→CH番号マッピングが十分に確定できない場合は無理にCH番号を断定しません。
- 完全重複区間では前後の同色トレース連続性を優先し、別色トレースへの乗り換えを抑制します。

# Energy Graph Scan iPhone v1.5.0

Mac/XcodeなしでiPhoneから使用できるSafari/PWA版です。

## 機能
- iPhoneカメラから直接撮影
- 写真ライブラリから画像選択
- 撮影時のEnergy per Bandガイド枠
- Energy per BandのAuto ROI
- ROIの手動位置調整
- Auto / Gain / Noise切替
- Low = Sample#0–270、High = Sample#270以降
- Channel未検出でもUnknownとして解析継続
- 複数Channel候補でも解析継続
- Gainは小数2桁、Noiseは小数4桁
- Gain High 1.00–1.50、Noise Low 0–0.015 / High 0.001–0.02のSpec判定
- 数値と同じ座標モデルでSample#270線・Low/High検出ラインを描画
- PWAキャッシュ対応。ホーム画面追加後はアプリ風に起動可能

## iPhoneでの使い方
1. GitHub Pages等のHTTPSサイトへこのフォルダを公開します。
2. iPhone SafariでURLを開きます。
3. 「共有」→「ホーム画面に追加」でアプリとして登録できます。
4. 「写真を撮る」でカメラを起動し、Channel欄とEnergy per Bandが入るよう撮影します。
5. 撮影後、自動ROIと解析が実行されます。
6. ROIがずれている場合は「ROI調整」を押し、赤枠をドラッグします。
7. 「Analyze」で再解析します。

## GitHub Pages
`.github/workflows/deploy-pages.yml`を同梱しています。GitHubのSettings → PagesでSourceをGitHub Actionsに設定後、workflowを実行してください。

## Windows v1.4.0との共通仕様 / iPhone v1.5.0 algorithm update
解析ロジックはWindows v1.4.0と同じ考え方で整理しています。ただしブラウザCanvas実装のためpixel extractionは別実装です。今後、実画像でWindows/iPhone双方の期待値を比較しながら閾値を揃える前提です。


## v1.5.0 解析アルゴリズム改善
- UI/撮影フローはv1.4.0から変更せず、解析エンジンを重点的に更新。
- Auto ROIを固定位置・固定サイズ中心の探索から、ダウンサンプル画像の黒背景連結領域検出へ変更。
- Energy per Band内の緑グリッドを検出できる場合、plotのleft/right/top/bottomを画像ごとに推定。
- Sample#270の分割線、Low/High表示線、数値換算が同じplot geometryを使用。
- 信号pixel抽出は各列独立のquantileだけでなく、前列の信号位置との連続性を使ってtraceを追跡。
- Low/High値はMAD外れ値除去に加え、10–90 percentileで極端値を抑制。
- ConfidenceはLow/Highのsample coverageと信号分離度の両方から算出。
- Channel検出はgraphからの固定320px位置依存を廃止し、graph相対領域から8候補を探索。
- Channel不明/複数候補の場合でも解析継続。
- Auto Gain/Noise判定はファイル名ではなくhorizontal green grid group数を利用。

### 重要
本版は解析アルゴリズムの構造改善版です。実際の失敗写真群を使ってROI、Channel、Low/High期待値を回帰検証すると、さらに精度を詰められます。


## iPhoneでオフラインアプリとして使う（v1.6.6）

1. GitHub PagesなどHTTPSの公開URLをSafariで一度オンラインで開きます。
2. 画面が完全に表示されたら、Safariの共有ボタンから「ホーム画面に追加」を選びます。
3. ホーム画面の **Energy Scan** アイコンから一度起動します。これでアプリ本体がiPhone内へキャッシュされます。
4. 以後は機内モードなど通信が無い状態でも、ホーム画面から起動して「写真を撮る」「写真を選ぶ」「解析」を利用できます。解析は端末内JavaScriptのみで実行され、画像をサーバーへ送信しません。

### 更新方法
新しいSOURCE ZIPをGitHubへアップロードしてPagesが更新された後、iPhoneをオンラインにしてEnergy Scanを一度起動してください。Service Workerが新しいアプリファイルを取得します。その後は再びオフライン利用できます。

### 注意
初回インストール/初回キャッシュだけはオンライン接続が必要です。Safariの通常タブより、ホーム画面に追加したアイコンからの起動を推奨します。iOSがWebサイトデータを削除した場合は、再度オンラインで開いてキャッシュし直す必要があります。


## v1.6.6 analysis fixes
- Auto mode does not use grid count. It uses the isolated foreground trace baseline/step/value-shape features.
- Auto ROI: prioritizes the compact green Energy per Band grid instead of generic black chart regions.
- Manual ROI: four corner handles resize the ROI; dragging inside moves it.
- Plot geometry: derives top/bottom/left/right from long green grid lines rather than green text pixels.
- Foreground trace scoring now requires coverage on both sides of Sample#270 and follows overexposed white centers near the same trace.
- Existing offline PWA behavior is preserved.


## v1.6.6 Auto mode
- Gain/Noise の判定にグリッド本数を使用しません。
- 前面トレースを0–1正規化してから Low/High の相対位置、段差、ベースライン形状で判定します。
- 判定が曖昧な場合は誤判定を避けるため Unknown とし、Gain/Noise の手動選択を求めます。
- Noise の縦軸換算はグリッド本数に依存せず 0.04 を基準にします。


## v1.6.6 fixes
- Auto ROI now uses multi-cue compact-chart scoring (dark plot + green grid + warm foreground signal) to avoid Raw Data/Spectrum.
- Plot geometry selects long, near-even major grid lines and ignores green text labels.
- Foreground color tracks are re-ranked after Gain/Noise is known; only the selected foreground trace is used.
- Auto mode uses the foreground step/baseline pattern; grid count is not used.
- Overlay now marks the actually tracked foreground trace and draws Low/High lines from the same geometry/value model.


## v1.6.6 変更点
- 撮影ボタンはアプリ内カメラを優先し、撮影中だけ3x3グリッドを表示。通常の解析画面には撮影グリッドを表示しません。
- Auto ROIの右上位置ボーナスを削除。Energy per Bandの見た目（黒背景、緑グリッド、色トレース、コンパクト形状）だけで全画面を探索します。
- Gain/Noise判定にグリッド本数は使用しません。
- Mode確定後、主要横グリッド間隔からY軸を校正し、同じ校正を数値計算とLow/High表示ラインに使用します。
- foreground trace / Channel優先ルール / オフラインPWAは維持。


## v1.6.6 camera fix
- 撮影経路をアプリ内カメラへ一本化。撮影中のみ3x3グリッド表示。
- 撮影画像はfile inputへ戻さず直接Imageとして読み込み、撮影後に選択が消えるiOS問題を回避。
- PWAのCSS/JSをnetwork-first + version queryにし、旧版キャッシュ混在を防止。
- カメラ許可/起動失敗時はモーダル内で状態を表示し再試行可能。
